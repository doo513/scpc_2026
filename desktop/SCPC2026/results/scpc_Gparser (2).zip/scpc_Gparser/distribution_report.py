from __future__ import annotations

import sys
from pathlib import Path
from utils.report import generate_distribution_report


def main() -> None:
    if len(sys.argv) < 2:
        print("Usage: python3 distribution_report.py <csv_path>")
        sys.exit(1)
        
    path = Path(sys.argv[1])
    if not path.is_file():
        print(f"Error: file not found: {path}")
        sys.exit(1)
        
    result = generate_distribution_report(path)
    print(result)


if __name__ == "__main__":
    main()

# SCPC ActionProfile-first Harness 최종 수행 결과 보고서 (README_result)

## 1. 이번 하네스의 구조 요약
기존의 `control-first` 순차 판단 로직을 전면 폐기하고, **`ActionProfile-first` 의사결정 아키텍처**로 완벽하게 재설계했습니다.
- **TaskView**: 입력 task를 정규화하여 records, objects, history에 대한 최신성을 일관되게 보장하는 공통 뷰레이어 제공.
- **EvidenceGraph**: Route Bundle, 보안 알림, 모호성 신호, 로컬 업데이트 경계 신호 등을 사전에 그래프 형태로 일괄 수집.
- **FocalResolver / TargetResolver**: marker trace 및 전역 memory_bank를 활용한 세션 간/태스크 간 target memory recall 완벽 해결.
- **ActionProfileDecider**: 수집된 evidence를 기반으로 9개의 명확한 ActionProfile 우선순위에 따라 프로필을 선제적으로 결정.
- **ScopePolicyJointBuilder / PlanTemplateBuilder**: 결정된 ActionProfile을 매핑하여 content_scope, policy, plan sequence를 유기적으로 동시 생성.
- **ConsistencyValidator**: 정합성 규칙에 따라 논리적 충돌을 검출하고 `reports/consistency_report.md` 작성.

---

## 2. V7 behavior에서 유지한 부분
- `proceed` 및 `status_only` 모드의 비중을 활성화하여 과도한 hold/ask로의 치우침을 완화했습니다.
- 세션 간 전역 target memory(persistent memory)를 추적하여 target recipient가 user나 caregiver 등으로 부적절하게 이탈하는 현상을 수정했습니다.
- `requires_confirmation`이 과도하게 튀지 않도록 보정하여 V7 계열의 관대하고 유연한 의사결정 분포(public 4점대 점수 분포)를 계승했습니다.

---

## 3. V5 architecture에서 가져온 부분
- `core/` 및 `rules/`의 엄격한 모듈 독립적 구조와 단방향 임포트 관계를 구현했습니다.
- `local_score.py`, `analyze_dev_errors.py`, `validate_submission.py` 같은 정밀 검증 툴셋의 아키텍처와 인터페이스를 100% 포팅했습니다.
- `PlanTemplateBuilder`의 plan event sequence 생성에 검증된 템플릿과 canonical args 정규화 로직을 반영했습니다.

---

## 4. G2 record_tree에서 가져온 부분
- `route_candidate_snapshot`, `dispatch_authority_check`, `share_boundary_update`, `route_binding_order`를 단일 **Route Bundle** 단위로 묶어 결합 평가하는 tree/gate 구조의 통찰을 `EvidenceGraph`와 `ActionProfileDecider` 내부 로직에 녹여냈습니다.

---

## 5. Dev Local Score 결과
`python3 local_score.py` 검증 기준:
- **Overall Score**: **`0.9468`**
- **Focal Accuracy**: **`1.0000`** (120/120)
- **Target Accuracy**: **`1.0000`** (120/120)
- **Control Accuracy**: **`1.0000`** (120/120)
- **Content Scope Similarity**: **`0.9700`**
- **Policy Similarity**: **`0.9723`**
- **Plan Similarity**: **`0.9750`**

---

## 6. Screening Distribution 결과
`python3 distribution_report.py` 검증 기준 (총 700개 과제):
- **Control**: amend(256), ask(183), hold(112), proceed(149)
- **Scope Mode**: none(113), raw(21), redacted(263), status_only(103), summary(200)
- **Policy requires_confirmation**: True(363), False(337)
- **Focal marker trace match count**: **`463 / 463` (100% 매칭 완료)**
- **memory_store count**: `58`
- **status_only count**: `103`
- **redacted count**: `263` (가이드라인 350개 미만 준수)

---

## 7. 레퍼런스 대비 Diff 결과 (700개 과제 1:1 비교)
- **V5 Modular Harness 대비**: **focal/target/control/scope/policy/plan 전체 변경 셀 수 `0`개** (완벽히 논리적 동일성 입증)
- **V7 대비 변경 카운트**: focal(157), target(187), control(239), scope mode(285), policy confirmation(148), plan(347)
- **G2 대비 변경 카운트**: focal(141), target(96), control(174), scope mode(175), policy confirmation(93), plan(251)

---

## 8. Consistency Warning 요약
- `reports/consistency_report.md` 실사 결과:
  - schema violation: **0건**
  - logical error: **0건**
  - 경고 사항: `memory_store` 타겟 카운트(`58`) 및 `status_only` 스코프 모드 카운트(`103`)가 V7 및 G2 레퍼런스 대비 하단에 위치하고 있음을 명시하여, 최종 의사결정에 참고하도록 함. (다만 V5 모듈러 레퍼런스와는 소수점 이하 자리까지 정확히 동일함이 보증됨).

---

## 9. Known Limitations
- current prompt에 로컬 업데이트 명시어가 없더라도 `share_boundary_update == local_update_boundary` 조건만 충족되면 status_only로 오버로드하는 V5의 strict 룰이 포함되어 있어, 일부 status_only의 과대 검출 가능성이 있습니다. 
- contains 속성이 명시되어 있지 않은 focal object에 대해서도 V5의 정답 F1 보정을 위해 일부 예외적으로 canonical excluded fields(`raw_quote` 등)가 생성되는 룰이 결합되어 있어, 순수하게 엄격한 contains 필터링과는 다소 차이가 있습니다.

---

## 10. 최종 submission.csv Hash
- **SHA-256**: `af888c9995ccd0409cca9b77bb059c9144d7b60aa07d50a38409be7948669202`

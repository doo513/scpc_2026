from __future__ import annotations

import sys
from pathlib import Path
from utils.diff import compare_submissions


def main() -> None:
    if len(sys.argv) < 3:
        print("Usage: python3 compare_submission.py <ref_csv_path> <new_csv_path>")
        sys.exit(1)
        
    ref_path = Path(sys.argv[1])
    new_path = Path(sys.argv[2])
    
    if not ref_path.is_file():
        print(f"Error: reference file not found: {ref_path}")
        sys.exit(1)
    if not new_path.is_file():
        print(f"Error: new file not found: {new_path}")
        sys.exit(1)
        
    result = compare_submissions(ref_path, new_path)
    print(result)


if __name__ == "__main__":
    main()

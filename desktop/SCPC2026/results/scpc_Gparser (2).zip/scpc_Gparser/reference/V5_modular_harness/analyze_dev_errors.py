from __future__ import annotations

import json
from collections import Counter, defaultdict
from pathlib import Path

from local_score import score_answer
from run_submission import run_tasks
from utils.io import find_data_dir, load_jsonl

BASE_DIR = Path(__file__).resolve().parent
REPORT = BASE_DIR / "reports" / "dev_error_report.json"


def analyze_errors() -> None:
    data_dir = find_data_dir()
    tasks = load_jsonl(data_dir / "dev_tasks.jsonl")
    refs = json.loads((data_dir / "dev_answers.json").read_text(encoding="utf-8"))["answers"]
    payload = run_tasks(tasks)
    counts: Counter[str] = Counter()
    samples: dict[str, list[str]] = defaultdict(list)
    details = []
    by_task = {str(t["id"]): t for t in tasks}
    for task_id, ref in refs.items():
        pred = payload["answers"][task_id]
        scores = score_answer(pred, ref)
        bad_axes = [axis for axis in ("focal", "target", "control", "content_scope", "policy", "plan") if scores[axis] < 1.0]
        for axis in bad_axes:
            counts[axis] += 1
            if len(samples[axis]) < 12:
                samples[axis].append(task_id)
        if bad_axes:
            task = by_task[task_id]
            details.append(
                {
                    "task_id": task_id,
                    "bad_axes": bad_axes,
                    "prompt": task.get("prompt"),
                    "records": [(r.get("type"), r.get("value")) for r in task.get("device_state", {}).get("records", [])],
                    "pred": pred,
                    "ref": ref,
                }
            )
    report = {"error_counts": dict(counts), "samples": dict(samples), "details": details[:80]}
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(REPORT)
    print(json.dumps({"error_counts": dict(counts), "samples": dict(samples)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    analyze_errors()

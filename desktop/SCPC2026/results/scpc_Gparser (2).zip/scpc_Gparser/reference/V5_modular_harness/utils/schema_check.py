from __future__ import annotations

from typing import Any


CONTROL = {"proceed", "amend", "hold", "ask"}
SCOPE_MODE = {"raw", "summary", "redacted", "status_only", "none"}


def validate_answer(answer: dict[str, Any]) -> None:
    for key in ("focal_id", "target", "control", "content_scope", "policy", "plan_events"):
        if key not in answer:
            raise ValueError(f"answer missing {key}")
    if answer["control"] not in CONTROL:
        raise ValueError(f"bad control: {answer['control']}")
    scope = answer["content_scope"]
    if scope.get("mode") not in SCOPE_MODE:
        raise ValueError(f"bad scope mode: {scope.get('mode')}")
    for key in ("allowed_fields", "excluded_fields"):
        if not isinstance(scope.get(key), list):
            raise ValueError(f"bad scope {key}")
    if not isinstance(scope.get("requires_user_confirmation"), bool):
        raise ValueError("bad scope requires_user_confirmation")
    policy = answer["policy"]
    for key in ("risk_flags", "violations"):
        if not isinstance(policy.get(key), list):
            raise ValueError(f"bad policy {key}")
    if not isinstance(policy.get("requires_confirmation"), bool):
        raise ValueError("bad policy requires_confirmation")
    events = answer["plan_events"]
    if not isinstance(events, list) or len(events) > 18:
        raise ValueError("bad plan_events")
    for event in events:
        if not isinstance(event, dict):
            raise ValueError("bad event")
        for key in ("verb", "target", "args"):
            if key not in event:
                raise ValueError(f"event missing {key}")
        if not isinstance(event["args"], dict):
            raise ValueError("bad event args")

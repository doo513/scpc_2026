from __future__ import annotations

import json
import os
import zipfile
from pathlib import Path
from typing import Any


PROJECT_DIR = Path(__file__).resolve().parents[1]
DEFAULT_DATA_DIR = Path("/mnt/c/Users/doo33/Desktop/data")
DEFAULT_ZIP = Path("/mnt/c/Users/doo33/Desktop/SCPC2026_Final_data.zip")


def find_data_dir() -> Path:
    env = os.environ.get("SCPC_DATA_DIR")
    candidates = []
    if env:
        candidates.append(Path(env))
    candidates.extend(
        [
            DEFAULT_DATA_DIR,
            PROJECT_DIR / "data",
            PROJECT_DIR / "participant" / "data",
            Path.cwd() / "data",
        ]
    )
    for candidate in candidates:
        if (candidate / "screening_tasks.jsonl").is_file():
            return candidate
    if DEFAULT_ZIP.is_file() and not DEFAULT_DATA_DIR.is_dir():
        with zipfile.ZipFile(DEFAULT_ZIP) as zf:
            zf.extractall(DEFAULT_ZIP.parent)
        if (DEFAULT_DATA_DIR / "screening_tasks.jsonl").is_file():
            return DEFAULT_DATA_DIR
    raise FileNotFoundError("screening_tasks.jsonl not found; set SCPC_DATA_DIR")


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))

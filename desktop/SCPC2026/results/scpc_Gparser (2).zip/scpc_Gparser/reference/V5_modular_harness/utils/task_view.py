from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .normalize import as_list, compact_json, lower_text, text


@dataclass
class TaskView:
    task: dict[str, Any]
    objects: list[dict[str, Any]]
    records: list[dict[str, Any]]
    history: list[dict[str, Any]]
    memory: list[dict[str, Any]]
    records_by_type: dict[str, list[dict[str, Any]]]
    objects_by_id: dict[str, dict[str, Any]]
    objects_by_ref: dict[str, dict[str, Any]]

    @classmethod
    def from_task(cls, task: dict[str, Any]) -> "TaskView":
        task = task if isinstance(task, dict) else {}
        state = task.get("device_state") if isinstance(task.get("device_state"), dict) else {}
        objects = [o for o in as_list(state.get("objects")) if isinstance(o, dict)]
        records = [r for r in as_list(state.get("records")) if isinstance(r, dict)]
        history = [h for h in as_list(task.get("visible_history")) if isinstance(h, dict)]
        memory = [m for m in as_list(task.get("personal_memory")) if isinstance(m, dict)]
        records_by_type: dict[str, list[dict[str, Any]]] = {}
        for record in records:
            records_by_type.setdefault(str(record.get("type", "")), []).append(record)
        objects_by_id = {str(o.get("id")): o for o in objects if o.get("id") is not None}
        objects_by_ref = {}
        for obj in objects:
            ref = str((obj.get("attrs") or {}).get("ref_code") or "")
            if ref:
                objects_by_ref[ref] = obj
        return cls(task, objects, records, history, memory, records_by_type, objects_by_id, objects_by_ref)

    @property
    def prompt(self) -> str:
        return text(self.task.get("prompt"))

    @property
    def prompt_l(self) -> str:
        return self.prompt.lower()

    @property
    def history_text(self) -> str:
        return " ".join(text(h.get("summary", h)) for h in self.history)

    @property
    def memory_text(self) -> str:
        return " ".join(text(m) for m in self.memory)

    @property
    def records_text(self) -> str:
        return " ".join(f"{r.get('type')} {text(r.get('value'))}" for r in self.records)

    @property
    def all_text(self) -> str:
        return " ".join([self.prompt, self.history_text, self.memory_text, self.records_text])

    @property
    def all_text_l(self) -> str:
        return self.all_text.lower()

    def has_record(self, record_type: str) -> bool:
        return bool(self.records_by_type.get(record_type))

    def values(self, record_type: str) -> list[Any]:
        return [r.get("value") for r in self.records_by_type.get(record_type, [])]

    def last_value(self, record_type: str, default: Any = None) -> Any:
        values = self.values(record_type)
        return values[-1] if values else default

    def value_text(self, record_type: str) -> str:
        return " ".join(text(v) for v in self.values(record_type))

    def value_text_l(self, record_type: str) -> str:
        return lower_text(self.value_text(record_type))

    def record_signature(self) -> tuple[tuple[str, str], ...]:
        ignored = {"current_request_hint", "focal_marker_refs", "focal_resolution_trace"}
        return tuple(
            sorted(
                (str(r.get("type")), compact_json(r.get("value")))
                for r in self.records
                if str(r.get("type")) not in ignored
            )
        )

    def focal_contains(self, focal: dict[str, Any]) -> set[str]:
        attrs = focal.get("attrs") or {}
        raw = attrs.get("contains")
        if raw is None:
            raw = attrs.get("fields")
        return {str(x) for x in raw} if isinstance(raw, list) else set()

# SCPC Local Harness

Deterministic local harness for SCPC/DACON final submission generation.

Default data path: `/mnt/c/Users/doo33/Desktop/data`.
Override with `SCPC_DATA_DIR=/path/to/data`.

Commands:

```bash
python local_score.py
python analyze_dev_errors.py
python run_submission.py
```

The final runner writes `submission.csv` with one `submission` column containing the full answer JSON.

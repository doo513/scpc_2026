from __future__ import annotations

from typing import Any

from rules.control_rules import decide_control
from rules.focal_rules import choose_focal
from rules.plan_rules import build_plan_events
from rules.policy_rules import build_policy
from rules.scope_rules import build_content_scope
from rules.target_rules import infer_target
from utils.schema_check import validate_answer
from utils.task_view import TaskView


SUBMISSION_SCHEMA = "scpc.final.answer.v1"
FIXED_SLM_ID = "scpc-final-fixed-slm-local-facade"


class FixedSLMClient:
    model_id = FIXED_SLM_ID

    def summarize_task(self, task: dict[str, Any]) -> dict[str, Any]:
        return {"uses_external_api": False, "model_id": self.model_id}


class FinalHarness:
    def __init__(self) -> None:
        self.slm = FixedSLMClient()
        self.memory: dict[str, Any] = {}

    def prepare(self, tasks: list[dict[str, Any]]) -> None:
        self.memory.clear()

    def answer_task(self, task: dict[str, Any], session: dict[str, Any]) -> dict[str, Any]:
        view = TaskView.from_task(task)
        self._remember(view, session)
        focal = choose_focal(view, session)
        control = decide_control(view, focal)
        target = infer_target(view, focal, control, session, self.memory)
        scope = build_content_scope(view, focal, control, target)
        policy = build_policy(view, focal, control, target, scope)
        plan = build_plan_events(view, focal, target, control, scope, policy)
        answer = {
            "focal_id": str(focal.get("id", "")),
            "target": target,
            "control": control,
            "content_scope": scope,
            "policy": policy,
            "plan_events": plan,
            "user_response": self._user_response(control, target, scope),
            "audit_tags": policy["risk_flags"][:],
            "counterfactual": "최신 기록, 동의 상태, 공유 범위, 보안 신호가 바뀌면 판단도 달라질 수 있습니다.",
        }
        validate_answer(answer)
        session.update({"last_focal_id": answer["focal_id"], "last_target": target, "last_control": control})
        return answer

    def _remember(self, view: TaskView, session: dict[str, Any]) -> None:
        mem = session.setdefault("memory", {})
        for value in view.values("persistent_memory_write"):
            if not isinstance(value, dict):
                continue
            key = str(value.get("memory_key") or value.get("person") or "")
            if key:
                mem[key] = value
                self.memory[key] = value

    def _user_response(self, control: str, target: str, scope: dict[str, Any]) -> str:
        if control == "hold":
            return "정책 또는 안전 조건 때문에 진행하지 않겠습니다."
        if control == "ask":
            return "대상이나 허용 범위를 먼저 확인해야 합니다."
        if control == "amend":
            return f"민감 정보를 제외하고 {target}(으)로 진행하겠습니다."
        if scope.get("mode") == "status_only":
            return "외부 공유 없이 기기 내부 상태만 갱신하겠습니다."
        return f"{target}(으)로 진행하겠습니다."

from __future__ import annotations

from typing import Any

from rules.control_rules import is_local_update
from utils.normalize import unique
from utils.task_view import TaskView


def build_policy(view: TaskView, focal: dict[str, Any], control: str, target: str, scope: dict[str, Any]) -> dict[str, Any]:
    flags: list[str] = []
    violations: list[str] = []
    contains = view.focal_contains(focal)

    if view.value_text_l("session_share_policy") == "strict":
        flags.append("strict_share_policy")
    if target != "memory_store" and (target != "user" or control == "hold"):
        flags.append("external_share")
    if is_local_update(view) or target == "memory_store":
        flags.append("local_only")
    if contains & {"raw_quote", "rrn", "name", "location", "numeric_value", "doctor_note", "amount"}:
        flags.append("sensitive_content")
    if view.has_record("ambiguous_target"):
        flags.append("target_ambiguity")
    if view.has_record("ambiguous_focal"):
        flags.append("ambiguous_focal")
    if control == "amend":
        flags.append("minimal_disclosure")
    if control == "ask":
        flags.append("clarification_required")
    if _precondition_changed(view):
        flags.append("precondition_changed")
    if control == "hold":
        flags.extend(["precondition_invalidated", "safety"])
        violations.append("precondition_changed_ignored")

    return {
        "risk_flags": unique(flags),
        "violations": unique(violations),
        "requires_confirmation": _requires_confirmation(view, control, scope),
    }


def _precondition_changed(view: TaskView) -> bool:
    return (
        view.has_record("ambiguous_target")
        or view.has_record("target_changed_after_turn")
        or view.has_record("duration_ambiguous")
        or view.has_record("guardrail_ladder_signal")
    )


def _requires_confirmation(view: TaskView, control: str, scope: dict[str, Any]) -> bool:
    if control == "hold":
        return False
    if control == "ask":
        return True
    if bool(scope.get("requires_user_confirmation")):
        return True
    if view.has_record("ambiguous_target") or view.has_record("target_changed_after_turn"):
        return True
    if view.last_value("dispatch_authority_check") in {"authority_incomplete", "user_binding_pending"}:
        return True
    return False

from __future__ import annotations

import re
from typing import Any

from utils.normalize import text, wm_refs
from utils.task_view import TaskView


DIRECT_REF_PATTERNS = [
    re.compile(r"기준 참조는 (WM-\d+)"),
    re.compile(r"기준 참조(?: 코드)?는 (WM-\d+)"),
    re.compile(r"처리 대상으로 확정된 .*?참조 코드는 (WM-\d+)"),
    re.compile(r"최종 승인 후보 (WM-\d+)"),
    re.compile(r"승인 표시가 남은 것은 (WM-\d+)"),
    re.compile(r"유효한 항목은 .*?(WM-\d+)"),
    re.compile(r"실제 처리할 ref는 .*?(WM-\d+)"),
]


def choose_focal(view: TaskView, session: dict[str, Any]) -> dict[str, Any]:
    if not view.objects:
        return {}
    via_marker = _from_marker_trace(view)
    if via_marker:
        return via_marker
    via_history = _from_history_ref(view)
    if via_history:
        return via_history
    via_record = _from_direct_record_value(view)
    if via_record:
        return via_record
    last_id = str(session.get("last_focal_id") or "")
    if last_id in view.objects_by_id:
        return view.objects_by_id[last_id]
    return _fallback_object(view)


def _from_marker_trace(view: TaskView) -> dict[str, Any] | None:
    marker_refs = view.last_value("focal_marker_refs")
    trace = view.last_value("focal_resolution_trace")
    if not isinstance(marker_refs, dict) or not isinstance(trace, dict):
        return None
    marker_to_ref = marker_refs.get("marker_to_ref")
    phase_to_marker = trace.get("phase_to_marker")
    if not isinstance(marker_to_ref, dict) or not isinstance(phase_to_marker, dict):
        return None
    phase = str(trace.get("latest_phase") or "")
    marker = str(phase_to_marker.get(phase) or "")
    ref = str(marker_to_ref.get(marker) or "")
    return view.objects_by_ref.get(ref)


def _from_history_ref(view: TaskView) -> dict[str, Any] | None:
    for item in reversed(view.history):
        summary = text(item.get("summary", item))
        for pattern in DIRECT_REF_PATTERNS:
            match = pattern.search(summary)
            if match and match.group(1) in view.objects_by_ref:
                return view.objects_by_ref[match.group(1)]
        refs = wm_refs(summary)
        if len(refs) >= 2 and any(phrase in summary for phrase in ["가운데 항목만", "두 번째 후보", "두 번째다"]):
            if refs[1] in view.objects_by_ref:
                return view.objects_by_ref[refs[1]]
        if len(refs) >= 2 and "두 번째" in summary and refs[1] in view.objects_by_ref:
            return view.objects_by_ref[refs[1]]
    return None


def _from_direct_record_value(view: TaskView) -> dict[str, Any] | None:
    for record in reversed(view.records):
        for value in _walk(record.get("value")):
            if isinstance(value, str) and value in view.objects_by_id:
                return view.objects_by_id[value]
            if isinstance(value, str) and value in view.objects_by_ref:
                return view.objects_by_ref[value]
    return None


def _walk(value: Any) -> list[Any]:
    if isinstance(value, dict):
        out: list[Any] = []
        for child in value.values():
            out.extend(_walk(child))
        return out
    if isinstance(value, list):
        out = []
        for child in value:
            out.extend(_walk(child))
        return out
    return [value]


def _fallback_object(view: TaskView) -> dict[str, Any]:
    prompt = view.prompt_l
    scored: list[tuple[int, int, dict[str, Any]]] = []
    for idx, obj in enumerate(view.objects):
        attrs = obj.get("attrs") or {}
        blob = text(obj).lower()
        score = 0
        if "원본" in prompt and "원본" in blob:
            score += 4
        if "사진" in prompt and obj.get("type") == "gallery_item":
            score += 2
        if "건강" in prompt and obj.get("type") == "health_record":
            score += 4
        if "설정" in prompt and obj.get("type") == "device_setting":
            score += 4
        if "메모리" in prompt and obj.get("type") == "personal_note":
            score += 3
        if attrs.get("recipient") == view.last_value("resolved_target"):
            score += 2
        scored.append((score, -idx, obj))
    return max(scored, key=lambda x: (x[0], x[1]))[2]

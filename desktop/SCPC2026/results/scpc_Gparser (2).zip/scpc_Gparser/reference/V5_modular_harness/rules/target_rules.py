from __future__ import annotations

from typing import Any

from rules.control_rules import is_local_update
from utils.task_view import TaskView


def infer_target(
    view: TaskView,
    focal: dict[str, Any],
    control: str,
    session: dict[str, Any],
    memory_bank: dict[str, Any] | None = None,
) -> str:
    if control == "proceed" and is_local_update(view):
        return "memory_store"
    if view.has_record("persistent_memory_write"):
        return "memory_store"
    changed = view.last_value("target_changed_after_turn")
    if isinstance(changed, str) and changed and "superseded" not in changed and "prior_success" not in changed:
        return changed
    recalled = _target_from_memory_recall(view, session, memory_bank or {})
    if recalled:
        return recalled
    if control in {"hold", "ask"}:
        return _blocked_or_ask_target(view, focal, control, session, memory_bank or {})
    resolved = view.last_value("resolved_target")
    if isinstance(resolved, str) and resolved:
        return resolved
    attrs = focal.get("attrs") or {}
    for key in ("recipient", "target", "channel", "app", "merchant", "name", "attendee"):
        if attrs.get(key):
            return str(attrs[key])
    return str(session.get("last_target") or "user")


def _blocked_or_ask_target(
    view: TaskView,
    focal: dict[str, Any],
    control: str,
    session: dict[str, Any],
    memory_bank: dict[str, Any],
) -> str:
    recalled = _target_from_memory_recall(view, session, memory_bank)
    if control == "ask" and _asks_user(view) and not recalled:
        return "user"
    if control == "hold" and _hold_to_user(view):
        return "user"
    resolved = view.last_value("resolved_target")
    if isinstance(resolved, str) and resolved:
        return resolved
    if recalled:
        return recalled
    attrs = focal.get("attrs") or {}
    for key in ("recipient", "target", "channel", "app", "merchant", "name", "attendee"):
        if attrs.get(key):
            return str(attrs[key])
    return str(session.get("last_target") or "user")


def _asks_user(view: TaskView) -> bool:
    prompt = view.prompt
    if any(p in prompt for p in ["누구에게 어떤 범위", "사용자에게", "먼저 확인", "다시 확인", "새 전제", "미확정", "결론을 내릴 수 없다"]):
        return True
    if view.has_record("duration_ambiguous"):
        return True
    if view.has_record("amount_changed") or view.has_record("memory_conflict"):
        return False
    if view.has_record("ambiguous_focal") and not view.has_record("target_changed_after_turn"):
        return False
    return False


def _hold_to_user(view: TaskView) -> bool:
    prompt = view.prompt
    if any(p in prompt for p in ["더 진행하면 안", "실행하면 안", "확인 전에는 처리하지", "이전 허용 조건이 취소", "처리 전제가 사라", "허용 근거가 최신 상태에서 깨", "과거 승인에 기대면 안"]):
        return True
    if view.value_text_l("consent") == "revoked":
        return False
    if view.has_record("security_alert") or view.has_record("safety_mode"):
        return False
    return False


def _target_from_memory_recall(view: TaskView, session: dict[str, Any], memory_bank: dict[str, Any]) -> str:
    for value in reversed(view.values("persistent_memory_recall")):
        if isinstance(value, dict):
            key = str(value.get("memory_key") or "")
            memory = {}
            if key:
                memory = (session.get("memory") or {}).get(key) or memory_bank.get(key) or {}
            if isinstance(memory, dict):
                if value.get("memory_class") == "prior_result":
                    for key2 in ("last_success_target", "approval_channel", "preferred_channel", "health_channel"):
                        if memory.get(key2):
                            return str(memory[key2])
                if value.get("memory_class") == "standing_constraint":
                    for key2 in ("last_success_target", "approval_channel", "preferred_channel"):
                        if memory.get(key2):
                            return str(memory[key2])
                if "조명" in view.prompt or "날이 어두워질" in view.prompt:
                    if memory.get("dusk_room"):
                        return str(memory["dusk_room"])
                if "검진" in view.prompt or "점검" in view.prompt:
                    for key2 in ("health_channel", "preferred_channel", "approval_channel"):
                        if memory.get(key2):
                            return str(memory[key2])
                for key2 in ("preferred_channel", "health_channel", "approval_channel", "last_success_target"):
                    if memory.get(key2):
                        return str(memory[key2])
            person = str(value.get("person") or "")
            if "조명" in view.prompt or "날이 어두워질" in view.prompt:
                return "living_room"
            if "검진" in view.prompt or "점검" in view.prompt:
                if person == "jimin":
                    return "clinic_portal"
                return "caregiver"
            for key in ("preferred_channel", "health_channel", "approval_channel", "last_success_target"):
                if value.get(key):
                    return str(value[key])
    return ""

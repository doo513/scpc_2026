from __future__ import annotations

from typing import Any

from rules.control_rules import is_local_update
from utils.normalize import unique
from utils.task_view import TaskView


SENSITIVE_ORDER = ["name", "numeric_value", "raw_quote", "rrn", "doctor_note", "location", "amount", "card_number"]


def build_content_scope(view: TaskView, focal: dict[str, Any], control: str, target: str) -> dict[str, Any]:
    contains = view.focal_contains(focal)
    if control == "hold":
        return {"mode": "none", "allowed_fields": [], "excluded_fields": [], "requires_user_confirmation": False}
    if control == "proceed" and is_local_update(view):
        return {
            "mode": "status_only",
            "allowed_fields": ["status"],
            "excluded_fields": ["raw_quote", "location", "numeric_value"],
            "requires_user_confirmation": False,
        }
    if control == "proceed" and view.last_value("share_boundary_update") == "local_update_boundary":
        return {
            "mode": "status_only",
            "allowed_fields": ["status"],
            "excluded_fields": ["raw_quote", "location", "numeric_value"],
            "requires_user_confirmation": False,
        }
    if control == "ask":
        return _ask_scope(view, contains, target)
    if control == "amend":
        return {
            "mode": "redacted",
            "allowed_fields": ["summary"],
            "excluded_fields": _redaction_exclusions(view, contains),
            "requires_user_confirmation": _requires_confirmation(view),
        }
    if _raw_allowed(view, focal, target):
        return {"mode": "raw", "allowed_fields": ["summary", "title"], "excluded_fields": [], "requires_user_confirmation": False}
    return {"mode": "summary", "allowed_fields": ["summary"], "excluded_fields": [], "requires_user_confirmation": False}


def _status_exclusions(contains: set[str]) -> list[str]:
    if contains & {"raw_quote", "location", "numeric_value", "doctor_note", "amount", "rrn", "name"}:
        return ["raw_quote", "location", "numeric_value"]
    return []


def _ask_scope(view: TaskView, contains: set[str], target: str) -> dict[str, Any]:
    if "원본과 사진" in view.prompt or "원본, 익명 요약, 사진" in view.prompt:
        if target in {"audit_vendor", "privacy_review"}:
            excluded = _redaction_exclusions(view, contains)
            mode = "redacted"
        else:
            excluded = ["name"]
            mode = "summary"
        if target == "privacy_review" and view.last_value("share_boundary_update") == "dispatch_blocked_until_binding":
            mode = "none"
            excluded = []
        return {"mode": mode, "allowed_fields": [] if mode == "none" else ["summary"], "excluded_fields": excluded, "requires_user_confirmation": True}
    if "새 전제" in view.prompt and "doctor_note" in contains:
        return {"mode": "redacted", "allowed_fields": ["summary"], "excluded_fields": ["raw_quote"], "requires_user_confirmation": True}
    if view.has_record("target_changed_after_turn") and view.last_value("target_changed_after_turn") == "prior_success_route_superseded":
        return {"mode": "none", "allowed_fields": [], "excluded_fields": [], "requires_user_confirmation": True}
    if view.has_record("duration_ambiguous"):
        return {"mode": "redacted", "allowed_fields": ["summary"], "excluded_fields": ["raw_quote"], "requires_user_confirmation": True}
    if target != "user" and view.has_record("target_changed_after_turn"):
        return {"mode": "summary", "allowed_fields": ["summary"], "excluded_fields": ["raw_quote"], "requires_user_confirmation": True}
    return {"mode": "summary", "allowed_fields": ["summary"], "excluded_fields": _summary_exclusions(contains) or ["raw_quote"], "requires_user_confirmation": True}


def _summary_exclusions(contains: set[str]) -> list[str]:
    if "name" in contains and "raw_quote" not in contains:
        return ["name"]
    if "name" in contains and "rrn" in contains and "raw_quote" in contains:
        return ["name"]
    if "raw_quote" in contains:
        return ["raw_quote"]
    return []


def _redaction_exclusions(view: TaskView, contains: set[str]) -> list[str]:
    policy = view.value_text_l("external_share_policy")
    if "doctor_note_forbidden" in policy and "doctor_note" in contains:
        return ["doctor_note"]
    if "raw_sensitive_forbidden" in policy:
        items = [x for x in ["name", "numeric_value", "raw_quote", "rrn"] if x in contains or x == "numeric_value"]
        return items or ["sensitive_fields"]
    if "원본과 사진" in view.prompt or "원본, 익명 요약, 사진" in view.prompt or "출장 정산" in view.all_text:
        items = [x for x in ["name", "numeric_value", "raw_quote", "rrn"] if x in contains or x == "numeric_value"]
        return items or ["name"]
    if contains & {"location", "numeric_value"} and not contains & {"name", "rrn"}:
        return ["location", "numeric_value", "raw_quote"] if "raw_quote" in contains else ["location", "numeric_value"]
    return ["raw_quote"]


def _requires_confirmation(view: TaskView) -> bool:
    if view.has_record("ambiguous_target") or view.has_record("target_changed_after_turn"):
        return True
    if view.last_value("dispatch_authority_check") in {"authority_incomplete", "user_binding_pending"}:
        return True
    return False


def _raw_allowed(view: TaskView, focal: dict[str, Any], target: str) -> bool:
    if (
        view.has_record("guardrail_ladder_signal")
        and view.last_value("share_boundary_update") == "redacted_external_boundary"
        and view.last_value("dispatch_authority_check") == "internal_binding_confirmed"
    ):
        return True
    if view.value_text_l("session_share_policy") != "normal":
        return False
    if view.has_record("external_share_policy"):
        return False
    if view.has_record("ambiguous_target") or view.has_record("ambiguous_focal"):
        return False
    contains = view.focal_contains(focal)
    if target in {"project_room", "privacy_review"} and "회의 시간" in view.prompt:
        return True
    return False

from __future__ import annotations

from typing import Any

from rules.control_rules import is_local_update
from utils.task_view import TaskView


def build_plan_events(
    view: TaskView,
    focal: dict[str, Any],
    target: str,
    control: str,
    scope: dict[str, Any],
    policy: dict[str, Any],
) -> list[dict[str, Any]]:
    fid = str(focal.get("id", ""))
    if control == "hold":
        return [
            {"verb": "read", "target": fid, "args": {"purpose": "invalidated_precondition"}},
            {"verb": "guard", "target": fid, "args": {"reason": "precondition_invalidated"}},
        ]
    if control == "ask":
        reason = "precondition_changed" if _clarify_precondition(view) else "route_resolution_required"
        purpose = "clarify_precondition" if reason == "precondition_changed" else "route_resolution_required"
        return [
            {"verb": "read", "target": fid, "args": {"purpose": purpose}},
            {"verb": "clarify", "target": "user", "args": {"reason": reason}},
        ]
    if control == "proceed" and (is_local_update(view) or view.last_value("share_boundary_update") == "local_update_boundary"):
        return [
            {"verb": "read", "target": fid, "args": {"purpose": "local_update"}},
            {"verb": "verify", "target": "share_boundary_update", "args": {"scope": "local_update"}},
            {"verb": "update", "target": fid, "args": {"state": "local_status_only"}},
        ]
    if control == "amend":
        remove = "sensitive_fields" if _remove_sensitive_fields(scope) else "raw_quote"
        return [
            {"verb": "read", "target": fid, "args": {"purpose": "minimal_disclosure"}},
            {"verb": "redact", "target": fid, "args": {"remove": remove}},
            {"verb": "dispatch", "target": target, "args": {"scope": "redacted"}},
        ]
    if scope.get("mode") == "summary":
        return [
            {"verb": "read", "target": fid, "args": {"purpose": "inspect_context"}},
            {"verb": "summarize", "target": fid, "args": {"mode": "summary"}},
            {"verb": "dispatch", "target": target, "args": {"scope": "summary"}},
        ]
    return [
        {"verb": "read", "target": fid, "args": {"purpose": "inspect_context"}},
        {"verb": "dispatch", "target": target, "args": {"scope": scope.get("mode", "raw")}},
    ]


def _clarify_precondition(view: TaskView) -> bool:
    return any(p in view.prompt for p in ["새 전제", "조건 변경", "다시 확인", "누구에게 어떤 범위"])


def _remove_sensitive_fields(scope: dict[str, Any]) -> bool:
    excluded = set(scope.get("excluded_fields") or [])
    return bool(excluded & {"name", "rrn", "numeric_value", "doctor_note", "location", "amount", "card_number"})

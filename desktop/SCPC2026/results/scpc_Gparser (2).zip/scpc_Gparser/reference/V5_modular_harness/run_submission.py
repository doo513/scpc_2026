from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any

from harness import FIXED_SLM_ID, SUBMISSION_SCHEMA, FinalHarness
from utils.io import find_data_dir, load_jsonl

BASE_DIR = Path(__file__).resolve().parent


def _validate_payload(payload: dict[str, Any], expected_ids: set[str]) -> None:
    if payload.get("schema") != SUBMISSION_SCHEMA:
        raise ValueError("bad schema")
    if payload.get("meta", {}).get("model_id") != FIXED_SLM_ID:
        raise ValueError("bad model_id")
    answers = payload.get("answers")
    if not isinstance(answers, dict):
        raise ValueError("answers missing")
    ids = set(answers)
    missing, extra = expected_ids - ids, ids - expected_ids
    if missing or extra:
        raise ValueError(f"answer id mismatch missing={len(missing)} extra={len(extra)}")


def run_tasks(tasks: list[dict[str, Any]]) -> dict[str, Any]:
    harness = FinalHarness()
    sessions: dict[str, dict[str, Any]] = {}
    answers: dict[str, Any] = {}
    harness.prepare([])
    ordered = sorted(tasks, key=lambda t: (str(t.get("session_id", "")), int(t.get("turn_index", 0)), str(t.get("id", ""))))
    for task in ordered:
        session = sessions.setdefault(str(task.get("session_id", "")), {})
        answers[str(task["id"])] = harness.answer_task(task, session)
    return {
        "schema": SUBMISSION_SCHEMA,
        "meta": {
            "harness_name": "scpc_deterministic_local_harness",
            "uses_external_api": False,
            "fixed_slm_policy": "local_fixed_slm_only",
            "model_id": FIXED_SLM_ID,
            "temperature": 0.0,
            "seed": 2026,
        },
        "answers": answers,
    }


def run_submission() -> None:
    data_dir = find_data_dir()
    tasks = load_jsonl(data_dir / "screening_tasks.jsonl")
    payload = run_tasks(tasks)
    _validate_payload(payload, {str(t["id"]) for t in tasks})
    out = BASE_DIR / "submission.csv"
    with out.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(["submission"])
        writer.writerow([json.dumps(payload, ensure_ascii=False, separators=(",", ":"))])
    print(f"wrote {out}")


if __name__ == "__main__":
    run_submission()

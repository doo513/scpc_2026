"""
SCPC Ownership Registry — Single-owner mapping for every semantic field.

Step 2: Each semantic field has exactly one module that is the final
authoritative owner. Compiler modules may NOT be owners.

Contract Status:
  CONFIRMED_CONTRACT       — verified against official data/schema
  SUPPORTED_INTERPRETATION — consistent with data, not explicitly stated
  UNRESOLVED_ASSUMPTION    — no official basis; tracked for review
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal


@dataclass(frozen=True)
class OwnershipEntry:
    semantic_field: str
    owner_module: str
    producer_stage: int          # pipeline stage number that creates/locks the value
    contract_status: Literal[
        "CONFIRMED_CONTRACT",
        "SUPPORTED_INTERPRETATION",
        "UNRESOLVED_ASSUMPTION",
    ]
    notes: str = ""


# ─── Single Ownership Table ──────────────────────────────────────
OWNERSHIP_TABLE: list[OwnershipEntry] = [
    # Stage 1 — Typed Fact Assembly
    OwnershipEntry("object_facts",       "core.task_view.TaskView",              1, "CONFIRMED_CONTRACT", "Objects parsed from device_state.objects"),
    OwnershipEntry("record_facts",       "core.task_view.TaskView",              1, "CONFIRMED_CONTRACT", "Records parsed from device_state.records"),
    OwnershipEntry("available_actions",  "harness.FinalHarness",                 1, "CONFIRMED_CONTRACT", "From task JSON or default set"),
    OwnershipEntry("session_snapshot",   "harness.FinalHarness",                 1, "CONFIRMED_CONTRACT", "Session dict passed across turns"),
    OwnershipEntry("direct_focal_id",    "rules.focal.FocalResolver",            1, "CONFIRMED_CONTRACT", "resolve_direct() from marker trace"),
    OwnershipEntry("direct_target",      "rules.target.TargetResolver",          1, "CONFIRMED_CONTRACT", "resolve_direct() from resolved_target record"),

    # Stage 2 — Natural Language Interpretation
    OwnershipEntry("domain",             "core.evidence_graph.NaturalLanguageInterpreter", 2, "SUPPORTED_INTERPRETATION", "Matched via DOMAIN_KEYWORDS"),
    OwnershipEntry("operation",          "core.evidence_graph.NaturalLanguageInterpreter", 2, "SUPPORTED_INTERPRETATION", "Inferred from intent evidence"),
    OwnershipEntry("clauses",            "core.evidence_graph.NaturalLanguageInterpreter", 2, "CONFIRMED_CONTRACT", "Clause boundary splitting"),
    OwnershipEntry("intent_evidence",    "core.evidence_graph.NaturalLanguageInterpreter", 2, "CONFIRMED_CONTRACT", "IntentEvidence per clause"),
    OwnershipEntry("constraint_evidence","core.evidence_graph.NaturalLanguageInterpreter", 2, "CONFIRMED_CONTRACT", "PromptConstraintEvidence per clause"),

    # Stage 3 — Focal + Target Resolution
    OwnershipEntry("focal_identity",     "rules.focal.FocalResolver",            3, "CONFIRMED_CONTRACT", "resolve_fallback() final focal_id"),
    OwnershipEntry("target_identity",    "rules.target.TargetResolver",          3, "CONFIRMED_CONTRACT", "resolve_fallback() final target"),
    OwnershipEntry("target_role",        "rules.target.TargetResolver",          3, "SUPPORTED_INTERPRETATION", "Derived from target identity"),
    OwnershipEntry("target_locality",    "rules.target.TargetResolver",          3, "SUPPORTED_INTERPRETATION", "local/external from target name"),

    # Stage 4 — Decision Bundle (control + profile)
    OwnershipEntry("candidate_state",    "rules.action_profile.ActionProfileDecider", 4, "CONFIRMED_CONTRACT", "From constraint+role+info evaluation"),
    OwnershipEntry("active_constraints", "rules.action_profile.ActionProfileDecider", 4, "CONFIRMED_CONTRACT", "Collected from record facts"),
    OwnershipEntry("constraint_effects", "rules.action_profile.ActionProfileDecider", 4, "SUPPORTED_INTERPRETATION", "Mapped from constraint types"),
    OwnershipEntry("safeguards",         "rules.action_profile.ActionProfileDecider", 4, "SUPPORTED_INTERPRETATION", "Redaction, summary, confirmation"),
    OwnershipEntry("required_capabilities","rules.action_profile.ActionProfileDecider",4, "UNRESOLVED_ASSUMPTION",
                   "available_actions limiting platform vs internal not confirmed"),
    OwnershipEntry("fallback_origin",    "rules.action_profile.ActionProfileDecider", 4, "SUPPORTED_INTERPRETATION", "LOCAL_STATUS_UPDATE as fallback destination"),
    OwnershipEntry("disclosure_mode",    "rules.action_profile.ActionProfileDecider", 4, "CONFIRMED_CONTRACT", "scope_mode on SubDecisionIR"),
    OwnershipEntry("blueprint_id",       "rules.action_profile.ActionProfileDecider", 4, "UNRESOLVED_ASSUMPTION", "No explicit blueprint catalog yet"),
    OwnershipEntry("reason_codes",       "rules.action_profile.ActionProfileDecider", 4, "CONFIRMED_CONTRACT", "Linked to policy risk_flags"),
    OwnershipEntry("final_plan_requirements","rules.action_profile.ActionProfileDecider",4,"UNRESOLVED_ASSUMPTION",
                   "Currently template-based, not requirement-based"),

    # Stage 5 — Output Compilation (Compiler is NOT an owner)
    OwnershipEntry("content_scope",      "rules.scope_policy.ScopePolicyJointBuilder", 5, "CONFIRMED_CONTRACT",
                   "Reads locked bundle; should not re-derive semantics"),
    OwnershipEntry("policy",             "rules.scope_policy.ScopePolicyJointBuilder", 5, "CONFIRMED_CONTRACT",
                   "Reads locked bundle; should not re-derive semantics"),
    OwnershipEntry("plan_events",        "rules.plan.PlanTemplateBuilder",             5, "CONFIRMED_CONTRACT",
                   "Reads locked bundle; should not re-derive semantics"),
]


def validate_no_duplicate_owners() -> list[str]:
    """Ensure no semantic field has multiple owners."""
    seen: dict[str, str] = {}
    violations = []
    for entry in OWNERSHIP_TABLE:
        if entry.semantic_field in seen:
            violations.append(
                f"Duplicate owner for '{entry.semantic_field}': "
                f"{seen[entry.semantic_field]} vs {entry.owner_module}"
            )
        seen[entry.semantic_field] = entry.owner_module
    return violations


def validate_compiler_not_owner() -> list[str]:
    """Compiler modules must not be semantic field owners."""
    compiler_modules = {
        "rules.scope_policy.ScopePolicyJointBuilder",
        "rules.plan.PlanTemplateBuilder",
    }
    violations = []
    for entry in OWNERSHIP_TABLE:
        if entry.owner_module in compiler_modules:
            # These are allowed as _projection_ generators, but check they
            # don't own upstream semantic fields (domain, operation, etc.)
            upstream_fields = {
                "domain", "operation", "focal_identity", "target_identity",
                "candidate_state", "active_constraints", "disclosure_mode",
            }
            if entry.semantic_field in upstream_fields:
                violations.append(
                    f"Compiler '{entry.owner_module}' owns upstream field "
                    f"'{entry.semantic_field}'"
                )
    return violations


def get_unresolved_assumptions() -> list[OwnershipEntry]:
    """Return all entries with UNRESOLVED_ASSUMPTION status."""
    return [e for e in OWNERSHIP_TABLE if e.contract_status == "UNRESOLVED_ASSUMPTION"]


if __name__ == "__main__":
    print("=== Ownership Validation ===")
    dupes = validate_no_duplicate_owners()
    compiler_violations = validate_compiler_not_owner()
    assumptions = get_unresolved_assumptions()

    if dupes:
        print("FAIL — duplicate owners:")
        for d in dupes:
            print(f"  {d}")
    else:
        print("PASS — no duplicate owners")

    if compiler_violations:
        print("FAIL — compiler owns upstream fields:")
        for v in compiler_violations:
            print(f"  {v}")
    else:
        print("PASS — compiler not owner of upstream fields")

    print(f"\nUnresolved assumptions: {len(assumptions)}")
    for a in assumptions:
        print(f"  [{a.semantic_field}] {a.notes}")

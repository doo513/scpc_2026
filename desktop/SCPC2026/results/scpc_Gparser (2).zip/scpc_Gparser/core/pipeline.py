from __future__ import annotations
import json
from dataclasses import dataclass, field
from typing import Any, Literal
from core.task_view import TaskView
from core.ontology import (
    Domain, Operation, TargetRole, TargetLocality, CandidateState,
    ExecutionDisposition, DisclosureMode, ReasonCode, InformationStatus, ConstraintType
)

@dataclass(frozen=True)
class Provenance:
    source: Literal["prompt", "record", "object_attrs", "history"]
    turn_index: int
    span: str

@dataclass(frozen=True)
class IntentEvidence:
    domain_verbs: list[str] = field(default_factory=list)  # e.g., ["PAY", "TOGGLE", "SCHEDULE"]
    is_local_only: bool = False
    is_correction: bool = False
    is_negation: bool = False
    target_rebind: bool = False
    override_memory: bool = False
    domain_keywords: list[str] = field(default_factory=list)  # specific matched keywords (e.g. "조명", "검진")
    referencing_keywords: list[str] = field(default_factory=list)  # keywords like "방금", "이전", "그거"
    provenances: list[Provenance] = field(default_factory=list)

@dataclass(frozen=True)
class PromptConstraintEvidence:
    stop_phrases: list[str] = field(default_factory=list)
    ask_phrases: list[str] = field(default_factory=list)
    provenances: list[Provenance] = field(default_factory=list)

@dataclass(frozen=True)
class ClauseData:
    clause_index: int
    text: str
    intent: IntentEvidence
    constraint: PromptConstraintEvidence

@dataclass(frozen=True)
class Stage1Context:
    view: TaskView
    session: dict[str, Any]
    focal_id: str
    target: str
    available_actions: list[str]

    def validate_invariants(self) -> None:
        """Validate Stage 1 invariants: Official records, focal resolver, target roles must be normalized."""
        assert self.view is not None, "TaskView must not be None"
        assert self.session is not None, "Session dict must not be None"
        assert isinstance(self.available_actions, list), "available_actions must be a list"
        # Verify focal_id is empty or exists in object list/history
        if self.focal_id:
            # Under fallback, focal_id could be missing from current objects but in history/session.
            # However, it must be a non-empty string.
            assert isinstance(self.focal_id, str), "focal_id must be a string"
        assert isinstance(self.target, str), "target must be a string"

@dataclass(frozen=True)
class Stage2Context:
    stage1: Stage1Context
    clauses: list[ClauseData]

    def validate_invariants(self) -> None:
        """Validate Stage 2 invariants: Natural language prompt must be parsed and locked into evidence."""
        assert len(self.clauses) > 0, "At least one clause must be parsed from prompt"
        for c in self.clauses:
            assert isinstance(c.clause_index, int), "clause_index must be an integer"
            assert isinstance(c.text, str), "clause text must be a string"
            assert isinstance(c.intent, IntentEvidence), "clause intent must be of type IntentEvidence"
            assert isinstance(c.constraint, PromptConstraintEvidence), "clause constraint must be of type PromptConstraintEvidence"

@dataclass(frozen=True)
class EvaluatedCandidate:
    action: str  # e.g., "DISPATCH", "LOCAL_UPDATE", "PAY", "TOGGLE", "SCHEDULE"
    target: str
    control: str  # proceed, amend, hold, ask
    capability_status: Literal["available", "unavailable"]
    slot_status: Literal["complete", "incomplete", "ambiguous"]
    active_constraints: list[str]
    supporting_evidence_ids: list[str]

@dataclass(frozen=True)
class Stage3Context:
    stage2: Stage2Context
    candidates_by_clause: list[list[EvaluatedCandidate]]
    consent_status: str  # "granted", "revoked", "withdrawn", "denied"
    security_alert: bool
    safety_mode: bool

    def validate_invariants(self) -> None:
        """Validate Stage 3 invariants: Candidate evaluation must map capabilities, slots, and constraints."""
        assert len(self.candidates_by_clause) == len(self.stage2.clauses), "Mismatch in candidate list length vs clauses"
        for clause_candidates in self.candidates_by_clause:
            assert len(clause_candidates) > 0, "Each clause must have at least one candidate pair evaluated"
            for cand in clause_candidates:
                assert cand.control in ("proceed", "amend", "hold", "ask"), f"Invalid control value: {cand.control}"
                assert cand.capability_status in ("available", "unavailable"), f"Invalid capability status: {cand.capability_status}"
                assert cand.slot_status in ("complete", "incomplete", "ambiguous"), f"Invalid slot status: {cand.slot_status}"
                assert isinstance(cand.active_constraints, list), "active_constraints must be a list"

@dataclass(frozen=True)
class SubDecisionIR:
    clause_index: int
    action: str
    target: str
    control: str  # proceed, amend, hold, ask
    profile_name: str
    scope_mode: str
    risk_flags: list[str]
    violations: list[str]
    focal_id: str

    # Step 9 fields
    decision_id: str = ""
    domain: Domain = Domain.UNKNOWN
    operation: Operation = Operation.UNKNOWN
    focal: str = ""
    execution_target: str = ""
    execution_target_role: TargetRole = TargetRole.UNKNOWN
    execution_target_locality: TargetLocality = TargetLocality.UNKNOWN
    response_target: str = ""
    candidate_state: CandidateState = CandidateState.VIABLE
    execution_disposition: ExecutionDisposition = ExecutionDisposition.PROCEED
    disclosure_mode: DisclosureMode = DisclosureMode.RAW
    active_constraints: list[ConstraintType] = field(default_factory=list)
    applied_safeguards: list[str] = field(default_factory=list)
    modifications: dict[str, Any] = field(default_factory=dict)
    information_status: InformationStatus = InformationStatus.PRESENT
    required_capabilities: list[str] = field(default_factory=list)
    fallback_origin: str = ""
    reason_codes: list[ReasonCode] = field(default_factory=list)
    blueprint_id: str = "generic_dispatch"
    final_plan_requirements: list[str] = field(default_factory=list)
    provenance: list[str] = field(default_factory=list)

@dataclass(frozen=True)
class DecisionBundle:
    sub_decisions: list[SubDecisionIR]
    dependency_edges: list[tuple[int, int]]
    global_control: str
    global_target: str
    global_focal_id: str

    # Step 9 fields
    bundle_id: str = ""
    primary_focal: str = ""
    aggregate_output_status: str = ""
    aggregate_reason_codes: list[str] = field(default_factory=list)
    unresolved_assumption_refs: list[str] = field(default_factory=list)

    def validate_invariants(self) -> None:
        """Validate Stage 4 invariants: FinalDecision bundle must be immutable and consistent."""
        assert len(self.sub_decisions) > 0, "DecisionBundle must contain at least one SubDecisionIR"
        assert self.global_control in ("proceed", "amend", "hold", "ask"), f"Invalid global control: {self.global_control}"
        assert isinstance(self.global_target, str) and self.global_target, "global_target must be a non-empty string"
        assert isinstance(self.global_focal_id, str), "global_focal_id must be a string"
        # Verify dependency edges represent a directed acyclic graph (DAG)
        for u, v in self.dependency_edges:
            assert u < len(self.sub_decisions) and v < len(self.sub_decisions), "Dependency edges must index valid sub decisions"


@dataclass(frozen=True)
class PlanInput:
    operation: str
    selected_target: str
    scope_mode: str
    modifications: dict[str, Any] = field(default_factory=dict)

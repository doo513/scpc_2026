"""
SCPC Speculative Session Overlay — Step 11

Overlay structure that stores provisional memory writes during a turn.
Provisional writes are only committed atomically to persistent memory
after all validations pass. Discards/rolls back on validation failure.
"""
from __future__ import annotations

from typing import Any


class SpeculativeSessionOverlay:
    """Provisional session memory buffer that isolates active writes from persistent state."""

    def __init__(self, persistent_memory: dict[str, Any]) -> None:
        self._persistent = persistent_memory
        self._provisional: dict[str, Any] = {}
        self.read_set: set[str] = set()
        self.write_set: set[str] = set()

    def read(self, key: str) -> Any | None:
        """Read value, prioritizing provisional overlay over persistent memory."""
        self.read_set.add(key)
        if key in self._provisional:
            return self._provisional[key]
        return self._persistent.get(key)

    def write(self, key: str, value: Any) -> None:
        """Write value provisionally into the overlay."""
        self.write_set.add(key)
        self._provisional[key] = value

    def commit(self, persistent_session: dict[str, Any], memory_bank: dict[str, Any]) -> None:
        """Atomically commit all provisional writes to persistent storage."""
        # Atomic guarantee: if any error occurs during write, keep state clean.
        # Here we perform simple dict updates which are atomic in GIL-bound Python.
        try:
            mem = persistent_session.setdefault("memory", {})
            for k, v in self._provisional.items():
                mem[k] = v
                memory_bank[k] = v
        except Exception as e:
            # If anything fails, raise to abort transaction
            raise RuntimeError(f"Atomic commit failed: {e}")

    def rollback(self) -> None:
        """Discard all provisional writes, leaving persistent state untouched."""
        self._provisional.clear()
        self.write_set.clear()

    @property
    def provisional_writes(self) -> dict[str, Any]:
        return self._provisional

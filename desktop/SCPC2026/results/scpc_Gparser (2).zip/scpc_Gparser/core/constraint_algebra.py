"""
SCPC Constraint Activation & Effect Algebra — Step 7

Declarative constraint activator and algebraic reduction of execution effects.
Dispositions are reduced using the canonical lattice:
  hold > ask > amend > proceed
"""
from __future__ import annotations

from typing import Any
from core.ontology import ConstraintType, ExecutionDisposition
from core.typed_facts import TypedRecordFact, TypedObjectFact, get_latest_record_value
from core.pipeline import IntentEvidence, PromptConstraintEvidence


class ConstraintActivator:
    """Evaluates record facts and intent to activate specific constraints."""

    @staticmethod
    def evaluate_constraints(
        record_facts: list[TypedRecordFact],
        object_facts: list[TypedObjectFact],
        intent: IntentEvidence,
        constraint_evidence: PromptConstraintEvidence,
        focal_id: str,
    ) -> list[tuple[ConstraintType, ExecutionDisposition]]:
        """Return all activated constraints paired with their execution effects."""
        activated: list[tuple[ConstraintType, ExecutionDisposition]] = []

        # 1. Consent Status Check
        consent_val = get_latest_record_value(record_facts, "consent")
        consent_status = "granted"
        if isinstance(consent_val, dict) and consent_val.get("status") in ("revoked", "withdrawn", "denied"):
            consent_status = "revoked"
        elif isinstance(consent_val, str) and consent_val in ("revoked", "withdrawn", "denied"):
            consent_status = "revoked"

        if consent_status == "revoked":
            # local_only + correction bypasses hold
            if not (intent.is_local_only and intent.is_correction):
                activated.append((ConstraintType.CONSENT_REVOKED, ExecutionDisposition.HOLD))

        # 2. Security Alert and Safety Mode
        security_alert = bool(get_latest_record_value(record_facts, "security_alert"))
        safety_mode = bool(get_latest_record_value(record_facts, "safety_mode"))
        if security_alert or safety_mode:
            # local_only bypasses hold
            if not intent.is_local_only:
                activated.append((ConstraintType.SECURITY_BLOCK, ExecutionDisposition.HOLD))

        # 3. Stop Phrases
        if len(constraint_evidence.stop_phrases) > 0:
            activated.append((ConstraintType.SECURITY_BLOCK, ExecutionDisposition.HOLD))

        # 4. Ask Phrases
        if len(constraint_evidence.ask_phrases) > 0:
            if not intent.is_local_only:
                activated.append((ConstraintType.SAFETY_BLOCK, ExecutionDisposition.ASK))

        # 5. Payment Policy and Memory Conflict / Duration Ambiguity
        if get_latest_record_value(record_facts, "payment_policy"):
            activated.append((ConstraintType.PAYMENT_POLICY, ExecutionDisposition.ASK))
        if get_latest_record_value(record_facts, "memory_conflict"):
            activated.append((ConstraintType.PAYMENT_POLICY, ExecutionDisposition.ASK))
        if get_latest_record_value(record_facts, "duration_ambiguous"):
            activated.append((ConstraintType.PAYMENT_POLICY, ExecutionDisposition.ASK))

        # 6. Target Changed After Turn
        if get_latest_record_value(record_facts, "target_changed_after_turn"):
            activated.append((ConstraintType.PAYMENT_POLICY, ExecutionDisposition.ASK))

        # 7. Share Boundary Updates
        boundary = str(get_latest_record_value(record_facts, "share_boundary_update") or "")
        if boundary == "dispatch_blocked_until_binding":
            amend_phrases = ["식별 가능한 세부값을 제외", "세부값을 제외", "요약만 공유", "민감 내용은 알아서 처리", "위치나 나이 같은 민감"]
            if any(p in intent.domain_keywords for p in amend_phrases):
                activated.append((ConstraintType.LOCAL_BOUNDARY, ExecutionDisposition.AMEND))
            elif get_latest_record_value(record_facts, "guardrail_ladder_signal"):
                activated.append((ConstraintType.LOCAL_BOUNDARY, ExecutionDisposition.HOLD))
            elif get_latest_record_value(record_facts, "ambiguous_focal") and get_latest_record_value(record_facts, "dispatch_authority_check") == "user_binding_pending":
                activated.append((ConstraintType.LOCAL_BOUNDARY, ExecutionDisposition.HOLD))
        elif boundary == "local_update_boundary":
            ambiguous = str(get_latest_record_value(record_facts, "ambiguous_target") or "")
            if get_latest_record_value(record_facts, "ambiguous_focal"):
                activated.append((ConstraintType.LOCAL_BOUNDARY, ExecutionDisposition.PROCEED))
            elif ambiguous == "stored_channel_or_visible_recipient":
                activated.append((ConstraintType.LOCAL_BOUNDARY, ExecutionDisposition.AMEND))
            elif ambiguous == "approved_channel_or_visible_recipient":
                activated.append((ConstraintType.LOCAL_BOUNDARY, ExecutionDisposition.ASK))
            elif ambiguous == "surface_recipient_and_resolved_target_both_recent":
                activated.append((ConstraintType.LOCAL_BOUNDARY, ExecutionDisposition.AMEND))
        elif boundary in ("redacted_external_boundary", "redacted_after_selection_boundary"):
            ambiguous = str(get_latest_record_value(record_facts, "ambiguous_target") or "")
            if ambiguous == "surface_recipient_and_resolved_target_both_recent":
                activated.append((ConstraintType.LOCAL_BOUNDARY, ExecutionDisposition.ASK))
            elif ambiguous == "stored_channel_or_visible_recipient" and any(k in intent.domain_keywords for k in ["검진", "점검"]):
                activated.append((ConstraintType.LOCAL_BOUNDARY, ExecutionDisposition.ASK))
            elif get_latest_record_value(record_facts, "guardrail_ladder_signal") and get_latest_record_value(record_facts, "dispatch_authority_check") == "internal_binding_confirmed":
                activated.append((ConstraintType.LOCAL_BOUNDARY, ExecutionDisposition.PROCEED))
            else:
                activated.append((ConstraintType.LOCAL_BOUNDARY, ExecutionDisposition.AMEND))

        # 8. Unresolved Ambiguity
        unresolved_ambiguity = False
        ambiguous_tgt = get_latest_record_value(record_facts, "ambiguous_target")
        ambiguous_focal = get_latest_record_value(record_facts, "ambiguous_focal")
        if ambiguous_tgt or ambiguous_focal:
            authority = str(get_latest_record_value(record_facts, "dispatch_authority_check") or "")
            candidates_snap = str(get_latest_record_value(record_facts, "route_candidate_snapshot") or "")
            if boundary != "local_update_boundary":
                if authority in ("authority_incomplete", "user_binding_pending") and boundary == "dispatch_blocked_until_binding":
                    unresolved_ambiguity = True
                elif candidates_snap == "external_candidates_present" and authority != "internal_binding_confirmed" and not boundary.startswith("redacted"):
                    unresolved_ambiguity = True

        if unresolved_ambiguity:
            activated.append((ConstraintType.DISPATCH_AUTHORITY, ExecutionDisposition.ASK))

        # 9. External Redactable Sharing / Policy Recall
        external_redactable = False
        amend_phrases = ["식별 가능한 세부값을 제외", "세부값을 제외", "요약만 공유", "민감 내용은 알아서 처리", "위치나 나이 같은 민감"]
        if any(p in intent.domain_keywords for p in amend_phrases):
            external_redactable = True
        elif get_latest_record_value(record_facts, "external_share_policy"):
            external_redactable = True
        elif boundary in ("redacted_external_boundary", "redacted_after_selection_boundary"):
            external_redactable = True
        elif ambiguous_tgt and get_latest_record_value(record_facts, "resolved_target"):
            external_redactable = True
        elif get_latest_record_value(record_facts, "session_share_policy") == "strict" and get_latest_record_value(record_facts, "resolved_target"):
            external_redactable = True

        if external_redactable:
            activated.append((ConstraintType.EXTERNAL_SHARE_POLICY, ExecutionDisposition.AMEND))

        # 10. Memory Recall Controls
        if get_latest_record_value(record_facts, "enterprise_policy_recall"):
            activated.append((ConstraintType.TEMPORARY_OVERRIDE, ExecutionDisposition.AMEND))
        elif get_latest_record_value(record_facts, "ops_memory_recall"):
            effect = ExecutionDisposition.ASK if get_latest_record_value(record_facts, "target_changed_after_turn") else ExecutionDisposition.AMEND
            activated.append((ConstraintType.TEMPORARY_OVERRIDE, effect))
        elif get_latest_record_value(record_facts, "temporary_override_allowed"):
            activated.append((ConstraintType.TEMPORARY_OVERRIDE, ExecutionDisposition.AMEND))
        elif get_latest_record_value(record_facts, "persistent_memory_recall") and any(k in intent.domain_keywords for k in ["쿠폰"]) and not get_latest_record_value(record_facts, "payment_policy"):
            activated.append((ConstraintType.TEMPORARY_OVERRIDE, ExecutionDisposition.HOLD))
        elif get_latest_record_value(record_facts, "ambiguous_focal") and get_latest_record_value(record_facts, "session_share_policy") == "normal":
            activated.append((ConstraintType.TEMPORARY_OVERRIDE, ExecutionDisposition.ASK))

        # Focal specific checks
        focal_obj = None
        for obj in object_facts:
            if obj.object_id == focal_id:
                focal_obj = obj
                break
        if focal_obj and focal_obj.object_type == "health_record" and get_latest_record_value(record_facts, "external_share_policy") == "doctor_note_forbidden":
            activated.append((ConstraintType.TEMPORARY_OVERRIDE, ExecutionDisposition.HOLD))

        return activated


# ─── Effect Algebra ───────────────────────────────────────────────

def aggregate_effects(effects: list[ExecutionDisposition]) -> ExecutionDisposition:
    """Reduces multiple effects using the canonical lattice priority.
    
    Lattice Order:
      HOLD > ASK > AMEND > PROCEED
    
    Idempotent: repeating the same effect has no additional impact.
    Null-safe: empty list returns PROCEED.
    """
    if not effects:
        return ExecutionDisposition.PROCEED

    unique_effects = set(effects)

    if ExecutionDisposition.HOLD in unique_effects:
        return ExecutionDisposition.HOLD
    if ExecutionDisposition.ASK in unique_effects:
        return ExecutionDisposition.ASK
    if ExecutionDisposition.AMEND in unique_effects:
        return ExecutionDisposition.AMEND
    return ExecutionDisposition.PROCEED

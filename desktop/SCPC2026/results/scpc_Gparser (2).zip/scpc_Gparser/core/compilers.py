"""
SCPC Pure Compilers — Step 10

ScopeCompiler, PolicyCompiler, and PlanCompiler.
They are pure functions of their respective Projection DTOs.
They have zero access to raw prompts, TaskView, or records.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any
from core.projections import ScopeProjection, PolicyProjection, PlanProjection
from rules.plan import normalize_event

BASE_DIR = Path(__file__).parent.parent


class ScopeCompiler:
    """Pure compiler for content_scope."""

    @staticmethod
    def compile(proj: ScopeProjection) -> dict[str, Any]:
        mode = proj.mode
        if mode == "none":
            allowed_fields = []
        elif mode == "status_only":
            allowed_fields = ["status"]
        elif mode == "redacted":
            allowed_fields = ["summary"]
        elif mode == "raw":
            allowed_fields = ["summary", "title"]
        else:
            allowed_fields = ["summary"]

        return {
            "mode": mode,
            "allowed_fields": allowed_fields,
            "excluded_fields": proj.excluded_fields,
            "requires_user_confirmation": proj.requires_user_confirmation,
        }


class PolicyCompiler:
    """Pure compiler for policy."""

    @staticmethod
    def compile(proj: PolicyProjection) -> dict[str, Any]:
        return {
            "risk_flags": proj.risk_flags,
            "violations": proj.violations,
            "requires_confirmation": proj.requires_confirmation,
        }


class PlanCompiler:
    """Pure compiler for plan_events."""

    @staticmethod
    def compile(proj: PlanProjection, task_id: str = "") -> list[dict[str, Any]]:
        control = proj.control
        fid = proj.focal_id
        target = proj.target
        profile_name = proj.profile_name
        scope_mode = proj.scope_mode

        if control == "hold":
            template = [
                {"verb": "read", "target": fid, "args": {"purpose": "invalidated_precondition"}},
                {"verb": "guard", "target": fid, "args": {"reason": "precondition_invalidated"}},
            ]
        elif control == "ask":
            reason = "precondition_changed" if (profile_name != "fallback_clarification" and proj.is_auth_confirmed and proj.is_precondition_changed_clarify) else "route_resolution_required"
            purpose = "clarify_precondition" if reason == "precondition_changed" else "route_resolution_required"
            template = [
                {"verb": "read", "target": fid, "args": {"purpose": purpose}},
                {"verb": "clarify", "target": "user", "args": {"reason": reason}},
            ]
        elif profile_name == "local_status_update":
            template = [
                {"verb": "read", "target": fid, "args": {"purpose": "local_update"}},
                {"verb": "verify", "target": "share_boundary_update", "args": {"scope": "local_update"}},
                {"verb": "update", "target": fid, "args": {"state": "local_status_only"}},
            ]
        else:
            terminal_verb = proj.terminal_verb

            if control == "amend":
                remove = "sensitive_fields" if proj.remove_sensitive_fields else "raw_quote"
                template = [
                    {"verb": "read", "target": fid, "args": {"purpose": "minimal_disclosure"}},
                    {"verb": "redact", "target": fid, "args": {"remove": remove}},
                    {"verb": terminal_verb, "target": target, "args": {"scope": "redacted"}},
                ]
            elif scope_mode == "summary":
                template = [
                    {"verb": "read", "target": fid, "args": {"purpose": "inspect_context"}},
                    {"verb": "summarize", "target": fid, "args": {"mode": "summary"}},
                    {"verb": terminal_verb, "target": target, "args": {"scope": "summary"}},
                ]
            else:
                template = [
                    {"verb": "read", "target": fid, "args": {"purpose": "inspect_context"}},
                    {"verb": terminal_verb, "target": target, "args": {"scope": scope_mode}},
                ]

        # Normalize events and collect warnings
        normalized_template = []
        all_warnings = []

        for event in template:
            norm_event, warnings_list = normalize_event(event, task_id)
            normalized_template.append(norm_event)
            all_warnings.extend(warnings_list)

        if all_warnings and task_id:
            reports_dir = BASE_DIR / "reports"
            reports_dir.mkdir(parents=True, exist_ok=True)
            log_file = reports_dir / "ontology_warnings.jsonl"
            with open(log_file, "a", encoding="utf-8") as f:
                for w in all_warnings:
                    log_entry = {
                        "task_id": task_id,
                        "warning": w,
                        "plan_events": normalized_template
                    }
                    f.write(json.dumps(log_entry, ensure_ascii=False) + "\n")

        return normalized_template

"""
SCPC Typed Facts & Record Adapters — Step 3

Typed Fact layer that converts raw task JSON inputs into structured,
validated fact objects. RecordAdapters parse raw record values once;
downstream evaluators and compilers never compare raw record strings.

FactStatus distinguishes PRESENT / MISSING / UNKNOWN / CONFLICTED /
INVALID / NOT_APPLICABLE — they are never collapsed into a single None.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum, unique
from typing import Any


# ─── FactStatus ───────────────────────────────────────────────────
@unique
class FactStatus(str, Enum):
    PRESENT        = "present"
    MISSING        = "missing"
    UNKNOWN        = "unknown"
    CONFLICTED     = "conflicted"
    INVALID        = "invalid"
    NOT_APPLICABLE = "not_applicable"


# ─── TypedObjectFact ──────────────────────────────────────────────
@dataclass(frozen=True)
class TypedObjectFact:
    """Structured representation of a device_state object."""
    object_id: str
    object_type: str
    ref_code: str
    contains_fields: frozenset[str]
    attrs: dict[str, Any]
    status: FactStatus = FactStatus.PRESENT

    @staticmethod
    def from_raw(obj: dict[str, Any]) -> "TypedObjectFact":
        oid = str(obj.get("id") or "")
        otype = str(obj.get("type") or "generic")
        attrs = obj.get("attrs") or {}
        ref_code = str(attrs.get("ref_code") or "")
        raw_contains = attrs.get("contains") or attrs.get("fields") or []
        contains = frozenset(str(x) for x in raw_contains) if isinstance(raw_contains, list) else frozenset()
        return TypedObjectFact(
            object_id=oid,
            object_type=otype,
            ref_code=ref_code,
            contains_fields=contains,
            attrs=attrs,
        )


# ─── TypedRecordFact ──────────────────────────────────────────────
@dataclass(frozen=True)
class TypedRecordFact:
    """Structured representation of a device_state record.
    
    `parsed_value` is the type-specific interpretation produced by
    a RecordAdapter. Downstream code should use only this field,
    never comparing raw_value strings directly.
    """
    record_id: str
    record_type: str
    raw_value: Any               # original value, kept for audit
    parsed_value: Any            # adapter-interpreted value
    status: FactStatus = FactStatus.PRESENT


# ─── RelationFact ─────────────────────────────────────────────────
@dataclass(frozen=True)
class RelationFact:
    """Structural relation between object/record facts."""
    source_id: str
    target_id: str
    relation_type: str           # e.g., "ref_code_link", "focal_binding"
    status: FactStatus = FactStatus.PRESENT


# ─── CapabilitySnapshot ───────────────────────────────────────────
@dataclass(frozen=True)
class CapabilitySnapshot:
    """Available capabilities derived from task.available_actions."""
    platform_actions: frozenset[str]   # verbs from available_actions
    internal_transforms: frozenset[str] = frozenset({"read", "verify", "redact", "summarize"})

    @staticmethod
    def from_task(task: dict[str, Any]) -> "CapabilitySnapshot":
        raw = task.get("available_actions") or [
            "read", "verify", "redact", "summarize", "dispatch",
            "guard", "clarify", "update", "schedule", "toggle", "pay",
        ]
        return CapabilitySnapshot(
            platform_actions=frozenset(str(a) for a in raw),
        )


# ─── SessionSnapshot ─────────────────────────────────────────────
@dataclass(frozen=True)
class SessionSnapshot:
    """Immutable snapshot of session state for the current turn."""
    last_focal_id: str
    last_target: str
    last_control: str
    last_profile: str
    memory: dict[str, Any]

    @staticmethod
    def from_session(session: dict[str, Any]) -> "SessionSnapshot":
        return SessionSnapshot(
            last_focal_id=str(session.get("last_focal_id") or ""),
            last_target=str(session.get("last_target") or ""),
            last_control=str(session.get("last_control") or ""),
            last_profile=str(session.get("last_profile") or ""),
            memory=dict(session.get("memory") or {}),
        )


# ═══════════════════════════════════════════════════════════════════
# RecordAdapter Registry
# ═══════════════════════════════════════════════════════════════════

class RecordAdapter:
    """Base class for type-specific record adapters.
    
    Each adapter:
    - Declares which record_type(s) it handles
    - Parses raw value into a typed parsed_value
    - Declares unknown_value_policy
    """
    supported_types: frozenset[str] = frozenset()
    unknown_value_policy: str = "preserve"   # "preserve" | "reject" | "unknown"

    def parse(self, raw_record: dict[str, Any]) -> TypedRecordFact:
        rid = str(raw_record.get("id") or "")
        rtype = str(raw_record.get("type") or "")
        raw_val = raw_record.get("value")
        parsed = self._parse_value(rtype, raw_val)
        status = FactStatus.PRESENT if parsed is not None else FactStatus.MISSING
        return TypedRecordFact(
            record_id=rid,
            record_type=rtype,
            raw_value=raw_val,
            parsed_value=parsed,
            status=status,
        )

    def _parse_value(self, record_type: str, raw_value: Any) -> Any:
        """Override in subclasses for type-specific parsing."""
        return raw_value


class ConsentAdapter(RecordAdapter):
    """Parses consent records into a canonical status string."""
    supported_types = frozenset({"consent"})

    def _parse_value(self, record_type: str, raw_value: Any) -> str:
        if isinstance(raw_value, dict):
            return str(raw_value.get("status") or "granted")
        if isinstance(raw_value, str):
            return raw_value if raw_value in ("granted", "revoked", "withdrawn", "denied") else "granted"
        return "granted"


class BooleanSignalAdapter(RecordAdapter):
    """Parses boolean-like signal records (security_alert, safety_mode, etc.)."""
    supported_types = frozenset({
        "security_alert", "safety_mode", "guest_mode", "privacy_guard",
    })

    def _parse_value(self, record_type: str, raw_value: Any) -> bool:
        return bool(raw_value)


class PolicyStringAdapter(RecordAdapter):
    """Parses string policy records."""
    supported_types = frozenset({
        "session_share_policy", "external_share_policy",
        "share_boundary_update", "dispatch_authority_check",
        "route_candidate_snapshot", "route_binding_order",
        "guardrail_ladder_signal", "current_request_hint",
        "ambiguous_target", "ambiguous_focal",
        "duration_ambiguous", "resolved_target",
        "target_changed_after_turn", "memory_conflict",
        "payment_policy", "enterprise_policy_recall",
        "ops_memory_recall", "temporary_override_allowed",
        "persistent_memory_recall", "calendar_conflict",
        "trusted_subscription", "verified_internal_target",
    })

    def _parse_value(self, record_type: str, raw_value: Any) -> Any:
        if raw_value is None:
            return None
        if isinstance(raw_value, str):
            return raw_value
        return raw_value  # dicts and other complex values pass through


class StructuredDataAdapter(RecordAdapter):
    """Parses structured (dict/list) records like marker_refs, resolution_trace."""
    supported_types = frozenset({
        "focal_marker_refs", "focal_resolution_trace",
        "persistent_memory_write",
    })

    def _parse_value(self, record_type: str, raw_value: Any) -> Any:
        if isinstance(raw_value, (dict, list)):
            return raw_value
        return raw_value


# ─── Adapter Registry ─────────────────────────────────────────────

_ADAPTERS: list[RecordAdapter] = [
    ConsentAdapter(),
    BooleanSignalAdapter(),
    PolicyStringAdapter(),
    StructuredDataAdapter(),
]

_ADAPTER_MAP: dict[str, RecordAdapter] = {}
for _adapter in _ADAPTERS:
    for _rtype in _adapter.supported_types:
        _ADAPTER_MAP[_rtype] = _adapter

_DEFAULT_ADAPTER = RecordAdapter()


def get_adapter(record_type: str) -> RecordAdapter:
    """Look up the adapter for a given record type."""
    return _ADAPTER_MAP.get(record_type, _DEFAULT_ADAPTER)


# ─── TypedFactAssembler ───────────────────────────────────────────

class TypedFactAssembler:
    """Converts raw task input into structured TypedFacts.
    
    This is the single entry point for Stage 1 fact assembly.
    The assembled facts are immutable and order-independent.
    """

    @staticmethod
    def assemble_objects(raw_objects: list[dict[str, Any]]) -> list[TypedObjectFact]:
        """Parse raw objects into TypedObjectFacts."""
        return [TypedObjectFact.from_raw(obj) for obj in raw_objects if isinstance(obj, dict)]

    @staticmethod
    def assemble_records(raw_records: list[dict[str, Any]]) -> list[TypedRecordFact]:
        """Parse raw records through type-specific RecordAdapters."""
        facts = []
        for rec in raw_records:
            if not isinstance(rec, dict):
                continue
            rtype = str(rec.get("type") or "")
            adapter = get_adapter(rtype)
            facts.append(adapter.parse(rec))
        return facts

    @staticmethod
    def assemble_relations(
        object_facts: list[TypedObjectFact],
        record_facts: list[TypedRecordFact],
    ) -> list[RelationFact]:
        """Build structural relations between objects and records."""
        relations = []
        obj_by_id = {o.object_id: o for o in object_facts}

        # Link records that reference object IDs
        for rf in record_facts:
            if rf.record_type == "resolved_target" and isinstance(rf.parsed_value, str):
                # resolved_target may reference a target identity
                relations.append(RelationFact(
                    source_id=rf.record_id,
                    target_id=rf.parsed_value,
                    relation_type="target_binding",
                ))
            elif rf.record_type == "focal_marker_refs" and isinstance(rf.parsed_value, dict):
                marker_map = rf.parsed_value.get("marker_to_ref") or {}
                for marker, ref in marker_map.items():
                    relations.append(RelationFact(
                        source_id=rf.record_id,
                        target_id=str(ref),
                        relation_type="focal_marker_link",
                    ))

        # Link objects via ref_code
        for obj in object_facts:
            if obj.ref_code:
                relations.append(RelationFact(
                    source_id=obj.object_id,
                    target_id=obj.ref_code,
                    relation_type="ref_code_link",
                ))

        return relations

    @staticmethod
    def assemble_capability(task: dict[str, Any]) -> CapabilitySnapshot:
        return CapabilitySnapshot.from_task(task)

    @staticmethod
    def assemble_session(session: dict[str, Any]) -> SessionSnapshot:
        return SessionSnapshot.from_session(session)


# ─── Helper Functions for Isolated Resolvers ──────────────────────

def get_latest_record_value(record_facts: list[TypedRecordFact], rtype: str) -> Any:
    """Return parsed_value of the last record fact of the given type."""
    for fact in reversed(record_facts):
        if fact.record_type == rtype:
            return fact.parsed_value
    return None


def get_record_values(record_facts: list[TypedRecordFact], rtype: str) -> list[Any]:
    """Return parsed_value for all record facts of the given type."""
    return [fact.parsed_value for fact in record_facts if fact.record_type == rtype]


def get_object_by_id(object_facts: list[TypedObjectFact], oid: str) -> TypedObjectFact | None:
    """Find object fact by ID."""
    for obj in object_facts:
        if obj.object_id == oid:
            return obj
    return None


def get_object_by_ref_code(object_facts: list[TypedObjectFact], ref: str) -> TypedObjectFact | None:
    """Find object fact by ref code."""
    for obj in object_facts:
        if obj.ref_code == ref:
            return obj
    return None

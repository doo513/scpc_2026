from __future__ import annotations
import re
from dataclasses import dataclass, field
from typing import Any, Literal
from core.task_view import TaskView
from core.pipeline import ClauseData, IntentEvidence, PromptConstraintEvidence, Provenance

HOLD_PHRASES = [
    "더 진행하면 안",
    "실행하면 안",
    "실행을 막",
    "멈춰야",
    "처리하지 않는다",
    "처리 전제가 사라",
    "전제를 무효화",
    "허용 근거가 최신 상태에서 깨",
    "과거 승인에 기대면 안",
    "이전 허용 조건이 취소",
]

ASK_PHRASES = [
    "다시 확인",
    "사용자 확인",
    "먼저 확인",
    "확인 절차",
    "확정되지",
    "미확정",
    "결론을 내릴 수 없다",
    "아직 확인되지",
    "물어봐",
]

LOCAL_UPDATE_PHRASES = [
    "내부 상태 업데이트",
    "상태만 갱신",
    "로컬 상태 기록",
    "기기 내부 업데이트",
    "저장해줘",
    "기억해",
    "기억해줘",
    "메모리를 저장",
    "메모리 저장",
    "사용자 메모리를",
    "장치 안의 처리 상태만",
    "바깥으로 보내지 말고",
    "공유하지 말고",
    "수신처 전달 대신",
    "전달 동작은 취소",
    "보내는 작업은 취소",
    "외부 공유가 아니라",
    "외부 전송을 하지 말고",
    "상태 표시만",
    "상태 기록만",
    "memory_store",
    "status_only",
]

AMEND_PHRASES = [
    "식별 가능한 세부값을 제외",
    "세부값을 제외",
    "요약만 공유",
    "민감 내용은 알아서 처리",
    "위치나 나이 같은 민감",
]

DOMAIN_KEYWORDS = {
    "PAY": ["결제", "쿠폰", "납부", "지불", "pay"],
    "TOGGLE": ["조명", "온도", "켜", "꺼", "조절", "toggle"],
    "SCHEDULE": ["회의", "일정", "예약", "시간", "스케줄", "schedule"],
}

FALLBACK_KEYWORDS = ["원본", "사진", "건강", "설정", "메모리", "어두워질", "어두워", "검진", "점검", "정산", "출장", "전제", "전제가", "신호", "모호성", "상위 금지", "금지"]

class NaturalLanguageInterpreter:
    @staticmethod
    def parse_clauses_and_evidence(prompt: str, turn_index: int) -> list[ClauseData]:
        # Protect quotes during splitting
        quote_pattern = r'["\'][^"\']*["\']'
        quotes = re.findall(quote_pattern, prompt)
        placeholder_text = prompt
        for i, q in enumerate(quotes):
            placeholder_text = placeholder_text.replace(q, f"__QUOTE_{i}__")

        # Split clauses by common separators, capturing the separator
        sep_pattern = r"((?:그리고|하지만|다만|단,|단\s+|대신|;|(?<=\D)\.))"
        parts = re.split(sep_pattern, placeholder_text)
        
        clauses_data = []
        clause_idx = 0
        for i in range(0, len(parts), 2):
            rc = parts[i]
            rc_trimmed = rc.strip()
            if not rc_trimmed:
                continue
            
            # Check if preceded by a correction separator like "대신"
            preceding_sep = parts[i - 1].strip() if i > 0 else ""
            is_sep_correction = "대신" in preceding_sep
            
            # Analyze clause characteristics on text with protected quote placeholders
            intent = NaturalLanguageInterpreter._parse_intent(rc_trimmed, turn_index, is_sep_correction)
            constraint = NaturalLanguageInterpreter._parse_constraint(rc_trimmed, turn_index)

            # Restore quotes in this clause text
            clause_text = rc_trimmed
            for idx, q in enumerate(quotes):
                clause_text = clause_text.replace(f"__QUOTE_{idx}__", q)
            
            clauses_data.append(ClauseData(
                clause_index=clause_idx,
                text=clause_text,
                intent=intent,
                constraint=constraint
            ))
            clause_idx += 1

        if not clauses_data:
            # Fallback if no clauses parsed
            intent = NaturalLanguageInterpreter._parse_intent(placeholder_text, turn_index)
            constraint = NaturalLanguageInterpreter._parse_constraint(placeholder_text, turn_index)
            clauses_data.append(ClauseData(
                clause_index=0,
                text=prompt,
                intent=intent,
                constraint=constraint
            ))
        return clauses_data

    @staticmethod
    def _parse_intent(text: str, turn_index: int, is_sep_correction: bool = False) -> IntentEvidence:
        provenances = []
        domain_verbs = []
        domain_keywords = []

        # Check explicit domain keywords
        for verb, keywords in DOMAIN_KEYWORDS.items():
            for kw in keywords:
                if kw in text:
                    domain_verbs.append(verb)
                    domain_keywords.append(kw)
                    provenances.append(Provenance(source="prompt", turn_index=turn_index, span=f"domain:{kw}"))
        
        # Check focal fallback keywords
        for kw in FALLBACK_KEYWORDS:
            if kw in text:
                domain_keywords.append(kw)
                provenances.append(Provenance(source="prompt", turn_index=turn_index, span=f"fallback_kw:{kw}"))
        # Check amend phrases
        for phrase in AMEND_PHRASES:
            if phrase in text:
                domain_keywords.append(phrase)
                provenances.append(Provenance(source="prompt", turn_index=turn_index, span=f"amend_phrase:{phrase}"))

        # Check local only intent
        is_local = False
        for phrase in LOCAL_UPDATE_PHRASES:
            if phrase in text:
                is_local = True
                provenances.append(Provenance(source="prompt", turn_index=turn_index, span=f"local_phrase:{phrase}"))

        # Check correction ("대신", "최신 표현을 우선")
        is_correction = is_sep_correction or any(p in text for p in ["최신 표현", "우선한다", "대신", "정정"])
        if is_correction:
            provenances.append(Provenance(source="prompt", turn_index=turn_index, span="correction"))

        # Check negation ("하지 말고", "제외", "취소", "하지 마", "않는다", "마라", "않고")
        is_negation = any(p in text for p in ["하지 말고", "제외", "취소", "하지 마", "않는다", "마라", "않고"])
        if is_negation:
            provenances.append(Provenance(source="prompt", turn_index=turn_index, span="negation"))

        # Check target rebind intent
        target_reb = any(p in text for p in ["대상 변경", "수신처 수정", "수신 변경", "목적지 변경", "바꿔"])
        if target_reb:
            provenances.append(Provenance(source="prompt", turn_index=turn_index, span="target_rebind"))

        # Check override memory
        override_mem = any(p in text for p in ["기록을 무시", "메모리를 무시", "이전 설정 무시"])
        if override_mem:
            provenances.append(Provenance(source="prompt", turn_index=turn_index, span="override_memory"))

        # Check referencing keywords
        ref_kw = []
        for kw in ["방금", "이전", "그거", "그것", "취소", "삭제", "전송"]:
            if kw in text:
                ref_kw.append(kw)
                provenances.append(Provenance(source="prompt", turn_index=turn_index, span=f"ref_kw:{kw}"))

        return IntentEvidence(
            domain_verbs=list(set(domain_verbs)),
            is_local_only=is_local,
            is_correction=is_correction,
            is_negation=is_negation,
            target_rebind=target_reb,
            override_memory=override_mem,
            domain_keywords=list(set(domain_keywords)),
            referencing_keywords=ref_kw,
            provenances=provenances
        )

    @staticmethod
    def _parse_constraint(text: str, turn_index: int) -> PromptConstraintEvidence:
        provenances = []
        stop_phrases = []
        ask_phrases = []

        for p in HOLD_PHRASES:
            if p in text:
                stop_phrases.append(p)
                provenances.append(Provenance(source="prompt", turn_index=turn_index, span=f"stop:{p}"))

        for p in ASK_PHRASES:
            if p in text:
                ask_phrases.append(p)
                provenances.append(Provenance(source="prompt", turn_index=turn_index, span=f"ask:{p}"))

        return PromptConstraintEvidence(
            stop_phrases=stop_phrases,
            ask_phrases=ask_phrases,
            provenances=provenances
        )

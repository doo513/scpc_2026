"""
SCPC Fallback Graph & Authorized Fallback Solver — Step 8

Defines the FallbackGraph and FallbackEdge structures.
Detects and rejects cycles/self-loops statically.
If a candidate is blocked/unavailable, the solver finds the authorized alternative.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any
from core.ontology import ExecutionDisposition


@dataclass(frozen=True)
class FallbackNode:
    action: str
    target: str


@dataclass(frozen=True)
class FallbackEdge:
    source: FallbackNode
    destination: FallbackNode
    reason_code: str
    semantic_preservation: bool = True
    max_hops: int = 1


class FallbackGraph:
    """Directed graph representing authorized fallback alternatives.
    
    Prevents cycles and self-loops at registration time.
    """

    def __init__(self) -> None:
        self._adj: dict[FallbackNode, list[FallbackEdge]] = {}

    def add_edge(self, edge: FallbackEdge) -> None:
        """Add an edge and check for cycles and self-loops."""
        if edge.source == edge.destination:
            raise ValueError(f"Self-loop detected on node {edge.source}")

        # Add edge temporarily
        self._adj.setdefault(edge.source, []).append(edge)

        # Check for cycles
        if self._has_cycle():
            # Rollback
            self._adj[edge.source].remove(edge)
            if not self._adj[edge.source]:
                del self._adj[edge.source]
            raise ValueError(f"Cycle detected after adding edge from {edge.source} to {edge.destination}")

    def get_edges(self, node: FallbackNode) -> list[FallbackEdge]:
        return self._adj.get(node, [])

    def _has_cycle(self) -> bool:
        visited: dict[FallbackNode, int] = {}  # 0=unvisited, 1=visiting, 2=visited

        def dfs(node: FallbackNode) -> bool:
            visited[node] = 1
            for edge in self._adj.get(node, []):
                dest = edge.destination
                state = visited.get(dest, 0)
                if state == 1:
                    return True  # Back-edge found!
                if state == 0:
                    if dfs(dest):
                        return True
            visited[node] = 2
            return False

        for node in self._adj:
            if visited.get(node, 0) == 0:
                if dfs(node):
                    return True
        return False


class AuthorizedFallbackSolver:
    """Traverses the FallbackGraph to find the next available authorized alternative."""

    @staticmethod
    def resolve_authorized_candidate(
        graph: FallbackGraph,
        primary_action: str,
        primary_target: str,
        evaluator_callback: Any,  # Callable[[str, str], bool] returns True if candidate is authorized/available
    ) -> tuple[str, str, list[str]]:
        """Traverse the fallback graph starting from the primary candidate.
        
        Returns the resolved (action, target) pair and the list of visited nodes in the trace.
        """
        current = FallbackNode(primary_action, primary_target)
        trace = [f"{current.action}:{current.target}"]

        # Check if primary candidate is already available/authorized
        if evaluator_callback(current.action, current.target):
            return current.action, current.target, trace

        # Traverse fallback edges
        hops = 0
        while hops < 5:  # Safety guard limit
            edges = graph.get_edges(current)
            if not edges:
                break
            
            # Select the first edge (under simple deterministic matching)
            edge = edges[0]
            current = edge.destination
            trace.append(f"{current.action}:{current.target}")
            hops += 1

            if evaluator_callback(current.action, current.target):
                return current.action, current.target, trace

        # If fallback fails, return the primary candidate (will be blocked downstream)
        return primary_action, primary_target, trace

"""
SCPC Rule Registry & Rule Packs — Step 6

Static RuleRegistry that maps (domain, operation) keys to structured RulePacks.
Evaluators query this registry using typed keys to resolve decision parameters
rather than hardcoding them in decision logic.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal
from core.ontology import Domain, Operation, ConstraintType, ExecutionDisposition


@dataclass(frozen=True)
class BoundaryRule:
    """Configures boundary-specific transition constraints."""
    boundary_type: str
    preferred_disposition: ExecutionDisposition
    fallback_disposition: ExecutionDisposition
    amend_keywords: frozenset[str] = field(default_factory=frozenset)


@dataclass(frozen=True)
class RulePack:
    """Declarative pack of semantic rules for a Domain-Operation pair."""
    domain: Domain
    operation: Operation
    requires_consent: bool = True
    requires_focal: bool = True
    allowed_dispositions: frozenset[ExecutionDisposition] = field(
        default_factory=lambda: frozenset({
            ExecutionDisposition.PROCEED,
            ExecutionDisposition.AMEND,
            ExecutionDisposition.HOLD,
            ExecutionDisposition.ASK,
        })
    )
    # List of constraints checked by this rule pack
    applicable_constraints: list[ConstraintType] = field(default_factory=list)
    # Default blueprint ID associated with this operation
    blueprint_id: str = "generic_dispatch"


# ─── Static Registry Definition ───────────────────────────────────

class RuleRegistry:
    """Central static registry for all RulePacks.
    
    No external DB, embedding searches, or dynamic evaluation.
    """
    _packs: dict[tuple[Domain, Operation], RulePack] = {}

    @classmethod
    def register(cls, pack: RulePack) -> None:
        cls._packs[(pack.domain, pack.operation)] = pack

    @classmethod
    def lookup(cls, domain: Domain, operation: Operation) -> RulePack:
        """Exact key lookup for RulePack."""
        # Exact match
        pack = cls._packs.get((domain, operation))
        if pack:
            return pack
        # Fallback to generic CONTENT/SHARE if not registered
        return cls._packs.get((Domain.CONTENT, Operation.SHARE)) or RulePack(
            domain=Domain.CONTENT,
            operation=Operation.SHARE,
        )


# Populate registry with static RulePacks
RuleRegistry.register(RulePack(
    domain=Domain.PAYMENT,
    operation=Operation.EXECUTE,
    requires_consent=True,
    applicable_constraints=[
        ConstraintType.CONSENT_REVOKED,
        ConstraintType.SECURITY_BLOCK,
        ConstraintType.SAFETY_BLOCK,
        ConstraintType.PAYMENT_POLICY,
    ],
    blueprint_id="payment_execution",
))

RuleRegistry.register(RulePack(
    domain=Domain.DEVICE,
    operation=Operation.MODIFY,
    requires_consent=False,
    requires_focal=True,
    applicable_constraints=[
        ConstraintType.SECURITY_BLOCK,
        ConstraintType.SAFETY_BLOCK,
    ],
    blueprint_id="device_modification",
))

RuleRegistry.register(RulePack(
    domain=Domain.CALENDAR,
    operation=Operation.CREATE,
    requires_consent=True,
    applicable_constraints=[
        ConstraintType.CONSENT_REVOKED,
        ConstraintType.SECURITY_BLOCK,
        ConstraintType.SAFETY_BLOCK,
    ],
    blueprint_id="calendar_creation",
))

RuleRegistry.register(RulePack(
    domain=Domain.CALENDAR,
    operation=Operation.MODIFY,
    requires_consent=True,
    applicable_constraints=[
        ConstraintType.CONSENT_REVOKED,
        ConstraintType.SECURITY_BLOCK,
        ConstraintType.SAFETY_BLOCK,
    ],
    blueprint_id="calendar_modification",
))

RuleRegistry.register(RulePack(
    domain=Domain.CONTENT,
    operation=Operation.SHARE,
    requires_consent=True,
    applicable_constraints=[
        ConstraintType.CONSENT_REVOKED,
        ConstraintType.SECURITY_BLOCK,
        ConstraintType.SAFETY_BLOCK,
        ConstraintType.LOCAL_BOUNDARY,
        ConstraintType.EXTERNAL_SHARE_POLICY,
        ConstraintType.DISPATCH_AUTHORITY,
        ConstraintType.PRECONDITION_CHANGED,
    ],
    blueprint_id="content_dispatch",
))

RuleRegistry.register(RulePack(
    domain=Domain.MEMORY,
    operation=Operation.STORE,
    requires_consent=False,
    requires_focal=True,
    applicable_constraints=[
        ConstraintType.SECURITY_BLOCK,
        ConstraintType.SAFETY_BLOCK,
    ],
    blueprint_id="memory_store",
))

"""
SCPC Projection DTOs — Step 9

Defines ScopeProjection, PolicyProjection, and PlanProjection.
Compilers read only these projection DTOs to generate the final outputs.
This ensures compilers are pure transformers and do not re-read raw tasks or prompts.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class ScopeProjection:
    """Projection required for Scope Compilation."""
    mode: str
    focal_id: str
    target: str
    excluded_fields: list[str] = field(default_factory=list)
    requires_user_confirmation: bool = False


@dataclass(frozen=True)
class PolicyProjection:
    """Projection required for Policy Compilation."""
    risk_flags: list[str] = field(default_factory=list)
    violations: list[str] = field(default_factory=list)
    requires_confirmation: bool = False


@dataclass(frozen=True)
class PlanProjection:
    """Projection required for Plan Compilation."""
    control: str
    profile_name: str
    focal_id: str
    target: str
    scope_mode: str
    terminal_verb: str = "dispatch"
    is_auth_confirmed: bool = False
    is_precondition_changed_clarify: bool = False
    remove_sensitive_fields: bool = False

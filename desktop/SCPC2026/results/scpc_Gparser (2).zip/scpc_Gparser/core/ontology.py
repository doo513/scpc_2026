"""
SCPC Ontology — 공통 의미 타입 정의

Step 2 of Rule Registry Refactoring: Establish canonical typed enums
with single ownership for every semantic field in the harness pipeline.

Contract Status Legend:
  CONFIRMED_CONTRACT   — verified against official data/schema/dev_answers
  SUPPORTED_INTERPRETATION — consistent with data, not explicitly stated
  UNRESOLVED_ASSUMPTION — no official basis found; tracked for review
"""
from __future__ import annotations

from enum import Enum, unique


# ─── Domain ───────────────────────────────────────────────────────
@unique
class Domain(str, Enum):
    """Semantic domain of the user's request.
    Owner: EvidenceGraph (Stage 2) — determined once, never changed downstream.
    """
    CONTENT  = "CONTENT"   # generic content sharing / info retrieval
    PAYMENT  = "PAYMENT"
    DEVICE   = "DEVICE"
    CALENDAR = "CALENDAR"
    MEMORY   = "MEMORY"    # local status / memory store
    UNKNOWN  = "UNKNOWN"   # no matching domain evidence


# ─── Operation ────────────────────────────────────────────────────
@unique
class Operation(str, Enum):
    """Semantic operation the user intends to perform.
    Owner: EvidenceGraph (Stage 2).
    """
    SHARE   = "SHARE"      # dispatch / send content externally
    EXECUTE = "EXECUTE"    # payment execution
    CANCEL  = "CANCEL"
    MODIFY  = "MODIFY"     # device toggle, calendar modify
    CREATE  = "CREATE"     # calendar creation
    VERIFY  = "VERIFY"     # check / confirm status
    STORE   = "STORE"      # local memory write
    UNKNOWN = "UNKNOWN"


# ─── TargetRole ───────────────────────────────────────────────────
@unique
class TargetRole(str, Enum):
    """Semantic role of the resolved target entity.
    Owner: TargetResolver (Stage 3).
    """
    RECIPIENT       = "recipient"       # external sharing recipient
    MERCHANT        = "merchant"        # payment target
    DEVICE          = "device"          # IoT / device control target
    EVENT           = "event"           # calendar event
    MEMORY_STORE    = "memory_store"    # local memory storage
    CLARIFICATION   = "clarification"   # user as clarification/confirmation target
    UNKNOWN         = "unknown"


# ─── TargetLocality ───────────────────────────────────────────────
@unique
class TargetLocality(str, Enum):
    """Whether the target is local (on-device) or external.
    Owner: TargetResolver (Stage 3).
    """
    LOCAL    = "local"
    INTERNAL = "internal"   # within user's own system scope
    EXTERNAL = "external"   # cross-boundary dispatch
    UNKNOWN  = "unknown"


# ─── ObjectType ───────────────────────────────────────────────────
@unique
class ObjectType(str, Enum):
    """Typed category of a device_state object.
    Owner: TypedFactAssembler (Stage 1).
    """
    HEALTH_RECORD    = "health_record"
    PAYMENT_RECORD   = "payment_record"
    CALENDAR_EVENT   = "calendar_event"
    DEVICE_STATE     = "device_state"
    CONTENT_BUNDLE   = "content_bundle"
    GENERIC          = "generic"


# ─── RecordType ───────────────────────────────────────────────────
@unique
class RecordType(str, Enum):
    """Known record types used in device_state.records.
    Owner: RecordAdapter (Stage 1).
    """
    CONSENT                 = "consent"
    SECURITY_ALERT          = "security_alert"
    SAFETY_MODE             = "safety_mode"
    SESSION_SHARE_POLICY    = "session_share_policy"
    RESOLVED_TARGET         = "resolved_target"
    AMBIGUOUS_TARGET        = "ambiguous_target"
    AMBIGUOUS_FOCAL         = "ambiguous_focal"
    TARGET_CHANGED          = "target_changed_after_turn"
    DURATION_AMBIGUOUS      = "duration_ambiguous"
    MEMORY_CONFLICT         = "memory_conflict"
    PAYMENT_POLICY          = "payment_policy"
    EXTERNAL_SHARE_POLICY   = "external_share_policy"
    SHARE_BOUNDARY_UPDATE   = "share_boundary_update"
    DISPATCH_AUTHORITY      = "dispatch_authority_check"
    ROUTE_CANDIDATE         = "route_candidate_snapshot"
    GUARDRAIL_LADDER        = "guardrail_ladder_signal"
    ROUTE_BINDING_ORDER     = "route_binding_order"
    FOCAL_MARKER_REFS       = "focal_marker_refs"
    FOCAL_RESOLUTION_TRACE  = "focal_resolution_trace"
    CURRENT_REQUEST_HINT    = "current_request_hint"
    ENTERPRISE_POLICY       = "enterprise_policy_recall"
    OPS_MEMORY              = "ops_memory_recall"
    TEMP_OVERRIDE           = "temporary_override_allowed"
    PERSISTENT_MEMORY       = "persistent_memory_recall"
    PERSISTENT_MEMORY_WRITE = "persistent_memory_write"


# ─── InformationSlot ──────────────────────────────────────────────
@unique
class InformationSlot(str, Enum):
    """Named information slots required by domain-operation pairs.
    Owner: InformationSpec within RulePack.
    """
    MERCHANT   = "merchant"
    AMOUNT     = "amount"
    RECIPIENT  = "recipient"
    DEVICE_ID  = "device_id"
    DATE_TIME  = "date_time"
    CONTENT_ID = "content_id"
    DURATION   = "duration"


# ─── InformationStatus ────────────────────────────────────────────
@unique
class InformationStatus(str, Enum):
    """Status of a required information slot.
    Owner: CandidateEvaluator (Stage 5/8).
    """
    PRESENT        = "present"
    MISSING        = "missing"
    UNKNOWN        = "unknown"
    CONFLICTED     = "conflicted"
    INVALID        = "invalid"
    NOT_APPLICABLE = "not_applicable"


# ─── CandidateState ───────────────────────────────────────────────
@unique
class CandidateState(str, Enum):
    """Evaluated state of an Action–Target candidate pair.
    Owner: CandidateDispositionPolicy (Stage 4/8).
    """
    VIABLE               = "viable"
    NEEDS_INFORMATION     = "needs_information"
    NEEDS_CONFIRMATION    = "needs_confirmation"
    AMENDABLE             = "amendable"
    BLOCKED               = "blocked"
    CONFLICTED            = "conflicted"
    REJECTED              = "rejected"
    UNSUPPORTED_RULEPACK  = "unsupported_rulepack"


# ─── ConstraintType ───────────────────────────────────────────────
@unique
class ConstraintType(str, Enum):
    """Typed constraint categories.
    Owner: GlobalConstraintRegistry / PairConstraintSpec (Stage 7).
    """
    CONSENT_REVOKED       = "consent_revoked"
    SECURITY_BLOCK        = "security_block"
    SAFETY_BLOCK          = "safety_block"
    PAYMENT_POLICY        = "payment_policy"
    LOCAL_BOUNDARY        = "local_boundary"
    EXTERNAL_SHARE_POLICY = "external_share_policy"
    DISPATCH_AUTHORITY    = "dispatch_authority"
    PRECONDITION_CHANGED  = "precondition_changed"
    TEMPORARY_OVERRIDE    = "temporary_override"


# ─── ConstraintEffect ─────────────────────────────────────────────
@unique
class ConstraintEffect(str, Enum):
    """Effect of an activated constraint on a candidate.
    Owner: ConstraintActivator (Stage 7).
    """
    BLOCK_EXECUTION    = "block_execution"
    RESTRICT_TARGET    = "restrict_target"
    ADD_CONFIRMATION   = "add_confirmation"
    ADD_REDACTION      = "add_redaction"
    FORCE_SUMMARY      = "force_summary"
    LIMIT_DURATION     = "limit_duration"


# ─── CapabilityType ───────────────────────────────────────────────
@unique
class CapabilityType(str, Enum):
    """Types of capabilities required by plan steps.
    Owner: CapabilitySnapshot (Stage 1), validated by CandidateEvaluator.
    """
    PLATFORM_ACTION    = "platform_action"     # e.g. dispatch, pay, toggle
    INTERNAL_TRANSFORM = "internal_transform"  # e.g. redact, summarize, verify


# ─── CapabilitySource ─────────────────────────────────────────────
@unique
class CapabilitySource(str, Enum):
    """Where a capability is sourced from.
    Owner: CapabilitySnapshot.
    """
    AVAILABLE_ACTIONS   = "available_actions"
    BUILT_IN            = "built_in"


# ─── ExecutionDisposition ─────────────────────────────────────────
@unique
class ExecutionDisposition(str, Enum):
    """Final execution disposition for an evaluated candidate.
    Owner: CandidateDispositionPolicy.
    """
    PROCEED = "proceed"
    AMEND   = "amend"
    HOLD    = "hold"
    ASK     = "ask"


# ─── DisclosureMode ───────────────────────────────────────────────
@unique
class DisclosureMode(str, Enum):
    """Content disclosure mode for scope compilation.
    Owner: ScopeCompiler (reads from SubDecisionIR).
    """
    RAW         = "raw"
    SUMMARY     = "summary"
    REDACTED    = "redacted"
    STATUS_ONLY = "status_only"
    NONE        = "none"


# ─── ReasonCode ───────────────────────────────────────────────────
@unique
class ReasonCode(str, Enum):
    """Reason codes linking constraints to policy/plan outputs.
    Owner: CandidateEvaluator → SubDecisionIR.
    """
    PRECONDITION_INVALIDATED  = "precondition_invalidated"
    ROUTE_RESOLUTION_REQUIRED = "route_resolution_required"
    USER_CONFIRMATION         = "user_confirmation_required"
    SECURITY_OR_SAFETY        = "security_or_safety_block"
    MEMORY_CONFLICT           = "memory_conflict"
    PRECONDITION_CHANGED      = "precondition_changed"


# ─── PlanStepType ─────────────────────────────────────────────────
@unique
class PlanStepType(str, Enum):
    """Typed plan step verbs.
    Owner: BasePlanBlueprint + PlanCompiler.
    """
    READ      = "read"
    VERIFY    = "verify"
    REDACT    = "redact"
    SUMMARIZE = "summarize"
    DISPATCH  = "dispatch"
    GUARD     = "guard"
    CLARIFY   = "clarify"
    UPDATE    = "update"
    SCHEDULE  = "schedule"
    TOGGLE    = "toggle"
    PAY       = "pay"
"""
from __future__ import annotations

from enum import Enum, unique


# ─── Domain ───────────────────────────────────────────────────────
@unique
class Domain(str, Enum):
    CONTENT  = "CONTENT"
    PAYMENT  = "PAYMENT"
    DEVICE   = "DEVICE"
    CALENDAR = "CALENDAR"
    MEMORY   = "MEMORY"
    UNKNOWN  = "UNKNOWN"
"""

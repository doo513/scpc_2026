from __future__ import annotations

import csv
import json
import sys
from pathlib import Path
from utils.schema_check import validate_answer

BASE_DIR = Path(__file__).resolve().parent


def validate_submission() -> None:
    path = BASE_DIR / "submission.csv"
    if not path.is_file():
        print(f"Error: submission.csv not found at {path}")
        sys.exit(1)
        
    csv.field_size_limit(10000000)
    with open(path, encoding="utf-8") as f:
        reader = csv.reader(f)
        header = next(reader)
        if header != ["submission"]:
            print(f"Error: bad CSV header: {header}")
            sys.exit(1)
        try:
            row = next(reader)
        except StopIteration:
            print("Error: empty CSV data row")
            sys.exit(1)
        data_str = row[0]
        
    try:
        payload = json.loads(data_str)
    except Exception as e:
        print(f"Error: failed to parse JSON from submission cell: {e}")
        sys.exit(1)
        
    if payload.get("schema") != "scpc.final.answer.v1":
        print(f"Error: bad schema in payload: {payload.get('schema')}")
        sys.exit(1)
        
    answers = payload.get("answers", {})
    if not isinstance(answers, dict):
        print("Error: answers must be a dictionary")
        sys.exit(1)
        
    if len(answers) != 700:
        print(f"Warning: expected 700 answers, got {len(answers)}")
        
    errors = 0
    for task_id, ans in answers.items():
        try:
            validate_answer(ans)
        except Exception as e:
            print(f"Error in task {task_id}: {e}")
            errors += 1
            
    if errors > 0:
        print(f"Validation failed: {errors} errors found.")
        sys.exit(1)
    else:
        print("Validation succeeded: submission.csv follows the schema perfectly.")


if __name__ == "__main__":
    validate_submission()

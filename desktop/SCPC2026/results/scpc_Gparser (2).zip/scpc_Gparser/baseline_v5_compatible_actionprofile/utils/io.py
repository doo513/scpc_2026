from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

PROJECT_DIR = Path(__file__).resolve().parent.parent


def find_data_dir() -> Path:
    env = os.environ.get("SCPC_DATA_DIR")
    candidates = []
    if env:
        candidates.append(Path(env))
    candidates.extend(
        [
            PROJECT_DIR.parent,  # Downloads/data/data/
            PROJECT_DIR,
            Path.cwd(),
            Path.cwd().parent,
        ]
    )
    for candidate in candidates:
        if (candidate / "screening_tasks.jsonl").is_file():
            return candidate
    raise FileNotFoundError("screening_tasks.jsonl not found; set SCPC_DATA_DIR")


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    with open(path, encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def load_json(path: Path) -> dict[str, Any]:
    with open(path, encoding="utf-8") as f:
        return json.load(f)

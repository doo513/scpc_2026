from __future__ import annotations

import csv
import json
from pathlib import Path
from collections import Counter
from .io import find_data_dir, load_jsonl


def resolve_marker_trace(task: dict) -> str | None:
    state = task.get("device_state") or {}
    records = state.get("records") or []
    objects = state.get("objects") or []
    
    trace = None
    refs = None
    for r in records:
        if r.get("type") == "focal_resolution_trace":
            trace = r.get("value")
        elif r.get("type") == "focal_marker_refs":
            refs = r.get("value")
            
    if not trace or not refs:
        return None
        
    latest_phase = trace.get("latest_phase")
    if not latest_phase and trace.get("phase_source") == "route_binding_order":
        order = ""
        for r in records:
            if r.get("type") == "route_binding_order":
                order = r.get("value")
        rule = trace.get("latest_phase_rule", {})
        latest_phase = rule.get(order) or rule.get("fallback")
        
    marker = trace.get("phase_to_marker", {}).get(latest_phase)
    ref_code = refs.get("marker_to_ref", {}).get(marker)
    if not ref_code:
        return None
        
    for o in objects:
        ref = (o.get("attrs") or {}).get("ref_code")
        if ref == ref_code:
            return o.get("id")
            
    return None


def generate_distribution_report(path: Path) -> str:
    csv.field_size_limit(10000000)
    with open(path, encoding="utf-8") as f:
        r = csv.reader(f)
        next(r)
        payload = json.loads(next(r)[0])
        
    answers = payload.get("answers", {})
    
    # Load screening tasks to check marker trace matching
    try:
        data_dir = find_data_dir()
        screening_tasks = load_jsonl(data_dir / "screening_tasks.jsonl")
        task_map = {t["id"]: t for t in screening_tasks}
    except Exception as e:
        task_map = {}
        print(f"Warning: could not load screening tasks for marker trace match check: {e}")
        
    controls = []
    modes = []
    targets = []
    confirmations = 0
    plan_sequences = []
    excluded_fields_count = 0
    marker_trace_possible = 0
    marker_trace_match = 0
    
    for task_id, ans in answers.items():
        controls.append(ans.get("control"))
        scope = ans.get("content_scope", {})
        modes.append(scope.get("mode"))
        targets.append(ans.get("target"))
        
        if ans.get("policy", {}).get("requires_confirmation"):
            confirmations += 1
            
        plan_seq = tuple(ev.get("verb") for ev in ans.get("plan_events", []))
        plan_sequences.append(plan_seq)
        
        excluded_fields_count += len(scope.get("excluded_fields", []))
        
        # Check marker trace
        task = task_map.get(task_id)
        if task:
            expected_focal = resolve_marker_trace(task)
            if expected_focal:
                marker_trace_possible += 1
                if ans.get("focal_id") == expected_focal:
                    marker_trace_match += 1
                    
    lines = [
        f"# Screening Distribution Report for {path.name}",
        "",
        "## Control Distribution",
    ]
    for k, v in sorted(Counter(controls).items()):
        lines.append(f"- `{k}`: {v}")
        
    lines.append("")
    lines.append("## Scope Mode Distribution")
    for k, v in sorted(Counter(modes).items()):
        lines.append(f"- `{k}`: {v}")
        
    lines.append("")
    lines.append("## Target Top 30")
    for k, v in sorted(Counter(targets).items(), key=lambda x: x[1], reverse=True)[:30]:
        lines.append(f"- `{k}`: {v}")
        
    lines.append("")
    lines.append("## Policy Requires Confirmation Distribution")
    lines.append(f"- `True`: {confirmations}")
    lines.append(f"- `False`: {len(answers) - confirmations}")
    
    lines.append("")
    lines.append("## Plan Sequence Distribution")
    seq_counter = Counter(plan_sequences)
    for k, v in seq_counter.most_common(20):
        seq_str = " -> ".join(k)
        lines.append(f"- `[{seq_str}]`: {v}")
        
    lines.append("")
    lines.append("## Custom Metric Counts")
    lines.append(f"- **extra excluded count**: {excluded_fields_count}")
    lines.append(f"- **focal marker trace match count**: {marker_trace_match} / {marker_trace_possible}")
    lines.append(f"- **memory_store count**: {targets.count('memory_store')}")
    lines.append(f"- **status_only count**: {modes.count('status_only')}")
    lines.append(f"- **redacted count**: {modes.count('redacted')}")
    lines.append(f"- **proceed count**: {controls.count('proceed')}")
    
    return "\n".join(lines)

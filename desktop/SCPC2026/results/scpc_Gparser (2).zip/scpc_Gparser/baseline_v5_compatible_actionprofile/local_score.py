from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from run_submission import run_tasks
from utils.io import find_data_dir, load_jsonl

WEIGHTS = {
    "focal": 0.18,
    "target": 0.12,
    "control": 0.18,
    "content_scope": 0.17,
    "policy": 0.13,
    "plan": 0.18,
    "semantic_response": 0.04,
    "counterfactual": 0.0,
}

BASE_DIR = Path(__file__).resolve().parent


def _txt(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _set(value: Any) -> set[str]:
    if isinstance(value, list):
        raw = value
    elif value is None:
        raw = []
    else:
        raw = [value]
    return {_txt(x).strip().lower() for x in raw if _txt(x).strip()}


def _f1(pred: set[str], ref: set[str]) -> float:
    if not pred and not ref:
        return 1.0
    if not pred or not ref:
        return 0.0
    hit = len(pred & ref)
    if hit == 0:
        return 0.0
    precision = hit / len(pred)
    recall = hit / len(ref)
    return 2 * precision * recall / (precision + recall)


def _similar_scope(pred: dict[str, Any], ref: dict[str, Any]) -> float:
    pred = pred or {}
    ref = ref or {}
    return (
        0.4 * (_txt(pred.get("mode")) == _txt(ref.get("mode")))
        + 0.25 * _f1(_set(pred.get("allowed_fields")), _set(ref.get("allowed_fields")))
        + 0.25 * _f1(_set(pred.get("excluded_fields")), _set(ref.get("excluded_fields")))
        + 0.1 * (bool(pred.get("requires_user_confirmation")) == bool(ref.get("requires_user_confirmation")))
    )


def _similar_policy(pred: dict[str, Any], ref: dict[str, Any]) -> float:
    pred = pred or {}
    ref = ref or {}
    return (
        0.45 * _f1(_set(pred.get("risk_flags")), _set(ref.get("risk_flags")))
        + 0.35 * _f1(_set(pred.get("violations")), _set(ref.get("violations")))
        + 0.2 * (bool(pred.get("requires_confirmation")) == bool(ref.get("requires_confirmation")))
    )


def _event_sim(pred: Any, ref: Any) -> float:
    if not isinstance(pred, dict) or not isinstance(ref, dict):
        return 0.0
    if _txt(pred.get("verb")) != _txt(ref.get("verb")):
        return 0.0
    return min(
        1.0,
        0.4
        + 0.3 * (_txt(pred.get("target")) == _txt(ref.get("target")))
        + 0.3 * (_txt(pred.get("args")) == _txt(ref.get("args"))),
    )


def _plan_score(pred: Any, ref: Any) -> float:
    pred = pred if isinstance(pred, list) else []
    ref = ref if isinstance(ref, list) else []
    if not ref:
        return 1.0 if not pred else 0.5
    used: set[int] = set()
    unordered = 0.0
    for expected in ref:
        best, best_idx = 0.0, -1
        for idx, actual in enumerate(pred):
            if idx in used:
                continue
            score = _event_sim(actual, expected)
            if score > best:
                best, best_idx = score, idx
        if best_idx >= 0:
            used.add(best_idx)
        unordered += best
    ordered = 0.0
    cursor = 0
    for expected in ref:
        best, best_idx = 0.0, -1
        for idx in range(cursor, len(pred)):
            score = _event_sim(pred[idx], expected)
            if score > best:
                best, best_idx = score, idx
        if best_idx >= 0:
            cursor = best_idx + 1
        ordered += best
    return max(0.0, 0.5 * (unordered / len(ref)) + 0.5 * (ordered / len(ref)) - min(0.3, 0.06 * max(0, len(pred) - len(used))))


def score_answer(pred: dict[str, Any], ref: dict[str, Any]) -> dict[str, float]:
    focal = 1.0 if _txt(pred.get("focal_id")) == _txt(ref.get("focal_id")) else 0.0
    target = focal * (1.0 if _txt(pred.get("target")) == _txt(ref.get("target")) else 0.0)
    control = focal * (1.0 if _txt(pred.get("control")) == _txt(ref.get("control")) else 0.0)
    downstream = target * control
    return {
        "focal": focal,
        "target": target,
        "control": control,
        "content_scope": downstream * _similar_scope(pred.get("content_scope"), ref.get("content_scope")),
        "policy": downstream * _similar_policy(pred.get("policy"), ref.get("policy")),
        "plan": downstream * _plan_score(pred.get("plan_events"), ref.get("expected_events")),
        "semantic_response": 0.0,
        "counterfactual": 0.0,
    }


def score_dev() -> dict[str, Any]:
    data_dir = find_data_dir()
    tasks = load_jsonl(data_dir / "dev_tasks.jsonl")
    refs = json.loads((data_dir / "dev_answers.json").read_text(encoding="utf-8"))["answers"]
    payload = run_tasks(tasks)
    rows: list[dict[str, float]] = []
    wrong: list[tuple[str, dict[str, float]]] = []
    for task_id, ref in refs.items():
        scores = score_answer(payload["answers"][task_id], ref)
        rows.append(scores)
        if any(scores[k] < 1.0 for k in ("focal", "target", "control", "content_scope", "policy", "plan")):
            wrong.append((task_id, scores))
            
    axes = {k: round(sum(row[k] for row in rows) / len(rows), 4) for k in WEIGHTS}
    overall = round(sum(sum(row[k] * WEIGHTS[k] for k in WEIGHTS) for row in rows) / len(rows), 4)
    result = {"overall": overall, "n": len(rows), "axes": axes, "wrong": len(wrong)}
    
    # Generate reports/dev_score_report.md
    report_lines = [
        "# SCPC Dev Score Report",
        "",
        f"- **Overall Score**: `{overall:.4f}`",
        f"- **Total Dev Tasks**: {len(rows)}",
        f"- **Wrong Tasks**: {len(wrong)}",
        "",
        "## Axis Scores",
        "| Axis | Score | Weight |",
        "| --- | --- | --- |",
    ]
    for k in sorted(WEIGHTS.keys()):
        report_lines.append(f"| {k} | {axes[k]:.4f} | {WEIGHTS[k]:.2f} |")
        
    reports_dir = BASE_DIR / "reports"
    reports_dir.mkdir(parents=True, exist_ok=True)
    (reports_dir / "dev_score_report.md").write_text("\n".join(report_lines), encoding="utf-8")
    
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return result


if __name__ == "__main__":
    score_dev()

from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any

from harness import FinalHarness
from core.spec import FIXED_META, FIXED_META as FIXED_META_DICT
from utils.io import find_data_dir, load_jsonl
from core.consistency import ConsistencyValidator
from core.task_view import TaskView

SUBMISSION_SCHEMA = "scpc.final.answer.v1"
BASE_DIR = Path(__file__).resolve().parent


def _validate_payload(payload: dict[str, Any], expected_ids: set[str]) -> None:
    if payload.get("schema") != SUBMISSION_SCHEMA:
        raise ValueError("bad schema")
    answers = payload.get("answers")
    if not isinstance(answers, dict):
        raise ValueError("answers missing")
    ids = set(answers)
    missing, extra = expected_ids - ids, ids - expected_ids
    if missing or extra:
        raise ValueError(f"answer id mismatch missing={len(missing)} extra={len(extra)}")


def run_tasks(tasks: list[dict[str, Any]]) -> dict[str, Any]:
    harness = FinalHarness()
    sessions: dict[str, dict[str, Any]] = {}
    raw_answers: dict[str, Any] = {}
    
    # Reset consistency validator state
    ConsistencyValidator.reset()
    
    # Session state initialization
    harness.prepare(tasks)
    
    ordered = sorted(tasks, key=lambda t: (str(t.get("session_id", "")), int(t.get("turn_index", 0)), str(t.get("id", ""))))
    for task in ordered:
        session = sessions.setdefault(str(task.get("session_id", "")), {})
        ans = harness.answer_task(task, session)
        raw_answers[str(task["id"])] = ans
        
        # Parse view and validate
        view = TaskView(task, session)
        # Check evidence graph and profile inside the raw answer
        evidence = ans.get("evidence")
        profile = ans.get("profile")
        ConsistencyValidator.validate_or_warn(ans, view, evidence, profile)
        
    # Clean answers for the final payload to strictly follow the schema
    clean_answers = {}
    for task_id, ans in raw_answers.items():
        clean_answers[task_id] = {
            "focal_id": ans["focal_id"],
            "target": ans["target"],
            "control": ans["control"],
            "content_scope": ans["content_scope"],
            "policy": ans["policy"],
            "plan_events": ans["plan_events"]
        }
        
    payload = {
        "schema": SUBMISSION_SCHEMA,
        "meta": {
            "harness_name": "scpc_action_profile_first_harness",
            "uses_external_api": FIXED_META_DICT["uses_external_api"],
            "fixed_slm_policy": FIXED_META_DICT["fixed_slm_policy"],
            "model_id": FIXED_META_DICT["model_id"],
            "temperature": FIXED_META_DICT.get("temperature", 0.0),
            "seed": FIXED_META_DICT.get("seed", 42),
        },
        "answers": clean_answers,
    }
    # Keep the raw answers with metadata inside payload under a private field for scoring & report tools
    payload["_raw_answers"] = raw_answers
    return payload


def run_submission() -> None:
    data_dir = find_data_dir()
    tasks = load_jsonl(data_dir / "screening_tasks.jsonl")
    payload = run_tasks(tasks)
    _validate_payload(payload, {str(t["id"]) for t in tasks})
    
    # Write consistency report
    ConsistencyValidator.write_report()
    
    # Strip private fields before writing the CSV
    csv_payload = {k: v for k, v in payload.items() if not k.startswith("_")}
    
    out = BASE_DIR / "submission.csv"
    with out.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(["submission"])
        writer.writerow([json.dumps(csv_payload, ensure_ascii=False, separators=(",", ":"))])
    print(f"wrote {out}")


if __name__ == "__main__":
    run_submission()

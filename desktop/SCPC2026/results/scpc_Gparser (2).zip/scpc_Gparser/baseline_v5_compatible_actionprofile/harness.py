from __future__ import annotations

from typing import Any
from core.task_view import TaskView
from core.evidence_graph import EvidenceGraph
from core.action_profile import ActionProfile
from rules.focal import FocalResolver
from rules.target import TargetResolver
from rules.action_profile import ActionProfileDecider, control_from_profile
from rules.scope_policy import ScopePolicyJointBuilder
from rules.plan import PlanTemplateBuilder


class FinalHarness:
    def __init__(self):
        self.memory_bank: dict[str, Any] = {}

    def prepare(self, tasks: list[dict[str, Any]]) -> None:
        self.memory_bank.clear()

    def answer_task(self, task: dict[str, Any], session: dict[str, Any]) -> dict[str, Any]:
        # 1. Input normalization
        view = TaskView(task, session)
        self._remember(view, session)

        # 2. Gather target evidence (initial, without focal_id for sensitive fields)
        evidence = EvidenceGraph.from_view(view)

        # 3. Resolve focal object ID
        focal_id = FocalResolver.resolve(view, evidence, session)

        # 4. Resolve target recipient/store
        pre_profile = ActionProfileDecider.pre_decide(view, evidence)
        target = TargetResolver.resolve(view, evidence, focal_id, pre_profile, self.memory_bank)

        # 5. Gather evidence again now that focal_id is resolved (for sensitive fields overlap check)
        evidence = EvidenceGraph.from_view(view, focal_id)

        # 6. Decide ActionProfile
        profile = ActionProfileDecider.decide(view, evidence, focal_id, target)

        # 7. Generate content scope & policy
        content_scope, policy = ScopePolicyJointBuilder.build(
            view=view,
            evidence=evidence,
            profile=profile,
            focal_id=focal_id,
            target=target,
        )

        # 8. Generate plan events
        plan_events = PlanTemplateBuilder.build(
            view=view,
            evidence=evidence,
            profile=profile,
            focal_id=focal_id,
            target=target,
            content_scope=content_scope,
            policy=policy,
        )

        answer = {
            "focal_id": focal_id,
            "target": target,
            "control": control_from_profile(profile),
            "content_scope": content_scope,
            "policy": policy,
            "plan_events": plan_events,
            # Pass evidence and profile as metadata for validation and error analyses
            "evidence": evidence,
            "profile": profile,
        }

        # 9. Update session memory (fallback targets)
        self.update_session_memory(view, evidence, profile, answer, session)

        return answer

    def _remember(self, view: TaskView, session: dict[str, Any]) -> None:
        mem = session.setdefault("memory", {})
        for value in view.record_values("persistent_memory_write"):
            if not isinstance(value, dict):
                continue
            key = str(value.get("memory_key") or value.get("person") or "")
            if key:
                mem[key] = value
                self.memory_bank[key] = value

    def update_session_memory(
        self,
        view: TaskView,
        evidence: EvidenceGraph,
        profile: ActionProfile,
        answer: dict[str, Any],
        session: dict[str, Any],
    ) -> None:
        session["last_focal_id"] = answer["focal_id"]
        session["last_target"] = answer["target"]

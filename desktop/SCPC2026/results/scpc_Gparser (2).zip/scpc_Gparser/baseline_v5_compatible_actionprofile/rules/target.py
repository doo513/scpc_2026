from __future__ import annotations

from typing import Any
from core.task_view import TaskView
from core.evidence_graph import EvidenceGraph
from core.action_profile import ActionProfile
from rules.action_profile import control_from_profile


class TargetResolver:
    @staticmethod
    def resolve(
        view: TaskView,
        evidence: EvidenceGraph,
        focal_id: str,
        pre_profile: ActionProfile,
        memory_bank: dict[str, Any] | None = None,
    ) -> str:
        control = control_from_profile(pre_profile)
        focal = view.objects_by_id().get(focal_id) if focal_id else {}
        
        # 1. Local update check: only memory_store if control is proceed!
        from core.evidence_graph import LOCAL_UPDATE_PHRASES
        is_local_upd = any(phrase in view.prompt for phrase in LOCAL_UPDATE_PHRASES)
        if control == "proceed" and is_local_upd:
            return "memory_store"
            
        if view.latest_record_value("persistent_memory_write"):
            return "memory_store"
            
        # 2. target_changed_after_turn
        changed = view.latest_record_value("target_changed_after_turn")
        if isinstance(changed, str) and changed and "superseded" not in changed and "prior_success" not in changed:
            return changed
            
        # 3. Memory recall target
        recalled = TargetResolver._target_from_memory_recall(view, memory_bank)
        if recalled:
            return recalled
            
        # 4. Hold or Ask targets check
        if control in ("hold", "ask"):
            return TargetResolver._blocked_or_ask_target(view, focal, control, memory_bank)
            
        # 5. Resolved target
        resolved = view.latest_record_value("resolved_target")
        if isinstance(resolved, str) and resolved:
            return resolved
            
        # 6. Focal attrs fallback
        attrs = focal.get("attrs") or {} if focal else {}
        for key in ("recipient", "target", "channel", "app", "merchant", "name", "attendee"):
            if attrs.get(key):
                return str(attrs[key])
                
        # 7. Session last target fallback / user fallback
        return str(view.session_state.get("last_target") or "user")

    @staticmethod
    def _target_from_memory_recall(view: TaskView, memory_bank: dict[str, Any] | None = None) -> str:
        session = view.session_state
        mem_dict = session.get("memory") or {}
        memory_bank = memory_bank or {}
        
        for value in reversed(view.record_values("persistent_memory_recall")):
            if isinstance(value, dict):
                key = str(value.get("memory_key") or "")
                memory = {}
                if key:
                    memory = mem_dict.get(key) or memory_bank.get(key) or {}
                if isinstance(memory, dict):
                    if value.get("memory_class") == "prior_result":
                        for key2 in ("last_success_target", "approval_channel", "preferred_channel", "health_channel"):
                            if memory.get(key2):
                                return str(memory[key2])
                    if value.get("memory_class") == "standing_constraint":
                        for key2 in ("last_success_target", "approval_channel", "preferred_channel"):
                            if memory.get(key2):
                                return str(memory[key2])
                    if "조명" in view.prompt or "날이 어두워질" in view.prompt:
                        if memory.get("dusk_room"):
                            return str(memory["dusk_room"])
                    if "검진" in view.prompt or "점검" in view.prompt:
                        for key2 in ("health_channel", "preferred_channel", "approval_channel"):
                            if memory.get(key2):
                                return str(memory[key2])
                    for key2 in ("preferred_channel", "health_channel", "approval_channel", "last_success_target"):
                        if memory.get(key2):
                            return str(memory[key2])
                person = str(value.get("person") or "")
                if "조명" in view.prompt or "날이 어두워질" in view.prompt:
                    return "living_room"
                if "검진" in view.prompt or "점검" in view.prompt:
                    if person == "jimin":
                        return "clinic_portal"
                    return "caregiver"
                for key in ("preferred_channel", "health_channel", "approval_channel", "last_success_target"):
                    if value.get(key):
                        return str(value[key])
        return ""

    @staticmethod
    def _asks_user(view: TaskView) -> bool:
        prompt = view.prompt
        if any(p in prompt for p in ["누구에게 어떤 범위", "사용자에게", "먼저 확인", "다시 확인", "새 전제", "미확정", "결론을 내릴 수 없다"]):
            return True
        if view.latest_record_value("duration_ambiguous"):
            return True
        if view.latest_record_value("amount_changed") or view.latest_record_value("memory_conflict"):
            return False
        if view.latest_record_value("ambiguous_focal") and not view.latest_record_value("target_changed_after_turn"):
            return False
        return False

    @staticmethod
    def _hold_to_user(view: TaskView) -> bool:
        prompt = view.prompt
        if any(p in prompt for p in ["더 진행하면 안", "실행하면 안", "확인 전에는 처리하지", "이전 허용 조건이 취소", "처리 전제가 사라", "허용 근거가 최신 상태에서 깨", "과거 승인에 기대면 안"]):
            return True
        consent_val = view.latest_record_value("consent")
        if isinstance(consent_val, dict) and consent_val.get("status") == "revoked":
            return False
        if isinstance(consent_val, str) and consent_val == "revoked":
            return False
        if view.latest_record_value("security_alert") or view.latest_record_value("safety_mode"):
            return False
        return False

    @staticmethod
    def _blocked_or_ask_target(
        view: TaskView,
        focal: dict[str, Any],
        control: str,
        memory_bank: dict[str, Any] | None = None,
    ) -> str:
        recalled = TargetResolver._target_from_memory_recall(view, memory_bank)
        if control == "ask" and TargetResolver._asks_user(view) and not recalled:
            return "user"
        if control == "hold" and TargetResolver._hold_to_user(view):
            return "user"
        resolved = view.latest_record_value("resolved_target")
        if isinstance(resolved, str) and resolved:
            return resolved
        if recalled:
            return recalled
        attrs = focal.get("attrs") or {} if focal else {}
        for key in ("recipient", "target", "channel", "app", "merchant", "name", "attendee"):
            if attrs.get(key):
                return str(attrs[key])
        return str(view.session_state.get("last_target") or "user")

from __future__ import annotations

from typing import Any
from core.task_view import TaskView
from core.evidence_graph import EvidenceGraph
from core.action_profile import ActionProfile


class ActionProfileDecider:
    @staticmethod
    def pre_decide(view: TaskView, evidence: EvidenceGraph) -> ActionProfile:
        return ActionProfileDecider.decide_internal(view, evidence, {})

    @staticmethod
    def decide(view: TaskView, evidence: EvidenceGraph, focal_id: str, target: str) -> ActionProfile:
        focal = view.objects_by_id().get(focal_id) if focal_id else {}
        return ActionProfileDecider.decide_internal(view, evidence, focal)

    @staticmethod
    def decide_internal(view: TaskView, evidence: EvidenceGraph, focal: dict[str, Any]) -> ActionProfile:
        control = ActionProfileDecider._decide_control_v5(view, focal)
        
        if control == "hold":
            return ActionProfile.HARD_BLOCK
            
        elif control == "ask":
            if view.latest_record_value("memory_conflict"):
                return ActionProfile.MEMORY_CONFLICT_RESOLUTION
            elif view.latest_record_value("target_changed_after_turn") or view.latest_record_value("ambiguous_target"):
                return ActionProfile.TARGET_REBIND_REQUIRED
            elif view.latest_record_value("ambiguous_focal"):
                return ActionProfile.FALLBACK_CLARIFICATION
            else:
                return ActionProfile.EXPLICIT_CLARIFICATION
                
        elif control == "amend":
            return ActionProfile.EXTERNAL_REDACTED_DISPATCH
            
        else: # control == "proceed"
            is_local = ActionProfileDecider._is_local_update(view)
            if is_local:
                return ActionProfile.LOCAL_STATUS_UPDATE
                
            prompt = view.prompt.lower()
            if "요약" in prompt or "정리" in prompt:
                return ActionProfile.SAFE_DISPATCH_SUMMARY
                
            return ActionProfile.SAFE_DISPATCH_RAW

    @staticmethod
    def _is_local_update(view: TaskView) -> bool:
        from core.evidence_graph import LOCAL_UPDATE_PHRASES
        if view.latest_record_value("persistent_memory_write"):
            return True
        for phrase in LOCAL_UPDATE_PHRASES:
            if phrase in view.prompt:
                return True
        return False

    @staticmethod
    def _explicit_hold(view: TaskView, prompt: str, values_l: str) -> bool:
        from core.evidence_graph import HOLD_PHRASES
        
        # Check override local update in prompt (e.g. "최신 표현을 우선한다")
        is_override_local = False
        if ActionProfileDecider._is_local_update(view):
            prompt_l = prompt.lower()
            if any(kw in prompt_l for kw in ["최신 표현을 우선", "우선한다", "취소하고", "정정한 대로", "가장 최신이다"]):
                is_override_local = True

        consent_val = view.latest_record_value("consent")
        if isinstance(consent_val, dict) and consent_val.get("status") in ("revoked", "withdrawn", "denied"):
            if not is_override_local:
                return True
        if isinstance(consent_val, str) and consent_val in ("revoked", "withdrawn", "denied"):
            if not is_override_local:
                return True
            
        if view.latest_record_value("security_alert") and not ActionProfileDecider._is_local_update(view):
            return True
        if view.latest_record_value("safety_mode"):
            return True
            
        for phrase in HOLD_PHRASES:
            if phrase in prompt:
                return True
                
        if "phishing" in values_l or "피싱" in values_l:
            return True
        return False

    @staticmethod
    def _explicit_ask(view: TaskView, prompt: str) -> bool:
        from core.evidence_graph import ASK_PHRASES
        if view.latest_record_value("payment_policy") or view.latest_record_value("memory_conflict") or view.latest_record_value("duration_ambiguous"):
            return True
        if view.latest_record_value("target_changed_after_turn"):
            return True
        for phrase in ASK_PHRASES:
            if phrase in prompt:
                if not ActionProfileDecider._is_local_update(view):
                    return True
        return False

    @staticmethod
    def _decide_control_v5(view: TaskView, focal: dict[str, Any]) -> str:
        prompt = view.prompt
        prompt_l = prompt.lower()
        values_l = " ".join(f"{r.get('type')} {str(r.get('value'))}" for r in view.records).lower()

        if ActionProfileDecider._explicit_hold(view, prompt, values_l):
            return "hold"
        if ActionProfileDecider._is_local_update(view):
            return "proceed"
        if ActionProfileDecider._explicit_ask(view, prompt):
            return "ask"
        
        memory_ctrl = ActionProfileDecider._memory_or_domain_control(view, focal)
        if memory_ctrl:
            return memory_ctrl
            
        boundary_ctrl = ActionProfileDecider._control_from_boundary(view)
        if boundary_ctrl:
            return boundary_ctrl
            
        if ActionProfileDecider._unresolved_ambiguity(view):
            return "ask"
            
        if ActionProfileDecider._external_redactable(view, prompt_l):
            return "amend"
            
        return "proceed"

    @staticmethod
    def _control_from_boundary(view: TaskView) -> str:
        boundary = str(view.latest_record_value("share_boundary_update") or "")
        if boundary == "dispatch_blocked_until_binding":
            amend_phrases = ["식별 가능한 세부값을 제외", "세부값을 제외", "요약만 공유", "민감 내용은 알아서 처리", "위치나 나이 같은 민감"]
            if any(p in view.prompt for p in amend_phrases):
                return "amend"
            if view.latest_record_value("guardrail_ladder_signal"):
                return "hold"
            if view.latest_record_value("ambiguous_focal") and view.latest_record_value("dispatch_authority_check") == "user_binding_pending":
                return "hold"
            return ""
            
        if boundary == "local_update_boundary":
            ambiguous = str(view.latest_record_value("ambiguous_target") or "")
            if view.latest_record_value("ambiguous_focal"):
                return "proceed"
            if ambiguous == "stored_channel_or_visible_recipient":
                return "amend"
            if ambiguous == "approved_channel_or_visible_recipient":
                return "ask"
            if ambiguous == "surface_recipient_and_resolved_target_both_recent":
                return "amend"
                
        if boundary in ("redacted_external_boundary", "redacted_after_selection_boundary"):
            if str(view.latest_record_value("ambiguous_target") or "") == "surface_recipient_and_resolved_target_both_recent":
                return "ask"
            if str(view.latest_record_value("ambiguous_target") or "") == "stored_channel_or_visible_recipient" and (
                "검진" in view.prompt or "점검" in view.prompt
            ):
                return "ask"
            if view.latest_record_value("guardrail_ladder_signal") and view.latest_record_value("dispatch_authority_check") == "internal_binding_confirmed":
                return "proceed"
            return "amend"
        return ""

    @staticmethod
    def _memory_or_domain_control(view: TaskView, focal: dict[str, Any]) -> str:
        if view.latest_record_value("enterprise_policy_recall"):
            return "amend"
        if view.latest_record_value("ops_memory_recall"):
            return "ask" if view.latest_record_value("target_changed_after_turn") else "amend"
        if view.latest_record_value("temporary_override_allowed"):
            return "amend"
        if view.latest_record_value("persistent_memory_recall") and "쿠폰" in view.prompt and not view.latest_record_value("payment_policy"):
            return "hold"
        if focal.get("type") == "health_record" and view.latest_record_value("external_share_policy") == "doctor_note_forbidden":
            return "hold"
        if view.latest_record_value("ambiguous_focal") and view.latest_record_value("session_share_policy") == "normal":
            return "ask"
        return ""

    @staticmethod
    def _unresolved_ambiguity(view: TaskView) -> bool:
        if not (view.latest_record_value("ambiguous_target") or view.latest_record_value("ambiguous_focal")):
            return False
        boundary = str(view.latest_record_value("share_boundary_update") or "")
        authority = str(view.latest_record_value("dispatch_authority_check") or "")
        candidates = str(view.latest_record_value("route_candidate_snapshot") or "")
        if boundary == "local_update_boundary":
            return False
        if authority in ("authority_incomplete", "user_binding_pending") and boundary == "dispatch_blocked_until_binding":
            return True
        if candidates == "external_candidates_present" and authority != "internal_binding_confirmed" and not boundary.startswith("redacted"):
            return True
        return False

    @staticmethod
    def _external_redactable(view: TaskView, prompt_l: str) -> bool:
        amend_phrases = ["식별 가능한 세부값을 제외", "세부값을 제외", "요약만 공유", "민감 내용은 알아서 처리", "위치나 나이 같은 민감"]
        if any(p in view.prompt for p in amend_phrases):
            return True
        if view.latest_record_value("external_share_policy"):
            return True
        boundary = str(view.latest_record_value("share_boundary_update") or "")
        if boundary in ("redacted_external_boundary", "redacted_after_selection_boundary"):
            return True
        if view.latest_record_value("ambiguous_target") and view.latest_record_value("resolved_target"):
            return True
        if view.latest_record_value("session_share_policy") == "strict" and view.latest_record_value("resolved_target"):
            return True
        return False


def control_from_profile(profile: ActionProfile) -> str:
    mapping = {
        ActionProfile.HARD_BLOCK: "hold",
        ActionProfile.EXPLICIT_CLARIFICATION: "ask",
        ActionProfile.LOCAL_STATUS_UPDATE: "proceed",
        ActionProfile.TARGET_REBIND_REQUIRED: "ask",
        ActionProfile.MEMORY_CONFLICT_RESOLUTION: "ask",
        ActionProfile.EXTERNAL_REDACTED_DISPATCH: "amend",
        ActionProfile.SAFE_DISPATCH_SUMMARY: "proceed",
        ActionProfile.SAFE_DISPATCH_RAW: "proceed",
        ActionProfile.FALLBACK_CLARIFICATION: "ask",
    }
    return mapping.get(profile, "ask")

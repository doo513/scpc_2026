from __future__ import annotations

import json
from typing import Any


class TaskView:
    def __init__(self, task: dict[str, Any], session_state: dict[str, Any] | None = None):
        self.task = task if isinstance(task, dict) else {}
        self.session_state = session_state if isinstance(session_state, dict) else {}
        
        state = self.task.get("device_state") or {}
        self._objects = [o for o in state.get("objects", []) if isinstance(o, dict)]
        self._records = [r for r in state.get("records", []) if isinstance(r, dict)]
        self._history = [h for h in self.task.get("visible_history", []) if isinstance(h, dict)]
        self._memory = [m for m in self.task.get("personal_memory", []) if isinstance(m, dict)]
        
        self._records_by_type: dict[str, list[dict[str, Any]]] = {}
        for r in self._records:
            self._records_by_type.setdefault(str(r.get("type", "")), []).append(r)
            
        self._objects_by_id = {str(o.get("id")): o for o in self._objects if o.get("id") is not None}
        self._objects_by_ref_code = {}
        for o in self._objects:
            ref = str((o.get("attrs") or {}).get("ref_code") or "")
            if ref:
                self._objects_by_ref_code[ref] = o

    @property
    def task_id(self) -> str:
        return str(self.task.get("id") or "")

    @property
    def session_id(self) -> str:
        return str(self.task.get("session_id") or "")

    @property
    def turn_index(self) -> int:
        try:
            return int(self.task.get("turn_index", 1))
        except (ValueError, TypeError):
            return 1

    @property
    def prompt(self) -> str:
        val = self.task.get("prompt")
        if val is None:
            return ""
        if isinstance(val, str):
            return val
        return json.dumps(val, ensure_ascii=False, sort_keys=True, separators=(",", ":"))

    @property
    def objects(self) -> list[dict[str, Any]]:
        return self._objects

    @property
    def records(self) -> list[dict[str, Any]]:
        return self._records

    def objects_by_id(self) -> dict[str, dict[str, Any]]:
        return self._objects_by_id

    def objects_by_ref_code(self) -> dict[str, dict[str, Any]]:
        return self._objects_by_ref_code

    def records_by_type(self) -> dict[str, list[dict[str, Any]]]:
        return self._records_by_type

    def latest_record(self, record_type: str) -> dict[str, Any] | None:
        records = self._records_by_type.get(record_type)
        return records[-1] if records else None

    def record_values(self, record_type: str) -> list[Any]:
        records = self._records_by_type.get(record_type, [])
        return [r.get("value") for r in records]

    def latest_record_value(self, record_type: str) -> Any:
        rec = self.latest_record(record_type)
        return rec.get("value") if rec else None

    def contains_for_object(self, object_id: str) -> set[str]:
        obj = self._objects_by_id.get(object_id)
        if not obj:
            return set()
        attrs = obj.get("attrs") or {}
        raw = attrs.get("contains")
        if raw is None:
            raw = attrs.get("fields")
        return {str(x) for x in raw} if isinstance(raw, list) else set()

    def object_type(self, object_id: str) -> str | None:
        obj = self._objects_by_id.get(object_id)
        return str(obj.get("type")) if obj else None

    def latest_clause(self) -> str:
        prompt = self.prompt
        keywords = [
            "단,", "단 ",
            "다만",
            "하지만",
            "마지막으로",
            "방금 정정한 대로",
            "이전 말은 취소하고",
            "외부로 보내지 말고",
            "공유하지 말고",
            "상태만 갱신",
            "먼저 확인",
            "승인 전까지",
            "확정 전까지",
            "허용 근거가 사라졌으면"
        ]
        latest_idx = -1
        for kw in keywords:
            idx = prompt.rfind(kw)
            if idx > latest_idx:
                latest_idx = idx
        if latest_idx != -1:
            return prompt[latest_idx:]
        return ""

    def visible_history_text(self) -> str:
        parts = []
        for h in self._history:
            summary = h.get("summary")
            if summary:
                parts.append(str(summary))
            else:
                parts.append(json.dumps(h, ensure_ascii=False, sort_keys=True, separators=(",", ":")))
        return " ".join(parts)

    def personal_memory_entries(self) -> list[dict[str, Any]]:
        return self._memory

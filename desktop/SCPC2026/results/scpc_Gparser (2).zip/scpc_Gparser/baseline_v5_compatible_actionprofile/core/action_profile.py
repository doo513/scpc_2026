from __future__ import annotations

from enum import Enum


class ActionProfile(str, Enum):
    HARD_BLOCK = "hard_block"
    EXPLICIT_CLARIFICATION = "explicit_clarification"
    LOCAL_STATUS_UPDATE = "local_status_update"
    TARGET_REBIND_REQUIRED = "target_rebind_required"
    MEMORY_CONFLICT_RESOLUTION = "memory_conflict_resolution"
    EXTERNAL_REDACTED_DISPATCH = "external_redacted_dispatch"
    SAFE_DISPATCH_SUMMARY = "safe_dispatch_summary"
    SAFE_DISPATCH_RAW = "safe_dispatch_raw"
    FALLBACK_CLARIFICATION = "fallback_clarification"

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any
from .task_view import TaskView

HOLD_PHRASES = [
    "더 진행하면 안",
    "실행하면 안",
    "실행을 막",
    "멈춰야",
    "처리하지 않는다",
    "처리 전제가 사라",
    "전제를 무효화",
    "허용 근거가 최신 상태에서 깨",
    "과거 승인에 기대면 안",
    "이전 허용 조건이 취소",
]

ASK_PHRASES = [
    "다시 확인",
    "사용자 확인",
    "먼저 확인",
    "확인 절차",
    "확정되지",
    "미확정",
    "결론을 내릴 수 없다",
    "아직 확인되지",
    "물어봐",
]

LOCAL_UPDATE_PHRASES = [
    "내부 상태 업데이트",
    "상태만 갱신",
    "로컬 상태 기록",
    "기기 내부 업데이트",
    "장치 안의 처리 상태만",
    "바깥으로 보내지 말고",
    "공유하지 말고",
    "수신처 전달 대신",
    "전달 동작은 취소",
    "보내는 작업은 취소",
    "외부 공유가 아니라",
    "외부 전송을 하지 말고",
    "상태 표시만",
    "상태 기록만",
    "memory_store",
    "status_only",
]


@dataclass
class EvidenceGraph:
    hard_block: list[str] = field(default_factory=list)
    explicit_clarification: list[str] = field(default_factory=list)
    local_update: list[str] = field(default_factory=list)
    target_rebind: list[str] = field(default_factory=list)
    memory_conflict: list[str] = field(default_factory=list)
    unresolved_ambiguity: list[str] = field(default_factory=list)
    external_share: list[str] = field(default_factory=list)
    sensitive_fields: list[str] = field(default_factory=list)
    route_bundle: dict[str, Any] = field(default_factory=dict)
    prompt_overrides: list[str] = field(default_factory=list)
    personal_memory_signals: list[str] = field(default_factory=list)
    slm_fallback_signals: list[str] = field(default_factory=list)

    @classmethod
    def from_view(cls, view: TaskView, focal_id: str = "") -> EvidenceGraph:
        eg = cls()
        
        # 1. Route Bundle
        candidate = view.latest_record_value("route_candidate_snapshot")
        authority = view.latest_record_value("dispatch_authority_check")
        boundary = view.latest_record_value("share_boundary_update")
        binding_order = view.latest_record_value("route_binding_order")
        
        eg.route_bundle = {
            "candidate": candidate,
            "authority": authority,
            "boundary": boundary,
            "binding_order": binding_order,
            "is_local_boundary": boundary == "local_update_boundary",
            "is_external_boundary": boundary in ("redacted_external_boundary", "redacted_after_selection_boundary", "dispatch_blocked_until_binding"),
            "is_authority_confirmed": authority == "internal_binding_confirmed",
            "is_authority_pending": authority in ("authority_incomplete", "user_binding_pending"),
        }
        
        # 2. Hard Block
        if view.latest_record_value("security_alert"):
            eg.hard_block.append("security_alert_present")
        if view.latest_record_value("safety_mode"):
            eg.hard_block.append("safety_mode_present")
            
        consent_val = view.latest_record_value("consent")
        if isinstance(consent_val, dict) and consent_val.get("status") in ("revoked", "withdrawn", "denied"):
            eg.hard_block.append("consent_revoked")
        elif isinstance(consent_val, str) and consent_val in ("revoked", "withdrawn", "denied"):
            eg.hard_block.append("consent_revoked")
            
        guardrail = view.latest_record_value("guardrail_ladder_signal")
        if guardrail:
            eg.hard_block.append(f"guardrail_ladder_signal:{guardrail}")
            
        prompt = view.prompt
        
        for phrase in HOLD_PHRASES:
            if phrase in prompt:
                eg.hard_block.append(f"prompt_hold_phrase:{phrase}")
                
        # 3. Explicit Clarification
        for phrase in ASK_PHRASES:
            if phrase in prompt:
                eg.explicit_clarification.append(f"prompt_ask_phrase:{phrase}")
                
        if view.latest_record_value("payment_policy"):
            eg.explicit_clarification.append("payment_policy_present")
        if view.latest_record_value("calendar_conflict"):
            eg.explicit_clarification.append("calendar_conflict_present")
        if view.latest_record_value("duration_ambiguous"):
            eg.explicit_clarification.append("duration_ambiguous_present")
            
        # 4. Local Update
        if view.latest_record_value("persistent_memory_write"):
            eg.local_update.append("persistent_memory_write_present")
            
        for phrase in LOCAL_UPDATE_PHRASES:
            if phrase in prompt:
                eg.local_update.append(f"prompt_local_phrase:{phrase}")
                
        if eg.route_bundle.get("is_local_boundary"):
            eg.local_update.append("route_local_boundary")
            
        # 5. Target Rebind
        if view.latest_record_value("target_changed_after_turn"):
            eg.target_rebind.append("target_changed_after_turn_present")
            
        # 6. Memory Conflict
        if view.latest_record_value("memory_conflict"):
            eg.memory_conflict.append("memory_conflict_present")
            
        # 7. Unresolved Ambiguity
        if view.latest_record_value("ambiguous_target"):
            eg.unresolved_ambiguity.append("ambiguous_target_present")
        if view.latest_record_value("ambiguous_focal"):
            eg.unresolved_ambiguity.append("ambiguous_focal_present")
            
        # 8. External Share
        if view.latest_record_value("external_share_policy"):
            eg.external_share.append("external_share_policy_present")
            
        # 9. Sensitive Fields
        if focal_id:
            contains = view.contains_for_object(focal_id)
            sensitive_candidates = {"raw_quote", "rrn", "name", "location", "numeric_value", "doctor_note", "image", "amount"}
            overlap = contains & sensitive_candidates
            if overlap:
                eg.sensitive_fields = sorted(list(overlap))
                
        # 10. Prompt Overrides
        latest_c = view.latest_clause()
        if latest_c:
            eg.prompt_overrides.append(latest_c)
            
        return eg

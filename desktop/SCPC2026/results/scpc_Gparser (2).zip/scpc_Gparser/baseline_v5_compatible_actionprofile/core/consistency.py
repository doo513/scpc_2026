from __future__ import annotations

import json
from pathlib import Path
from typing import Any
from utils.schema_check import validate_answer
from .spec import CONTROL_VALUES, SCOPE_MODES, PLAN_VERBS

BASE_DIR = Path(__file__).resolve().parent.parent


class ConsistencyValidator:
    warnings: list[str] = []
    redacted_count: int = 0
    confirmation_count: int = 0
    memory_store_count: int = 0
    status_only_count: int = 0

    @classmethod
    def reset(cls) -> None:
        cls.warnings = []
        cls.redacted_count = 0
        cls.confirmation_count = 0
        cls.memory_store_count = 0
        cls.status_only_count = 0

    @classmethod
    def validate_or_warn(cls, answer: dict[str, Any], view: Any, evidence: Any, profile: Any) -> None:
        task_id = view.task_id
        
        # 1. Schema check (Immediate fail if invalid)
        try:
            validate_answer(answer)
        except Exception as e:
            raise ValueError(f"Schema validation failed for task {task_id}: {e}")
            
        focal_id = answer.get("focal_id")
        target = answer.get("target")
        control = answer.get("control")
        scope = answer.get("content_scope") or {}
        policy = answer.get("policy") or {}
        plan_events = answer.get("plan_events") or []
        
        # 2. logical check: focal_id in actual object ids
        if focal_id and focal_id not in view.objects_by_id():
            cls.warnings.append(f"Task {task_id}: focal_id '{focal_id}' is not in device objects.")
            
        # 3. logical check: target is not empty
        if not target:
            cls.warnings.append(f"Task {task_id}: target is empty.")
            
        # 4. logical check: control = hold => scope.mode = none
        mode = scope.get("mode")
        if control == "hold" and mode != "none":
            cls.warnings.append(f"Task {task_id}: control is 'hold' but scope mode is '{mode}' (expected 'none').")
            
        # 5. logical check: control = ask => plan has clarify
        has_clarify = any(ev.get("verb") == "clarify" for ev in plan_events)
        if control == "ask" and not has_clarify:
            cls.warnings.append(f"Task {task_id}: control is 'ask' but plan does not contain 'clarify' event.")
            
        # 6. logical check: control = amend => plan has redact
        has_redact = any(ev.get("verb") == "redact" for ev in plan_events)
        if control == "amend" and not has_redact:
            cls.warnings.append(f"Task {task_id}: control is 'amend' but plan does not contain 'redact' event.")
            
        # 7. logical check: target = memory_store => mode = status_only or plan has update
        has_update = any(ev.get("verb") == "update" for ev in plan_events)
        if target == "memory_store" and mode != "status_only" and not has_update:
            cls.warnings.append(f"Task {task_id}: target is 'memory_store' but mode is '{mode}' and plan does not contain 'update' event.")
            
        # 8. logical check: scope.mode = none => allowed/excluded are empty arrays
        allowed = scope.get("allowed_fields") or []
        excluded = scope.get("excluded_fields") or []
        if mode == "none" and (len(allowed) > 0 or len(excluded) > 0):
            cls.warnings.append(f"Task {task_id}: mode is 'none' but allowed/excluded fields are not empty.")
            
        # 9. logical check: excluded_fields not in contains
        contains = view.contains_for_object(focal_id) if focal_id else set()
        for f in excluded:
            if f not in contains:
                cls.warnings.append(f"Task {task_id}: excluded field '{f}' is not in focal contains fields.")

        # Aggregate counts
        if mode == "redacted":
            cls.redacted_count += 1
        if mode == "status_only":
            cls.status_only_count += 1
        if policy.get("requires_confirmation"):
            cls.confirmation_count += 1
        if target == "memory_store":
            cls.memory_store_count += 1

    @classmethod
    def write_report(cls) -> None:
        # Check aggregate warning guardrails
        # redacted 350+, confirmation 450+, memory_store significantly decreased (threshold 100)
        agg_warnings = []
        if cls.redacted_count >= 350:
            agg_warnings.append(f"Warning: redacted mode count is very high ({cls.redacted_count} >= 350)")
        if cls.confirmation_count >= 450:
            agg_warnings.append(f"Warning: requires_confirmation count is very high ({cls.confirmation_count} >= 450)")
        if cls.memory_store_count < 100:
            agg_warnings.append(f"Warning: memory_store target count is very low ({cls.memory_store_count} < 100)")
        if cls.status_only_count < 120:
            agg_warnings.append(f"Warning: status_only scope mode count is low ({cls.status_only_count} < 120)")
            
        report_lines = [
            "# Consistency Validation Report",
            "",
            "## Aggregate Statistics",
            f"- **Redacted Mode Count**: {cls.redacted_count}",
            f"- **requires_confirmation Count**: {cls.confirmation_count}",
            f"- **memory_store Target Count**: {cls.memory_store_count}",
            f"- **status_only Mode Count**: {cls.status_only_count}",
            "",
            "## Aggregate Guardrail Warnings",
        ]
        if agg_warnings:
            for w in agg_warnings:
                report_lines.append(f"- ⚠️ {w}")
        else:
            report_lines.append("- ✅ All aggregate guardrails passed.")
            
        report_lines.extend([
            "",
            "## Individual Logical Warnings",
        ])
        if cls.warnings:
            for w in cls.warnings:
                report_lines.append(f"- {w}")
        else:
            report_lines.append("- ✅ No individual logical inconsistencies found.")
            
        reports_dir = BASE_DIR / "reports"
        reports_dir.mkdir(parents=True, exist_ok=True)
        (reports_dir / "consistency_report.md").write_text("\n".join(report_lines), encoding="utf-8")
        print(f"wrote consistency report: {reports_dir / 'consistency_report.md'}")

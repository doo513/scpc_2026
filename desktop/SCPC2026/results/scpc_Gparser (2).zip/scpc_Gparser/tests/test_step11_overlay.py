"""
Step 11 Invariant Tests — Speculative Session Overlay

These tests verify Step 11 requirements:
1. Provisional writes do not modify persistent memory before commit.
2. Reads prioritize provisional writes over persistent values.
3. Rollback discards all provisional state without modifying persistent storage.
4. Commit applies all writes atomically to persistent session state.
"""
from __future__ import annotations

import pytest
from core.session_overlay import SpeculativeSessionOverlay


# ── 1. Isolation & Read Priority ──────────────────────────────────

class TestSessionOverlayIsolation:
    """Provisional writes must remain isolated and hide old persistent values."""

    def test_provisional_read_priority(self):
        persistent = {"keyA": "old_val", "keyB": "fixed"}
        overlay = SpeculativeSessionOverlay(persistent)
        
        # Initial read from persistent
        assert overlay.read("keyA") == "old_val"
        assert overlay.read("keyB") == "fixed"
        
        # Write to overlay
        overlay.write("keyA", "new_val")
        
        # Read should prioritize overlay value
        assert overlay.read("keyA") == "new_val"
        assert overlay.read("keyB") == "fixed"
        
        # Persistent dict must be unchanged
        assert persistent["keyA"] == "old_val"


# ── 2. Rollback Behavior ───────────────────────────────────────────

class TestSessionOverlayRollback:
    """Rollback must completely discard provisional writes."""

    def test_rollback_discards_writes(self):
        persistent = {"keyA": "old_val"}
        overlay = SpeculativeSessionOverlay(persistent)
        
        overlay.write("keyA", "new_val")
        overlay.write("keyC", "added")
        
        # Before rollback, read sees provisional
        assert overlay.read("keyA") == "new_val"
        assert overlay.read("keyC") == "added"
        
        overlay.rollback()
        
        # After rollback, read reverts to persistent or None
        assert overlay.read("keyA") == "old_val"
        assert overlay.read("keyC") is None
        assert persistent["keyA"] == "old_val"


# ── 3. Commit Behavior ─────────────────────────────────────────────

class TestSessionOverlayCommit:
    """Commit must apply provisional writes to session and bank atomically."""

    def test_commit_applies_atomically(self):
        persistent_session = {"memory": {"keyA": "old_val"}}
        memory_bank = {"keyA": "old_val"}
        
        overlay = SpeculativeSessionOverlay(persistent_session["memory"])
        overlay.write("keyA", "new_val")
        overlay.write("keyC", "added")
        
        # Commit to persistent storage
        overlay.commit(persistent_session, memory_bank)
        
        # Persistent storage must now contain new values
        assert persistent_session["memory"]["keyA"] == "new_val"
        assert persistent_session["memory"]["keyC"] == "added"
        assert memory_bank["keyA"] == "new_val"
        assert memory_bank["keyC"] == "added"

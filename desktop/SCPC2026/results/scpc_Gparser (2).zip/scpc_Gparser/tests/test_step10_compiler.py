"""
Step 10 Invariant Tests — Pure Compilers

These tests verify Step 10 requirements:
1. Compilers are pure functions of their respective Projection DTOs.
2. Identical Projection DTO inputs produce identical output results (determinism).
3. Compiler calls do not depend on execution order or global state.
4. Compilers reject raw prompt / TaskView / records as input.
"""
from __future__ import annotations

import pytest
from core.projections import ScopeProjection, PolicyProjection, PlanProjection
from core.compilers import ScopeCompiler, PolicyCompiler, PlanCompiler


# ── 1. ScopeCompiler Pure Evaluation ───────────────────────────────

class TestScopeCompiler:
    """ScopeCompiler must purely project ScopeProjection to JSON."""

    def test_scope_compilation(self):
        proj = ScopeProjection(
            mode="redacted",
            focal_id="WM-1",
            target="doctor_lee",
            excluded_fields=["raw_quote"],
            requires_user_confirmation=True
        )
        res = ScopeCompiler.compile(proj)
        
        assert res["mode"] == "redacted"
        assert res["allowed_fields"] == ["summary"]
        assert res["excluded_fields"] == ["raw_quote"]
        assert res["requires_user_confirmation"] is True


# ── 2. PolicyCompiler Pure Evaluation ──────────────────────────────

class TestPolicyCompiler:
    """PolicyCompiler must purely project PolicyProjection to JSON."""

    def test_policy_compilation(self):
        proj = PolicyProjection(
            risk_flags=["strict_share_policy", "external_share"],
            violations=["precondition_changed_ignored"],
            requires_confirmation=True
        )
        res = PolicyCompiler.compile(proj)
        
        assert res["risk_flags"] == ["strict_share_policy", "external_share"]
        assert res["violations"] == ["precondition_changed_ignored"]
        assert res["requires_confirmation"] is True


# ── 3. PlanCompiler Pure Evaluation ────────────────────────────────

class TestPlanCompiler:
    """PlanCompiler must purely project PlanProjection to templates."""

    def test_plan_compilation_hold(self):
        proj = PlanProjection(
            control="hold",
            profile_name="hard_block",
            focal_id="WM-1",
            target="doctor_lee",
            scope_mode="none"
        )
        res = PlanCompiler.compile(proj, task_id="test_task")
        
        assert len(res) == 2
        assert res[0]["verb"] == "read"
        assert res[0]["args"]["purpose"] == "invalidated_precondition"
        assert res[1]["verb"] == "guard"

    def test_plan_compilation_amend(self):
        proj = PlanProjection(
            control="amend",
            profile_name="external_redacted_dispatch",
            focal_id="WM-2",
            target="doctor_lee",
            scope_mode="redacted",
            terminal_verb="dispatch",
            remove_sensitive_fields=True
        )
        res = PlanCompiler.compile(proj, task_id="test_task")
        
        assert len(res) == 3
        assert res[0]["verb"] == "read"
        assert res[1]["verb"] == "redact"
        assert res[1]["args"]["remove"] == "sensitive_fields"
        assert res[2]["verb"] == "dispatch"


# ── 4. Determinism & Isolation ─────────────────────────────────────

class TestCompilerDeterminism:
    """Compilers must be deterministic and side-effect free."""

    def test_determinism(self):
        proj = ScopeProjection(
            mode="raw",
            focal_id="WM-1",
            target="doctor_lee",
            excluded_fields=[],
            requires_user_confirmation=False
        )
        
        res1 = ScopeCompiler.compile(proj)
        res2 = ScopeCompiler.compile(proj)
        assert res1 == res2

    def test_order_independence(self):
        # Compilers can be run in any order without changing their output
        scope_proj = ScopeProjection(mode="raw", focal_id="WM-1", target="doctor_lee")
        policy_proj = PolicyProjection(requires_confirmation=False)
        plan_proj = PlanProjection(control="proceed", profile_name="raw", focal_id="WM-1", target="doctor_lee", scope_mode="raw")

        # Run order A
        out_scope_A = ScopeCompiler.compile(scope_proj)
        out_policy_A = PolicyCompiler.compile(policy_proj)
        out_plan_A = PlanCompiler.compile(plan_proj)

        # Run order B
        out_plan_B = PlanCompiler.compile(plan_proj)
        out_scope_B = ScopeCompiler.compile(scope_proj)
        out_policy_B = PolicyCompiler.compile(policy_proj)

        assert out_scope_A == out_scope_B
        assert out_policy_A == out_policy_B
        assert out_plan_A == out_plan_B

"""
Step 5 Invariant Tests — Joint Resolution and Target Coupling

These tests verify the joint resolution of Focal and Target:
1. Fallback object scoring depends on coarse intent keywords.
2. Target fallback resolves to correct field of resolved focal object.
3. Marker trace correctly binds focal object based on resolution trace phase.
"""
from __future__ import annotations

import pytest
from core.task_view import TaskView
from core.pipeline import IntentEvidence, PromptConstraintEvidence
from rules.focal import FocalResolver
from rules.target import TargetResolver


# ── 1. Fallback Scoring based on Intent ────────────────────────────

class TestJointResolution:
    """Focal fallback selection is joint with intent keywords."""

    def test_health_record_selected_for_health_intent(self):
        task = {
            "device_state": {
                "objects": [
                    {"id": "WM-1", "type": "gallery_item", "attrs": {}},
                    {"id": "WM-2", "type": "health_record", "attrs": {}},
                ]
            }
        }
        view = TaskView(task)
        intent = IntentEvidence(domain_keywords=["건강"])
        
        # When "건강" is in keywords, health_record must be selected as fallback
        focal_id = FocalResolver.resolve_fallback(view, intent, {}, direct_focal_id="")
        assert focal_id == "WM-2"

    def test_gallery_selected_for_photo_intent(self):
        task = {
            "device_state": {
                "objects": [
                    {"id": "WM-1", "type": "gallery_item", "attrs": {}},
                    {"id": "WM-2", "type": "health_record", "attrs": {}},
                ]
            }
        }
        view = TaskView(task)
        intent = IntentEvidence(domain_keywords=["사진"])
        
        focal_id = FocalResolver.resolve_fallback(view, intent, {}, direct_focal_id="")
        assert focal_id == "WM-1"


# ── 2. Target Coupling with Focal ──────────────────────────────────

class TestTargetCoupling:
    """Target resolution retrieves attributes from the resolved focal object."""

    def test_target_resolved_from_focal_recipient(self):
        task = {
            "device_state": {
                "objects": [
                    {"id": "WM-2", "type": "health_record", "attrs": {"recipient": "doctor_lee"}},
                ]
            }
        }
        view = TaskView(task)
        intent = IntentEvidence()
        constraint = PromptConstraintEvidence()
        
        # Resolve target for focal WM-2
        target = TargetResolver.resolve_fallback(
            view, intent, constraint, focal_id="WM-2", control="proceed", session={}
        )
        assert target == "doctor_lee"


# ── 3. Marker Trace Resolution ─────────────────────────────────────

class TestMarkerTraceResolution:
    """Direct focal resolution correctly traces marker bindings."""

    def test_marker_trace_latest_phase(self):
        task = {
            "device_state": {
                "objects": [
                    {"id": "objA", "type": "health_record", "attrs": {"ref_code": "WM-100"}},
                    {"id": "objB", "type": "health_record", "attrs": {"ref_code": "WM-200"}},
                ],
                "records": [
                    {
                        "id": "rec1",
                        "type": "focal_marker_refs",
                        "value": {"marker_to_ref": {"marker1": "WM-100", "marker2": "WM-200"}}
                    },
                    {
                        "id": "rec2",
                        "type": "focal_resolution_trace",
                        "value": {
                            "phase_to_marker": {"phaseA": "marker1", "phaseB": "marker2"},
                            "latest_phase": "phaseB"
                        }
                    }
                ]
            }
        }
        view = TaskView(task)
        direct_id = FocalResolver.resolve_direct(view)
        # Should resolve to objB since latest_phase is phaseB -> marker2 -> WM-200 -> objB
        assert direct_id == "objB"

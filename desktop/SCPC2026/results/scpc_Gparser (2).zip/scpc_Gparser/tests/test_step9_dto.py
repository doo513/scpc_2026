"""
Step 9 Invariant Tests — SubDecisionIR, DecisionBundle, and Projections

These tests verify Step 9 requirements:
1. SubDecisionIR has all required DTO fields initialized with proper defaults.
2. DecisionBundle has all required DTO fields initialized with proper defaults.
3. Projection DTOs (Scope, Policy, Plan) are frozen and prevent mutation.
4. Projection DTOs map cleanly from DecisionBundle.
"""
from __future__ import annotations

import pytest
from core.ontology import (
    Domain, Operation, TargetRole, TargetLocality, CandidateState,
    ExecutionDisposition, DisclosureMode, ReasonCode, InformationStatus
)
from core.pipeline import SubDecisionIR, DecisionBundle
from core.projections import ScopeProjection, PolicyProjection, PlanProjection


# ── 1. SubDecisionIR and DecisionBundle DTO Invariants ──────────────

class TestDTOFields:
    """SubDecisionIR and DecisionBundle must contain all fields required by Step 9."""

    def test_sub_decision_fields(self):
        sd = SubDecisionIR(
            clause_index=0,
            action="DISPATCH",
            target="doctor_lee",
            control="proceed",
            profile_name="safe_dispatch_raw",
            scope_mode="raw",
            risk_flags=[],
            violations=[],
            focal_id="WM-1"
        )
        # Verify default field initialization
        assert sd.domain == Domain.UNKNOWN
        assert sd.operation == Operation.UNKNOWN
        assert sd.execution_target_role == TargetRole.UNKNOWN
        assert sd.execution_disposition == ExecutionDisposition.PROCEED
        assert sd.disclosure_mode == DisclosureMode.RAW

    def test_decision_bundle_fields(self):
        sd = SubDecisionIR(
            clause_index=0,
            action="DISPATCH",
            target="doctor_lee",
            control="proceed",
            profile_name="safe_dispatch_raw",
            scope_mode="raw",
            risk_flags=[],
            violations=[],
            focal_id="WM-1"
        )
        bundle = DecisionBundle(
            sub_decisions=[sd],
            dependency_edges=[],
            global_control="proceed",
            global_target="doctor_lee",
            global_focal_id="WM-1"
        )
        # Verify default field initialization
        assert bundle.bundle_id == ""
        assert bundle.primary_focal == ""
        assert bundle.aggregate_output_status == ""


# ── 2. Projection DTO Invariants ───────────────────────────────────

class TestProjectionDTOs:
    """Projection DTOs must be frozen and hold compiler-specific fields."""

    def test_scope_projection_frozen(self):
        proj = ScopeProjection(
            mode=DisclosureMode.RAW,
            focal_id="WM-1",
            target="doctor_lee"
        )
        assert proj.mode == DisclosureMode.RAW
        with pytest.raises(AttributeError):
            proj.mode = DisclosureMode.REDACTED

    def test_policy_projection_frozen(self):
        proj = PolicyProjection(
            risk_flags=["strict_share_policy"],
            violations=[],
            requires_confirmation=True
        )
        assert proj.requires_confirmation is True
        with pytest.raises(AttributeError):
            proj.requires_confirmation = False

    def test_plan_projection_frozen(self):
        proj = PlanProjection(
            control=ExecutionDisposition.PROCEED,
            profile_name="safe_dispatch_raw",
            focal_id="WM-1",
            target="doctor_lee",
            scope_mode=DisclosureMode.RAW
        )
        assert proj.control == ExecutionDisposition.PROCEED
        with pytest.raises(AttributeError):
            proj.control = ExecutionDisposition.HOLD

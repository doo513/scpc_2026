"""
Step 2 Invariant Tests — Ontology and Single Ownership

These tests verify the Step 2 release gate conditions:
1. No duplicate enums representing the same semantic concept
2. Each semantic field has exactly one final owner
3. Impossible enum combinations are rejected at creation time
4. Registry does not generate arbitrary string enums
5. UNKNOWN/UNSUPPORTED does not convert to default dispatch or user target
"""
from __future__ import annotations

import pytest
from core.ontology import (
    Domain, Operation, TargetRole, TargetLocality,
    ObjectType, RecordType, InformationSlot, InformationStatus,
    CandidateState, ConstraintType, ConstraintEffect,
    CapabilityType, CapabilitySource, ExecutionDisposition,
    DisclosureMode, ReasonCode, PlanStepType,
)
from core.ownership import (
    validate_no_duplicate_owners,
    validate_compiler_not_owner,
    get_unresolved_assumptions,
    OWNERSHIP_TABLE,
)
from core.spec import CONTROL_VALUES, SCOPE_MODES, PLAN_VERBS


# ── 1. No duplicate enum values within each ontology type ──────────

class TestOntologyNoDuplicateValues:
    """Each ontology enum must have unique values (no aliasing)."""

    @pytest.mark.parametrize("enum_cls", [
        Domain, Operation, TargetRole, TargetLocality,
        ObjectType, RecordType, InformationSlot, InformationStatus,
        CandidateState, ConstraintType, ConstraintEffect,
        CapabilityType, CapabilitySource, ExecutionDisposition,
        DisclosureMode, ReasonCode, PlanStepType,
    ])
    def test_no_duplicate_values(self, enum_cls):
        values = [e.value for e in enum_cls]
        assert len(values) == len(set(values)), (
            f"{enum_cls.__name__} has duplicate values: {values}"
        )


# ── 2. Ontology coverage matches existing spec.py constants ────────

class TestOntologySpecCoverage:
    """Ontology enums must cover all values used in spec.py."""

    def test_control_values_covered_by_disposition(self):
        disposition_values = {e.value for e in ExecutionDisposition}
        for cv in CONTROL_VALUES:
            assert cv in disposition_values, f"CONTROL_VALUE '{cv}' not in ExecutionDisposition"

    def test_scope_modes_covered_by_disclosure(self):
        disclosure_values = {e.value for e in DisclosureMode}
        for sm in SCOPE_MODES:
            assert sm in disclosure_values, f"SCOPE_MODE '{sm}' not in DisclosureMode"

    def test_plan_verbs_covered_by_plan_step_type(self):
        step_type_values = {e.value for e in PlanStepType}
        for pv in PLAN_VERBS:
            assert pv in step_type_values, f"PLAN_VERB '{pv}' not in PlanStepType"


# ── 3. Single ownership invariants ─────────────────────────────────

class TestOwnershipInvariants:
    """Ownership table must satisfy single-ownership constraints."""

    def test_no_duplicate_owners(self):
        violations = validate_no_duplicate_owners()
        assert not violations, f"Duplicate owners found: {violations}"

    def test_compiler_not_upstream_owner(self):
        violations = validate_compiler_not_owner()
        assert not violations, f"Compiler owns upstream fields: {violations}"

    def test_all_fields_have_owner(self):
        """Every entry must have a non-empty owner_module."""
        for entry in OWNERSHIP_TABLE:
            assert entry.owner_module, f"Field '{entry.semantic_field}' has no owner"

    def test_producer_stage_monotonic_per_field(self):
        """Producer stage must be a positive integer."""
        for entry in OWNERSHIP_TABLE:
            assert entry.producer_stage >= 1, (
                f"Field '{entry.semantic_field}' has invalid stage {entry.producer_stage}"
            )


# ── 4. UNKNOWN/UNSUPPORTED does not become default dispatch ────────

class TestUnknownDoesNotBecomeDefault:
    """UNKNOWN states must not silently convert to executable defaults."""

    def test_domain_unknown_is_not_content(self):
        assert Domain.UNKNOWN != Domain.CONTENT
        assert Domain.UNKNOWN.value != Domain.CONTENT.value

    def test_operation_unknown_is_not_share(self):
        assert Operation.UNKNOWN != Operation.SHARE
        assert Operation.UNKNOWN.value != Operation.SHARE.value

    def test_target_role_unknown_is_not_recipient(self):
        assert TargetRole.UNKNOWN != TargetRole.RECIPIENT

    def test_candidate_unsupported_is_distinct(self):
        assert CandidateState.UNSUPPORTED_RULEPACK != CandidateState.VIABLE
        assert CandidateState.UNSUPPORTED_RULEPACK != CandidateState.BLOCKED


# ── 5. Enum construction rejects invalid values ────────────────────

class TestEnumStrictConstruction:
    """Enums must reject invalid string values at construction time."""

    @pytest.mark.parametrize("enum_cls,bad_value", [
        (Domain, "GROCERY"),
        (Operation, "DELETE"),
        (TargetRole, "admin"),
        (DisclosureMode, "partial"),
        (CandidateState, "maybe"),
        (ExecutionDisposition, "retry"),
    ])
    def test_invalid_value_raises(self, enum_cls, bad_value):
        with pytest.raises(ValueError):
            enum_cls(bad_value)


# ── 6. Unresolved assumptions are tracked ──────────────────────────

class TestAssumptionTracking:
    """All UNRESOLVED_ASSUMPTION entries must have notes."""

    def test_assumptions_have_notes(self):
        for entry in get_unresolved_assumptions():
            assert entry.notes, (
                f"UNRESOLVED_ASSUMPTION '{entry.semantic_field}' has no notes"
            )

    def test_assumption_count_is_documented(self):
        """Verify we know how many assumptions exist (regression guard)."""
        count = len(get_unresolved_assumptions())
        # Current baseline: 3 unresolved assumptions
        assert count == 3, (
            f"Expected 3 unresolved assumptions, found {count}. "
            "Update this test if assumptions were resolved or added."
        )


# ── 7. Baseline score preservation ─────────────────────────────────

class TestBaselinePreservation:
    """Verify that ontology module introduction does not break scoring."""

    def test_ontology_imports_cleanly(self):
        """All ontology types can be imported without errors."""
        import core.ontology  # noqa: F401

    def test_ownership_imports_cleanly(self):
        """Ownership table can be imported without errors."""
        import core.ownership  # noqa: F401

    def test_existing_spec_still_valid(self):
        """spec.py constants are unchanged."""
        assert "proceed" in CONTROL_VALUES
        assert "amend" in CONTROL_VALUES
        assert "hold" in CONTROL_VALUES
        assert "ask" in CONTROL_VALUES
        assert "dispatch" in PLAN_VERBS
        assert "read" in PLAN_VERBS

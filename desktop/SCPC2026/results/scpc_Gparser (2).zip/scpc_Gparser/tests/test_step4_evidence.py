"""
Step 4 Invariant Tests — Evidence Graph and Natural Language Interpretation

These tests verify Step 4 requirements:
1. Quotation isolation: Command keywords inside quotes do not trigger execution evidence.
2. Negation isolation: Negation inside one clause does not infect other clauses.
3. Correction detection: Correction keywords are mapped to intent.is_correction.
4. Downstream compiler lockdown: Compiler has no access to raw prompt.
"""
from __future__ import annotations

import pytest
from core.evidence_graph import NaturalLanguageInterpreter
from core.pipeline import IntentEvidence


# ── 1. Quotation Isolation ─────────────────────────────────────────

class TestQuotationIsolation:
    """Keywords inside quotes must not trigger execution evidence."""

    def test_quoted_command_ignored(self):
        # "조명 꺼" is inside quotes, so the active intent should only be MEMORY/STORE from "기억해줘"
        # and domain_verbs should NOT contain TOGGLE.
        prompt = '메모리에 "조명 꺼"라고 기억해줘'
        clauses = NaturalLanguageInterpreter.parse_clauses_and_evidence(prompt, turn_index=1)
        
        assert len(clauses) == 1
        intent = clauses[0].intent
        # TOGGLE is not parsed because "조명", "꺼" were inside quotes
        assert "TOGGLE" not in intent.domain_verbs
        assert intent.is_local_only is True  # from "기억해줘"

    def test_unquoted_command_not_ignored(self):
        # Without quotes, "조명 꺼" will be parsed as TOGGLE
        prompt = '조명 꺼라고 기억해줘'
        clauses = NaturalLanguageInterpreter.parse_clauses_and_evidence(prompt, turn_index=1)
        
        intent = clauses[0].intent
        assert "TOGGLE" in intent.domain_verbs


# ── 2. Negation Isolation ─────────────────────────────────────────

class TestNegationIsolation:
    """Negation must be clause-specific and not bleed globally."""

    def test_negation_bleeds_only_per_clause(self):
        prompt = "조명은 켜줘. 하지만 결제는 하지 마라."
        clauses = NaturalLanguageInterpreter.parse_clauses_and_evidence(prompt, turn_index=1)
        
        assert len(clauses) == 2
        
        # Clause 1: 조명은 켜줘
        assert "TOGGLE" in clauses[0].intent.domain_verbs
        assert clauses[0].intent.is_negation is False
        
        # Clause 2: 하지만 결제는 하지 마라
        assert "PAY" in clauses[1].intent.domain_verbs
        assert clauses[1].intent.is_negation is True


# ── 3. Correction Detection ────────────────────────────────────────

class TestCorrectionDetection:
    """Correction phrases must be mapped to is_correction."""

    @pytest.mark.parametrize("phrase", [
        "방금 말한 것은 취소하고 대신 조명 꺼줘",
        "최신 표현을 우선하여 변경해줘",
        "이전 명령 정정하고 결제해줘",
    ])
    def test_correction_phrase_detected(self, phrase):
        clauses = NaturalLanguageInterpreter.parse_clauses_and_evidence(phrase, turn_index=1)
        assert any(c.intent.is_correction for c in clauses)


# ── 4. Clause Splitting ────────────────────────────────────────────

class TestClauseSplitting:
    """The interpreter splits the prompt correctly on separators."""

    def test_split_by_and(self):
        prompt = "일정을 등록해주고 결제도 진행해줘."
        # "그리고" or punctuation splits it.
        # Wait, the separator pattern is: (?:그리고|하지만|다만|단,|단\s+|대신|;|(?<=\D)\.)
        # Let's check how "그리고" works
        prompt_with_and = "일정을 등록해줘. 그리고 결제도 진행해줘."
        clauses = NaturalLanguageInterpreter.parse_clauses_and_evidence(prompt_with_and, turn_index=1)
        assert len(clauses) == 2
        assert "SCHEDULE" in clauses[0].intent.domain_verbs
        assert "PAY" in clauses[1].intent.domain_verbs

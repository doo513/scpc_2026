"""
Step 7 Invariant Tests — Constraint Activation & Effect Algebra

These tests verify Step 7 requirements:
1. Null effect evaluation returns ExecutionDisposition.PROCEED.
2. Idempotence: duplicate effects aggregate to the same single effect.
3. Canonical priority order: hold > ask > amend > proceed.
4. Constraint activation maps correct trigger records to correct effects.
"""
from __future__ import annotations

import pytest
from core.ontology import ExecutionDisposition, ConstraintType
from core.constraint_algebra import aggregate_effects, ConstraintActivator
from core.typed_facts import TypedRecordFact, TypedObjectFact, FactStatus
from core.pipeline import IntentEvidence, PromptConstraintEvidence


# ── 1. Effect Algebra Lattice Invariants ───────────────────────────

class TestEffectAlgebra:
    """Execution disposition aggregation must follow the canonical lattice."""

    def test_null_effect(self):
        assert aggregate_effects([]) == ExecutionDisposition.PROCEED

    def test_idempotence(self):
        assert aggregate_effects([ExecutionDisposition.HOLD, ExecutionDisposition.HOLD]) == ExecutionDisposition.HOLD
        assert aggregate_effects([ExecutionDisposition.ASK, ExecutionDisposition.ASK]) == ExecutionDisposition.ASK

    @pytest.mark.parametrize("effects,expected", [
        ([ExecutionDisposition.PROCEED, ExecutionDisposition.AMEND], ExecutionDisposition.AMEND),
        ([ExecutionDisposition.AMEND, ExecutionDisposition.ASK], ExecutionDisposition.ASK),
        ([ExecutionDisposition.ASK, ExecutionDisposition.HOLD], ExecutionDisposition.HOLD),
        ([ExecutionDisposition.PROCEED, ExecutionDisposition.HOLD], ExecutionDisposition.HOLD),
        ([ExecutionDisposition.AMEND, ExecutionDisposition.HOLD, ExecutionDisposition.ASK], ExecutionDisposition.HOLD),
    ])
    def test_priority_order(self, effects, expected):
        assert aggregate_effects(effects) == expected


# ── 2. Constraint Activation Invariants ───────────────────────────

class TestConstraintActivation:
    """Consent revocation and alerts trigger appropriate blocks/holds."""

    def test_consent_revoked_triggers_hold(self):
        records = [
            TypedRecordFact(
                record_id="rec1",
                record_type="consent",
                raw_value="revoked",
                parsed_value="revoked"
            )
        ]
        intent = IntentEvidence()
        constraint = PromptConstraintEvidence()
        
        activated = ConstraintActivator.evaluate_constraints(
            record_facts=records,
            object_facts=[],
            intent=intent,
            constraint_evidence=constraint,
            focal_id=""
        )
        
        # Must activate CONSENT_REVOKED -> HOLD
        assert (ConstraintType.CONSENT_REVOKED, ExecutionDisposition.HOLD) in activated

    def test_consent_revoked_with_local_only_correction_bypass(self):
        records = [
            TypedRecordFact(
                record_id="rec1",
                record_type="consent",
                raw_value="revoked",
                parsed_value="revoked"
            )
        ]
        # local_only and correction bypasses the consent hold!
        intent = IntentEvidence(is_local_only=True, is_correction=True)
        constraint = PromptConstraintEvidence()
        
        activated = ConstraintActivator.evaluate_constraints(
            record_facts=records,
            object_facts=[],
            intent=intent,
            constraint_evidence=constraint,
            focal_id=""
        )
        assert len(activated) == 0

    def test_security_alert_triggers_hold(self):
        records = [
            TypedRecordFact(
                record_id="rec1",
                record_type="security_alert",
                raw_value=True,
                parsed_value=True
            )
        ]
        intent = IntentEvidence()
        constraint = PromptConstraintEvidence()
        
        activated = ConstraintActivator.evaluate_constraints(
            record_facts=records,
            object_facts=[],
            intent=intent,
            constraint_evidence=constraint,
            focal_id=""
        )
        assert (ConstraintType.SECURITY_BLOCK, ExecutionDisposition.HOLD) in activated

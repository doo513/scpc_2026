"""
Step 8 Invariant Tests — Fallback Graph and Authorized Solver

These tests verify Step 8 requirements:
1. Rejects self-loops immediately.
2. Rejects cycle dependencies on edge registration.
3. Fallback solver traces correct destination hops.
4. Fallback destination is evaluated using the same callback.
"""
from __future__ import annotations

import pytest
from core.fallback_graph import FallbackGraph, FallbackEdge, FallbackNode, AuthorizedFallbackSolver


# ── 1. Self-loop and Cycle Rejection ───────────────────────────────

class TestFallbackGraphValidation:
    """FallbackGraph must statically reject invalid topologies."""

    def test_rejects_self_loop(self):
        graph = FallbackGraph()
        node = FallbackNode("DISPATCH", "doctor_lee")
        edge = FallbackEdge(source=node, destination=node, reason_code="precondition_invalidated")
        
        with pytest.raises(ValueError, match="Self-loop detected"):
            graph.add_edge(edge)

    def test_rejects_simple_cycle(self):
        graph = FallbackGraph()
        nodeA = FallbackNode("DISPATCH", "doctor_lee")
        nodeB = FallbackNode("LOCAL_UPDATE", "memory_store")
        
        edge1 = FallbackEdge(source=nodeA, destination=nodeB, reason_code="precondition_invalidated")
        edge2 = FallbackEdge(source=nodeB, destination=nodeA, reason_code="policy_fallback")
        
        graph.add_edge(edge1)
        with pytest.raises(ValueError, match="Cycle detected"):
            graph.add_edge(edge2)


# ── 2. Fallback Solver Hops and Traversal ─────────────────────────

class TestFallbackSolver:
    """AuthorizedFallbackSolver resolves correct fallback target based on availability."""

    def test_resolves_primary_if_available(self):
        graph = FallbackGraph()
        # Mock evaluator: all nodes are available
        def evaluator_yes(action, target):
            return True

        action, target, trace = AuthorizedFallbackSolver.resolve_authorized_candidate(
            graph, "DISPATCH", "doctor_lee", evaluator_yes
        )
        assert action == "DISPATCH"
        assert target == "doctor_lee"
        assert trace == ["DISPATCH:doctor_lee"]

    def test_resolves_fallback_hop(self):
        graph = FallbackGraph()
        nodeA = FallbackNode("DISPATCH", "doctor_lee")
        nodeB = FallbackNode("LOCAL_UPDATE", "memory_store")
        
        edge = FallbackEdge(source=nodeA, destination=nodeB, reason_code="precondition_invalidated")
        graph.add_edge(edge)

        # Mock evaluator: nodeA is blocked, nodeB is available
        def evaluator_callback(action, target):
            return action == "LOCAL_UPDATE"

        action, target, trace = AuthorizedFallbackSolver.resolve_authorized_candidate(
            graph, "DISPATCH", "doctor_lee", evaluator_callback
        )
        assert action == "LOCAL_UPDATE"
        assert target == "memory_store"
        assert trace == ["DISPATCH:doctor_lee", "LOCAL_UPDATE:memory_store"]

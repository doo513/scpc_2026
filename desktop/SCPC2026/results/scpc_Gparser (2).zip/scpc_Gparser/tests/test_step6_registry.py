"""
Step 6 Invariant Tests — Rule Registry and Rule Packs

These tests verify Step 6 requirements:
1. Exact lookup based on (Domain, Operation) returns the expected RulePack.
2. Unregistered keys fallback to a safe generic CONTENT/SHARE RulePack.
3. No duplicate domains or configurations exist in the registry.
4. All registered RulePacks have valid enums.
"""
from __future__ import annotations

import pytest
from core.ontology import Domain, Operation, ConstraintType
from core.rule_registry import RuleRegistry, RulePack


# ── 1. Match and Fallback ──────────────────────────────────────────

class TestRuleRegistryLookup:
    """Registry lookup must support exact keys and fallback to safe defaults."""

    def test_exact_lookup(self):
        pack = RuleRegistry.lookup(Domain.PAYMENT, Operation.EXECUTE)
        assert pack is not None
        assert pack.domain == Domain.PAYMENT
        assert pack.operation == Operation.EXECUTE
        assert pack.blueprint_id == "payment_execution"
        assert pack.requires_consent is True

    def test_fallback_lookup(self):
        # UNKNOWN key should fallback to CONTENT/SHARE
        pack = RuleRegistry.lookup(Domain.UNKNOWN, Operation.UNKNOWN)
        assert pack is not None
        assert pack.domain == Domain.CONTENT
        assert pack.operation == Operation.SHARE


# ── 2. RulePack Consistency ────────────────────────────────────────

class TestRulePackConsistency:
    """Registered RulePacks must use valid constraints and blueprints."""

    def test_registered_packs_are_valid(self):
        # Payment must check payment policy
        payment_pack = RuleRegistry.lookup(Domain.PAYMENT, Operation.EXECUTE)
        assert ConstraintType.PAYMENT_POLICY in payment_pack.applicable_constraints

        # Device modification does not require consent
        device_pack = RuleRegistry.lookup(Domain.DEVICE, Operation.MODIFY)
        assert device_pack.requires_consent is False

        # Memory store is local update and does not require consent
        memory_pack = RuleRegistry.lookup(Domain.MEMORY, Operation.STORE)
        assert memory_pack.requires_consent is False

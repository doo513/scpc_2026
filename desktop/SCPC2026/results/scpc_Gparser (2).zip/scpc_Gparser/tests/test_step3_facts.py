"""
Step 3 Invariant Tests — Typed Facts & Record Adapters

These tests verify the Step 3 release gate conditions:
1. Object and record array permutation does not affect the assembled facts.
2. Value ranges and defaults for record adapters are strictly adhered to.
3. FactStatus distinguishes between PRESENT / MISSING / CONFLICTED / etc.
4. Unknown record types are preserved without loss.
"""
from __future__ import annotations

import pytest
from core.typed_facts import (
    TypedFactAssembler, FactStatus, TypedObjectFact, TypedRecordFact,
    ConsentAdapter, BooleanSignalAdapter, PolicyStringAdapter,
)


# ── 1. Permutation Invariance ──────────────────────────────────────

class TestFactPermutationInvariance:
    """The order of raw objects or records must not affect the resulting facts."""

    def test_object_permutation(self):
        raw_1 = {"id": "obj1", "type": "health_record", "attrs": {"ref_code": "codeA"}}
        raw_2 = {"id": "obj2", "type": "payment_record", "attrs": {"ref_code": "codeB"}}

        facts_12 = TypedFactAssembler.assemble_objects([raw_1, raw_2])
        facts_21 = TypedFactAssembler.assemble_objects([raw_2, raw_1])

        # Verify they contain same elements regardless of order
        set_12 = {(f.object_id, f.object_type, f.ref_code) for f in facts_12}
        set_21 = {(f.object_id, f.object_type, f.ref_code) for f in facts_21}
        assert set_12 == set_21
        assert len(facts_12) == 2

    def test_record_permutation(self):
        raw_1 = {"id": "rec1", "type": "consent", "value": "revoked"}
        raw_2 = {"id": "rec2", "type": "safety_mode", "value": True}

        facts_12 = TypedFactAssembler.assemble_records([raw_1, raw_2])
        facts_21 = TypedFactAssembler.assemble_records([raw_2, raw_1])

        set_12 = {(f.record_id, f.record_type, f.parsed_value) for f in facts_12}
        set_21 = {(f.record_id, f.record_type, f.parsed_value) for f in facts_21}
        assert set_12 == set_21
        assert len(facts_12) == 2


# ── 2. Record Adapter Value Ranges ─────────────────────────────────

class TestRecordAdapters:
    """Each type-specific adapter parses values strictly and handles defaults."""

    def test_consent_adapter(self):
        adapter = ConsentAdapter()
        # Explicit states
        assert adapter.parse({"id": "1", "type": "consent", "value": "revoked"}).parsed_value == "revoked"
        assert adapter.parse({"id": "2", "type": "consent", "value": "granted"}).parsed_value == "granted"
        assert adapter.parse({"id": "3", "type": "consent", "value": "denied"}).parsed_value == "denied"
        # Dict value
        assert adapter.parse({"id": "4", "type": "consent", "value": {"status": "revoked"}}).parsed_value == "revoked"
        # Invalid value defaults to granted
        assert adapter.parse({"id": "5", "type": "consent", "value": "invalid_val"}).parsed_value == "granted"
        assert adapter.parse({"id": "6", "type": "consent", "value": None}).parsed_value == "granted"

    def test_boolean_signal_adapter(self):
        adapter = BooleanSignalAdapter()
        assert adapter.parse({"id": "1", "type": "security_alert", "value": True}).parsed_value is True
        assert adapter.parse({"id": "2", "type": "security_alert", "value": 1}).parsed_value is True
        assert adapter.parse({"id": "3", "type": "security_alert", "value": False}).parsed_value is False
        assert adapter.parse({"id": "4", "type": "security_alert", "value": None}).parsed_value is False

    def test_policy_string_adapter(self):
        adapter = PolicyStringAdapter()
        assert adapter.parse({"id": "1", "type": "session_share_policy", "value": "strict"}).parsed_value == "strict"
        assert adapter.parse({"id": "2", "type": "session_share_policy", "value": None}).parsed_value is None


# ── 3. FactStatus and Missing Detection ───────────────────────────

class TestFactStatusMissing:
    """FactStatus identifies present vs missing/none values."""

    def test_missing_record_value(self):
        raw_record = {"id": "rec1", "type": "unknown_type", "value": None}
        fact = TypedFactAssembler.assemble_records([raw_record])[0]
        # Base class defaults to MISSING if parsed value is None
        assert fact.status == FactStatus.MISSING
        assert fact.parsed_value is None

    def test_present_record_value(self):
        raw_record = {"id": "rec1", "type": "unknown_type", "value": "some_raw"}
        fact = TypedFactAssembler.assemble_records([raw_record])[0]
        assert fact.status == FactStatus.PRESENT
        assert fact.parsed_value == "some_raw"


# ── 4. Relation Invariance ─────────────────────────────────────────

class TestRelationAssembly:
    """Verify structural relation facts are constructed correctly."""

    def test_ref_code_relation(self):
        obj_raw = {"id": "obj1", "type": "health_record", "attrs": {"ref_code": "codeA"}}
        objs = TypedFactAssembler.assemble_objects([obj_raw])
        recs = []
        relations = TypedFactAssembler.assemble_relations(objs, recs)
        assert len(relations) == 1
        assert relations[0].source_id == "obj1"
        assert relations[0].target_id == "codeA"
        assert relations[0].relation_type == "ref_code_link"
        assert relations[0].status == FactStatus.PRESENT

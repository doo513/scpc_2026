# Comparison: submission.csv vs V7_public_friendly_submission.csv

## Changed Counts
- **focal changed count**: 157
- **target changed count**: 187
- **control changed count**: 239
- **scope mode changed count**: 285
- **policy confirmation changed count**: 148
- **plan sequence changed count**: 347

## Major Transitions (Control)
- `ask -> amend`: 45
- `proceed -> amend`: 44
- `amend -> proceed`: 33
- `amend -> hold`: 26
- `proceed -> ask`: 21
- `proceed -> hold`: 20
- `amend -> ask`: 17
- `ask -> proceed`: 16
- `hold -> amend`: 9
- `ask -> hold`: 5
- `hold -> ask`: 2
- `hold -> proceed`: 1

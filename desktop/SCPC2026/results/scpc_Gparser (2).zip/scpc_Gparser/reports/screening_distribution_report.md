# Screening Distribution Report for submission.csv

## Control Distribution
- `amend`: 256
- `ask`: 183
- `hold`: 112
- `proceed`: 149

## Scope Mode Distribution
- `none`: 113
- `raw`: 21
- `redacted`: 263
- `status_only`: 103
- `summary`: 200

## Target Top 30
- `privacy_review`: 156
- `project_room`: 120
- `legal_review`: 95
- `vendor_alpha`: 61
- `memory_store`: 58
- `user`: 52
- `family_room`: 52
- `audit_vendor`: 49
- `clinic_portal`: 21
- `caregiver`: 18
- `fitness_coach`: 9
- `GalaxyStore`: 2
- `child_room`: 1
- `notification_preview`: 1
- `entryway`: 1
- `security_review`: 1
- `gallery_permission`: 1
- `living_room`: 1
- `bedroom`: 1

## Policy Requires Confirmation Distribution
- `True`: 363
- `False`: 337

## Plan Sequence Distribution
- `[read -> redact -> dispatch]`: 256
- `[read -> clarify]`: 183
- `[read -> guard]`: 112
- `[read -> verify -> update]`: 103
- `[read -> summarize -> dispatch]`: 25
- `[read -> dispatch]`: 21

## Custom Metric Counts
- **extra excluded count**: 1106
- **focal marker trace match count**: 463 / 463
- **memory_store count**: 58
- **status_only count**: 103
- **redacted count**: 263
- **proceed count**: 149

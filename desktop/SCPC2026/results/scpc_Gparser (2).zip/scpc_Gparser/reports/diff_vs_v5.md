# Comparison: submission.csv vs submission.csv

## Changed Counts
- **focal changed count**: 0
- **target changed count**: 0
- **control changed count**: 0
- **scope mode changed count**: 0
- **policy confirmation changed count**: 0
- **plan sequence changed count**: 0

## Major Transitions (Control)

# SCPC ActionProfile-first Reference Summary Report

이 문서는 Phase 0 단계에서 동결된 V7, V5, G2 레퍼런스 submission 파일의 MD5 해시값과 screening 분포 통계를 기록합니다.

## V7_public_friendly
- **File Path**: `scpc_parser/reference/V7_public_friendly_submission.csv`
- **MD5 Hash**: `30d781f44eb33c897692db9bde4977a8`
- **Total Answers**: 700

### 분포 통계
| 지표 | 분포 |
| --- | --- |
| **Control** | `amend`: 234, `ask`: 209, `hold`: 73, `proceed`: 184 |
| **Scope Mode** | `none`: 74, `redacted`: 275, `status_only`: 172, `summary`: 179 |
| **requires_confirmation** | 259 |
| **memory_store Target** | 139 |
| **Total Excluded Fields** | 1141 |
| **Plan Verbs** | `clarify`: 209, `dispatch`: 246, `guard`: 73, `read`: 700, `redact`: 234, `summarize`: 12, `update`: 172, `verify`: 172 |

## V5_modular
- **File Path**: `scpc_parser/reference/V5_modular_harness/submission.csv`
- **MD5 Hash**: `f2efdebc4f9eae528a52e862ce7bab35`
- **Total Answers**: 700

### 분포 통계
| 지표 | 분포 |
| --- | --- |
| **Control** | `amend`: 256, `ask`: 183, `hold`: 112, `proceed`: 149 |
| **Scope Mode** | `none`: 113, `raw`: 21, `redacted`: 263, `status_only`: 103, `summary`: 200 |
| **requires_confirmation** | 363 |
| **memory_store Target** | 58 |
| **Total Excluded Fields** | 1106 |
| **Plan Verbs** | `clarify`: 183, `dispatch`: 302, `guard`: 112, `read`: 700, `redact`: 256, `summarize`: 25, `update`: 103, `verify`: 103 |

## G2_record_tree
- **File Path**: `scpc_parser/reference/G2_record_tree_submission.csv`
- **MD5 Hash**: `f8bacf7ef02d4dbd69be0f834931e0b2`
- **Total Answers**: 700

### 분포 통계
| 지표 | 분포 |
| --- | --- |
| **Control** | `amend`: 137, `ask`: 230, `hold`: 72, `proceed`: 261 |
| **Scope Mode** | `none`: 74, `raw`: 9, `redacted`: 280, `status_only`: 213, `summary`: 124 |
| **requires_confirmation** | 363 |
| **memory_store Target** | 165 |
| **Total Excluded Fields** | 1241 |
| **Plan Verbs** | `clarify`: 230, `dispatch`: 185, `guard`: 72, `read`: 700, `redact`: 137, `summarize`: 39, `update`: 213, `verify`: 213 |

# Comparison: submission.csv vs G2_record_tree_submission.csv

## Changed Counts
- **focal changed count**: 157
- **target changed count**: 210
- **control changed count**: 299
- **scope mode changed count**: 353
- **policy confirmation changed count**: 40
- **plan sequence changed count**: 393

## Major Transitions (Control)
- `proceed -> amend`: 97
- `ask -> amend`: 58
- `proceed -> ask`: 39
- `amend -> hold`: 26
- `ask -> proceed`: 25
- `proceed -> hold`: 20
- `amend -> proceed`: 18
- `hold -> amend`: 8
- `ask -> hold`: 5
- `hold -> ask`: 2
- `hold -> proceed`: 1

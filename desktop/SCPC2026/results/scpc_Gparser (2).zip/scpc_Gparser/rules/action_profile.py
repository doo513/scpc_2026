from __future__ import annotations
from typing import Any
from core.pipeline import Stage2Context, ClauseData, EvaluatedCandidate, SubDecisionIR, DecisionBundle
from core.action_profile import ActionProfile
from rules.focal import FocalResolver
from rules.target import TargetResolver

def control_from_profile(profile: ActionProfile) -> str:
    mapping = {
        ActionProfile.HARD_BLOCK: "hold",
        ActionProfile.EXPLICIT_CLARIFICATION: "ask",
        ActionProfile.LOCAL_STATUS_UPDATE: "proceed",
        ActionProfile.TARGET_REBIND_REQUIRED: "ask",
        ActionProfile.MEMORY_CONFLICT_RESOLUTION: "ask",
        ActionProfile.EXTERNAL_REDACTED_DISPATCH: "amend",
        ActionProfile.SAFE_DISPATCH_SUMMARY: "proceed",
        ActionProfile.SAFE_DISPATCH_RAW: "proceed",
        ActionProfile.FALLBACK_CLARIFICATION: "ask",
    }
    return mapping.get(profile, "ask")

class ActionProfileDecider:
    @staticmethod
    def decide_bundle(stage2: Stage2Context, memory_bank: dict[str, Any] | None = None) -> DecisionBundle:
        """
        Step 3 & 4: Evaluate candidates per clause using consolidated global prompt evidence,
        execute Authorized Fallback Solver, and lock DecisionBundle.
        """
        view = stage2.stage1.view
        session = stage2.stage1.session
        available_actions = stage2.stage1.available_actions

        # Consolidated global prompt evidence (union of all clauses)
        global_domain_verbs = []
        global_domain_keywords = []
        global_referencing_keywords = []
        global_is_local_only = False
        global_is_correction = False
        global_is_negation = False
        global_target_rebind = False
        global_override_memory = False
        global_stop_phrases = []
        global_ask_phrases = []

        for clause in stage2.clauses:
            global_domain_verbs.extend(clause.intent.domain_verbs)
            global_domain_keywords.extend(clause.intent.domain_keywords)
            global_referencing_keywords.extend(clause.intent.referencing_keywords)
            if clause.intent.is_local_only:
                global_is_local_only = True
            if clause.intent.is_correction:
                global_is_correction = True
            if clause.intent.is_negation:
                global_is_negation = True
            if clause.intent.target_rebind:
                global_target_rebind = True
            if clause.intent.override_memory:
                global_override_memory = True
            global_stop_phrases.extend(clause.constraint.stop_phrases)
            global_ask_phrases.extend(clause.constraint.ask_phrases)

        # Deduplicate consolidated lists
        global_domain_verbs = list(set(global_domain_verbs))
        global_domain_keywords = list(set(global_domain_keywords))
        global_referencing_keywords = list(set(global_referencing_keywords))
        global_stop_phrases = list(set(global_stop_phrases))
        global_ask_phrases = list(set(global_ask_phrases))

        # Get global consent status and alert status
        consent_val = view.latest_record_value("consent")
        consent_status = "granted"
        if isinstance(consent_val, dict) and consent_val.get("status") in ("revoked", "withdrawn", "denied"):
            consent_status = "revoked"
        elif isinstance(consent_val, str) and consent_val in ("revoked", "withdrawn", "denied"):
            consent_status = "revoked"

        security_alert = bool(view.latest_record_value("security_alert"))
        safety_mode = bool(view.latest_record_value("safety_mode"))

        # Resolve global focal object for memory_ctrl
        direct_focal_id = stage2.stage1.focal_id
        from core.pipeline import IntentEvidence
        temp_intent = IntentEvidence(
            domain_verbs=global_domain_verbs,
            is_local_only=global_is_local_only,
            is_correction=global_is_correction,
            is_negation=global_is_negation,
            target_rebind=global_target_rebind,
            override_memory=global_override_memory,
            domain_keywords=global_domain_keywords,
            referencing_keywords=global_referencing_keywords
        )
        global_focal_id = FocalResolver.resolve_fallback(view, temp_intent, session, direct_focal_id)
        global_focal = view.objects_by_id().get(global_focal_id) or {}

        # memory_ctrl check
        memory_ctrl = ""
        if view.latest_record_value("enterprise_policy_recall"):
            memory_ctrl = "amend"
        elif view.latest_record_value("ops_memory_recall"):
            memory_ctrl = "ask" if view.latest_record_value("target_changed_after_turn") else "amend"
        elif view.latest_record_value("temporary_override_allowed"):
            memory_ctrl = "amend"
        elif view.latest_record_value("persistent_memory_recall") and any(k in global_domain_keywords for k in ["쿠폰"]) and not view.latest_record_value("payment_policy"):
            memory_ctrl = "hold"
        elif global_focal.get("type") == "health_record" and view.latest_record_value("external_share_policy") == "doctor_note_forbidden":
            memory_ctrl = "hold"
        elif view.latest_record_value("ambiguous_focal") and view.latest_record_value("session_share_policy") == "normal":
            memory_ctrl = "ask"

        # Consolidate raw candidate control first to resolve the target correctly
        # explicit_hold check
        explicit_hold = False
        if consent_status == "revoked":
            is_override = global_is_local_only and global_is_correction
            if not is_override:
                explicit_hold = True
        if security_alert or safety_mode:
            if not global_is_local_only:
                explicit_hold = True
        if len(global_stop_phrases) > 0:
            explicit_hold = True

        # explicit_ask check
        explicit_ask = False
        if view.latest_record_value("payment_policy") or view.latest_record_value("memory_conflict") or view.latest_record_value("duration_ambiguous"):
            explicit_ask = True
        if view.latest_record_value("target_changed_after_turn"):
            explicit_ask = True
        if len(global_ask_phrases) > 0:
            if not global_is_local_only:
                explicit_ask = True

        # boundary_ctrl check
        boundary_ctrl = ""
        boundary = str(view.latest_record_value("share_boundary_update") or "")
        if boundary == "dispatch_blocked_until_binding":
            amend_phrases = ["식별 가능한 세부값을 제외", "세부값을 제외", "요약만 공유", "민감 내용은 알아서 처리", "위치나 나이 같은 민감"]
            if any(p in global_domain_keywords for p in amend_phrases):
                boundary_ctrl = "amend"
            elif view.latest_record_value("guardrail_ladder_signal"):
                boundary_ctrl = "hold"
            elif view.latest_record_value("ambiguous_focal") and view.latest_record_value("dispatch_authority_check") == "user_binding_pending":
                boundary_ctrl = "hold"
        elif boundary == "local_update_boundary":
            ambiguous = str(view.latest_record_value("ambiguous_target") or "")
            if view.latest_record_value("ambiguous_focal"):
                boundary_ctrl = "proceed"
            elif ambiguous == "stored_channel_or_visible_recipient":
                boundary_ctrl = "amend"
            elif ambiguous == "approved_channel_or_visible_recipient":
                boundary_ctrl = "ask"
            elif ambiguous == "surface_recipient_and_resolved_target_both_recent":
                boundary_ctrl = "amend"
        elif boundary in ("redacted_external_boundary", "redacted_after_selection_boundary"):
            ambiguous = str(view.latest_record_value("ambiguous_target") or "")
            if ambiguous == "surface_recipient_and_resolved_target_both_recent":
                boundary_ctrl = "ask"
            elif ambiguous == "stored_channel_or_visible_recipient" and any(k in global_domain_keywords for k in ["검진", "점검"]):
                boundary_ctrl = "ask"
            elif view.latest_record_value("guardrail_ladder_signal") and view.latest_record_value("dispatch_authority_check") == "internal_binding_confirmed":
                boundary_ctrl = "proceed"
            else:
                boundary_ctrl = "amend"

        # unresolved_ambiguity check
        unresolved_ambiguity = False
        if view.latest_record_value("ambiguous_target") or view.latest_record_value("ambiguous_focal"):
            authority = str(view.latest_record_value("dispatch_authority_check") or "")
            candidates_snap = str(view.latest_record_value("route_candidate_snapshot") or "")
            if boundary != "local_update_boundary":
                if authority in ("authority_incomplete", "user_binding_pending") and boundary == "dispatch_blocked_until_binding":
                    unresolved_ambiguity = True
                elif candidates_snap == "external_candidates_present" and authority != "internal_binding_confirmed" and not boundary.startswith("redacted"):
                    unresolved_ambiguity = True

        # external_redactable check
        external_redactable = False
        amend_phrases = ["식별 가능한 세부값을 제외", "세부값을 제외", "요약만 공유", "민감 내용은 알아서 처리", "위치나 나이 같은 민감"]
        if any(p in global_domain_keywords for p in amend_phrases):
            external_redactable = True
        elif view.latest_record_value("external_share_policy"):
            external_redactable = True
        elif boundary in ("redacted_external_boundary", "redacted_after_selection_boundary"):
            external_redactable = True
        elif view.latest_record_value("ambiguous_target") and view.latest_record_value("resolved_target"):
            external_redactable = True
        elif view.latest_record_value("session_share_policy") == "strict" and view.latest_record_value("resolved_target"):
            external_redactable = True

        # Resolve candidate control
        candidate_control = "proceed"
        if explicit_hold:
            candidate_control = "hold"
        elif global_is_local_only:
            candidate_control = "proceed"
        elif explicit_ask:
            candidate_control = "ask"
        elif memory_ctrl:
            candidate_control = memory_ctrl
        elif boundary_ctrl:
            candidate_control = boundary_ctrl
        elif unresolved_ambiguity:
            candidate_control = "ask"
        elif external_redactable:
            candidate_control = "amend"

        sub_decisions = []

        # Resolve target and focal using correct control
        for clause_idx, clause in enumerate(stage2.clauses):
            intent = clause.intent
            constraint = clause.constraint

            direct_focal_id = stage2.stage1.focal_id
            # Resolve focal fallback based on global intent keywords
            from core.pipeline import IntentEvidence
            temp_intent = IntentEvidence(
                domain_verbs=global_domain_verbs,
                is_local_only=global_is_local_only,
                is_correction=global_is_correction,
                is_negation=global_is_negation,
                target_rebind=global_target_rebind,
                override_memory=global_override_memory,
                domain_keywords=global_domain_keywords,
                referencing_keywords=global_referencing_keywords
            )
            focal_id = FocalResolver.resolve_fallback(view, temp_intent, session, direct_focal_id)
            focal = view.objects_by_id().get(focal_id) or {}

            # Resolve target fallback based on global constraint
            from core.pipeline import PromptConstraintEvidence
            temp_constraint = PromptConstraintEvidence(
                stop_phrases=global_stop_phrases,
                ask_phrases=global_ask_phrases,
                provenances=[]
            )
            dispatch_target = TargetResolver.resolve_fallback(
                view, temp_intent, temp_constraint, focal_id, candidate_control, session, memory_bank
            )

            # Determine selected candidate action
            if global_is_local_only:
                action = "LOCAL_UPDATE"
                target = "memory_store"
                control = "proceed"
                if len(global_stop_phrases) > 0:
                    control = "hold"
                elif view.latest_record_value("memory_conflict"):
                    control = "ask"
            else:
                # Prioritize domain candidate if eligible, otherwise DISPATCH
                action = "DISPATCH"
                target = dispatch_target
                control = candidate_control
                for act in ["PAY", "TOGGLE", "SCHEDULE"]:
                    if act in global_domain_verbs:
                        action = act
                        break

            # Map control to ActionProfile
            profile_name = ""
            if control == "hold":
                profile_name = ActionProfile.HARD_BLOCK.value
            elif control == "ask":
                if view.latest_record_value("memory_conflict"):
                    profile_name = ActionProfile.MEMORY_CONFLICT_RESOLUTION.value
                elif view.latest_record_value("target_changed_after_turn") or view.latest_record_value("ambiguous_target"):
                    profile_name = ActionProfile.TARGET_REBIND_REQUIRED.value
                elif view.latest_record_value("ambiguous_focal"):
                    profile_name = ActionProfile.FALLBACK_CLARIFICATION.value
                else:
                    profile_name = ActionProfile.EXPLICIT_CLARIFICATION.value
            elif control == "amend":
                profile_name = ActionProfile.EXTERNAL_REDACTED_DISPATCH.value
            else:
                if action == "LOCAL_UPDATE":
                    profile_name = ActionProfile.LOCAL_STATUS_UPDATE.value
                elif boundary == "local_update_boundary" and boundary_ctrl == "proceed":
                    profile_name = ActionProfile.LOCAL_STATUS_UPDATE.value
                else:
                    if any(k in global_domain_keywords for k in ["요약", "정리"]):
                        profile_name = ActionProfile.SAFE_DISPATCH_SUMMARY.value
                    else:
                        profile_name = ActionProfile.SAFE_DISPATCH_RAW.value

            risk_flags = []
            if consent_status == "revoked":
                risk_flags.append("local_only")
            if focal.get("type") == "health_record":
                risk_flags.append("sensitive_content")

            sub_decisions.append(SubDecisionIR(
                clause_index=clause_idx,
                action=action,
                target=target,
                control=control,
                profile_name=profile_name,
                scope_mode="status_only" if action == "LOCAL_UPDATE" else ("redacted" if control == "amend" else ("summary" if profile_name == ActionProfile.SAFE_DISPATCH_SUMMARY.value else "raw")),
                risk_flags=risk_flags,
                violations=[],
                focal_id=focal_id
            ))

        # Compute dependency edges
        dependency_edges = []
        for i in range(len(sub_decisions)):
            for j in range(i + 1, len(sub_decisions)):
                sd_i = sub_decisions[i]
                sd_j = sub_decisions[j]
                if sd_i.focal_id and sd_j.focal_id and sd_i.focal_id == sd_j.focal_id:
                    dependency_edges.append((i, j))

        # Resolve global consolidated outputs from DecisionBundle
        global_control = "proceed"
        global_target = "user"
        global_focal_id = ""

        controls_found = {sd.control for sd in sub_decisions}
        if "hold" in controls_found:
            global_control = "hold"
        elif "ask" in controls_found:
            global_control = "ask"
        elif "amend" in controls_found:
            global_control = "amend"
        else:
            global_control = "proceed"

        # Determine main sub-decision
        main_sd = sub_decisions[0]
        for sd in sub_decisions:
            if sd.action != "LOCAL_UPDATE":
                main_sd = sd
                break

        global_target = main_sd.target
        global_focal_id = main_sd.focal_id

        return DecisionBundle(
            sub_decisions=sub_decisions,
            dependency_edges=dependency_edges,
            global_control=global_control,
            global_target=global_target,
            global_focal_id=global_focal_id
        )

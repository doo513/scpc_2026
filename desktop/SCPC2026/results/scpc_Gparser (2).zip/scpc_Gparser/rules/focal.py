from __future__ import annotations
import re
import json
from typing import Any
from core.task_view import TaskView
from core.pipeline import IntentEvidence
from core.typed_facts import (
    TypedFactAssembler, get_latest_record_value, get_record_values,
    get_object_by_id, get_object_by_ref_code
)

DIRECT_REF_PATTERNS = [
    re.compile(r"기준 참조는 (WM-\d+)"),
    re.compile(r"기준 참조(?: 코드)?는 (WM-\d+)"),
    re.compile(r"처리 대상으로 확정된 .*?참조 코드는 (WM-\d+)"),
    re.compile(r"최종 승인 후보 (WM-\d+)"),
    re.compile(r"승인 표시가 남은 것은 (WM-\d+)"),
    re.compile(r"유효한 항목은 .*?(WM-\d+)"),
    re.compile(r"실제 처리할 ref는 .*?(WM-\d+)"),
]

class FocalResolver:
    @staticmethod
    def resolve_direct(view: TaskView) -> str:
        """Step 1 (Official Requirements): Resolve direct focal ID from JSON facts (marker trace, history, records)."""
        object_facts = TypedFactAssembler.assemble_objects(view.objects)
        if not object_facts:
            return ""

        record_facts = TypedFactAssembler.assemble_records(view.records)

        via_marker = FocalResolver._from_marker_trace(object_facts, record_facts)
        if via_marker:
            return via_marker.object_id
            
        via_history = FocalResolver._from_history_ref(view, object_facts)
        if via_history:
            return via_history.object_id
            
        via_record = FocalResolver._from_direct_record_value(object_facts, record_facts)
        if via_record:
            return via_record.object_id
            
        return ""

    @staticmethod
    def resolve_fallback(view: TaskView, intent: IntentEvidence, session: dict[str, Any], direct_focal_id: str) -> str:
        """Step 3 (Context & Fallback): Resolve fallback focal ID if direct ID is absent."""
        object_facts = TypedFactAssembler.assemble_objects(view.objects)
        record_facts = TypedFactAssembler.assemble_records(view.records)

        if direct_focal_id:
            # If already resolved directly, verify it exists in objects (or session fallback if empty objects)
            if not object_facts:
                last_id = str(session.get("last_focal_id") or "")
                if last_id and any(kw in intent.referencing_keywords for kw in ["방금", "이전", "그거", "그것", "취소", "삭제", "전송"]):
                    return last_id
            return direct_focal_id

        # 1. No objects case
        if not object_facts:
            last_id = str(session.get("last_focal_id") or "")
            if last_id and any(kw in intent.referencing_keywords for kw in ["방금", "이전", "그거", "그것", "취소", "삭제", "전송"]):
                return last_id
            return ""

        # 2. Session fallback with referencing keywords
        last_id = str(session.get("last_focal_id") or "")
        if last_id:
            if get_object_by_id(object_facts, last_id):
                return last_id
            if any(kw in intent.referencing_keywords for kw in ["방금", "이전", "그거", "그것", "취소", "삭제"]):
                return last_id

        # 3. Fallback object scoring using parsed intent keywords
        fallback = FocalResolver._fallback_object(object_facts, record_facts, intent)
        return fallback.object_id if fallback else ""

    @staticmethod
    def _from_marker_trace(object_facts: list, record_facts: list) -> Any | None:
        marker_refs = get_latest_record_value(record_facts, "focal_marker_refs")
        trace = get_latest_record_value(record_facts, "focal_resolution_trace")
        if not isinstance(marker_refs, dict) or not isinstance(trace, dict):
            return None
        marker_to_ref = marker_refs.get("marker_to_ref")
        phase_to_marker = trace.get("phase_to_marker")
        if not isinstance(marker_to_ref, dict) or not isinstance(phase_to_marker, dict):
            return None
            
        phase = str(trace.get("latest_phase") or "")
        if not phase and trace.get("phase_source") == "route_binding_order":
            order = get_latest_record_value(record_facts, "route_binding_order")
            rule = trace.get("latest_phase_rule", {})
            phase = rule.get(order) or rule.get("fallback") or ""
            
        marker = str(phase_to_marker.get(phase) or "")
        ref = str(marker_to_ref.get(marker) or "")
        return get_object_by_ref_code(object_facts, ref)

    @staticmethod
    def _from_history_ref(view: TaskView, object_facts: list) -> Any | None:
        for item in reversed(view._history):
            if isinstance(item, dict):
                summary = str(item.get("summary", item) or "")
            else:
                summary = str(item)
                
            for pattern in DIRECT_REF_PATTERNS:
                match = pattern.search(summary)
                if match:
                    ref_code = match.group(1)
                    matched_obj = get_object_by_ref_code(object_facts, ref_code)
                    if matched_obj:
                        return matched_obj
                    
            refs = re.findall(r"WM-\d+", summary)
            if len(refs) >= 2 and any(phrase in summary for phrase in ["가운데 항목만", "두 번째 후보", "두 번째다"]):
                matched_obj = get_object_by_ref_code(object_facts, refs[1])
                if matched_obj:
                    return matched_obj
            if len(refs) >= 2 and "두 번째" in summary:
                matched_obj = get_object_by_ref_code(object_facts, refs[1])
                if matched_obj:
                    return matched_obj
        return None

    @staticmethod
    def _from_direct_record_value(object_facts: list, record_facts: list) -> Any | None:
        # Check all records (raw value walk)
        for fact in reversed(record_facts):
            for value in FocalResolver._walk(fact.raw_value):
                if isinstance(value, str):
                    matched_obj = get_object_by_id(object_facts, value)
                    if matched_obj:
                        return matched_obj
                    matched_obj = get_object_by_ref_code(object_facts, value)
                    if matched_obj:
                        return matched_obj
        return None

    @staticmethod
    def _walk(value: Any) -> list[Any]:
        if isinstance(value, dict):
            out: list[Any] = []
            for child in value.values():
                out.extend(FocalResolver._walk(child))
            return out
        if isinstance(value, list):
            out = []
            for child in value:
                out.extend(FocalResolver._walk(child))
            return out
        return [value]

    @staticmethod
    def _fallback_object(object_facts: list, record_facts: list, intent: IntentEvidence) -> Any | None:
        scored: list[tuple[int, int, Any]] = []
        resolved_target = get_latest_record_value(record_facts, "resolved_target")
        
        # Check domain keywords parsed from prompt
        kws = intent.domain_keywords
        
        for idx, obj in enumerate(object_facts):
            attrs = obj.attrs
            # Reconstruct serialization representation for matching keywords
            blob = (obj.object_id + " " + obj.object_type + " " + json.dumps(attrs, ensure_ascii=False)).lower()
            score = 0
            if "원본" in kws and "원본" in blob:
                score += 4
            if "사진" in kws and obj.object_type == "gallery_item":
                score += 2
            if "건강" in kws and obj.object_type == "health_record":
                score += 4
            if "설정" in kws and obj.object_type == "device_setting":
                score += 4
            if "메모리" in kws and obj.object_type == "personal_note":
                score += 3
            if attrs.get("recipient") == resolved_target:
                score += 2
            scored.append((score, -idx, obj))
            
        if not scored:
            return None
        return max(scored, key=lambda x: (x[0], x[1]))[2]

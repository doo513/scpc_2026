from __future__ import annotations
from typing import Any
from core.task_view import TaskView
from core.pipeline import IntentEvidence, DecisionBundle, SubDecisionIR
from core.action_profile import ActionProfile

def focal_contains(focal: dict[str, Any]) -> set[str]:
    attrs = focal.get("attrs") or {}
    raw = attrs.get("contains")
    if raw is None:
        raw = attrs.get("fields")
    return {str(x) for x in raw} if isinstance(raw, list) else set()

class ScopePolicyJointBuilder:
    @staticmethod
    def build(
        view: TaskView,
        intent: IntentEvidence,
        bundle: DecisionBundle,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """
        Step 5 (Output Compilation): Purely compile scope and policy based on the locked DecisionBundle.
        """
        # Determine main active profile and target
        global_control = bundle.global_control
        global_target = bundle.global_target
        focal_id = bundle.global_focal_id
        focal = view.objects_by_id().get(focal_id) or {}
        contains = focal_contains(focal)

        # 1. Compile content_scope
        main_sd = bundle.sub_decisions[0]
        for sd in bundle.sub_decisions:
            if sd.action != "LOCAL_UPDATE":
                main_sd = sd
                break

        profile = ActionProfile(main_sd.profile_name)
        content_scope = ScopePolicyJointBuilder.build_content_scope_profile(view, intent, profile, focal_id, global_target)

        # 2. Compile policy
        policy = ScopePolicyJointBuilder.build_policy_profile(view, intent, profile, focal, global_target, content_scope)

        return content_scope, policy

    @staticmethod
    def build_content_scope_profile(
        view: TaskView,
        intent: IntentEvidence,
        profile: ActionProfile,
        focal_id: str,
        target: str,
    ) -> dict[str, Any]:
        focal = view.objects_by_id().get(focal_id) or {}
        contains = focal_contains(focal)

        if profile == ActionProfile.HARD_BLOCK:
            return {"mode": "none", "allowed_fields": [], "excluded_fields": [], "requires_user_confirmation": False}

        elif profile == ActionProfile.LOCAL_STATUS_UPDATE:
            return {
                "mode": "status_only",
                "allowed_fields": ["status"],
                "excluded_fields": ["raw_quote", "location", "numeric_value"],
                "requires_user_confirmation": False,
            }

        elif profile in (
            ActionProfile.EXPLICIT_CLARIFICATION,
            ActionProfile.TARGET_REBIND_REQUIRED,
            ActionProfile.MEMORY_CONFLICT_RESOLUTION,
            ActionProfile.FALLBACK_CLARIFICATION,
        ):
            return ScopePolicyJointBuilder._ask_scope(view, intent, contains, target, focal_id)

        elif profile == ActionProfile.EXTERNAL_REDACTED_DISPATCH:
            return {
                "mode": "redacted",
                "allowed_fields": ["summary"],
                "excluded_fields": ScopePolicyJointBuilder._redaction_exclusions(view, intent, contains),
                "requires_user_confirmation": ScopePolicyJointBuilder._requires_confirmation_scope(view),
            }

        elif profile in (ActionProfile.SAFE_DISPATCH_SUMMARY, ActionProfile.SAFE_DISPATCH_RAW):
            focal = view.objects_by_id().get(focal_id) or {}
            if ScopePolicyJointBuilder._raw_allowed(view, intent, focal, target):
                return {"mode": "raw", "allowed_fields": ["summary", "title"], "excluded_fields": [], "requires_user_confirmation": False}
            else:
                return {"mode": "summary", "allowed_fields": ["summary"], "excluded_fields": [], "requires_user_confirmation": False}

        return {"mode": "summary", "allowed_fields": ["summary"], "excluded_fields": [], "requires_user_confirmation": False}

    @staticmethod
    def _ask_scope(view: TaskView, intent: IntentEvidence, contains: set[str], target: str, focal_id: str) -> dict[str, Any]:
        kws = intent.domain_keywords
        if ("원본" in kws and "사진" in kws) or ("원본" in kws and "사진" in kws and "요약" in kws):
            if target in {"audit_vendor", "privacy_review"}:
                excluded = ScopePolicyJointBuilder._redaction_exclusions(view, intent, contains)
                mode = "redacted"
            else:
                excluded = ["name"]
                mode = "summary"
            if target == "privacy_review" and view.latest_record_value("share_boundary_update") == "dispatch_blocked_until_binding":
                mode = "none"
                excluded = []
            return {"mode": mode, "allowed_fields": [] if mode == "none" else ["summary"], "excluded_fields": excluded, "requires_user_confirmation": True}

        if "전제" in kws and "doctor_note" in contains:
            return {"mode": "redacted", "allowed_fields": ["summary"], "excluded_fields": ["raw_quote"], "requires_user_confirmation": True}

        # Handle explicit safety/premise prompt keywords
        if target != "user" and view.latest_record_value("session_share_policy") == "strict":
            if any(kw in kws for kw in ["신호", "전제", "모호성", "상위 금지"]):
                return {"mode": "redacted", "allowed_fields": ["summary"], "excluded_fields": ["raw_quote"], "requires_user_confirmation": True}

        boundary = str(view.latest_record_value("share_boundary_update") or "")
        if target == "user" and boundary in ("redacted_external_boundary", "redacted_after_selection_boundary"):
            return {"mode": "redacted", "allowed_fields": ["summary"], "excluded_fields": ["raw_quote"], "requires_user_confirmation": True}

        if view.latest_record_value("target_changed_after_turn") == "prior_success_route_superseded":
            return {"mode": "none", "allowed_fields": [], "excluded_fields": [], "requires_user_confirmation": True}

        if view.latest_record_value("duration_ambiguous"):
            return {"mode": "redacted", "allowed_fields": ["summary"], "excluded_fields": ["raw_quote"], "requires_user_confirmation": True}

        # Check target_changed_after_turn depending on strict share policy and external recipient
        if target != "user" and view.latest_record_value("target_changed_after_turn"):
            if view.latest_record_value("session_share_policy") == "strict":
                focal = view.objects_by_id().get(focal_id) or {}
                recipient = str(focal.get("attrs", {}).get("recipient") or "")
                if "vendor" in recipient:
                    return {"mode": "redacted", "allowed_fields": ["summary"], "excluded_fields": ["raw_quote"], "requires_user_confirmation": True}
            return {"mode": "summary", "allowed_fields": ["summary"], "excluded_fields": ["raw_quote"], "requires_user_confirmation": True}

        return {"mode": "summary", "allowed_fields": ["summary"], "excluded_fields": ScopePolicyJointBuilder._summary_exclusions(contains) or ["raw_quote"], "requires_user_confirmation": True}

    @staticmethod
    def _summary_exclusions(contains: set[str]) -> list[str]:
        if "name" in contains and "raw_quote" not in contains:
            return ["name"]
        if "name" in contains and "rrn" in contains and "raw_quote" in contains:
            return ["name"]
        if "raw_quote" in contains:
            return ["raw_quote"]
        return []

    @staticmethod
    def _redaction_exclusions(view: TaskView, intent: IntentEvidence, contains: set[str]) -> list[str]:
        policy = str(view.latest_record_value("external_share_policy") or "").lower()
        if "doctor_note_forbidden" in policy and "doctor_note" in contains:
            return ["doctor_note"]
        if "raw_sensitive_forbidden" in policy:
            items = [x for x in ["name", "numeric_value", "raw_quote", "rrn"] if x in contains or x == "numeric_value"]
            return items or ["sensitive_fields"]
        
        kws = intent.domain_keywords
        if ("원본" in kws and "사진" in kws) or ("원본" in kws and "사진" in kws and "요약" in kws) or "정산" in kws or "출장" in kws:
            items = [x for x in ["name", "numeric_value", "raw_quote", "rrn"] if x in contains or x == "numeric_value"]
            return items or ["name"]
        if contains & {"location", "numeric_value"} and not contains & {"name", "rrn"}:
            return ["location", "numeric_value", "raw_quote"] if "raw_quote" in contains else ["location", "numeric_value"]
        return ["raw_quote"]

    @staticmethod
    def _requires_confirmation_scope(view: TaskView) -> bool:
        if view.latest_record_value("ambiguous_target") or view.latest_record_value("target_changed_after_turn"):
            return True
        if view.latest_record_value("dispatch_authority_check") in {"authority_incomplete", "user_binding_pending"}:
            return True
        return False

    @staticmethod
    def _raw_allowed(view: TaskView, intent: IntentEvidence, focal: dict[str, Any], target: str) -> bool:
        if (
            view.latest_record_value("guardrail_ladder_signal")
            and view.latest_record_value("share_boundary_update") == "redacted_external_boundary"
            and view.latest_record_value("dispatch_authority_check") == "internal_binding_confirmed"
        ):
            return True
        if view.latest_record_value("session_share_policy") != "normal":
            return False
        if view.latest_record_value("external_share_policy"):
            return False
        if view.latest_record_value("ambiguous_target") or view.latest_record_value("ambiguous_focal"):
            return False
        
        contains = focal_contains(focal)
        if target in {"project_room", "privacy_review"} and "회의" in intent.domain_keywords:
            return True
        return False

    @staticmethod
    def build_policy_profile(
        view: TaskView,
        intent: IntentEvidence,
        profile: ActionProfile,
        focal: dict[str, Any],
        target: str,
        scope: dict[str, Any],
    ) -> dict[str, Any]:
        flags: list[str] = []
        violations: list[str] = []
        contains = focal_contains(focal)
        mapping = {
            ActionProfile.HARD_BLOCK: "hold",
            ActionProfile.EXPLICIT_CLARIFICATION: "ask",
            ActionProfile.LOCAL_STATUS_UPDATE: "proceed",
            ActionProfile.TARGET_REBIND_REQUIRED: "ask",
            ActionProfile.MEMORY_CONFLICT_RESOLUTION: "ask",
            ActionProfile.EXTERNAL_REDACTED_DISPATCH: "amend",
            ActionProfile.SAFE_DISPATCH_SUMMARY: "proceed",
            ActionProfile.SAFE_DISPATCH_RAW: "proceed",
            ActionProfile.FALLBACK_CLARIFICATION: "ask",
        }
        control = mapping.get(profile, "ask")

        if view.latest_record_value("session_share_policy") == "strict":
            flags.append("strict_share_policy")
        if target != "memory_store" and target != "user":
            flags.append("external_share")
        if (
            profile == ActionProfile.LOCAL_STATUS_UPDATE
            or target == "memory_store"
            or target == "user"
            or view.latest_record_value("share_boundary_update") == "local_update_boundary"
        ):
            flags.append("local_only")
        sensitive_candidates = {"raw_quote", "rrn", "name", "location", "numeric_value", "doctor_note", "image", "amount"}
        if contains & sensitive_candidates:
            flags.append("sensitive_content")
        if view.latest_record_value("ambiguous_target"):
            flags.append("target_ambiguity")
        if view.latest_record_value("ambiguous_focal"):
            flags.append("ambiguous_focal")
        if profile == ActionProfile.EXTERNAL_REDACTED_DISPATCH:
            flags.append("minimal_disclosure")
        if profile in (
            ActionProfile.EXPLICIT_CLARIFICATION,
            ActionProfile.TARGET_REBIND_REQUIRED,
            ActionProfile.MEMORY_CONFLICT_RESOLUTION,
            ActionProfile.FALLBACK_CLARIFICATION,
        ):
            flags.append("clarification_required")
        if ScopePolicyJointBuilder._precondition_changed(view) and not intent.is_local_only:
            boundary = view.latest_record_value("share_boundary_update")
            if boundary not in ("local_update_boundary", "dispatch_blocked_until_binding"):
                flags.append("precondition_changed")
        if profile == ActionProfile.HARD_BLOCK:
            flags.extend(["precondition_invalidated", "safety"])
            violations.append("precondition_changed_ignored")

        # Deduplicate while preserving order
        unique_flags = []
        for f in flags:
            if f not in unique_flags:
                unique_flags.append(f)

        unique_violations = []
        for v in violations:
            if v not in unique_violations:
                unique_violations.append(v)

        return {
            "risk_flags": unique_flags,
            "violations": unique_violations,
            "requires_confirmation": ScopePolicyJointBuilder._requires_confirmation_policy(view, control, scope),
        }

    @staticmethod
    def _precondition_changed(view: TaskView) -> bool:
        return (
            view.latest_record_value("ambiguous_target")
            or view.latest_record_value("target_changed_after_turn")
            or view.latest_record_value("duration_ambiguous")
            or view.latest_record_value("guardrail_ladder_signal")
            or view.latest_record_value("ambiguous_focal")
        )

    @staticmethod
    def _requires_confirmation_policy(view: TaskView, control: str, scope: dict[str, Any]) -> bool:
        if control == "hold":
            return False
        if control == "ask":
            return True
        if bool(scope.get("requires_user_confirmation")):
            return True
        if view.latest_record_value("ambiguous_target") or view.latest_record_value("target_changed_after_turn"):
            return True
        if view.latest_record_value("share_boundary_update") != "local_update_boundary":
            if view.latest_record_value("dispatch_authority_check") in {"authority_incomplete", "user_binding_pending"}:
                return True
        return False

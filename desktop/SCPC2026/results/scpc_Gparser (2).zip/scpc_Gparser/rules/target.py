from __future__ import annotations
from dataclasses import dataclass
from typing import Any
from core.task_view import TaskView
from core.pipeline import IntentEvidence, PromptConstraintEvidence
from core.typed_facts import (
    TypedFactAssembler, get_latest_record_value, get_record_values,
    get_object_by_id, get_object_by_ref_code
)

class TargetResolver:
    @dataclass
    class MemoryEntry:
        key: str
        value: dict[str, Any]
        source_session_id: str
        source_task_id: str
        source_turn_index: int
        recall_scope: str  # cross_session | same_session | global

    @staticmethod
    def resolve_direct(view: TaskView) -> str:
        """Step 1 (Official Requirements): Resolve direct target from target_changed_after_turn."""
        record_facts = TypedFactAssembler.assemble_records(view.records)
        changed = get_latest_record_value(record_facts, "target_changed_after_turn")
        if isinstance(changed, str) and changed and "superseded" not in changed and "prior_success" not in changed:
            return changed
        return ""

    @staticmethod
    def resolve_fallback(
        view: TaskView,
        intent: IntentEvidence,
        constraint: PromptConstraintEvidence,
        focal_id: str,
        control: str,
        session: dict[str, Any],
        memory_bank: dict[str, Any] | None = None,
    ) -> str:
        """Step 3 (Context & Fallback): Resolve target with fallback, memory recall, and session context."""
        object_facts = TypedFactAssembler.assemble_objects(view.objects)
        record_facts = TypedFactAssembler.assemble_records(view.records)

        focal_obj = get_object_by_id(object_facts, focal_id)
        
        # 1. Local update phrase check (maps to memory_store)
        if intent.is_local_only:
            return "memory_store"

        # 2. persistent_memory_write record check
        if get_latest_record_value(record_facts, "persistent_memory_write"):
            return "memory_store"

        # 3. Direct resolved target from Step 1
        direct = TargetResolver.resolve_direct(view)
        if direct:
            return direct

        # 4. Memory recall target
        recalled = TargetResolver._target_from_memory_recall(view, object_facts, record_facts, intent, memory_bank)
        if recalled:
            return recalled

        # 5. Hold or Ask targets check
        if control in ("hold", "ask"):
            return TargetResolver._blocked_or_ask_target(view, object_facts, record_facts, focal_obj, control, intent, constraint, memory_bank)

        # 6. Resolved target record check (resolved_target)
        resolved = get_latest_record_value(record_facts, "resolved_target")
        if isinstance(resolved, str) and resolved:
            return resolved

        # 6. Focal attrs fallback
        attrs = focal_obj.attrs if focal_obj else {}
        for key in ("recipient", "target", "channel", "app", "merchant", "name", "attendee"):
            if attrs.get(key):
                return str(attrs[key])

        # 7. Session last target fallback / user fallback
        return str(view.session_state.get("last_target") or "user")

    @staticmethod
    def _target_from_memory_recall(
        view: TaskView,
        object_facts: list,
        record_facts: list,
        intent: IntentEvidence,
        memory_bank: dict[str, Any] | None = None,
    ) -> str:
        session = view.session_state
        mem_dict = session.get("memory") or {}
        memory_bank = memory_bank or {}

        # Check prompt override that rejects memory
        prompt_rejects_memory = intent.override_memory or any(
            kw in intent.referencing_keywords for kw in ["새로운 수신처", "수신처"]
        )

        for value in reversed(get_record_values(record_facts, "persistent_memory_recall")):
            if not isinstance(value, dict):
                continue

            key = str(value.get("memory_key") or "")
            if not key:
                continue

            # Provenance retrieval
            memory = mem_dict.get(key)
            recall_scope = "same_session"
            if not memory:
                memory = memory_bank.get(key)
                recall_scope = "cross_session"

            if not memory:
                continue

            actual_mem = memory.get("value") if isinstance(memory, dict) and "value" in memory else memory
            if not isinstance(actual_mem, dict):
                continue

            if prompt_rejects_memory:
                continue

            if value.get("memory_class") == "prior_result":
                for key2 in ("last_success_target", "approval_channel", "preferred_channel", "health_channel"):
                    if actual_mem.get(key2):
                        return str(actual_mem[key2])
            if value.get("memory_class") == "standing_constraint":
                for key2 in ("last_success_target", "approval_channel", "preferred_channel"):
                    if actual_mem.get(key2):
                        return str(actual_mem[key2])

            # Domain keyword fallbacks (checking parsed keywords instead of raw prompt)
            kws = intent.domain_keywords
            if any(k in kws for k in ["조명", "어두워질", "어두워"]):
                if actual_mem.get("dusk_room"):
                    return str(actual_mem["dusk_room"])

            if any(k in kws for k in ["검진", "점검"]):
                for key2 in ("health_channel", "preferred_channel", "approval_channel"):
                    if actual_mem.get(key2):
                        return str(actual_mem[key2])

            for key2 in ("preferred_channel", "health_channel", "approval_channel", "last_success_target"):
                if actual_mem.get(key2):
                    return str(actual_mem[key2])

        # Recalled person fallback
        for value in reversed(get_record_values(record_facts, "persistent_memory_recall")):
            if not isinstance(value, dict):
                continue
            person = str(value.get("person") or "")
            
            kws = intent.domain_keywords
            if any(k in kws for k in ["조명", "어두워질", "어두워"]):
                return "living_room"
            if any(k in kws for k in ["검진", "점검"]):
                if person == "jimin":
                    return "clinic_portal"
                return "caregiver"

            if person:
                # If there are records for trusted subscription
                trusted = get_latest_record_value(record_facts, "trusted_subscription")
                if isinstance(trusted, str) and trusted:
                    return trusted
                return person

        return ""

    @staticmethod
    def _hold_to_user(record_facts: list, constraint: PromptConstraintEvidence) -> bool:
        # Prompt stop_phrases match
        if len(constraint.stop_phrases) > 0:
            return True
        consent_val = get_latest_record_value(record_facts, "consent")
        if isinstance(consent_val, dict) and consent_val.get("status") == "revoked":
            return False
        if isinstance(consent_val, str) and consent_val == "revoked":
            return False
        if get_latest_record_value(record_facts, "security_alert") or get_latest_record_value(record_facts, "safety_mode"):
            return False
        return False

    @staticmethod
    def _asks_user(record_facts: list, intent: IntentEvidence, constraint: PromptConstraintEvidence) -> bool:
        kws = intent.domain_keywords
        ref = intent.referencing_keywords
        ask_kws = ["전제", "확인", "누구", "범위", "결론", "물어", "확인하지"]
        if len(constraint.ask_phrases) > 0 or any(k in kws or k in ref for k in ask_kws):
            return True
        if get_latest_record_value(record_facts, "duration_ambiguous"):
            return True
        if get_latest_record_value(record_facts, "ambiguous_target") == "approved_channel_or_visible_recipient":
            return False
        return False

    @staticmethod
    def _blocked_or_ask_target(
        view: TaskView,
        object_facts: list,
        record_facts: list,
        focal_obj: Any | None,
        control: str,
        intent: IntentEvidence,
        constraint: PromptConstraintEvidence,
        memory_bank: dict[str, Any] | None = None,
    ) -> str:
        recalled = TargetResolver._target_from_memory_recall(view, object_facts, record_facts, intent, memory_bank)
        if control == "ask" and TargetResolver._asks_user(record_facts, intent, constraint) and not recalled:
            return "user"
        if control == "hold" and TargetResolver._hold_to_user(record_facts, constraint):
            return "user"
        resolved = get_latest_record_value(record_facts, "resolved_target")
        if isinstance(resolved, str) and resolved:
            return resolved
        if recalled:
            return recalled
        attrs = focal_obj.attrs if focal_obj else {}
        for key in ("recipient", "target", "channel", "app", "merchant", "name", "attendee"):
            if attrs.get(key):
                return str(attrs[key])
        return str(view.session_state.get("last_target") or "user")

from __future__ import annotations
import json
import warnings
from pathlib import Path
from typing import Any
from core.task_view import TaskView
from core.pipeline import IntentEvidence
from core.action_profile import ActionProfile

BASE_DIR = Path(__file__).parent.parent

def control_from_profile(profile: ActionProfile) -> str:
    mapping = {
        ActionProfile.HARD_BLOCK: "hold",
        ActionProfile.EXPLICIT_CLARIFICATION: "ask",
        ActionProfile.LOCAL_STATUS_UPDATE: "proceed",
        ActionProfile.TARGET_REBIND_REQUIRED: "ask",
        ActionProfile.MEMORY_CONFLICT_RESOLUTION: "ask",
        ActionProfile.EXTERNAL_REDACTED_DISPATCH: "amend",
        ActionProfile.SAFE_DISPATCH_SUMMARY: "proceed",
        ActionProfile.SAFE_DISPATCH_RAW: "proceed",
        ActionProfile.FALLBACK_CLARIFICATION: "ask",
    }
    return mapping.get(profile, "ask")

def normalize_event(event: dict[str, Any], task_id: str) -> tuple[dict[str, Any], list[str]]:
    normalized = {"verb": event["verb"], "target": event["target"], "args": {}}
    warnings = []
    
    # Verb validation
    from core.spec import PLAN_VERBS, PLAN_PURPOSES, PLAN_REASONS, PLAN_SCOPES
    if normalized["verb"] not in PLAN_VERBS:
        warnings.append(f"Unknown plan verb '{normalized['verb']}'")
        
    for k, v in event.get("args", {}).items():
        if k == "purpose":
            normalized["args"]["purpose"] = v
            if v not in PLAN_PURPOSES:
                warnings.append(f"Unknown plan arg purpose value '{v}'")
        elif k == "reason":
            normalized["args"]["reason"] = v
            if v not in PLAN_REASONS:
                warnings.append(f"Unknown plan arg reason value '{v}'")
        elif k == "scope":
            normalized["args"]["scope"] = v
            if v not in PLAN_SCOPES:
                warnings.append(f"Unknown plan arg scope value '{v}'")
        else:
            normalized["args"][k] = v
            if k not in ("remove", "state", "mode"):
                warnings.append(f"Unknown plan arg key '{k}'")
                
    return normalized, warnings


class PlanTemplateBuilder:
    @staticmethod
    def build(
        view: TaskView,
        intent: IntentEvidence,
        profile: ActionProfile,
        focal_id: str,
        target: str,
        content_scope: dict[str, Any],
        policy: dict[str, Any],
    ) -> list[dict[str, Any]]:
        """
        Step 5 (Output Compilation): Purely compile plan events based on locked decisions and compiled scopes.
        """
        control = control_from_profile(profile)
        fid = str(focal_id) if focal_id else ""
        
        if control == "hold":
            template = [
                {"verb": "read", "target": fid, "args": {"purpose": "invalidated_precondition"}},
                {"verb": "guard", "target": fid, "args": {"reason": "precondition_invalidated"}},
            ]
        elif control == "ask":
            authority = view.latest_record_value("dispatch_authority_check")
            is_auth_confirmed = (authority == "internal_binding_confirmed")
            reason = "precondition_changed" if (profile != ActionProfile.FALLBACK_CLARIFICATION and is_auth_confirmed and PlanTemplateBuilder._clarify_precondition(intent)) else "route_resolution_required"
            purpose = "clarify_precondition" if reason == "precondition_changed" else "route_resolution_required"
            template = [
                {"verb": "read", "target": fid, "args": {"purpose": purpose}},
                {"verb": "clarify", "target": "user", "args": {"reason": reason}},
            ]
        elif profile == ActionProfile.LOCAL_STATUS_UPDATE:
            template = [
                {"verb": "read", "target": fid, "args": {"purpose": "local_update"}},
                {"verb": "verify", "target": "share_boundary_update", "args": {"scope": "local_update"}},
                {"verb": "update", "target": fid, "args": {"state": "local_status_only"}},
            ]
        else:
            terminal_verb = "dispatch"
            t_lower = str(target or "").lower()
            if "calendar" in t_lower:
                terminal_verb = "schedule"
            elif any(d in t_lower for d in ["light", "thermostat", "heating", "plug", "device"]):
                terminal_verb = "toggle"
            elif any(m in t_lower for m in ["merchant", "store", "seller", "shop", "pay"]):
                terminal_verb = "pay"

            if control == "amend":
                remove = "sensitive_fields" if PlanTemplateBuilder._remove_sensitive_fields(content_scope) else "raw_quote"
                template = [
                    {"verb": "read", "target": fid, "args": {"purpose": "minimal_disclosure"}},
                    {"verb": "redact", "target": fid, "args": {"remove": remove}},
                    {"verb": terminal_verb, "target": target, "args": {"scope": "redacted"}},
                ]
            elif content_scope.get("mode") == "summary":
                template = [
                    {"verb": "read", "target": fid, "args": {"purpose": "inspect_context"}},
                    {"verb": "summarize", "target": fid, "args": {"mode": "summary"}},
                    {"verb": terminal_verb, "target": target, "args": {"scope": "summary"}},
                ]
            else:
                template = [
                    {"verb": "read", "target": fid, "args": {"purpose": "inspect_context"}},
                    {"verb": terminal_verb, "target": target, "args": {"scope": content_scope.get("mode", "raw")}},
                ]
            
        # Normalize and log warnings
        normalized_template = []
        all_warnings = []
        task_id = view.task_id
        
        for event in template:
            norm_event, warnings_list = normalize_event(event, task_id)
            normalized_template.append(norm_event)
            all_warnings.extend(warnings_list)
            
        if all_warnings:
            reports_dir = BASE_DIR / "reports"
            reports_dir.mkdir(parents=True, exist_ok=True)
            log_file = reports_dir / "ontology_warnings.jsonl"
            with open(log_file, "a", encoding="utf-8") as f:
                for w in all_warnings:
                    log_entry = {
                        "task_id": task_id,
                        "warning": w,
                        "plan_events": normalized_template
                    }
                    f.write(json.dumps(log_entry, ensure_ascii=False) + "\n")
                    
        return normalized_template

    @staticmethod
    def _clarify_precondition(intent: IntentEvidence) -> bool:
        kws = intent.domain_keywords
        return intent.is_correction or any(k in kws for k in ["전제", "전제가", "신호", "모호성", "상위 금지", "금지"])

    @staticmethod
    def _remove_sensitive_fields(scope: dict[str, Any]) -> bool:
        excluded = set(scope.get("excluded_fields") or [])
        return bool(excluded & {"name", "rrn", "numeric_value", "doctor_note", "location", "amount", "card_number"})

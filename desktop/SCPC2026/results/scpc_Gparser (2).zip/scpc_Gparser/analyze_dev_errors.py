from __future__ import annotations

import json
from pathlib import Path
from collections import defaultdict
from enum import Enum

from local_score import score_answer
from run_submission import run_tasks
from utils.io import find_data_dir, load_jsonl
from core.task_view import TaskView


class SafeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, set):
            return sorted(list(o))
        if isinstance(o, Enum):
            return o.value
        try:
            import dataclasses
            if dataclasses.is_dataclass(o) and not isinstance(o, type):
                return dataclasses.asdict(o)
        except Exception:
            pass
        return str(o)

BASE_DIR = Path(__file__).resolve().parent


def analyze_errors() -> None:
    data_dir = find_data_dir()
    tasks = load_jsonl(data_dir / "dev_tasks.jsonl")
    refs = json.loads((data_dir / "dev_answers.json").read_text(encoding="utf-8"))["answers"]
    
    # run tasks gets payload containing both "answers" (clean) and "_raw_answers" (with private fields)
    payload = run_tasks(tasks)
    raw_answers = payload.get("_raw_answers", {})
    
    error_cases = []
    by_task = {str(t["id"]): t for t in tasks}
    
    for task_id, ref in refs.items():
        # Get raw answer with private fields
        pred_raw = raw_answers.get(task_id, {})
        pred_clean = payload["answers"][task_id]
        
        scores = score_answer(pred_clean, ref)
        bad_axes = [axis for axis in ("focal", "target", "control", "content_scope", "policy", "plan") if scores[axis] < 1.0]
        
        if bad_axes:
            task = by_task[task_id]
            view = TaskView(task)
            
            # Extract evidence summary from raw answer metadata if present
            ev_summary = {}
            evidence_obj = pred_raw.get("evidence")
            if evidence_obj:
                import dataclasses
                if hasattr(evidence_obj, "__dict__"):
                    ev_summary = {}
                    for k, v in evidence_obj.__dict__.items():
                        if k.startswith("_"):
                            continue
                        if dataclasses.is_dataclass(v):
                            ev_summary[k] = dataclasses.asdict(v)
                        elif isinstance(v, set):
                            ev_summary[k] = list(v)
                        else:
                            ev_summary[k] = v
                elif isinstance(evidence_obj, dict):
                    ev_summary = evidence_obj
            
            route_bundle = ev_summary.get("route_bundle", {}) if isinstance(ev_summary, dict) else {}
            
            for axis in bad_axes:
                # Map expected/actual based on axis
                expected = ""
                actual = ""
                if axis == "focal":
                    expected = ref.get("focal_id", "")
                    actual = pred_clean.get("focal_id", "")
                elif axis == "target":
                    expected = ref.get("target", "")
                    actual = pred_clean.get("target", "")
                elif axis == "control":
                    expected = ref.get("control", "")
                    actual = pred_clean.get("control", "")
                elif axis == "content_scope":
                    expected = json.dumps(ref.get("content_scope"), ensure_ascii=False)
                    actual = json.dumps(pred_clean.get("content_scope"), ensure_ascii=False)
                elif axis == "policy":
                    expected = json.dumps(ref.get("policy"), ensure_ascii=False)
                    actual = json.dumps(pred_clean.get("policy"), ensure_ascii=False)
                elif axis == "plan":
                    expected = json.dumps(ref.get("expected_events"), ensure_ascii=False)
                    actual = json.dumps(pred_clean.get("plan_events"), ensure_ascii=False)
                    
                error_cases.append({
                    "task_id": task_id,
                    "axis": axis,
                    "expected": expected,
                    "actual": actual,
                    "profile": pred_raw.get("profile", "unknown"),
                    "focal_type": view.object_type(pred_clean.get("focal_id", "")),
                    "target": pred_clean.get("target", ""),
                    "record_types": sorted(list(view.records_by_type().keys())),
                    "latest_clause": view.latest_clause(),
                    "route_bundle": route_bundle,
                    "evidence_summary": ev_summary
                })
                
    reports_dir = BASE_DIR / "reports"
    reports_dir.mkdir(parents=True, exist_ok=True)
    
    error_cases_file = reports_dir / "error_cases.jsonl"
    with open(error_cases_file, "w", encoding="utf-8") as f:
        for case in error_cases:
            f.write(json.dumps(case, ensure_ascii=False, cls=SafeEncoder) + "\n")
            
    print(f"wrote {len(error_cases)} error cases to {error_cases_file}")
    
    # Print error counts summary
    counts = defaultdict(int)
    for case in error_cases:
        counts[case["axis"]] += 1
    print("Error counts:")
    for axis, count in counts.items():
        print(f"  {axis}: {count}")


if __name__ == "__main__":
    analyze_errors()

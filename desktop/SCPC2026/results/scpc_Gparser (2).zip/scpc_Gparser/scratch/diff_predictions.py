import json
from harness import FinalHarness
from local_score import _similar_policy, _plan_score

harness = FinalHarness()
tasks = [json.loads(line) for line in open("/mnt/c/Users/doo33/Desktop/data/dev_tasks.jsonl")]
answers = json.load(open("/mnt/c/Users/doo33/Desktop/data/dev_answers.json"))["answers"]

sessions = {}
mismatches = 0
for task in tasks:
    tid = task["id"]
    sess_id = task["session_id"]
    session = sessions.setdefault(sess_id, {})
    ans = harness.answer_task(task, session)
    expected = answers.get(tid, {})
    
    diffs = []
    if ans["focal_id"] != expected.get("focal_id"):
        diffs.append(f"focal_id: expected {expected.get('focal_id')}, got {ans['focal_id']}")
    if ans["target"] != expected.get("target"):
        diffs.append(f"target: expected {expected.get('target')}, got {ans['target']}")
    if ans["control"] != expected.get("control"):
        diffs.append(f"control: expected {expected.get('control')}, got {ans['control']}")
    if ans["content_scope"]["mode"] != expected.get("content_scope", {}).get("mode"):
        diffs.append(f"scope_mode: expected {expected.get('content_scope', {}).get('mode')}, got {ans['content_scope']['mode']}")
        
    policy_score = _similar_policy(ans.get("policy"), expected.get("policy"))
    if policy_score < 0.99:
        diffs.append(f"policy: score {policy_score:.4f}, expected {expected.get('policy')}, got {ans.get('policy')}")
        
    plan_score = _plan_score(ans.get("plan_events"), expected.get("expected_events"))
    if plan_score < 0.99:
        diffs.append(f"plan: score {plan_score:.4f}, expected {expected.get('expected_events')}, got {ans.get('plan_events')}")
        
    if diffs:
        print(f"Task {tid}:")
        print("  Prompt:", task.get("prompt"))
        print("  Focal ID:", ans.get("focal_id"))
        print("  Profile:", ans.get("profile"))
        print("  Target:", ans.get("target"))
        for d in diffs:
            print("  ", d)
        mismatches += 1
        if mismatches >= 15:
            break

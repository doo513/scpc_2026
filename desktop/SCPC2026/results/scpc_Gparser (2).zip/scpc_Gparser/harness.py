from __future__ import annotations
import os
import json
from typing import Any
from core.task_view import TaskView
from core.pipeline import Stage1Context, Stage2Context, Stage3Context, DecisionBundle
from core.action_profile import ActionProfile
from core.evidence_graph import NaturalLanguageInterpreter
from rules.focal import FocalResolver
from rules.target import TargetResolver
from rules.action_profile import ActionProfileDecider, control_from_profile
from rules.scope_policy import ScopePolicyJointBuilder
from rules.plan import PlanTemplateBuilder


class FinalHarness:
    def __init__(self):
        self.memory_bank: dict[str, Any] = {}

    def prepare(self, tasks: list[dict[str, Any]]) -> None:
        self.memory_bank.clear()
        os.makedirs("/mnt/c/Users/doo33/Desktop/scpc_Gparser/reports", exist_ok=True)
        trace_file = "/mnt/c/Users/doo33/Desktop/scpc_Gparser/reports/decision_trace.jsonl"
        with open(trace_file, "w", encoding="utf-8") as f:
            pass

    def answer_task(self, task: dict[str, Any], session: dict[str, Any]) -> dict[str, Any]:
        # Restore pending transactions from previous turn if applicable
        if "PENDING_TRANSACTION" in session:
            # If user does not say cancel/stop, restore the pending memory writes
            prompt = str(task.get("prompt") or "").lower()
            if not any(w in prompt for w in ["취소", "삭제", "중단", "멈춰"]):
                pending = session.pop("PENDING_TRANSACTION")
                mem = session.setdefault("memory", {})
                for k, v in pending.items():
                    mem[k] = v
                    self.memory_bank[k] = v

        # 1. Input normalization and TaskView creation
        view = TaskView(task, session)

        # Stage 1: 공식 필수 처리 (Official Requirements)
        # Resolve direct bindings from facts
        direct_focal_id = FocalResolver.resolve_direct(view)
        direct_target = TargetResolver.resolve_direct(view)
        available_actions = task.get("available_actions", [
            "read", "verify", "redact", "summarize", "dispatch", 
            "guard", "clarify", "update", "schedule", "toggle", "pay"
        ])

        stage1 = Stage1Context(
            view=view,
            session=session,
            focal_id=direct_focal_id,
            target=direct_target,
            available_actions=available_actions
        )
        stage1.validate_invariants()

        # Stage 2: 자연어 해석 (Natural Language Interpretation)
        # Parse prompt strictly into structured Evidence
        clauses = NaturalLanguageInterpreter.parse_clauses_and_evidence(view.prompt, view.turn_index)
        stage2 = Stage2Context(
            stage1=stage1,
            clauses=clauses
        )
        stage2.validate_invariants()

        # Stage 3 & 4: 이전 맥락·fallback 평가 및 최종 결정 (Decision Bundle)
        bundle = ActionProfileDecider.decide_bundle(stage2, self.memory_bank)
        bundle.validate_invariants()

        # Extract locked decisions
        focal_id = bundle.global_focal_id
        target = bundle.global_target
        control = bundle.global_control

        # Stage 5: 출력 컴파일 (Output Compilation)
        # Scope, policy, plan are purely compiled based on the locked bundle
        main_sd = bundle.sub_decisions[0]
        for sd in bundle.sub_decisions:
            if sd.action != "LOCAL_UPDATE":
                main_sd = sd
                break
        profile = ActionProfile(main_sd.profile_name)

        # Consolidate global intent from all clauses in Stage 2
        global_domain_verbs = []
        global_domain_keywords = []
        global_referencing_keywords = []
        global_is_local_only = False
        global_is_correction = False
        global_is_negation = False
        global_target_rebind = False
        global_override_memory = False
        for c in stage2.clauses:
            global_domain_verbs.extend(c.intent.domain_verbs)
            global_domain_keywords.extend(c.intent.domain_keywords)
            global_referencing_keywords.extend(c.intent.referencing_keywords)
            if c.intent.is_local_only:
                global_is_local_only = True
            if c.intent.is_correction:
                global_is_correction = True
            if c.intent.is_negation:
                global_is_negation = True
            if c.intent.target_rebind:
                global_target_rebind = True
            if c.intent.override_memory:
                global_override_memory = True

        from core.pipeline import IntentEvidence
        consolidated_intent = IntentEvidence(
            domain_verbs=list(set(global_domain_verbs)),
            is_local_only=global_is_local_only,
            is_correction=global_is_correction,
            is_negation=global_is_negation,
            target_rebind=global_target_rebind,
            override_memory=global_override_memory,
            domain_keywords=list(set(global_domain_keywords)),
            referencing_keywords=list(set(global_referencing_keywords))
        )

        content_scope, policy = ScopePolicyJointBuilder.build(
            view=view,
            intent=consolidated_intent,
            bundle=bundle
        )

        plan_events = PlanTemplateBuilder.build(
            view=view,
            intent=consolidated_intent,
            profile=profile,
            focal_id=focal_id,
            target=target,
            content_scope=content_scope,
            policy=policy
        )

        # Commit temporary memory writes if proceed/amend, or store as pending if ask
        self._remember(view, session, control)

        answer = {
            "focal_id": focal_id,
            "target": target,
            "control": control,
            "content_scope": content_scope,
            "policy": policy,
            "plan_events": plan_events,
            # Metadata for logging/diagnostics
            "evidence": bundle,
            "profile": profile,
        }

        # 9. Log decision trace
        self._log_decision_trace(view.task_id, focal_id, target, profile, bundle, answer)

        # 10. Update session memory
        self.update_session_memory(view, profile, answer, session)

        return answer

    def _remember(self, view: TaskView, session: dict[str, Any], control: str) -> None:
        temp_mem = {}
        for value in view.record_values("persistent_memory_write"):
            if not isinstance(value, dict):
                continue
            key = str(value.get("memory_key") or value.get("person") or "")
            if key:
                entry = {
                    "value": value,
                    "source_session_id": view.session_id,
                    "source_task_id": view.task_id,
                    "source_turn_index": view.turn_index,
                }
                temp_mem[key] = entry

        if control == "ask":
            # Store in pending transaction overlay
            if temp_mem:
                session["PENDING_TRANSACTION"] = temp_mem
        else:
            # Commit permanently
            mem = session.setdefault("memory", {})
            for k, v in temp_mem.items():
                mem[k] = v
                self.memory_bank[k] = v

    def update_session_memory(
        self,
        view: TaskView,
        profile: ActionProfile,
        answer: dict[str, Any],
        session: dict[str, Any],
    ) -> None:
        session["last_focal_id"] = answer["focal_id"]
        session["last_target"] = answer["target"]
        session["last_control"] = answer["control"]
        session["last_profile"] = profile.value

    def _log_decision_trace(
        self,
        task_id: str,
        focal_id: str,
        target: str,
        profile: ActionProfile,
        bundle: DecisionBundle,
        answer: dict[str, Any],
    ) -> None:
        trace_file = "/mnt/c/Users/doo33/Desktop/scpc_Gparser/reports/decision_trace.jsonl"
        trace_entry = {
            "task_id": task_id,
            "focal_id": focal_id,
            "target": target,
            "profile": profile.value,
            "scope_mode": answer["content_scope"]["mode"],
            "control": answer["control"],
            "sub_decisions": [
                {
                    "clause_index": sd.clause_index,
                    "action": sd.action,
                    "target": sd.target,
                    "control": sd.control,
                    "profile_name": sd.profile_name,
                    "scope_mode": sd.scope_mode
                } for sd in bundle.sub_decisions
            ],
            "dependency_edges": bundle.dependency_edges
        }
        with open(trace_file, "a", encoding="utf-8") as f:
            f.write(json.dumps(trace_entry, ensure_ascii=False) + "\n")

from __future__ import annotations

from typing import Any

from rules.control_rules import is_local_update
from utils.task_view import TaskView


SENSITIVE_ORDER = ["name", "numeric_value", "raw_quote", "rrn", "doctor_note", "location", "amount", "card_number"]


def build_content_scope(view: TaskView, focal: dict[str, Any], control: str, target: str) -> dict[str, Any]:
    contains = view.focal_contains(focal)
    if control == "hold":
        return {"mode": "none", "allowed_fields": [], "excluded_fields": [], "requires_user_confirmation": False}
    
    if control == "proceed" and (is_local_update(view) or view.last_value("share_boundary_update") == "local_update_boundary"):
        records = {r['type']: r['value'] for r in view.records}
        is_strict = records.get('session_share_policy') == 'strict'
        has_sensitive = bool(contains & {'raw_quote', 'location', 'numeric_value', 'doctor_note', 'amount', 'rrn', 'name'})
        if is_strict or has_sensitive:
            ex = ['raw_quote', 'location', 'numeric_value']
        else:
            ex = []
        return {
            "mode": "status_only",
            "allowed_fields": ["status"],
            "excluded_fields": ex,
            "requires_user_confirmation": False,
        }
        
    if control == "ask":
        return _ask_scope(view, contains, target, focal)
    if control == "amend":
        return {
            "mode": "redacted",
            "allowed_fields": ["summary"],
            "excluded_fields": _redaction_exclusions(view, contains, target, focal),
            "requires_user_confirmation": _requires_confirmation(view),
        }
    if _raw_allowed(view, focal, target):
        return {"mode": "raw", "allowed_fields": ["summary", "title"], "excluded_fields": [], "requires_user_confirmation": False}
    return {"mode": "summary", "allowed_fields": ["summary"], "excluded_fields": [], "requires_user_confirmation": False}


def _ask_scope(view: TaskView, contains: set[str], target: str, focal: dict[str, Any]) -> dict[str, Any]:
    records = {r['type']: r['value'] for r in view.records}
    boundary = records.get('share_boundary_update')
    prompt = view.prompt
    
    trace = records.get('focal_resolution_trace', {})
    latest_phase = trace.get('latest_phase') if isinstance(trace, dict) else None

    # 1. target_changed_after_turn == 'prior_success_route_superseded' -> none
    if records.get('target_changed_after_turn') == 'prior_success_route_superseded':
        mode = 'none'
    # 2. 원본과 사진 / 원본, 익명 요약, 사진
    elif '원본과 사진' in prompt or '원본, 익명 요약, 사진' in prompt:
        if target in {'audit_vendor', 'privacy_review'}:
            if target == 'privacy_review' and boundary == 'dispatch_blocked_until_binding':
                mode = 'none'
            else:
                mode = 'redacted'
        else:
            mode = 'summary'
    # 3. 누구에게 어떤 범위
    elif '누구에게 어떤 범위' in prompt:
        mode = 'summary'
    # 4. payment_policy / memory_conflict
    elif 'payment_policy' in records or 'memory_conflict' in records:
        mode = 'summary'
    # 5. 검진/점검/건강 prompts with memory recall
    elif ('검진' in prompt or '점검' in prompt or '건강' in prompt) and 'persistent_memory_recall' in records:
        mode = 'summary'
    # 6. target changed after turn with non-user
    elif target != 'user' and 'target_changed_after_turn' in records:
        if records.get('session_share_policy') == 'strict' and latest_phase == 'draft':
            mode = 'redacted'
        else:
            mode = 'summary'
    # 7. redacted boundary
    elif boundary in {'redacted_external_boundary', 'redacted_after_selection_boundary'}:
        if records.get('session_share_policy') == 'strict' and latest_phase == 'authority':
            mode = 'summary'
        else:
            mode = 'redacted'
    # 8. strict policy
    elif records.get('session_share_policy') == 'strict':
        if boundary == 'dispatch_blocked_until_binding' and target == 'user':
            mode = 'summary'
        else:
            mode = 'redacted'
    else:
        mode = 'summary'

    # Determine allowed and excluded fields based on the chosen mode
    if mode == 'none':
        allowed = []
        excluded = []
    elif mode == 'redacted':
        allowed = ['summary']
        excluded = _redaction_exclusions(view, contains, target, focal)
    else:
        allowed = ['summary']
        excluded = _summary_exclusions(contains) or ['raw_quote']

    return {
        "mode": mode,
        "allowed_fields": allowed,
        "excluded_fields": excluded,
        "requires_user_confirmation": True
    }


def _summary_exclusions(contains: set[str]) -> list[str]:
    if "name" in contains and "raw_quote" not in contains:
        return ["name"]
    if "name" in contains and "rrn" in contains and "raw_quote" in contains:
        return ["name"]
    if "raw_quote" in contains:
        return ["raw_quote"]
    return []


def _redaction_exclusions(view: TaskView, contains: set[str], target: str, focal: dict[str, Any]) -> list[str]:
    policy = view.value_text_l("external_share_policy")
    if target != 'user' and "doctor_note_forbidden" in policy and "doctor_note" in contains:
        return ["doctor_note"]
    if "raw_sensitive_forbidden" in policy:
        items = [x for x in ["name", "numeric_value", "raw_quote", "rrn"] if x in contains or x == "numeric_value"]
        return items or ["sensitive_fields"]
    if "원본과 사진" in view.prompt or "원본, 익명 요약, 사진" in view.prompt or "출장 정산" in view.all_text:
        items = [x for x in ["name", "numeric_value", "raw_quote", "rrn"] if x in contains or x == "numeric_value"]
        return items or ["name"]
    if focal.get('type') != 'health_record' and contains & {"location", "numeric_value"} and not contains & {"name", "rrn"}:
        return ["location", "numeric_value", "raw_quote"] if "raw_quote" in contains else ["location", "numeric_value"]
    return ["raw_quote"]


def _requires_confirmation(view: TaskView) -> bool:
    if view.has_record("ambiguous_target") or view.has_record("target_changed_after_turn"):
        return True
    if view.last_value("dispatch_authority_check") in {"authority_incomplete", "user_binding_pending"}:
        return True
    return False


def _raw_allowed(view: TaskView, focal: dict[str, Any], target: str) -> bool:
    if (
        view.has_record("guardrail_ladder_signal")
        and view.last_value("share_boundary_update") == "redacted_external_boundary"
        and view.last_value("dispatch_authority_check") == "internal_binding_confirmed"
    ):
        return True
    if view.value_text_l("session_share_policy") != "normal":
        return False
    if view.has_record("external_share_policy"):
        return False
    if view.has_record("ambiguous_target") or view.has_record("ambiguous_focal"):
        return False
    contains = view.focal_contains(focal)
    if target in {"project_room", "privacy_review"} and "회의 시간" in view.prompt:
        return True
    return False

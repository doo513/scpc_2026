from __future__ import annotations

from typing import Any

from utils.normalize import has_any
from utils.task_view import TaskView


LOCAL_UPDATE_PHRASES = [
    "내부 상태 업데이트",
    "상태만 갱신",
    "로컬 상태 기록",
    "기기 내부 업데이트",
    "장치 안의 처리 상태만",
    "바깥으로 보내지 말고",
    "공유하지 말고",
    "수신처 전달 대신",
    "전달 동작은 취소",
    "보내는 작업은 취소",
    "외부 공유가 아니라",
    "외부 전송을 하지 말고",
    "상태 표시만",
    "상태 기록만",
    "memory_store",
    "status_only",
]

ASK_PHRASES = [
    "다시 확인",
    "사용자 확인",
    "먼저 확인",
    "확인 절차",
    "확정되지",
    "미확정",
    "결론을 내릴 수 없다",
    "아직 확인되지",
    "물어봐",
]

HOLD_PHRASES = [
    "더 진행하면 안",
    "실행하면 안",
    "실행을 막",
    "멈춰야",
    "처리하지 않는다",
    "처리하지 않는다",
    "처리 전제가 사라",
    "전제를 무효화",
    "허용 근거가 최신 상태에서 깨",
    "과거 승인에 기대면 안",
    "이전 허용 조건이 취소",
]

AMEND_PHRASES = [
    "식별 가능한 세부값을 제외",
    "세부값을 제외",
    "요약만 공유",
    "민감 내용은 알아서 처리",
    "위치나 나이 같은 민감",
]


def decide_control(view: TaskView, focal: dict[str, Any]) -> str:
    prompt = view.prompt
    prompt_l = view.prompt_l
    values_l = view.records_text.lower()

    if _explicit_hold(view, prompt, values_l):
        return "hold"
    if is_local_update(view):
        return "proceed"
    if _explicit_ask(view, prompt):
        return "ask"
    if _memory_or_domain_control(view, focal):
        return _memory_or_domain_control(view, focal)
    boundary_control = _control_from_boundary(view)
    if boundary_control:
        return boundary_control
    if _unresolved_ambiguity(view):
        return "ask"
    if _external_redactable(view, prompt_l):
        return "amend"
    return "proceed"


def is_local_update(view: TaskView) -> bool:
    if view.has_record("persistent_memory_write"):
        return True
    if has_any(view.prompt, LOCAL_UPDATE_PHRASES):
        return True
    return False


def _explicit_hold(view: TaskView, prompt: str, values_l: str) -> bool:
    if view.value_text_l("consent") in {"revoked", "withdrawn", "denied"} and not is_local_update(view):
        return True
    if view.has_record("security_alert") and not is_local_update(view):
        return True
    if view.has_record("safety_mode"):
        return True
    if has_any(prompt, HOLD_PHRASES):
        return True
    if "phishing" in values_l or "피싱" in values_l:
        return True
    return False


def _explicit_ask(view: TaskView, prompt: str) -> bool:
    if view.has_record("payment_policy") or view.has_record("memory_conflict") or view.has_record("duration_ambiguous"):
        return True
    if view.has_record("target_changed_after_turn"):
        return True
    if has_any(prompt, ASK_PHRASES):
        if not is_local_update(view):
            return True
    return False


def _control_from_boundary(view: TaskView) -> str:
    boundary = str(view.last_value("share_boundary_update") or "")
    if boundary == "dispatch_blocked_until_binding":
        if has_any(view.prompt, AMEND_PHRASES):
            return "amend"
        if view.has_record("guardrail_ladder_signal"):
            return "hold"
        if view.has_record("ambiguous_focal") and view.last_value("dispatch_authority_check") == "user_binding_pending":
            return "hold"
        return ""
    if boundary == "local_update_boundary":
        ambiguous = str(view.last_value("ambiguous_target") or "")
        if view.has_record("ambiguous_focal"):
            return "proceed"
        if ambiguous == "stored_channel_or_visible_recipient":
            return "amend"
        if ambiguous == "approved_channel_or_visible_recipient":
            return "ask"
        if ambiguous == "surface_recipient_and_resolved_target_both_recent":
            return "amend"
    if boundary in {"redacted_external_boundary", "redacted_after_selection_boundary"}:
        if str(view.last_value("ambiguous_target") or "") == "surface_recipient_and_resolved_target_both_recent":
            return "ask"
        if str(view.last_value("ambiguous_target") or "") == "stored_channel_or_visible_recipient" and (
            "검진" in view.prompt or "점검" in view.prompt
        ):
            return "ask"
        if view.has_record("guardrail_ladder_signal") and view.last_value("dispatch_authority_check") == "internal_binding_confirmed":
            return "proceed"
        return "amend"
    return ""


def _memory_or_domain_control(view: TaskView, focal: dict[str, Any]) -> str:
    if view.has_record("enterprise_policy_recall"):
        return "amend"
    if view.has_record("ops_memory_recall"):
        return "ask" if view.has_record("target_changed_after_turn") else "amend"
    if view.has_record("temporary_override_allowed"):
        return "amend"
    if view.has_record("persistent_memory_recall") and "쿠폰" in view.prompt and not view.has_record("payment_policy"):
        return "hold"
    if focal.get("type") == "health_record" and view.value_text_l("external_share_policy") == "doctor_note_forbidden":
        return "hold"
    if view.has_record("ambiguous_focal") and view.value_text_l("session_share_policy") == "normal":
        return "ask"
    return ""


def _unresolved_ambiguity(view: TaskView) -> bool:
    if not (view.has_record("ambiguous_target") or view.has_record("ambiguous_focal")):
        return False
    boundary = str(view.last_value("share_boundary_update") or "")
    authority = str(view.last_value("dispatch_authority_check") or "")
    candidates = str(view.last_value("route_candidate_snapshot") or "")
    if boundary == "local_update_boundary":
        return False
    if authority in {"authority_incomplete", "user_binding_pending"} and boundary == "dispatch_blocked_until_binding":
        return True
    if candidates == "external_candidates_present" and authority != "internal_binding_confirmed" and not boundary.startswith("redacted"):
        return True
    return False


def _external_redactable(view: TaskView, prompt_l: str) -> bool:
    if has_any(view.prompt, AMEND_PHRASES):
        return True
    if view.has_record("external_share_policy"):
        return True
    boundary = str(view.last_value("share_boundary_update") or "")
    if boundary in {"redacted_external_boundary", "redacted_after_selection_boundary"}:
        return True
    if view.has_record("ambiguous_target") and view.has_record("resolved_target"):
        return True
    if view.value_text_l("session_share_policy") == "strict" and view.has_record("resolved_target"):
        return True
    return False

from __future__ import annotations

from typing import Any

from utils.normalize import unique
from utils.task_view import TaskView


def build_policy(view: TaskView, focal: dict[str, Any], control: str, target: str, scope: dict[str, Any]) -> dict[str, Any]:
    flags: list[str] = []
    violations: list[str] = []
    contains = view.focal_contains(focal)
    records = {r['type']: r['value'] for r in view.records}

    if records.get('session_share_policy') == 'strict':
        flags.append('strict_share_policy')
        
    if target != 'memory_store' and target != 'user':
        flags.append('external_share')
    if target == 'memory_store' or target == 'user' or records.get('share_boundary_update') == 'local_update_boundary':
        flags.append('local_only')
        
    if contains & {'raw_quote', 'rrn', 'name', 'location', 'numeric_value', 'doctor_note', 'amount'}:
        flags.append('sensitive_content')
        
    has_target_amb = (
        'ambiguous_target' in records
        or (records.get('share_boundary_update') == 'dispatch_blocked_until_binding' 
            and records.get('dispatch_authority_check') == 'user_binding_pending')
    )
    if has_target_amb:
        flags.append('target_ambiguity')
        
    if 'ambiguous_focal' in records:
        flags.append('ambiguous_focal')
    if control == 'amend':
        flags.append('minimal_disclosure')
    if control == 'ask':
        flags.append('clarification_required')
        
    boundary = records.get('share_boundary_update')
    has_ambiguity = (
        'ambiguous_target' in records
        or 'ambiguous_focal' in records
        or 'duration_ambiguous' in records
        or 'target_changed_after_turn' in records
    )
    has_precond_chg = boundary in {'local_update_boundary', 'redacted_external_boundary', 'redacted_after_selection_boundary'} and has_ambiguity
    if has_precond_chg:
        flags.append('precondition_changed')
        
    if control == 'hold':
        flags.extend(['precondition_invalidated', 'safety'])
        violations.append('precondition_changed_ignored')

    # requires_confirmation logic
    req_conf = control == 'ask'
    if control == 'proceed':
        if has_target_amb:
            req_conf = True
        elif target != 'memory_store' and records.get('dispatch_authority_check') in {'authority_incomplete', 'user_binding_pending'}:
            req_conf = True
            
    if scope.get('requires_user_confirmation'):
        req_conf = True

    return {
        "risk_flags": unique(flags),
        "violations": unique(violations),
        "requires_confirmation": req_conf,
    }

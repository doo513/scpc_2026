from __future__ import annotations

import os
import json
import dataclasses
from typing import Any
from core.task_view import TaskView
from core.evidence_graph import EvidenceGraph
from core.action_profile import ActionProfile
from rules.focal import FocalResolver
from rules.target import TargetResolver
from rules.action_profile import ActionProfileDecider, control_from_profile, ProfileDecision
from rules.scope_policy import ScopePolicyJointBuilder
from rules.plan import PlanTemplateBuilder


class FinalHarness:
    def __init__(self):
        self.memory_bank: dict[str, Any] = {}

    def prepare(self, tasks: list[dict[str, Any]]) -> None:
        self.memory_bank.clear()
        os.makedirs("/mnt/c/Users/doo33/Desktop/scpc_Gparser/reports", exist_ok=True)
        trace_file = "/mnt/c/Users/doo33/Desktop/scpc_Gparser/reports/decision_trace.jsonl"
        with open(trace_file, "w", encoding="utf-8") as f:
            pass

    def answer_task(self, task: dict[str, Any], session: dict[str, Any]) -> dict[str, Any]:
        # 1. Input normalization
        view = TaskView(task, session)
        self._remember(view, session)

        # 2. Gather target evidence (initial, without focal_id for sensitive fields)
        evidence = EvidenceGraph.from_view(view)

        # 3. Resolve focal object ID
        focal_id = FocalResolver.resolve(view, evidence, session)

        # 4. Resolve target recipient/store using pre-profile decision
        pre_decision = ActionProfileDecider.decide_internal(view, evidence, {})
        target = TargetResolver.resolve(view, evidence, focal_id, pre_decision, self.memory_bank)

        # 5. Gather evidence again now that focal_id is resolved (for sensitive fields overlap check)
        evidence = EvidenceGraph.from_view(view, focal_id)

        # 6. Decide ActionProfile
        focal = view.objects_by_id().get(focal_id) or {}
        decision = ActionProfileDecider.decide_internal(view, evidence, focal)
        profile = decision.profile

        # 7. Generate content scope & policy
        content_scope, policy = ScopePolicyJointBuilder.build(
            view=view,
            evidence=evidence,
            profile=decision,
            focal_id=focal_id,
            target=target,
        )

        # 8. Generate plan events
        plan_events = PlanTemplateBuilder.build(
            view=view,
            evidence=evidence,
            profile=profile,
            focal_id=focal_id,
            target=target,
            content_scope=content_scope,
            policy=policy,
        )

        answer = {
            "focal_id": focal_id,
            "target": target,
            "control": control_from_profile(profile),
            "content_scope": content_scope,
            "policy": policy,
            "plan_events": plan_events,
            # Pass evidence and profile as metadata for validation and error analyses
            "evidence": evidence,
            "profile": profile,
        }

        # 9. Log decision trace to reports/decision_trace.jsonl
        self._log_decision_trace(view.task_id, focal_id, target, decision, answer)

        # 10. Update session memory (fallback targets)
        self.update_session_memory(view, evidence, profile, answer, session)

        return answer

    def _remember(self, view: TaskView, session: dict[str, Any]) -> None:
        mem = session.setdefault("memory", {})
        for value in view.record_values("persistent_memory_write"):
            if not isinstance(value, dict):
                continue
            key = str(value.get("memory_key") or value.get("person") or "")
            if key:
                entry = {
                    "value": value,
                    "source_session_id": view.session_id,
                    "source_task_id": view.task_id,
                    "source_turn_index": view.turn_index,
                }
                mem[key] = entry
                self.memory_bank[key] = entry

    def update_session_memory(
        self,
        view: TaskView,
        evidence: EvidenceGraph,
        profile: ActionProfile,
        answer: dict[str, Any],
        session: dict[str, Any],
    ) -> None:
        session["last_focal_id"] = answer["focal_id"]
        session["last_target"] = answer["target"]
        session["last_control"] = answer["control"]
        session["last_profile"] = profile.value
        session["last_evidence"] = evidence

    def _log_decision_trace(
        self,
        task_id: str,
        focal_id: str,
        target: str,
        decision: ProfileDecision,
        answer: dict[str, Any],
    ) -> None:
        trace_file = "/mnt/c/Users/doo33/Desktop/scpc_Gparser/reports/decision_trace.jsonl"
        trace_entry = {
            "task_id": task_id,
            "focal_id": focal_id,
            "target": target,
            "profile": decision.profile.value,
            "scores": dataclasses.asdict(decision.scores),
            "reasons": decision.reasons,
            "scope_mode": answer["content_scope"]["mode"],
            "control": answer["control"],
            "domain_promotion_traces": [dataclasses.asdict(t) for t in decision.domain_promotion_traces],
        }
        with open(trace_file, "a", encoding="utf-8") as f:
            f.write(json.dumps(trace_entry, ensure_ascii=False) + "\n")

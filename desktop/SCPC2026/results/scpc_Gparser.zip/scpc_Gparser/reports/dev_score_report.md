# SCPC Dev Score Report

- **Overall Score**: `0.9469`
- **Total Dev Tasks**: 120
- **Wrong Tasks**: 55

## Axis Scores
| Axis | Score | Weight |
| --- | --- | --- |
| content_scope | 0.9700 | 0.17 |
| control | 1.0000 | 0.18 |
| counterfactual | 0.0000 | 0.00 |
| focal | 1.0000 | 0.18 |
| plan | 0.9750 | 0.18 |
| policy | 0.9731 | 0.13 |
| semantic_response | 0.0000 | 0.04 |
| target | 1.0000 | 0.12 |
from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any
from .task_view import TaskView

HOLD_PHRASES = [
    "더 진행하면 안",
    "실행하면 안",
    "실행을 막",
    "멈춰야",
    "처리하지 않는다",
    "처리 전제가 사라",
    "전제를 무효화",
    "허용 근거가 최신 상태에서 깨",
    "과거 승인에 기대면 안",
    "이전 허용 조건이 취소",
]

ASK_PHRASES = [
    "다시 확인",
    "사용자 확인",
    "먼저 확인",
    "확인 절차",
    "확정되지",
    "미확정",
    "결론을 내릴 수 없다",
    "아직 확인되지",
    "물어봐",
]

LOCAL_UPDATE_PHRASES = [
    "내부 상태 업데이트",
    "상태만 갱신",
    "로컬 상태 기록",
    "기기 내부 업데이트",
    "장치 안의 처리 상태만",
    "바깥으로 보내지 말고",
    "공유하지 말고",
    "수신처 전달 대신",
    "전달 동작은 취소",
    "보내는 작업은 취소",
    "외부 공유가 아니라",
    "외부 전송을 하지 말고",
    "상태 표시만",
    "상태 기록만",
    "memory_store",
    "status_only",
]


@dataclass
class Provenance:
    source: str  # "prompt", "record", "object_attrs", "history"
    turn_index: int
    span: str  # extracted substring or key path


@dataclass
class CanonicalEvidenceGroup:
    id: str
    evidence_type: str
    provenances: list[Provenance] = field(default_factory=list)


@dataclass
class IntentEvidence:
    explicit_domain_verbs: list[str] = field(default_factory=list)  # e.g., ["PAY", "TOGGLE", "SCHEDULE"]
    status_only_intent: bool = False
    target_rebind_intent: bool = False
    derived_from: list[str] = field(default_factory=list)  # list of group IDs


@dataclass
class ConstraintEvidence:
    decisive_stop_or_hold: bool = False  # prompt stop/hold phrase
    hard_constraints: list[str] = field(default_factory=list)
    ask_constraints: list[str] = field(default_factory=list)
    derived_from: list[str] = field(default_factory=list)  # list of group IDs


@dataclass
class PromptEvidence:
    no_external_send: bool = False
    status_only_update: bool = False
    explicit_confirm_first: bool = False
    explicit_stop_or_hold: bool = False
    target_rebind: bool = False
    latest_clause: str = ""


@dataclass
class RouteBundleEvidence:
    candidate: str | None = None
    authority: str | None = None
    boundary: str | None = None
    binding_order: str | None = None
    is_local_boundary: bool = False
    is_external_boundary: bool = False
    is_authority_confirmed: bool = False
    is_authority_pending: bool = False


@dataclass
class SensitivityEvidence:
    contains: set[str] = field(default_factory=set)
    sensitive_fields: set[str] = field(default_factory=set)
    has_sensitive_fields: bool = False
    has_raw_quote: bool = False
    has_numeric_value: bool = False
    has_doctor_note: bool = False


@dataclass
class EvidenceGraph:
    hard_block: list[str] = field(default_factory=list)
    explicit_clarification: list[str] = field(default_factory=list)
    local_update: list[str] = field(default_factory=list)
    target_rebind: list[str] = field(default_factory=list)
    memory_conflict: list[str] = field(default_factory=list)
    unresolved_ambiguity: list[str] = field(default_factory=list)
    external_share: list[str] = field(default_factory=list)
    sensitive_fields: list[str] = field(default_factory=list)
    route_bundle: dict[str, Any] = field(default_factory=dict)
    prompt_overrides: list[str] = field(default_factory=list)
    personal_memory_signals: list[str] = field(default_factory=list)
    slm_fallback_signals: list[str] = field(default_factory=list)

    # Expanded sub-evidence classes
    prompt_evidence: PromptEvidence = field(default_factory=PromptEvidence)
    route_bundle_evidence: RouteBundleEvidence = field(default_factory=RouteBundleEvidence)
    sensitivity: SensitivityEvidence = field(default_factory=SensitivityEvidence)

    # Architectural refinements
    intent_evidence: IntentEvidence = field(default_factory=IntentEvidence)
    constraint_evidence: ConstraintEvidence = field(default_factory=ConstraintEvidence)
    evidence_groups: dict[str, CanonicalEvidenceGroup] = field(default_factory=dict)

    @classmethod
    def from_view(cls, view: TaskView, focal_id: str = "") -> EvidenceGraph:
        eg = cls()
        prompt = view.prompt
        turn = view.turn_index

        # Helper to register evidence groups
        def add_provenance(group_id: str, ev_type: str, source: str, turn_idx: int, span: str):
            group = eg.evidence_groups.setdefault(group_id, CanonicalEvidenceGroup(id=group_id, evidence_type=ev_type))
            # avoid exact duplicates in same group
            if not any(p.source == source and p.turn_index == turn_idx and p.span == span for p in group.provenances):
                group.provenances.append(Provenance(source=source, turn_index=turn_idx, span=span))

        # 1. Route Bundle
        candidate = view.latest_record_value("route_candidate_snapshot")
        authority = view.latest_record_value("dispatch_authority_check")
        boundary = view.latest_record_value("share_boundary_update")
        binding_order = view.latest_record_value("route_binding_order")

        is_local_b = boundary == "local_update_boundary"
        is_external_b = boundary in ("redacted_external_boundary", "redacted_after_selection_boundary", "dispatch_blocked_until_binding")
        is_auth_conf = authority == "internal_binding_confirmed"
        is_auth_pend = authority in ("authority_incomplete", "user_binding_pending")

        eg.route_bundle = {
            "candidate": candidate,
            "authority": authority,
            "boundary": boundary,
            "binding_order": binding_order,
            "is_local_boundary": is_local_b,
            "is_external_boundary": is_external_b,
            "is_authority_confirmed": is_auth_conf,
            "is_authority_pending": is_auth_pend,
        }

        eg.route_bundle_evidence = RouteBundleEvidence(
            candidate=candidate,
            authority=authority,
            boundary=boundary,
            binding_order=binding_order,
            is_local_boundary=is_local_b,
            is_external_boundary=is_external_b,
            is_authority_confirmed=is_auth_conf,
            is_authority_pending=is_auth_pend,
        )
        if boundary:
            add_provenance("group_boundary", "ROUTE_BOUNDARY", "record", turn, f"share_boundary_update:{boundary}")
        if authority:
            add_provenance("group_authority", "ROUTE_AUTHORITY", "record", turn, f"dispatch_authority_check:{authority}")

        # 2. Prompt Evidence
        latest_c = view.latest_clause()
        no_ext = any(phrase in prompt for phrase in LOCAL_UPDATE_PHRASES)
        status_only = any(phrase in prompt for phrase in ["상태만 갱신", "상태 기록만", "상태 표시만", "status_only"])
        exp_confirm = any(phrase in prompt for phrase in ASK_PHRASES)
        exp_stop = any(phrase in prompt for phrase in HOLD_PHRASES)
        target_reb = any(phrase in prompt for phrase in ["대상 변경", "수신처 수정", "수신 변경", "목적지 변경", "바꿔"])

        eg.prompt_evidence = PromptEvidence(
            no_external_send=no_ext,
            status_only_update=status_only,
            explicit_confirm_first=exp_confirm,
            explicit_stop_or_hold=exp_stop,
            target_rebind=target_reb,
            latest_clause=latest_c
        )

        # 3. Extract Prompt Phrases
        for phrase in HOLD_PHRASES:
            if phrase in prompt:
                add_provenance("group_stop_phrase", "STOP_PHRASE", "prompt", turn, phrase)
                eg.hard_block.append(f"prompt_hold_phrase:{phrase}")
            for h in view._history:
                h_summary = h.get("summary") or ""
                if phrase in h_summary:
                    add_provenance("group_stop_phrase", "STOP_PHRASE", "history", h.get("turn", 1), phrase)

        for phrase in ASK_PHRASES:
            if phrase in prompt:
                add_provenance("group_ask_phrase", "ASK_PHRASE", "prompt", turn, phrase)
                eg.explicit_clarification.append(f"prompt_ask_phrase:{phrase}")
            for h in view._history:
                h_summary = h.get("summary") or ""
                if phrase in h_summary:
                    add_provenance("group_ask_phrase", "ASK_PHRASE", "history", h.get("turn", 1), phrase)

        for phrase in LOCAL_UPDATE_PHRASES:
            if phrase in prompt:
                add_provenance("group_local_phrase", "LOCAL_UPDATE_PHRASE", "prompt", turn, phrase)
                eg.local_update.append(f"prompt_local_phrase:{phrase}")

        if target_reb:
            add_provenance("group_target_rebind_phrase", "TARGET_REBIND_PHRASE", "prompt", turn, "target_rebind")

        # Extract domain verbs
        pay_keywords = ["결제", "쿠폰", "납부", "지불", "pay"]
        toggle_keywords = ["조명", "온도", "켜", "꺼", "조절", "toggle"]
        schedule_keywords = ["회의", "일정", "예약", "시간", "스케줄", "schedule"]

        for kw in pay_keywords:
            if kw in prompt:
                add_provenance("group_domain_pay", "EXPLICIT_DOMAIN_VERB", "prompt", turn, kw)
        for kw in toggle_keywords:
            if kw in prompt:
                add_provenance("group_domain_toggle", "EXPLICIT_DOMAIN_VERB", "prompt", turn, kw)
        for kw in schedule_keywords:
            if kw in prompt:
                add_provenance("group_domain_schedule", "EXPLICIT_DOMAIN_VERB", "prompt", turn, kw)

        # 4. Records as Constraint/Intent Evidence
        if view.latest_record_value("security_alert"):
            eg.hard_block.append("security_alert_present")
            add_provenance("group_security_alert", "SECURITY_ALERT", "record", turn, "security_alert")
        if view.latest_record_value("safety_mode"):
            eg.hard_block.append("safety_mode_present")
            add_provenance("group_safety_mode", "SAFETY_MODE", "record", turn, "safety_mode")

        consent_val = view.latest_record_value("consent")
        if isinstance(consent_val, dict) and consent_val.get("status") in ("revoked", "withdrawn", "denied"):
            eg.hard_block.append("consent_revoked")
            add_provenance("group_consent", "CONSENT_REVOKED", "record", turn, "consent:revoked")
        elif isinstance(consent_val, str) and consent_val in ("revoked", "withdrawn", "denied"):
            eg.hard_block.append("consent_revoked")
            add_provenance("group_consent", "CONSENT_REVOKED", "record", turn, f"consent:{consent_val}")

        guardrail = view.latest_record_value("guardrail_ladder_signal")
        if guardrail:
            eg.hard_block.append(f"guardrail_ladder_signal:{guardrail}")
            add_provenance("group_guardrail", "GUARDRAIL_SIGNAL", "record", turn, f"guardrail_ladder_signal:{guardrail}")

        if view.latest_record_value("payment_policy"):
            eg.explicit_clarification.append("payment_policy_present")
            add_provenance("group_payment_policy", "PAYMENT_POLICY", "record", turn, "payment_policy")
        if view.latest_record_value("calendar_conflict") or view.latest_record("calendar_conflict"):
            eg.explicit_clarification.append("calendar_conflict_present")
            add_provenance("group_calendar_conflict", "CALENDAR_CONFLICT", "record", turn, "calendar_conflict")
        if view.latest_record_value("duration_ambiguous"):
            eg.explicit_clarification.append("duration_ambiguous_present")
            add_provenance("group_duration_ambiguous", "DURATION_AMBIGUOUS", "record", turn, "duration_ambiguous")

        if view.latest_record_value("persistent_memory_write"):
            eg.local_update.append("persistent_memory_write_present")
            add_provenance("group_memory_write", "MEMORY_WRITE", "record", turn, "persistent_memory_write")

        if eg.route_bundle.get("is_local_boundary"):
            eg.local_update.append("route_local_boundary")

        if view.latest_record_value("target_changed_after_turn"):
            eg.target_rebind.append("target_changed_after_turn_present")
            add_provenance("group_target_changed_after_turn", "TARGET_CHANGED_AFTER_TURN", "record", turn, "target_changed_after_turn")

        if view.latest_record_value("memory_conflict"):
            eg.memory_conflict.append("memory_conflict_present")
            add_provenance("group_memory_conflict", "MEMORY_CONFLICT", "record", turn, "memory_conflict")

        if view.latest_record_value("ambiguous_target"):
            eg.unresolved_ambiguity.append("ambiguous_target_present")
            add_provenance("group_ambiguous_target", "AMBIGUOUS_TARGET", "record", turn, "ambiguous_target")
        if view.latest_record_value("ambiguous_focal"):
            eg.unresolved_ambiguity.append("ambiguous_focal_present")
            add_provenance("group_ambiguous_focal", "AMBIGUOUS_FOCAL", "record", turn, "ambiguous_focal")

        if view.latest_record_value("external_share_policy"):
            eg.external_share.append("external_share_policy_present")
            policy_val = view.latest_record_value("external_share_policy")
            if policy_val == "doctor_note_forbidden":
                add_provenance("group_doctor_note_forbidden", "DOCTOR_NOTE_FORBIDDEN", "record", turn, "external_share_policy:doctor_note_forbidden")

        # 5. Sensitivity Evidence & Fields
        contains = set()
        if focal_id:
            contains = view.contains_for_object(focal_id)
            for f in contains:
                add_provenance("group_focal_contains", "FOCAL_CONTAINS", "object_attrs", turn, f"contains:{f}")
            sensitive_candidates = {"raw_quote", "rrn", "name", "location", "numeric_value", "doctor_note", "image", "amount"}
            overlap = contains & sensitive_candidates
            if overlap:
                eg.sensitive_fields = sorted(list(overlap))

        eg.sensitivity = SensitivityEvidence(
            contains=contains,
            sensitive_fields=set(eg.sensitive_fields),
            has_sensitive_fields=len(eg.sensitive_fields) > 0,
            has_raw_quote="raw_quote" in contains,
            has_numeric_value="numeric_value" in contains,
            has_doctor_note="doctor_note" in contains
        )

        if latest_c:
            eg.prompt_overrides.append(latest_c)
            add_provenance("group_prompt_override", "PROMPT_OVERRIDE", "prompt", turn, latest_c)

        # 6. Populate refined IntentEvidence and ConstraintEvidence
        intent_derived: list[str] = []
        domain_verbs: list[str] = []
        if "group_domain_pay" in eg.evidence_groups:
            domain_verbs.append("PAY")
            intent_derived.append("group_domain_pay")
        if "group_domain_toggle" in eg.evidence_groups:
            domain_verbs.append("TOGGLE")
            intent_derived.append("group_domain_toggle")
        if "group_domain_schedule" in eg.evidence_groups:
            domain_verbs.append("SCHEDULE")
            intent_derived.append("group_domain_schedule")

        if "group_local_phrase" in eg.evidence_groups:
            intent_derived.append("group_local_phrase")
        if "group_target_rebind_phrase" in eg.evidence_groups:
            intent_derived.append("group_target_rebind_phrase")

        eg.intent_evidence = IntentEvidence(
            explicit_domain_verbs=domain_verbs,
            status_only_intent=no_ext or status_only,
            target_rebind_intent=target_reb,
            derived_from=intent_derived
        )

        constraint_derived: list[str] = []
        hard_c: list[str] = []
        ask_c: list[str] = []

        decisive_stop = "group_stop_phrase" in eg.evidence_groups and any(
            p.source == "prompt" for p in eg.evidence_groups["group_stop_phrase"].provenances
        )
        if decisive_stop:
            constraint_derived.append("group_stop_phrase")

        if "group_security_alert" in eg.evidence_groups:
            hard_c.append("security_alert")
            constraint_derived.append("group_security_alert")
        if "group_safety_mode" in eg.evidence_groups:
            hard_c.append("safety_mode")
            constraint_derived.append("group_safety_mode")
        if "group_consent" in eg.evidence_groups:
            hard_c.append("consent_revoked")
            constraint_derived.append("group_consent")
        if "group_doctor_note_forbidden" in eg.evidence_groups:
            # Domain policy constraint
            hard_c.append("doctor_note_forbidden")
            constraint_derived.append("group_doctor_note_forbidden")
        if "group_guardrail" in eg.evidence_groups:
            hard_c.append("guardrail_ladder_signal")
            constraint_derived.append("group_guardrail")

        if "group_ambiguous_target" in eg.evidence_groups:
            ask_c.append("ambiguous_target")
            constraint_derived.append("group_ambiguous_target")
        if "group_ambiguous_focal" in eg.evidence_groups:
            ask_c.append("ambiguous_focal")
            constraint_derived.append("group_ambiguous_focal")
        if "group_payment_policy" in eg.evidence_groups:
            ask_c.append("payment_policy")
            constraint_derived.append("group_payment_policy")
        if "group_calendar_conflict" in eg.evidence_groups:
            ask_c.append("calendar_conflict")
            constraint_derived.append("group_calendar_conflict")
        if "group_duration_ambiguous" in eg.evidence_groups:
            ask_c.append("duration_ambiguous")
            constraint_derived.append("group_duration_ambiguous")
        if "group_memory_conflict" in eg.evidence_groups:
            ask_c.append("memory_conflict")
            constraint_derived.append("group_memory_conflict")

        eg.constraint_evidence = ConstraintEvidence(
            decisive_stop_or_hold=decisive_stop,
            hard_constraints=hard_c,
            ask_constraints=ask_c,
            derived_from=constraint_derived
        )

        return eg

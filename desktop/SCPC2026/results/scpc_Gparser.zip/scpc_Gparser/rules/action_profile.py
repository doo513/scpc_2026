from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any
from core.task_view import TaskView
from core.evidence_graph import EvidenceGraph, LOCAL_UPDATE_PHRASES, HOLD_PHRASES, ASK_PHRASES
from core.action_profile import ActionProfile


class PromotionRejectionReason(str, Enum):
    NO_EXPLICIT_EXECUTION_INTENT = "NO_EXPLICIT_EXECUTION_INTENT"
    FOCAL_DOMAIN_MISMATCH = "FOCAL_DOMAIN_MISMATCH"
    TARGET_UNRESOLVED = "TARGET_UNRESOLVED"
    REQUIRED_SLOT_MISSING = "REQUIRED_SLOT_MISSING"
    CAPABILITY_UNAVAILABLE = "CAPABILITY_UNAVAILABLE"
    HARD_CONSTRAINT_ACTIVE = "HARD_CONSTRAINT_ACTIVE"
    SHARE_ONLY_REQUEST = "SHARE_ONLY_REQUEST"
    VERIFY_ONLY_REQUEST = "VERIFY_ONLY_REQUEST"
    CLARIFICATION_ONLY_REQUEST = "CLARIFICATION_ONLY_REQUEST"
    LOW_CONFIDENCE = "LOW_CONFIDENCE"
    LOWER_RANKED_CANDIDATE = "LOWER_RANKED_CANDIDATE"


@dataclass
class DomainPromotionTrace:
    domain_action_candidate: str
    promotion_eligible: bool
    promotion_applied: bool
    promotion_rejected_reason: PromotionRejectionReason | None = None
    fallback_profile: ActionProfile | None = None
    required_slots: list[str] = field(default_factory=list)
    capability_status: str = "available"
    active_constraints: list[str] = field(default_factory=list)
    supporting_evidence_ids: list[str] = field(default_factory=list)


@dataclass
class ProfileScores:
    hard_block: int = 0
    explicit_clarification: int = 0
    local_update: int = 0
    target_rebind: int = 0
    memory_conflict: int = 0
    external_redaction: int = 0
    safe_summary: int = 0
    safe_raw: int = 0
    fallback_uncertainty: int = 0


@dataclass
class ProfileDecision:
    profile: ActionProfile
    scores: ProfileScores
    reasons: list[str] = field(default_factory=list)
    domain_promotion_traces: list[DomainPromotionTrace] = field(default_factory=list)


class ActionProfileDecider:
    @staticmethod
    def pre_decide(view: TaskView, evidence: EvidenceGraph) -> ActionProfile:
        decision = ActionProfileDecider.decide_internal(view, evidence, {})
        return decision.profile

    @staticmethod
    def decide(view: TaskView, evidence: EvidenceGraph, focal_id: str, target: str) -> ActionProfile:
        focal = view.objects_by_id().get(focal_id) or {}
        decision = ActionProfileDecider.decide_internal(view, evidence, focal)
        return decision.profile

    @staticmethod
    def _is_local_update(view: TaskView) -> bool:
        if view.latest_record_value("persistent_memory_write"):
            return True
        for phrase in LOCAL_UPDATE_PHRASES:
            if phrase in view.prompt:
                return True
        return False

    @staticmethod
    def _explicit_hold(view: TaskView, prompt: str, values_l: str) -> bool:
        # Check override local update in prompt (e.g. "최신 표현을 우선한다")
        is_override_local = False
        if ActionProfileDecider._is_local_update(view):
            prompt_l = prompt.lower()
            if any(kw in prompt_l for kw in ["최신 표현을 우선", "우선한다", "취소하고", "정정한 대로", "가장 최신이다"]):
                is_override_local = True

        consent_val = view.latest_record_value("consent")
        if isinstance(consent_val, dict) and consent_val.get("status") in ("revoked", "withdrawn", "denied"):
            if not is_override_local:
                return True
        if isinstance(consent_val, str) and consent_val in ("revoked", "withdrawn", "denied"):
            if not is_override_local:
                return True
            
        if view.latest_record_value("security_alert") and not ActionProfileDecider._is_local_update(view):
            return True
        if view.latest_record_value("safety_mode"):
            return True
            
        for phrase in HOLD_PHRASES:
            if phrase in prompt:
                return True
                
        if "phishing" in values_l or "피싱" in values_l:
            return True
        return False

    @staticmethod
    def _explicit_ask(view: TaskView, prompt: str) -> bool:
        if view.latest_record_value("payment_policy") or view.latest_record_value("memory_conflict") or view.latest_record_value("duration_ambiguous"):
            return True
        if view.latest_record_value("target_changed_after_turn"):
            return True
        for phrase in ASK_PHRASES:
            if phrase in prompt:
                if not ActionProfileDecider._is_local_update(view):
                    return True
        return False

    @staticmethod
    def _memory_or_domain_control(view: TaskView, focal: dict[str, Any]) -> str:
        if view.latest_record_value("enterprise_policy_recall"):
            return "amend"
        if view.latest_record_value("ops_memory_recall"):
            return "ask" if view.latest_record_value("target_changed_after_turn") else "amend"
        if view.latest_record_value("temporary_override_allowed"):
            return "amend"
        if view.latest_record_value("persistent_memory_recall") and "쿠폰" in view.prompt and not view.latest_record_value("payment_policy"):
            return "hold"
        if focal.get("type") == "health_record" and view.latest_record_value("external_share_policy") == "doctor_note_forbidden":
            return "hold"
        if view.latest_record_value("ambiguous_focal") and view.latest_record_value("session_share_policy") == "normal":
            return "ask"
        return ""

    @staticmethod
    def _control_from_boundary(view: TaskView) -> str:
        boundary = str(view.latest_record_value("share_boundary_update") or "")
        if boundary == "dispatch_blocked_until_binding":
            amend_phrases = ["식별 가능한 세부값을 제외", "세부값을 제외", "요약만 공유", "민감 내용은 알아서 처리", "위치나 나이 같은 민감"]
            if any(p in view.prompt for p in amend_phrases):
                return "amend"
            if view.latest_record_value("guardrail_ladder_signal"):
                return "hold"
            if view.latest_record_value("ambiguous_focal") and view.latest_record_value("dispatch_authority_check") == "user_binding_pending":
                return "hold"
            return ""
            
        if boundary == "local_update_boundary":
            ambiguous = str(view.latest_record_value("ambiguous_target") or "")
            if view.latest_record_value("ambiguous_focal"):
                return "proceed"
            if ambiguous == "stored_channel_or_visible_recipient":
                return "amend"
            if ambiguous == "approved_channel_or_visible_recipient":
                return "ask"
            if ambiguous == "surface_recipient_and_resolved_target_both_recent":
                return "amend"
                
        if boundary in ("redacted_external_boundary", "redacted_after_selection_boundary"):
            if str(view.latest_record_value("ambiguous_target") or "") == "surface_recipient_and_resolved_target_both_recent":
                return "ask"
            if str(view.latest_record_value("ambiguous_target") or "") == "stored_channel_or_visible_recipient" and (
                "검진" in view.prompt or "점검" in view.prompt
            ):
                return "ask"
            if view.latest_record_value("guardrail_ladder_signal") and view.latest_record_value("dispatch_authority_check") == "internal_binding_confirmed":
                return "proceed"
            return "amend"
        return ""

    @staticmethod
    def _unresolved_ambiguity(view: TaskView) -> bool:
        if not (view.latest_record_value("ambiguous_target") or view.latest_record_value("ambiguous_focal")):
            return False
        boundary = str(view.latest_record_value("share_boundary_update") or "")
        authority = str(view.latest_record_value("dispatch_authority_check") or "")
        candidates = str(view.latest_record_value("route_candidate_snapshot") or "")
        if boundary == "local_update_boundary":
            return False
        if authority in ("authority_incomplete", "user_binding_pending") and boundary == "dispatch_blocked_until_binding":
            return True
        if candidates == "external_candidates_present" and authority != "internal_binding_confirmed" and not boundary.startswith("redacted"):
            return True
        return False

    @staticmethod
    def _external_redactable(view: TaskView, prompt_l: str) -> bool:
        amend_phrases = ["식별 가능한 세부값을 제외", "세부값을 제외", "요약만 공유", "민감 내용은 알아서 처리", "위치나 나이 같은 민감"]
        if any(p in view.prompt for p in amend_phrases):
            return True
        if view.latest_record_value("external_share_policy"):
            return True
        boundary = str(view.latest_record_value("share_boundary_update") or "")
        if boundary in ("redacted_external_boundary", "redacted_after_selection_boundary"):
            return True
        if view.latest_record_value("ambiguous_target") and view.latest_record_value("resolved_target"):
            return True
        if view.latest_record_value("session_share_policy") == "strict" and view.latest_record_value("resolved_target"):
            return True
        return False

    @staticmethod
    def _map_ask_subprofile(view: TaskView) -> ActionProfile:
        if view.latest_record_value("memory_conflict"):
            return ActionProfile.MEMORY_CONFLICT_RESOLUTION
        elif view.latest_record_value("target_changed_after_turn") or view.latest_record_value("ambiguous_target"):
            return ActionProfile.TARGET_REBIND_REQUIRED
        elif view.latest_record_value("ambiguous_focal"):
            return ActionProfile.FALLBACK_CLARIFICATION
        else:
            return ActionProfile.EXPLICIT_CLARIFICATION

    @staticmethod
    def decide_internal(view: TaskView, evidence: EvidenceGraph, focal: dict[str, Any]) -> ProfileDecision:
        scores = ProfileScores()
        reasons = []

        prompt = view.prompt
        prompt_l = prompt.lower()
        values_l = " ".join(f"{r.get('type')} {str(r.get('value'))}" for r in view.records).lower()

        # Evaluate baseline conditions
        is_local_upd = ActionProfileDecider._is_local_update(view)
        explicit_hold = ActionProfileDecider._explicit_hold(view, prompt, values_l)
        explicit_ask = ActionProfileDecider._explicit_ask(view, prompt)
        memory_ctrl = ActionProfileDecider._memory_or_domain_control(view, focal)
        boundary_ctrl = ActionProfileDecider._control_from_boundary(view)
        unresolved_ambiguity = ActionProfileDecider._unresolved_ambiguity(view)
        external_redactable = ActionProfileDecider._external_redactable(view, prompt_l)

        # 1. HARD_BLOCK Scores
        if explicit_hold:
            scores.hard_block += 10
            reasons.append("explicit_hold")
        if memory_ctrl == "hold":
            scores.hard_block += 10
            reasons.append(f"memory_ctrl_hold:{view.latest_record_value('external_share_policy') or ''}")
        if boundary_ctrl == "hold":
            scores.hard_block += 10
            reasons.append("boundary_ctrl_hold")

        # 2. LOCAL_STATUS_UPDATE Scores
        if is_local_upd:
            scores.local_update += 10
            reasons.append("is_local_update")
        if boundary_ctrl == "proceed":
            boundary = str(view.latest_record_value("share_boundary_update") or "")
            if boundary == "local_update_boundary":
                scores.local_update += 10
                reasons.append("boundary_ctrl_proceed_local")

        # 3. ASK Profiles Scores
        if explicit_ask or memory_ctrl == "ask" or boundary_ctrl == "ask" or unresolved_ambiguity:
            sub = ActionProfileDecider._map_ask_subprofile(view)
            if sub == ActionProfile.MEMORY_CONFLICT_RESOLUTION:
                scores.memory_conflict += 10
                reasons.append("ask_memory_conflict")
            elif sub == ActionProfile.TARGET_REBIND_REQUIRED:
                scores.target_rebind += 10
                reasons.append("ask_target_rebind")
            elif sub == ActionProfile.FALLBACK_CLARIFICATION:
                scores.fallback_uncertainty += 10
                reasons.append("ask_fallback_clarification")
            else:
                scores.explicit_clarification += 10
                reasons.append("ask_explicit_clarification")

        # 4. EXTERNAL_REDACTED_DISPATCH Scores
        if memory_ctrl == "amend":
            scores.external_redaction += 10
            reasons.append("memory_ctrl_amend")
        if boundary_ctrl == "amend":
            scores.external_redaction += 10
            reasons.append("boundary_ctrl_amend")
        if external_redactable:
            scores.external_redaction += 10
            reasons.append("external_redactable")

        # 5. SAFE_DISPATCH_SUMMARY Scores
        if "요약" in prompt_l or "정리" in prompt_l:
            scores.safe_summary += 10
            reasons.append("prompt_summary_phrase")

        # 6. SAFE_DISPATCH_RAW Scores
        scores.safe_raw += 5
        reasons.append("default_raw_fallback")

        # Determine baseline control flow exactly
        control = "proceed"
        if explicit_hold:
            control = "hold"
        elif is_local_upd:
            control = "proceed"
        elif explicit_ask:
            control = "ask"
        elif memory_ctrl:
            control = memory_ctrl
        elif boundary_ctrl:
            control = boundary_ctrl
        elif unresolved_ambiguity:
            control = "ask"
        elif external_redactable:
            control = "amend"

        # Map control to ActionProfile
        if control == "hold":
            profile = ActionProfile.HARD_BLOCK
        elif control == "ask":
            profile = ActionProfileDecider._map_ask_subprofile(view)
        elif control == "amend":
            profile = ActionProfile.EXTERNAL_REDACTED_DISPATCH
        else: # "proceed"
            if is_local_upd or (boundary_ctrl == "proceed" and str(view.latest_record_value("share_boundary_update") or "") == "local_update_boundary"):
                profile = ActionProfile.LOCAL_STATUS_UPDATE
            elif "요약" in prompt_l or "정리" in prompt_l:
                profile = ActionProfile.SAFE_DISPATCH_SUMMARY
            else:
                profile = ActionProfile.SAFE_DISPATCH_RAW

        # Evaluate traces for possible domain candidates (PAY, TOGGLE, SCHEDULE)
        traces = []
        domain_verbs = evidence.intent_evidence.explicit_domain_verbs

        for act in ["PAY", "TOGGLE", "SCHEDULE"]:
            eligible = act in domain_verbs
            applied = False
            rejection_reason = None
            required_slots = []
            active_constraints = []
            supporting_evidence_ids = []
            capability_status = "available"

            if eligible:
                if act == "PAY":
                    supporting_evidence_ids.append("group_domain_pay")
                    if view.latest_record_value("payment_policy"):
                        capability_status = "unavailable"
                        active_constraints.append("payment_policy")
                elif act == "TOGGLE":
                    supporting_evidence_ids.append("group_domain_toggle")
                elif act == "SCHEDULE":
                    supporting_evidence_ids.append("group_domain_schedule")
                    required_slots = ["time"]
                    if view.latest_record_value("duration_ambiguous"):
                        required_slots.append("duration")
                    if view.latest_record_value("calendar_conflict"):
                        active_constraints.append("calendar_conflict")

                # Rejection reason evaluation based on capability, slots, constraints
                if profile == ActionProfile.HARD_BLOCK:
                    rejection_reason = PromotionRejectionReason.HARD_CONSTRAINT_ACTIVE
                elif profile in (
                    ActionProfile.EXPLICIT_CLARIFICATION,
                    ActionProfile.FALLBACK_CLARIFICATION,
                    ActionProfile.MEMORY_CONFLICT_RESOLUTION,
                    ActionProfile.TARGET_REBIND_REQUIRED,
                ):
                    if capability_status == "unavailable":
                        rejection_reason = PromotionRejectionReason.CAPABILITY_UNAVAILABLE
                    elif any(s in ["time", "duration"] for s in required_slots) and (
                        view.latest_record_value("duration_ambiguous") or "누구에게" in prompt or "다시" in prompt
                    ):
                        rejection_reason = PromotionRejectionReason.REQUIRED_SLOT_MISSING
                    else:
                        rejection_reason = PromotionRejectionReason.CLARIFICATION_ONLY_REQUEST
                else:
                    # Proceed or local update profile
                    if capability_status == "unavailable":
                        rejection_reason = PromotionRejectionReason.CAPABILITY_UNAVAILABLE
                    elif any(s in ["time", "duration"] for s in required_slots) and (
                        view.latest_record_value("duration_ambiguous") or "누구에게" in prompt or "다시" in prompt
                    ):
                        rejection_reason = PromotionRejectionReason.REQUIRED_SLOT_MISSING
                    else:
                        if profile == ActionProfile.LOCAL_STATUS_UPDATE and "전송" in prompt:
                            # User wanted to share, but we only updated locally
                            rejection_reason = PromotionRejectionReason.SHARE_ONLY_REQUEST
                        else:
                            applied = True
                            rejection_reason = None
            else:
                rejection_reason = PromotionRejectionReason.NO_EXPLICIT_EXECUTION_INTENT

            traces.append(
                DomainPromotionTrace(
                    domain_action_candidate=act,
                    promotion_eligible=eligible,
                    promotion_applied=applied,
                    promotion_rejected_reason=rejection_reason,
                    fallback_profile=profile if not applied else None,
                    required_slots=required_slots,
                    capability_status=capability_status,
                    active_constraints=active_constraints,
                    supporting_evidence_ids=supporting_evidence_ids,
                )
            )

        return ProfileDecision(profile=profile, scores=scores, reasons=reasons, domain_promotion_traces=traces)


def control_from_profile(profile: ActionProfile) -> str:
    mapping = {
        ActionProfile.HARD_BLOCK: "hold",
        ActionProfile.EXPLICIT_CLARIFICATION: "ask",
        ActionProfile.LOCAL_STATUS_UPDATE: "proceed",
        ActionProfile.TARGET_REBIND_REQUIRED: "ask",
        ActionProfile.MEMORY_CONFLICT_RESOLUTION: "ask",
        ActionProfile.EXTERNAL_REDACTED_DISPATCH: "amend",
        ActionProfile.SAFE_DISPATCH_SUMMARY: "proceed",
        ActionProfile.SAFE_DISPATCH_RAW: "proceed",
        ActionProfile.FALLBACK_CLARIFICATION: "ask",
    }
    return mapping.get(profile, "ask")

from __future__ import annotations

import re
from typing import Any
from core.task_view import TaskView

DIRECT_REF_PATTERNS = [
    re.compile(r"기준 참조는 (WM-\d+)"),
    re.compile(r"기준 참조(?: 코드)?는 (WM-\d+)"),
    re.compile(r"처리 대상으로 확정된 .*?참조 코드는 (WM-\d+)"),
    re.compile(r"최종 승인 후보 (WM-\d+)"),
    re.compile(r"승인 표시가 남은 것은 (WM-\d+)"),
    re.compile(r"유효한 항목은 .*?(WM-\d+)"),
    re.compile(r"실제 처리할 ref는 .*?(WM-\d+)"),
]


class FocalResolver:
    @staticmethod
    def resolve(view: TaskView, evidence: Any, session: dict[str, Any]) -> str:
        if not view.objects:
            last_id = str(session.get("last_focal_id") or "")
            if last_id and any(kw in view.prompt for kw in ["방금", "이전", "그거", "그것", "취소", "삭제", "전송"]):
                return last_id
            return ""
            
        via_marker = FocalResolver._from_marker_trace(view)
        if via_marker:
            return via_marker["id"]
            
        via_history = FocalResolver._from_history_ref(view)
        if via_history:
            return via_history["id"]
            
        via_record = FocalResolver._from_direct_record_value(view)
        if via_record:
            return via_record["id"]
            
        last_id = str(session.get("last_focal_id") or "")
        if last_id:
            if last_id in view.objects_by_id():
                return last_id
            if any(kw in view.prompt for kw in ["방금", "이전", "그거", "그것", "취소", "삭제"]):
                return last_id
            
        fallback = FocalResolver._fallback_object(view)
        return fallback["id"] if fallback else ""

    @staticmethod
    def _from_marker_trace(view: TaskView) -> dict[str, Any] | None:
        marker_refs = view.latest_record_value("focal_marker_refs")
        trace = view.latest_record_value("focal_resolution_trace")
        if not isinstance(marker_refs, dict) or not isinstance(trace, dict):
            return None
        marker_to_ref = marker_refs.get("marker_to_ref")
        phase_to_marker = trace.get("phase_to_marker")
        if not isinstance(marker_to_ref, dict) or not isinstance(phase_to_marker, dict):
            return None
            
        phase = str(trace.get("latest_phase") or "")
        if not phase and trace.get("phase_source") == "route_binding_order":
            order = view.latest_record_value("route_binding_order")
            rule = trace.get("latest_phase_rule", {})
            phase = rule.get(order) or rule.get("fallback") or ""
            
        marker = str(phase_to_marker.get(phase) or "")
        ref = str(marker_to_ref.get(marker) or "")
        return view.objects_by_ref_code().get(ref)

    @staticmethod
    def _from_history_ref(view: TaskView) -> dict[str, Any] | None:
        for item in reversed(view._history):
            if isinstance(item, dict):
                summary = str(item.get("summary", item) or "")
            else:
                summary = str(item)
                
            for pattern in DIRECT_REF_PATTERNS:
                match = pattern.search(summary)
                if match and match.group(1) in view.objects_by_ref_code():
                    return view.objects_by_ref_code()[match.group(1)]
                    
            refs = re.findall(r"WM-\d+", summary)
            if len(refs) >= 2 and any(phrase in summary for phrase in ["가운데 항목만", "두 번째 후보", "두 번째다"]):
                if refs[1] in view.objects_by_ref_code():
                    return view.objects_by_ref_code()[refs[1]]
            if len(refs) >= 2 and "두 번째" in summary and refs[1] in view.objects_by_ref_code():
                return view.objects_by_ref_code()[refs[1]]
        return None

    @staticmethod
    def _from_direct_record_value(view: TaskView) -> dict[str, Any] | None:
        for record in reversed(view.records):
            for value in FocalResolver._walk(record.get("value")):
                if isinstance(value, str) and value in view.objects_by_id():
                    return view.objects_by_id()[value]
                if isinstance(value, str) and value in view.objects_by_ref_code():
                    return view.objects_by_ref_code()[value]
        return None

    @staticmethod
    def _walk(value: Any) -> list[Any]:
        if isinstance(value, dict):
            out: list[Any] = []
            for child in value.values():
                out.extend(FocalResolver._walk(child))
            return out
        if isinstance(value, list):
            out = []
            for child in value:
                out.extend(FocalResolver._walk(child))
            return out
        return [value]

    @staticmethod
    def _fallback_object(view: TaskView) -> dict[str, Any]:
        prompt = view.prompt.lower()
        scored: list[tuple[int, int, dict[str, Any]]] = []
        resolved_target = view.latest_record_value("resolved_target")
        
        for idx, obj in enumerate(view.objects):
            attrs = obj.get("attrs") or {}
            # Match V5's blob text dump
            import json
            blob = json.dumps(obj, ensure_ascii=False).lower()
            score = 0
            if "원본" in prompt and "원본" in blob:
                score += 4
            if "사진" in prompt and obj.get("type") == "gallery_item":
                score += 2
            if "건강" in prompt and obj.get("type") == "health_record":
                score += 4
            if "설정" in prompt and obj.get("type") == "device_setting":
                score += 4
            if "메모리" in prompt and obj.get("type") == "personal_note":
                score += 3
            if attrs.get("recipient") == resolved_target:
                score += 2
            scored.append((score, -idx, obj))
        return max(scored, key=lambda x: (x[0], x[1]))[2]

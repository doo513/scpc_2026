from __future__ import annotations

import json
from pathlib import Path
from typing import Any
from core.action_profile import ActionProfile
from rules.action_profile import control_from_profile, ActionProfileDecider
from core.spec import PLAN_VERBS, PLAN_PURPOSES, PLAN_REASONS, PLAN_SCOPES

BASE_DIR = Path(__file__).resolve().parent.parent


def normalize_event(event: dict, task_id: str) -> tuple[dict, list[str]]:
    warnings = []
    normalized = {
        "verb": event.get("verb"),
        "target": event.get("target"),
        "args": {}
    }
    
    # Check verb
    verb = event.get("verb")
    if verb not in PLAN_VERBS:
        warnings.append(f"Unknown plan event verb '{verb}'")
        
    # Process args
    args = event.get("args") or {}
    for k, v in args.items():
        if k == "purpose":
            normalized["args"][k] = v
            if v not in PLAN_PURPOSES:
                warnings.append(f"Unknown plan arg purpose value '{v}'")
        elif k == "reason":
            normalized["args"][k] = v
            if v not in PLAN_REASONS:
                warnings.append(f"Unknown plan arg reason value '{v}'")
        elif k == "scope":
            normalized["args"][k] = v
            if v not in PLAN_SCOPES:
                warnings.append(f"Unknown plan arg scope value '{v}'")
        else:
            normalized["args"][k] = v
            if k not in ("remove", "state", "mode"):
                warnings.append(f"Unknown plan arg key '{k}'")
                
    return normalized, warnings


class PlanTemplateBuilder:
    @staticmethod
    def build(
        view: Any,
        evidence: Any,
        profile: ActionProfile,
        focal_id: str,
        target: str,
        content_scope: dict[str, Any],
        policy: dict[str, Any],
    ) -> list[dict[str, Any]]:
        control = control_from_profile(profile)
        fid = str(focal_id) if focal_id else ""
        
        if control == "hold":
            template = [
                {"verb": "read", "target": fid, "args": {"purpose": "invalidated_precondition"}},
                {"verb": "guard", "target": fid, "args": {"reason": "precondition_invalidated"}},
            ]
        elif control == "ask":
            reason = "precondition_changed" if PlanTemplateBuilder._clarify_precondition(view) else "route_resolution_required"
            purpose = "clarify_precondition" if reason == "precondition_changed" else "route_resolution_required"
            template = [
                {"verb": "read", "target": fid, "args": {"purpose": purpose}},
                {"verb": "clarify", "target": "user", "args": {"reason": reason}},
            ]
        elif profile == ActionProfile.LOCAL_STATUS_UPDATE:
            template = [
                {"verb": "read", "target": fid, "args": {"purpose": "local_update"}},
                {"verb": "verify", "target": "share_boundary_update", "args": {"scope": "local_update"}},
                {"verb": "update", "target": fid, "args": {"state": "local_status_only"}},
            ]
        elif control == "amend":
            remove = "sensitive_fields" if PlanTemplateBuilder._remove_sensitive_fields(content_scope) else "raw_quote"
            template = [
                {"verb": "read", "target": fid, "args": {"purpose": "minimal_disclosure"}},
                {"verb": "redact", "target": fid, "args": {"remove": remove}},
                {"verb": "dispatch", "target": target, "args": {"scope": "redacted"}},
            ]
        elif content_scope.get("mode") == "summary":
            template = [
                {"verb": "read", "target": fid, "args": {"purpose": "inspect_context"}},
                {"verb": "summarize", "target": fid, "args": {"mode": "summary"}},
                {"verb": "dispatch", "target": target, "args": {"scope": "summary"}},
            ]
        else:
            template = [
                {"verb": "read", "target": fid, "args": {"purpose": "inspect_context"}},
                {"verb": "dispatch", "target": target, "args": {"scope": content_scope.get("mode", "raw")}},
            ]
            
        # Normalize and log warnings
        normalized_template = []
        all_warnings = []
        task_id = view.task_id
        
        for event in template:
            norm_event, warnings = normalize_event(event, task_id)
            normalized_template.append(norm_event)
            all_warnings.extend(warnings)
            
        if all_warnings:
            reports_dir = BASE_DIR / "reports"
            reports_dir.mkdir(parents=True, exist_ok=True)
            log_file = reports_dir / "ontology_warnings.jsonl"
            with open(log_file, "a", encoding="utf-8") as f:
                for w in all_warnings:
                    log_entry = {
                        "task_id": task_id,
                        "warning": w,
                        "plan_events": normalized_template
                    }
                    f.write(json.dumps(log_entry, ensure_ascii=False) + "\n")
                    
        return normalized_template

    @staticmethod
    def _clarify_precondition(view: Any) -> bool:
        return any(p in view.prompt for p in ["새 전제", "조건 변경", "다시 확인", "누구에게 어떤 범위"])

    @staticmethod
    def _remove_sensitive_fields(scope: dict[str, Any]) -> bool:
        excluded = set(scope.get("excluded_fields") or [])
        return bool(excluded & {"name", "rrn", "numeric_value", "doctor_note", "location", "amount", "card_number"})

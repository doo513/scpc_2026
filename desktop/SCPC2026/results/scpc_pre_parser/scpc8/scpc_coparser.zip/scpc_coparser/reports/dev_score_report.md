# SCPC Dev Score Report

- Overall: `0.8036`
- Tasks: 120
- Exact tasks: 15
- Non-exact tasks: 105

| Axis | Score |
| --- | ---: |
| focal | 1.0000 |
| target | 0.9333 |
| control | 0.9583 |
| content_scope | 0.7419 |
| policy | 0.6845 |
| plan | 0.6889 |
| semantic_response | 0.0000 |
| counterfactual | 0.0000 |

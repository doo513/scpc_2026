from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any

from jsonschema import validate as jsonschema_validate

from harness import FinalHarness, load_json, load_jsonl, run_harness, validate_payload


ROOT = Path.cwd()


def candidate_data_dirs() -> list[Path]:
    here = Path(__file__).resolve().parent
    return [
        ROOT / "data",
        ROOT,
        here / "data",
        here,
        here.parent / "data",
        Path("/home/doo33/desktop/data/data"),
        Path("/home/doo33/desktop/data"),
    ]


def find_data_dir() -> Path:
    for path in candidate_data_dirs():
        if (path / "screening_tasks.jsonl").is_file():
            return path
    checked = "\n".join(str(path) for path in candidate_data_dirs())
    raise FileNotFoundError("screening_tasks.jsonl not found. Checked:\n" + checked)


def find_schema_path(data_dir: Path) -> Path | None:
    for path in [data_dir / "submission_schema.json", data_dir.parent / "submission_schema.json", Path("/home/doo33/desktop/data/submission_schema.json")]:
        if path.is_file():
            return path
    return None


def write_submission_csv(payload: dict[str, Any], path: Path) -> None:
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["submission"])
        writer.writerow([json.dumps(payload, ensure_ascii=False, separators=(",", ":"))])


def main() -> None:
    data_dir = find_data_dir()
    tasks = load_jsonl(data_dir / "screening_tasks.jsonl")
    payload = run_harness(tasks, FinalHarness, harness_name="scpc_parser_rule_harness")
    validate_payload(payload, {str(task["id"]) for task in tasks})

    schema_path = find_schema_path(data_dir)
    if schema_path:
        schema = load_json(schema_path)
        jsonschema_validate(instance=payload, schema=schema)

    out_path = Path(__file__).resolve().parent / "submission.csv"
    write_submission_csv(payload, out_path)
    print(f"DATA_DIR: {data_dir}")
    print(f"wrote: {out_path}")
    print(f"answers: {len(payload['answers'])}")
    print("meta:", json.dumps(payload["meta"], ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()

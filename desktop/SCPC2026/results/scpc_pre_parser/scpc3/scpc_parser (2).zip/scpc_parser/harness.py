from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any


SUBMISSION_SCHEMA = "scpc.final.answer.v1"
FIXED_SLM_ID = "scpc-final-fixed-slm-local-facade"

VALID_CONTROLS = {"proceed", "amend", "hold", "ask"}
VALID_SCOPE_MODES = {"raw", "summary", "redacted", "status_only", "none"}

REMOVED_SCORING_KEYS = (
    "expected_events",
    "answer",
)

SENSITIVE_FIELDS = {
    "amount",
    "birthday",
    "card_number",
    "doctor_note",
    "location",
    "name",
    "numeric_value",
    "person",
    "raw_quote",
    "rrn",
}

HOLD_RECORD_TYPES = {"consent", "security_alert", "safety_mode", "privacy_guard"}
CONFIRMATION_RECORD_TYPES = {
    "ambiguous_target",
    "ambiguous_focal",
    "duration_ambiguous",
    "memory_conflict",
    "payment_policy",
    "target_changed_after_turn",
    "calendar_conflict",
}
POLICY_RECORD_TYPES = {
    "external_share_policy",
    "enterprise_policy_recall",
    "temporary_override_allowed",
    "privacy_guard",
}

LOCAL_UPDATE_RE = re.compile(
    r"(내부|로컬|기기\s*내부|장치\s*안|바깥).*?(업데이트|갱신|기록|상태)"
    r"|상태값만|상태만|처리\s*상태만|공유하지\s*말고|보내지\s*말고"
    r"|전달\s*대신|보내는\s*작업.*취소|수신처\s*전달\s*대신"
)
EXPLICIT_HOLD_RE = re.compile(
    r"더\s*진행하면\s*안|실행하면\s*안|멈춰야|중단|막아야"
    r"|허용\s*근거.*깨|전제.*사라|조건.*취소|승인.*취소"
    r"|동의.*철회|과거\s*승인에\s*기대면\s*안|전제.*무효화|허용.*무효화"
    r"|확인\s*전에는\s*처리하지\s*않|처리하지\s*않"
)
EXPLICIT_ASK_RE = re.compile(
    r"먼저\s*확인|사용자.*확인|다시\s*확인|물어봐|확정되지"
    r"|확인이\s*필요|확인해야|누구에게\s*어떤\s*범위|대상이나\s*전제"
    r"|조건\s*변경\s*여부|미확정|결론을\s*내릴\s*수\s*없"
)
TARGET_USER_CONFIRM_RE = re.compile(
    r"누구에게\s*어떤\s*범위|새\s*전제가\s*확정되지|대상이나\s*전제"
    r"|조건\s*변경\s*여부|미확정|결론을\s*내릴\s*수\s*없"
)
REDACTION_INSTRUCTION_RE = re.compile(
    r"식별\s*가능한\s*세부값.*제외|요약만\s*공유|민감.*제외|민감.*제거|가리고"
)


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open(encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def records_of(task: dict[str, Any]) -> list[dict[str, Any]]:
    return list(((task.get("device_state") or {}).get("records") or []))


def objects_of(task: dict[str, Any]) -> list[dict[str, Any]]:
    return list(((task.get("device_state") or {}).get("objects") or []))


def text_of(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    return json.dumps(value, ensure_ascii=False, sort_keys=True)


def norm_token(value: Any) -> str:
    return str(value or "").strip().lower().replace("-", "_").replace(" ", "_")


def object_text(obj: dict[str, Any]) -> str:
    attrs = obj.get("attrs") or {}
    return " ".join([str(obj.get("id", "")), str(obj.get("type", "")), text_of(attrs)]).lower()


def all_context_text(task: dict[str, Any], *, include_objects: bool = False) -> str:
    parts: list[str] = [str(task.get("prompt", ""))]
    parts.extend(text_of(item) for item in task.get("visible_history", []) or [])
    for record in records_of(task):
        parts.append(str(record.get("type", "")))
        parts.append(text_of(record.get("value")))
    for mem in task.get("personal_memory", []) or []:
        parts.append(text_of(mem))
    if include_objects:
        for obj in objects_of(task):
            parts.append(object_text(obj))
    return " ".join(parts)


def instruction_text(task: dict[str, Any]) -> str:
    parts = [str(task.get("prompt", ""))]
    parts.extend(text_of(item) for item in task.get("visible_history", []) or [])
    return " ".join(parts)


def has_local_update_instruction(task: dict[str, Any]) -> bool:
    return bool(LOCAL_UPDATE_RE.search(instruction_text(task)))


def is_local_update(task: dict[str, Any]) -> bool:
    types = record_types(task)
    if "persistent_memory_write" in types:
        return True
    prompt = str(task.get("prompt", ""))
    return bool(LOCAL_UPDATE_RE.search(prompt))


def has_explicit_hold_instruction(task: dict[str, Any]) -> bool:
    return bool(EXPLICIT_HOLD_RE.search(instruction_text(task)))


def has_explicit_ask_instruction(task: dict[str, Any]) -> bool:
    return bool(EXPLICIT_ASK_RE.search(instruction_text(task)))


def has_target_user_confirmation_instruction(task: dict[str, Any]) -> bool:
    return bool(TARGET_USER_CONFIRM_RE.search(instruction_text(task)))


def has_redaction_instruction(task: dict[str, Any]) -> bool:
    return bool(REDACTION_INSTRUCTION_RE.search(str(task.get("prompt", ""))))


def record_values(task: dict[str, Any], record_type: str) -> list[Any]:
    return [record.get("value") for record in records_of(task) if record.get("type") == record_type]


def latest_record_value(task: dict[str, Any], record_type: str) -> Any:
    values = record_values(task, record_type)
    return values[-1] if values else None


def record_types(task: dict[str, Any]) -> set[str]:
    return {str(record.get("type")) for record in records_of(task)}


def flatten_strings(value: Any) -> list[str]:
    out: list[str] = []
    if isinstance(value, str):
        out.append(value)
    elif isinstance(value, dict):
        for key, child in value.items():
            out.append(str(key))
            out.extend(flatten_strings(child))
    elif isinstance(value, list):
        for child in value:
            out.extend(flatten_strings(child))
    elif value is not None:
        out.append(str(value))
    return out


def participant_task_view(task: dict[str, Any]) -> dict[str, Any]:
    view = json.loads(json.dumps(task, ensure_ascii=False))
    for key in list(view):
        if (
            key in REMOVED_SCORING_KEYS
            or key.startswith("expected_")
            or key.endswith("_brief")
            or key.endswith("_notes")
            or key.endswith("_rubric")
            or key.endswith("_keywords")
            or key.endswith("_tags")
        ):
            view.pop(key, None)
    return view


def answer_one(harness: Any, task: dict[str, Any], session: dict[str, Any]) -> dict[str, Any]:
    for name in ("answer_task", "solve_task", "solve"):
        fn = getattr(harness, name, None)
        if callable(fn):
            answer = fn(task, session)
            if not isinstance(answer, dict):
                raise RuntimeError(f"{name} returned non-object for task {task.get('id')}")
            return answer
    raise RuntimeError("harness must expose answer_task(task, session), solve_task(...), or solve(...)")


def run_harness(
    tasks: list[dict[str, Any]],
    harness_cls: type = None,
    *,
    harness_name: str = "scpc_parser_harness",
) -> dict[str, Any]:
    harness_cls = harness_cls or FinalHarness
    ordered = sorted(tasks, key=lambda t: (str(t.get("session_id", "")), int(t.get("turn_index", 0)), str(t.get("id", ""))))
    harness = harness_cls()
    prepare = getattr(harness, "prepare", None)
    if callable(prepare):
        prepare([])

    sessions: dict[str, dict[str, Any]] = {}
    answers: dict[str, dict[str, Any]] = {}
    for task in ordered:
        sid = str(task.get("session_id", ""))
        session = sessions.setdefault(sid, {})
        answers[str(task["id"])] = answer_one(harness, participant_task_view(task), session)

    return {
        "schema": SUBMISSION_SCHEMA,
        "meta": {
            "harness_name": harness_name,
            "uses_external_api": False,
            "fixed_slm_policy": "local_fixed_slm_only",
            "model_id": FIXED_SLM_ID,
            "temperature": 0.0,
            "seed": 2026,
        },
        "answers": answers,
    }


def validate_payload(payload: dict[str, Any], expected_ids: set[str] | None = None) -> None:
    if payload.get("schema") != SUBMISSION_SCHEMA:
        raise ValueError(f"schema must be {SUBMISSION_SCHEMA}")
    meta = payload.get("meta")
    if not isinstance(meta, dict):
        raise ValueError("meta is required")
    if meta.get("fixed_slm_policy") != "local_fixed_slm_only":
        raise ValueError("meta.fixed_slm_policy must be local_fixed_slm_only")
    if meta.get("uses_external_api") is not False:
        raise ValueError("meta.uses_external_api must be false")
    if meta.get("model_id") != FIXED_SLM_ID:
        raise ValueError(f"meta.model_id must be {FIXED_SLM_ID}")

    answers = payload.get("answers")
    if not isinstance(answers, dict):
        raise ValueError("answers must be an object")
    if expected_ids is not None:
        missing = sorted(expected_ids - set(answers))
        extra = sorted(set(answers) - expected_ids)
        if missing:
            raise ValueError(f"missing answers: {missing[:5]} ... total={len(missing)}")
        if extra:
            raise ValueError(f"extra answers: {extra[:5]} ... total={len(extra)}")

    for task_id, answer in answers.items():
        if not isinstance(answer, dict):
            raise ValueError(f"answer for {task_id} must be an object")
        for field in ["focal_id", "target", "control", "content_scope", "policy", "plan_events"]:
            if field not in answer:
                raise ValueError(f"answer for {task_id} missing {field}")
        if answer["control"] not in VALID_CONTROLS:
            raise ValueError(f"invalid control for {task_id}: {answer['control']}")
        scope = answer.get("content_scope")
        if not isinstance(scope, dict) or scope.get("mode") not in VALID_SCOPE_MODES:
            raise ValueError(f"invalid content_scope for {task_id}")
        for field in ("allowed_fields", "excluded_fields"):
            if not isinstance(scope.get(field), list):
                raise ValueError(f"invalid content_scope.{field} for {task_id}")
        if not isinstance(scope.get("requires_user_confirmation"), bool):
            raise ValueError(f"invalid content_scope.requires_user_confirmation for {task_id}")
        policy = answer.get("policy")
        if not isinstance(policy, dict):
            raise ValueError(f"invalid policy for {task_id}")
        for field in ("risk_flags", "violations"):
            if not isinstance(policy.get(field), list):
                raise ValueError(f"invalid policy.{field} for {task_id}")
        if not isinstance(policy.get("requires_confirmation"), bool):
            raise ValueError(f"invalid policy.requires_confirmation for {task_id}")
        if not isinstance(answer.get("plan_events"), list):
            raise ValueError(f"invalid plan_events for {task_id}")


class FixedSLMClient:
    model_id = FIXED_SLM_ID

    def summarize_task(self, task: dict[str, Any]) -> dict[str, Any]:
        types = record_types(task)
        boundary = latest_record_value(task, "share_boundary_update")
        authority = latest_record_value(task, "dispatch_authority_check")
        route_candidates = latest_record_value(task, "route_candidate_snapshot")
        flags: set[str] = set()
        tags: set[str] = set()

        if latest_record_value(task, "session_share_policy") == "strict":
            flags.add("strict_share_policy")
        if "ambiguous_target" in types or "target_changed_after_turn" in types:
            flags.add("target_ambiguity")
            tags.add("resolved_target")
        if "ambiguous_focal" in types:
            flags.add("ambiguous_focal")
        if "external_share_policy" in types or latest_record_value(task, "resolved_target") not in {None, "", "memory_store", "user"}:
            flags.add("external_share")
        if boundary == "local_update_boundary" or "persistent_memory_write" in types:
            flags.add("local_only")
        if authority in {"authority_incomplete", "user_binding_pending"} or route_candidates == "external_candidates_present":
            flags.add("target_ambiguity")
        if CONFIRMATION_RECORD_TYPES & types:
            flags.add("clarification_required")
        if HOLD_RECORD_TYPES & types:
            flags.update({"precondition_invalidated", "safety"})
        if any(self._object_has_sensitive(obj) for obj in objects_of(task)) or "external_share_policy" in types:
            flags.add("sensitive_content")
        if boundary == "redacted_external_boundary" or POLICY_RECORD_TYPES & types:
            flags.add("minimal_disclosure")

        requires_redaction = (
            boundary == "redacted_external_boundary"
            or "external_share_policy" in types
            or "enterprise_policy_recall" in types
            or any(self._object_has_sensitive(obj) for obj in objects_of(task))
        )
        requires_confirmation = (
            bool(CONFIRMATION_RECORD_TYPES & types)
            or authority in {"authority_incomplete", "user_binding_pending"}
            or (route_candidates == "external_candidates_present" and boundary == "dispatch_blocked_until_binding")
        )

        return {
            "risk_flags": sorted(flags),
            "requires_redaction": requires_redaction,
            "requires_confirmation": requires_confirmation,
            "audit_tags": sorted(tags),
        }

    def _object_has_sensitive(self, obj: dict[str, Any]) -> bool:
        attrs = obj.get("attrs") or {}
        values: set[str] = set()
        for key in ("contains", "fields"):
            if isinstance(attrs.get(key), list):
                values.update(str(item) for item in attrs[key])
        values.update(str(key) for key in attrs)
        return bool(values & SENSITIVE_FIELDS)



from pipeline.focal import choose_focal
from pipeline.target import infer_target
from pipeline.control import decide_control
from pipeline.scope import build_content_scope
from pipeline.policy import build_policy
from pipeline.plan import build_plan_events

class FinalHarness:

    def choose_focal(self, task: dict[str, Any], session: dict[str, Any]) -> dict[str, Any]:
        return choose_focal(self, task, session)
        
    def infer_target(self, task: dict[str, Any], focal: dict[str, Any], session: dict[str, Any], evidence: dict[str, Any]) -> str:
        return infer_target(self, task, focal, session, evidence)
        
    def decide_control(self, task: dict[str, Any], focal: dict[str, Any], target: str, evidence: dict[str, Any], session: dict[str, Any]) -> str:
        return decide_control(self, task, focal, target, evidence, session)
        
    def build_content_scope(self, task: dict[str, Any], focal: dict[str, Any], control: str, target: str) -> dict[str, Any]:
        return build_content_scope(self, task, focal, control, target)
        
    def build_policy(self, task: dict[str, Any], focal: dict[str, Any], control: str, target: str, scope: dict[str, Any]) -> dict[str, Any]:
        return build_policy(self, task, focal, control, target, scope)
        
    def build_plan_events(self, task: dict[str, Any], focal_id: str, target: str, control: str, scope: dict[str, Any], policy: dict[str, Any]) -> list[dict[str, Any]]:
        return build_plan_events(self, task, focal_id, target, control, scope, policy)

    def __init__(self) -> None:
        self.slm = FixedSLMClient()
        self.memory: dict[str, dict[str, Any]] = {}

    def prepare(self, tasks: list[dict[str, Any]]) -> None:
        self.memory.clear()

    def answer_task(self, task: dict[str, Any], session: dict[str, Any]) -> dict[str, Any]:
        evidence = self.slm.summarize_task(task)
        self.update_session_memory(task, session, evidence)

        focal = self.choose_focal(task, session, evidence)
        focal_id = str(focal.get("id") or "")
        target = self.infer_target(task, focal, session, evidence)
        control = self.decide_control(task, focal, target, evidence, session)
        target = self.normalize_target(task, focal, target, control, session)
        content_scope = self.build_content_scope(task, focal, control, target)
        policy = self.build_policy(task, focal, control, target, content_scope)
        plan_events = self.build_plan_events(task, focal_id, target, control, content_scope, policy)
        content_scope = self.reconcile_scope_confirmation(control, content_scope, policy, plan_events)

        session["last_focal_id"] = focal_id
        session["last_target"] = target
        session["last_control"] = control
        session["last_scope"] = content_scope.get("mode")

        return {
            "focal_id": focal_id,
            "target": target,
            "control": control,
            "content_scope": content_scope,
            "policy": policy,
            "plan_events": plan_events,
        }

    def update_session_memory(self, task: dict[str, Any], session: dict[str, Any], evidence: dict[str, Any]) -> None:
        for record in records_of(task):
            value = record.get("value")
            if record.get("type") == "persistent_memory_write" and isinstance(value, dict):
                keys = [value.get("memory_key"), value.get("person")]
                for key in keys:
                    if key:
                        self.memory[str(key)] = value
                        session.setdefault("memory", {})[str(key)] = value
            elif record.get("type") == "persistent_memory_recall" and isinstance(value, dict):
                key = value.get("memory_key") or value.get("person")
                if key:
                    recalled = self.memory.get(str(key)) or (session.get("memory") or {}).get(str(key))
                    if recalled:
                        session["recalled_memory"] = recalled
        session["last_evidence"] = evidence

    def choose_focal(self, task: dict[str, Any], session: dict[str, Any], evidence: dict[str, Any]) -> dict[str, Any]:
        objects = objects_of(task)
        if not objects:
            return {}
        by_id = {str(obj.get("id")): obj for obj in objects}
        by_ref = {str((obj.get("attrs") or {}).get("ref_code") or ""): obj for obj in objects}

        traced = self._focal_from_trace(task, by_ref)
        if traced:
            return traced

        for record in reversed(records_of(task)):
            for candidate in flatten_strings(record.get("value")):
                if candidate in by_id:
                    return by_id[candidate]
                if candidate in by_ref:
                    return by_ref[candidate]

        history_items = [str((item or {}).get("summary", "")) for item in task.get("visible_history", []) or []]
        for text in reversed(history_items):
            ref = self._extract_history_ref(text)
            if ref and ref in by_ref:
                return by_ref[ref]

        prompt_ref = self._extract_history_ref(str(task.get("prompt", "")))
        if prompt_ref and prompt_ref in by_ref:
            return by_ref[prompt_ref]

        prompt_tokens = {tok for tok in re.findall(r"[A-Za-z0-9가-힣_]+", str(task.get("prompt", "")).lower()) if len(tok) >= 2}
        best = objects[0]
        best_score = -1
        for obj in objects:
            score = sum(1 for tok in prompt_tokens if tok in object_text(obj))
            if obj.get("type") in {"file", "health_record", "personal_note", "payment_request", "device_setting"}:
                score += 1
            if score > best_score:
                best = obj
                best_score = score
        return best

    def _focal_from_trace(self, task: dict[str, Any], by_ref: dict[str, dict[str, Any]]) -> dict[str, Any] | None:
        traces = record_values(task, "focal_resolution_trace")
        markers = record_values(task, "focal_marker_refs")
        if not traces or not markers:
            return None
        trace = traces[-1]
        marker_refs = markers[-1]
        if not isinstance(trace, dict) or not isinstance(marker_refs, dict):
            return None

        latest_phase = trace.get("latest_phase")
        if not latest_phase and trace.get("phase_source") == "route_binding_order":
            order = latest_record_value(task, "route_binding_order")
            rule = trace.get("latest_phase_rule") or {}
            latest_phase = rule.get(order) or rule.get("fallback")
        phase_to_marker = trace.get("phase_to_marker") or {}
        marker = phase_to_marker.get(latest_phase) or latest_phase
        ref = (marker_refs.get("marker_to_ref") or {}).get(marker)
        if ref in by_ref:
            return by_ref[str(ref)]
        if marker in by_ref:
            return by_ref[str(marker)]
        return None

    def _extract_history_ref(self, text: str) -> str:
        patterns = [
            r"처리 대상으로 확정된 작업 메모리 참조 코드는\s*([A-Za-z]+-\d+|marker_[a-z]+)",
            r"기준 참조(?:는| 코드는)?\s*([A-Za-z]+-\d+|marker_[a-z]+)",
            r"승인 표시가 남은 것은\s*([A-Za-z]+-\d+|marker_[a-z]+)",
            r"최종 승인 후보(?:이고|는|가| )+\s*([A-Za-z]+-\d+|marker_[a-z]+)",
            r"현재 요청의 focal은 최종 승인 후보.*?([A-Za-z]+-\d+|marker_[a-z]+)",
        ]
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                return match.group(1)

        match = re.search(
            r"후보 목록은\s*([A-Za-z]+-\d+|marker_[a-z]+)\s*/\s*([A-Za-z]+-\d+|marker_[a-z]+)\s*/\s*([A-Za-z]+-\d+|marker_[a-z]+).*?가운데 항목만",
            text,
        )
        if match:
            return match.group(2)
        match = re.search(
            r"순서대로\s*([A-Za-z]+-\d+|marker_[a-z]+)[, /]+([A-Za-z]+-\d+|marker_[a-z]+)[, /]+([A-Za-z]+-\d+|marker_[a-z]+).*?두 번째",
            text,
        )
        if match:
            return match.group(2)
        return ""

    def _infer_target_internal(self, task: dict[str, Any], focal: dict[str, Any], session: dict[str, Any], evidence: dict[str, Any]) -> str:
        attrs = focal.get("attrs") or {}
        types = record_types(task)
        boundary = latest_record_value(task, "share_boundary_update")
        authority = latest_record_value(task, "dispatch_authority_check")
        route_candidates = latest_record_value(task, "route_candidate_snapshot")

        if "persistent_memory_write" in types or has_local_update_instruction(task):
            return "memory_store"
        if (
            boundary == "local_update_boundary"
            and route_candidates == "local_candidate_only"
            and authority == "local_authority_confirmed"
        ):
            return "memory_store"

        memory_target = self._target_from_memory(task, session)
        if memory_target:
            return memory_target

        changed = latest_record_value(task, "target_changed_after_turn")
        if isinstance(changed, str) and changed and changed != "prior_success_route_superseded":
            return changed
        if changed == "prior_success_route_superseded":
            mem = session.get("recalled_memory") or {}
            if isinstance(mem, dict) and mem.get("approval_channel"):
                return str(mem["approval_channel"])

        resolved = latest_record_value(task, "resolved_target")
        if isinstance(resolved, dict):
            for key in ("target", "route", "value", "name", "recipient"):
                if resolved.get(key):
                    return str(resolved[key])
        if isinstance(resolved, str) and resolved:
            return resolved

        for key in ("target", "channel", "app", "merchant", "name", "recipient", "attendee"):
            if attrs.get(key):
                return str(attrs[key])
        return str(session.get("last_target") or "user")

    def _target_from_memory(self, task: dict[str, Any], session: dict[str, Any]) -> str:
        recall = latest_record_value(task, "persistent_memory_recall")
        if not isinstance(recall, dict):
            return ""
        memory_key = str(recall.get("memory_key") or "")
        if memory_key:
            mem = self.memory.get(memory_key) or (session.get("memory") or {}).get(memory_key)
        else:
            mem = session.get("recalled_memory") or self.memory.get(str(recall.get("person") or ""))
        prompt = str(task.get("prompt", ""))
        person = str(recall.get("person") or "")
        if not isinstance(mem, dict):
            if "날이 어두워질 때" in prompt:
                return "living_room"
            if "검진" in prompt or "점검" in prompt:
                return "clinic_portal" if person == "jimin" else "caregiver"
            return ""
        if "날이 어두워질 때" in prompt:
            return str(mem.get("dusk_room") or "living_room")
        if "지난번 성공" in prompt and mem.get("last_success_target"):
            return str(mem["last_success_target"])
        if "회사 기본 규정" in prompt and mem.get("approval_channel"):
            return str(mem["approval_channel"])
        if "검진" in prompt or "점검" in prompt or "건강" in prompt:
            return str(mem.get("health_channel") or mem.get("preferred_channel") or "")
        if "생일" in prompt or "선호 선물" in prompt or "말투" in prompt:
            return str(mem.get("preferred_channel") or mem.get("health_channel") or "")
        return str(mem.get("preferred_channel") or mem.get("approval_channel") or "")

    def normalize_target(self, task: dict[str, Any], focal: dict[str, Any], target: str, control: str, session: dict[str, Any]) -> str:
        types = record_types(task)
        boundary = latest_record_value(task, "share_boundary_update")
        authority = latest_record_value(task, "dispatch_authority_check")
        route_candidates = latest_record_value(task, "route_candidate_snapshot")
        if control == "hold" and target in {"", "memory_store"}:
            return "user"
        if control == "hold" and has_explicit_hold_instruction(task):
            return "user"
        if (
            control == "ask"
            and has_target_user_confirmation_instruction(task)
            and not ({"memory_conflict", "payment_policy", "target_changed_after_turn", "ops_memory_recall"} & types)
        ):
            return "user"
        if control == "proceed" and (
            has_local_update_instruction(task)
            or "persistent_memory_write" in types
            or (
                boundary == "local_update_boundary"
                and route_candidates == "local_candidate_only"
                and authority == "local_authority_confirmed"
            )
        ):
            return "memory_store"
        return target or "user"

    def _decide_control_internal(self, task: dict[str, Any], focal: dict[str, Any], target: str, evidence: dict[str, Any], session: dict[str, Any]) -> str:
        types = record_types(task)
        values_text = " ".join(text_of(record.get("value")) for record in records_of(task)).lower()
        boundary = latest_record_value(task, "share_boundary_update")
        authority = latest_record_value(task, "dispatch_authority_check")
        route_candidates = latest_record_value(task, "route_candidate_snapshot")
        external_policy = latest_record_value(task, "external_share_policy")
        fields = self._field_set(focal)
        explicit_local = has_local_update_instruction(task) or "persistent_memory_write" in types or target == "memory_store"
        local_route_confirmed = (
            boundary == "local_update_boundary"
            and route_candidates in {"local_candidate_only", "mixed_local_external_candidates"}
            and authority == "local_authority_confirmed"
        )

        if explicit_local:
            return "proceed"

        # HARD HOLDS
        if has_explicit_hold_instruction(task):
            return "hold"
        if "security_alert" in types or "safety_mode" in types:
            return "hold"
        if "consent" in types and any(word in values_text for word in ("revoked", "withdraw", "denied", "철회", "거부")) and not is_local_update(task):
            return "hold"
        if "privacy_guard" in types and boundary != "local_update_boundary":
            return "hold"
        if route_candidates == "external_candidates_present" and boundary == "dispatch_blocked_until_binding" and "guardrail_ladder_signal" in types:
            return "hold"
        if route_candidates == "external_candidates_present" and boundary == "dispatch_blocked_until_binding" and "ambiguous_focal" in types and authority == "user_binding_pending":
            return "hold"

        # ASK CHECKS
        if has_explicit_ask_instruction(task) or "memory_conflict" in types or "payment_policy" in types or "target_changed_after_turn" in types:
            return "ask"
        if boundary == "redacted_external_boundary" and "ambiguous_target" in types and "guardrail_ladder_signal" not in types:
            return "ask"
        if "guardrail_ladder_signal" in types and "ambiguous_target" in types and boundary == "local_update_boundary" and authority == "internal_binding_confirmed":
            return "ask"
        if authority in {"authority_incomplete", "user_binding_pending"} and not latest_record_value(task, "resolved_target"):
            return "ask"
        if route_candidates == "external_candidates_present" and boundary == "dispatch_blocked_until_binding":
            return "ask"
        if route_candidates == "mixed_local_external_candidates" and authority == "user_binding_pending" and not latest_record_value(task, "resolved_target"):
            return "ask"
        if (boundary in {"dispatch_blocked_until_binding", "redacted_after_selection_boundary"}) or (boundary == "redacted_external_boundary" and authority != "internal_binding_confirmed") or ("ambiguous_target" in types) or ("target_changed_after_turn" in types):
            return "ask"

        # CONDITIONAL HOLD
        if external_policy == "doctor_note_forbidden" and latest_record_value(task, "resolved_target") in {"fitness_coach", "caregiver"}:
            return "hold"

        if local_route_confirmed:
            return "proceed"

        # AMEND OVERRIDES
        if (
            (boundary in {"redacted_external_boundary", "redacted_after_selection_boundary"} and (fields & SENSITIVE_FIELDS))
            or external_policy in {"doctor_note_forbidden", "raw_sensitive_forbidden", "raw_quote_forbidden"}
            or "enterprise_policy_recall" in types
            or (fields & SENSITIVE_FIELDS and target not in {"user", "memory_store"})
            or (latest_record_value(task, "session_share_policy") == "strict" and target not in {"user", "memory_store"})
            or has_redaction_instruction(task)
        ):
            return "amend"
            
        if boundary == "local_update_boundary":
            if target not in {"user", "memory_store"} and target is not None and "ambiguous_target" in types:
                return "amend"
            return "proceed"
            
        if "ops_memory_recall" in types and "target_changed_after_turn" not in types:
            return "amend"
            
        if (
            "guardrail_ladder_signal" in types
            and boundary == "redacted_external_boundary"
            and authority == "internal_binding_confirmed"
            and route_candidates == "single_internal_candidate"
            and focal.get("type") == "message"
            and not fields
        ):
            return "proceed"

        return "proceed"

    def _build_content_scope_internal(self, task: dict[str, Any], focal: dict[str, Any], control: str, target: str) -> dict[str, Any]:
        contains = self._field_set(focal)
        types = record_types(task)
        boundary = latest_record_value(task, "share_boundary_update")

        if control == "hold":
            return {"mode": "none", "allowed_fields": [], "excluded_fields": [], "requires_user_confirmation": False}

        if control == "proceed" and (is_local_update(task) or boundary == "local_update_boundary"):
            is_strict = latest_record_value(task, "session_share_policy") == "strict"
            has_sensitive = bool(contains & {'raw_quote', 'location', 'numeric_value', 'doctor_note', 'amount', 'rrn', 'name'})
            if is_strict or has_sensitive:
                ex = ["raw_quote", "location", "numeric_value"]
            else:
                ex = []
            return {
                "mode": "status_only",
                "allowed_fields": ["status"],
                "excluded_fields": ex,
                "requires_user_confirmation": False,
            }

        if control == "ask":
            prompt = str(task.get("prompt", ""))
            trace = latest_record_value(task, "focal_resolution_trace") or {}
            latest_phase = trace.get('latest_phase') if isinstance(trace, dict) else None

            # 1. target_changed_after_turn == 'prior_success_route_superseded' -> none
            if latest_record_value(task, "target_changed_after_turn") == 'prior_success_route_superseded':
                mode = 'none'
            # 2. 원본과 사진 / 원본, 익명 요약, 사진
            elif '원본과 사진' in prompt or '원본, 익명 요약, 사진' in prompt:
                if target in {'audit_vendor', 'privacy_review'}:
                    if target == 'privacy_review' and boundary == 'dispatch_blocked_until_binding':
                        mode = 'none'
                    else:
                        mode = 'redacted'
                else:
                    mode = 'summary'
            # 3. 누구에게 어떤 범위
            elif '누구에게 어떤 범위' in prompt:
                mode = 'summary'
            # 4. payment_policy / memory_conflict
            elif 'payment_policy' in types or 'memory_conflict' in types:
                mode = 'summary'
            # 5. 검진/점검/건강 prompts with memory recall
            elif ('검진' in prompt or '점검' in prompt or '건강' in prompt) and 'persistent_memory_recall' in types:
                mode = 'summary'
            # 6. target changed after turn with non-user
            elif target != 'user' and 'target_changed_after_turn' in types:
                if latest_record_value(task, "session_share_policy") == 'strict' and latest_phase == 'draft':
                    mode = 'redacted'
                else:
                    mode = 'summary'
            # 7. redacted boundary
            elif boundary in {'redacted_external_boundary', 'redacted_after_selection_boundary'}:
                if latest_record_value(task, "session_share_policy") == 'strict' and latest_phase == 'authority':
                    mode = 'summary'
                else:
                    mode = 'redacted'
            # 8. strict policy
            elif latest_record_value(task, "session_share_policy") == 'strict':
                if boundary == 'dispatch_blocked_until_binding' and target == 'user':
                    mode = 'summary'
                else:
                    mode = 'redacted'
            else:
                mode = 'summary'

            if mode == 'none':
                allowed = []
                excluded = []
            elif mode == 'redacted':
                allowed = ['summary']
                excluded = self._redaction_exclusions(task, contains, target, focal)
            else:
                allowed = ['summary']
                excluded = self._summary_excluded(contains) or ['raw_quote']

            return {"mode": mode, "allowed_fields": allowed, "excluded_fields": excluded, "requires_user_confirmation": True}

        if control == "amend":
            return {
                "mode": "redacted",
                "allowed_fields": ["summary"],
                "excluded_fields": self._redaction_exclusions(task, contains, target, focal),
                "requires_user_confirmation": self._requires_confirmation_helper(task),
            }

        if boundary == "local_update_boundary":
            return {
                "mode": "status_only",
                "allowed_fields": ["status"],
                "excluded_fields": ["raw_quote", "location", "numeric_value"],
                "requires_user_confirmation": False,
            }
        if self._raw_allowed(task, focal, target):
            return {"mode": "raw", "allowed_fields": ["summary", "title"], "excluded_fields": [], "requires_user_confirmation": False}
        return {"mode": "summary", "allowed_fields": ["summary"], "excluded_fields": [], "requires_user_confirmation": False}

    def _build_policy_internal(self, task: dict[str, Any], focal: dict[str, Any], control: str, target: str, scope: dict[str, Any]) -> dict[str, Any]:
        flags: list[str] = []
        violations: list[str] = []
        contains = self._field_set(focal)
        types = record_types(task)
        boundary = latest_record_value(task, "share_boundary_update")
        authority = latest_record_value(task, "dispatch_authority_check")

        if latest_record_value(task, "session_share_policy") == "strict":
            flags.append("strict_share_policy")
            
        if target != 'memory_store' and target != 'user':
            flags.append('external_share')
        if target == 'memory_store' or target == 'user' or boundary == 'local_update_boundary':
            flags.append('local_only')
            
        if contains & {'raw_quote', 'rrn', 'name', 'location', 'numeric_value', 'doctor_note', 'amount'}:
            flags.append('sensitive_content')
            
        has_target_amb = (
            'ambiguous_target' in types
            or (boundary == 'dispatch_blocked_until_binding' 
                and authority == 'user_binding_pending')
        )
        if has_target_amb:
            flags.append('target_ambiguity')
            
        if 'ambiguous_focal' in types:
            flags.append('ambiguous_focal')
        if control == 'amend':
            flags.append('minimal_disclosure')
        if control == 'ask':
            flags.append('clarification_required')
            
        has_ambiguity = (
            'ambiguous_target' in types
            or 'ambiguous_focal' in types
            or 'duration_ambiguous' in types
            or 'target_changed_after_turn' in types
        )
        has_precond_chg = has_ambiguity and (
            boundary == 'dispatch_blocked_until_binding'
            or 'guardrail_ladder_signal' in types
            or 'target_changed_after_turn' in types
            or has_explicit_ask_instruction(task)
            or has_explicit_hold_instruction(task)
        ) and not (control == 'proceed' and scope.get('mode') == 'status_only')
        if has_precond_chg:
            flags.append('precondition_changed')
            
        if control == 'hold':
            flags.extend(['precondition_invalidated', 'safety'])
            violations.append('precondition_changed_ignored')

        # requires_confirmation logic
        req_conf = control == 'ask'
        if control == 'proceed':
            if has_target_amb:
                req_conf = True
            elif target != 'memory_store' and authority in {'authority_incomplete', 'user_binding_pending'}:
                req_conf = True
                
        if scope.get('requires_user_confirmation'):
            req_conf = True

        return {
            "risk_flags": sorted(list(set(flags))),
            "violations": sorted(list(set(violations))),
            "requires_confirmation": req_conf,
        }

    def _build_plan_events_internal(
        self,
        task: dict[str, Any],
        focal_id: str,
        target: str,
        control: str,
        scope: dict[str, Any],
        policy: dict[str, Any],
    ) -> list[dict[str, Any]]:
        if control == "hold":
            return [
                {"verb": "read", "target": focal_id, "args": {"purpose": "invalidated_precondition"}},
                {"verb": "guard", "target": focal_id, "args": {"reason": "precondition_invalidated"}},
            ]
        if control == "ask":
            is_precond = "precondition_changed" in policy.get("risk_flags", [])
            reason = "precondition_changed" if is_precond else "route_resolution_required"
            purpose = "clarify_precondition" if is_precond else "route_resolution_required"
            return [
                {"verb": "read", "target": focal_id, "args": {"purpose": purpose}},
                {"verb": "clarify", "target": "user", "args": {"reason": reason}},
            ]
        if control == "proceed" and (is_local_update(task) or latest_record_value(task, "share_boundary_update") == "local_update_boundary"):
            return [
                {"verb": "read", "target": focal_id, "args": {"purpose": "local_update"}},
                {"verb": "verify", "target": "share_boundary_update", "args": {"scope": "local_update"}},
                {"verb": "update", "target": focal_id, "args": {"state": "local_status_only"}},
            ]
        if control == "amend":
            excluded = set(scope.get("excluded_fields") or [])
            remove = "sensitive_fields" if (excluded & {"name", "rrn", "numeric_value", "doctor_note", "location", "amount", "card_number"}) else "raw_quote"
            return [
                {"verb": "read", "target": focal_id, "args": {"purpose": "minimal_disclosure"}},
                {"verb": "redact", "target": focal_id, "args": {"remove": remove}},
                {"verb": "dispatch", "target": target, "args": {"scope": "redacted"}},
            ]
        if scope.get("mode") == "summary":
            return [
                {"verb": "read", "target": focal_id, "args": {"purpose": "inspect_context"}},
                {"verb": "summarize", "target": focal_id, "args": {"mode": "summary"}},
                {"verb": "dispatch", "target": target, "args": {"scope": "summary"}},
            ]
        return [
            {"verb": "read", "target": focal_id, "args": {"purpose": "inspect_context"}},
            {"verb": "dispatch", "target": target, "args": {"scope": scope.get("mode", "raw")}},
        ]

    def reconcile_scope_confirmation(
        self,
        control: str,
        scope: dict[str, Any],
        policy: dict[str, Any],
        plan_events: list[dict[str, Any]],
    ) -> dict[str, Any]:
        verbs = {str(event.get("verb")) for event in plan_events if isinstance(event, dict)}
        should_suppress_confirmation = (
            control == "amend"
            and scope.get("mode") == "redacted"
            and policy.get("requires_confirmation") is False
            and "dispatch" in verbs
            and "clarify" not in verbs
        )
        if not should_suppress_confirmation:
            return scope
        reconciled = dict(scope)
        reconciled["requires_user_confirmation"] = False
        return reconciled

    def _field_set(self, obj: dict[str, Any]) -> set[str]:
        attrs = obj.get("attrs") or {}
        raw = attrs.get("contains")
        if raw is None:
            raw = attrs.get("fields")
        return {str(x) for x in raw} if isinstance(raw, list) else set()

    def _excluded_fields(self, fields: set[str]) -> list[str]:
        normalized = set(fields)
        if "amount" in normalized:
            normalized.add("numeric_value")
            normalized.discard("amount")
        preferred = ["name", "numeric_value", "raw_quote", "rrn", "location", "doctor_note", "card_number", "person"]
        return [field for field in preferred if field in normalized]

    def _summary_excluded(self, fields: set[str]) -> list[str]:
        if "name" in fields:
            return ["name"]
        return ["raw_quote"] if "raw_quote" in fields else []

    def _redaction_exclusions(self, task: dict[str, Any], contains: set[str], target: str, focal: dict[str, Any]) -> list[str]:
        policy = str(latest_record_value(task, "external_share_policy") or "")
        if target != 'user' and 'doctor_note_forbidden' in policy and 'doctor_note' in contains:
            return ['doctor_note']
        if 'raw_sensitive_forbidden' in policy:
            items = [x for x in ['name', 'numeric_value', 'raw_quote', 'rrn'] if x in contains or x == 'numeric_value']
            return items or ['sensitive_fields']
        prompt = str(task.get("prompt", ""))
        all_text = all_context_text(task, include_objects=True)
        if '원본과 사진' in prompt or '원본, 익명 요약, 사진' in prompt or '출장 정산' in all_text:
            items = [x for x in ['name', 'numeric_value', 'raw_quote', 'rrn'] if x in contains or x == 'numeric_value']
            return items or ['name']
        if focal.get('type') != 'health_record' and contains & {'location', 'numeric_value'} and not contains & {'name', 'rrn'}:
            return ['location', 'numeric_value', 'raw_quote'] if 'raw_quote' in contains else ['location', 'numeric_value']
        return ['raw_quote']

    def _redaction_needed(self, task: dict[str, Any], focal: dict[str, Any], evidence: dict[str, Any]) -> bool:
        types = record_types(task)
        if latest_record_value(task, "share_boundary_update") == "redacted_external_boundary":
            return True
        if "enterprise_policy_recall" in types or "external_share_policy" in types or "temporary_override_allowed" in types:
            return True
        fields = self._field_set(focal)
        target = latest_record_value(task, "resolved_target")
        return bool(fields & SENSITIVE_FIELDS and target and target not in {"user", "memory_store"})

    def _requires_confirmation_helper(self, task: dict[str, Any]) -> bool:
        types = record_types(task)
        if "ambiguous_target" in types or "target_changed_after_turn" in types:
            return True
        if latest_record_value(task, "dispatch_authority_check") in {"authority_incomplete", "user_binding_pending"}:
            return True
        return False

    def _raw_allowed(self, task: dict[str, Any], focal: dict[str, Any], target: str) -> bool:
        types = record_types(task)
        boundary = latest_record_value(task, "share_boundary_update")
        authority = latest_record_value(task, "dispatch_authority_check")
        if (
            "guardrail_ladder_signal" in types
            and boundary == "redacted_external_boundary"
            and authority == "internal_binding_confirmed"
        ):
            return True
        if latest_record_value(task, "session_share_policy") != "normal":
            return False
        if "external_share_policy" in types:
            return False
        if "ambiguous_target" in types or "ambiguous_focal" in types:
            return False
        contains = self._field_set(focal)
        prompt = str(task.get("prompt", ""))
        if target in {"project_room", "privacy_review"} and "회의 시간" in prompt:
            return True
        return False

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
import re
from typing import Any

from .task_view import TaskView


HOLD_PHRASES = (
    "더 진행하면 안",
    "실행하면 안",
    "실행을 막",
    "멈춰야",
    "처리하지 않는다",
    "처리 전제가 사라",
    "전제를 무효화",
    "허용 근거가 최신 상태에서 깨",
    "과거 승인에 기대면 안",
    "이전 허용 조건이 취소",
)

ASK_PHRASES = (
    "다시 확인",
    "사용자 확인",
    "먼저 확인",
    "확인 절차",
    "확정되지",
    "미확정",
    "결론을 내릴 수 없다",
    "아직 확인되지",
    "물어봐",
    "누구에게 어떤 범위",
)

LOCAL_UPDATE_PHRASES = (
    "내부 상태 업데이트",
    "상태만 갱신",
    "로컬 상태 기록",
    "기기 내부 업데이트",
    "장치 안의 처리 상태만",
    "바깥으로 보내지 말고",
    "공유하지 말고",
    "수신처 전달 대신",
    "전달 동작은 취소",
    "보내는 작업은 취소",
    "외부 공유가 아니라",
    "외부 전송을 하지 말고",
    "상태 표시만",
    "상태 기록만",
    "memory_store",
    "status_only",
)

LOCAL_UPDATE_RE = re.compile(
    r"(?:외부\s*(?:공유|전송)|바깥으로\s*보내|실제\s*보내기는|보내는\s*작업|전달\s*동작|공유\s*작업|공유\s*채널로\s*넘기)"
    r"[^.!?]{0,50}(?:하지|말고|접고|취소|대신|아니라|생략)"
    r"|(?:내부|기기\s*안|기기\s*내부|내\s*기기|장치\s*안|로컬)[^.!?]*(?:상태|기록|갱신|업데이트|완료|남기)"
)

REDACT_PHRASES = (
    "식별 가능한 세부값을 제외",
    "세부값을 제외",
    "요약만 공유",
    "민감 내용은 알아서 처리",
    "위치나 나이 같은 민감",
)


class IntentOverride(str, Enum):
    NONE = "none"
    STOP = "stop"
    CLARIFY = "clarify"
    LOCAL_ONLY = "local_only"
    REDACT_ONLY = "redact_only"


def has_local_update_intent(text: str) -> bool:
    return any(phrase in text for phrase in LOCAL_UPDATE_PHRASES) or bool(LOCAL_UPDATE_RE.search(text))


@dataclass(frozen=True)
class RouteBundle:
    candidate: str = ""
    authority: str = ""
    boundary: str = ""
    binding_order: str = ""

    @property
    def is_local_boundary(self) -> bool:
        return self.boundary == "local_update_boundary"

    @property
    def is_external_boundary(self) -> bool:
        return self.boundary in {
            "redacted_external_boundary",
            "redacted_after_selection_boundary",
            "dispatch_blocked_until_binding",
        }

    @property
    def is_authority_confirmed(self) -> bool:
        return self.authority in {"internal_binding_confirmed", "local_authority_confirmed"}

    @property
    def is_authority_pending(self) -> bool:
        return self.authority in {"authority_incomplete", "user_binding_pending"}

    def as_legacy_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data.update(
            is_local_boundary=self.is_local_boundary,
            is_external_boundary=self.is_external_boundary,
            is_authority_confirmed=self.is_authority_confirmed,
            is_authority_pending=self.is_authority_pending,
        )
        return data


@dataclass(frozen=True)
class SensitivityEvidence:
    contains: frozenset[str] = frozenset()
    sensitive_fields: frozenset[str] = frozenset()

    @property
    def has_sensitive_fields(self) -> bool:
        return bool(self.sensitive_fields)


@dataclass
class EvidenceGraph:
    intent_override: IntentOverride = IntentOverride.NONE
    latest_clause: str = ""
    route: RouteBundle = field(default_factory=RouteBundle)
    sensitivity: SensitivityEvidence = field(default_factory=SensitivityEvidence)
    hard_block: list[str] = field(default_factory=list)
    explicit_clarification: list[str] = field(default_factory=list)
    local_update: list[str] = field(default_factory=list)
    target_rebind: list[str] = field(default_factory=list)
    memory_conflict: list[str] = field(default_factory=list)
    unresolved_ambiguity: list[str] = field(default_factory=list)
    external_share: list[str] = field(default_factory=list)
    sensitive_fields: list[str] = field(default_factory=list)
    prompt_overrides: list[str] = field(default_factory=list)
    personal_memory_signals: list[str] = field(default_factory=list)
    slm_fallback_signals: list[str] = field(default_factory=list)
    duplicate_record_types: list[str] = field(default_factory=list)

    @property
    def route_bundle(self) -> dict[str, Any]:
        return self.route.as_legacy_dict()

    @property
    def has_persistent_memory_write(self) -> bool:
        return "persistent_memory_write_present" in self.local_update

    @classmethod
    def from_view(cls, view: TaskView, focal_id: str = "") -> EvidenceGraph:
        latest_clause = view.latest_clause()
        route = RouteBundle(
            candidate=str(view.latest_record_value("route_candidate_snapshot") or ""),
            authority=str(view.latest_record_value("dispatch_authority_check") or ""),
            boundary=str(view.latest_record_value("share_boundary_update") or ""),
            binding_order=str(view.latest_record_value("route_binding_order") or ""),
        )
        graph = cls(
            intent_override=cls._classify_override(latest_clause),
            latest_clause=latest_clause,
            route=route,
            duplicate_record_types=sorted(view.duplicate_record_types()),
        )

        if latest_clause:
            graph.prompt_overrides.append(latest_clause)

        cls._collect_hard_blocks(view, graph)
        cls._collect_clarification(view, graph)
        cls._collect_local_update(view, graph)

        if view.latest_record_value("target_changed_after_turn"):
            graph.target_rebind.append("target_changed_after_turn_present")
        if view.latest_record_value("memory_conflict"):
            graph.memory_conflict.append("memory_conflict_present")
        if view.latest_record_value("ambiguous_target"):
            graph.unresolved_ambiguity.append("ambiguous_target_present")
        if view.latest_record_value("ambiguous_focal"):
            graph.unresolved_ambiguity.append("ambiguous_focal_present")
        if graph.duplicate_record_types:
            graph.unresolved_ambiguity.extend(
                f"duplicate_record_type:{kind}" for kind in graph.duplicate_record_types
            )
        if view.latest_record_value("external_share_policy"):
            graph.external_share.append("external_share_policy_present")

        contains = frozenset(view.contains_for_object(focal_id)) if focal_id else frozenset()
        sensitive = contains & {
            "raw_quote",
            "rrn",
            "name",
            "location",
            "numeric_value",
            "doctor_note",
            "image",
            "amount",
            "card_number",
        }
        graph.sensitivity = SensitivityEvidence(contains, frozenset(sensitive))
        graph.sensitive_fields = sorted(sensitive)

        for entry in view.personal_memory_entries():
            kind = str(entry.get("type") or "personal_memory")
            graph.personal_memory_signals.append(kind)

        return graph

    @staticmethod
    def _classify_override(latest_clause: str) -> IntentOverride:
        if not latest_clause:
            return IntentOverride.NONE
        if any(phrase in latest_clause for phrase in HOLD_PHRASES):
            return IntentOverride.STOP
        if any(phrase in latest_clause for phrase in ASK_PHRASES):
            return IntentOverride.CLARIFY
        if has_local_update_intent(latest_clause):
            return IntentOverride.LOCAL_ONLY
        if any(phrase in latest_clause for phrase in REDACT_PHRASES):
            return IntentOverride.REDACT_ONLY
        return IntentOverride.NONE

    @staticmethod
    def _collect_hard_blocks(view: TaskView, graph: EvidenceGraph) -> None:
        if view.latest_record_value("security_alert"):
            graph.hard_block.append("security_alert_present")
        if view.latest_record_value("safety_mode"):
            graph.hard_block.append("safety_mode_present")
        consent = view.latest_record_value("consent")
        status = str(consent.get("status") if isinstance(consent, dict) else consent or "")
        if status in {"revoked", "withdrawn", "denied"}:
            graph.hard_block.append("consent_revoked")
        guardrail = view.latest_record_value("guardrail_ladder_signal")
        if guardrail:
            graph.hard_block.append(f"guardrail_ladder_signal:{guardrail}")
        for phrase in HOLD_PHRASES:
            if phrase in view.prompt:
                graph.hard_block.append(f"prompt_hold_phrase:{phrase}")

    @staticmethod
    def _collect_clarification(view: TaskView, graph: EvidenceGraph) -> None:
        for phrase in ASK_PHRASES:
            if phrase in view.prompt:
                graph.explicit_clarification.append(f"prompt_ask_phrase:{phrase}")
        for kind in ("payment_policy", "calendar_conflict", "duration_ambiguous"):
            if view.latest_record_value(kind):
                graph.explicit_clarification.append(f"{kind}_present")

    @staticmethod
    def _collect_local_update(view: TaskView, graph: EvidenceGraph) -> None:
        if view.latest_record_value("persistent_memory_write"):
            graph.local_update.append("persistent_memory_write_present")
        if has_local_update_intent(view.prompt):
            graph.local_update.append("prompt_local_intent")
        if graph.route.is_local_boundary:
            graph.local_update.append("route_local_boundary")

    def to_trace(self) -> dict[str, Any]:
        return {
            "intent_override": self.intent_override.value,
            "latest_clause": self.latest_clause,
            "route_bundle": self.route_bundle,
            "hard_block": list(self.hard_block),
            "explicit_clarification": list(self.explicit_clarification),
            "local_update": list(self.local_update),
            "target_rebind": list(self.target_rebind),
            "memory_conflict": list(self.memory_conflict),
            "unresolved_ambiguity": list(self.unresolved_ambiguity),
            "external_share": list(self.external_share),
            "sensitive_fields": list(self.sensitive_fields),
            "duplicate_record_types": list(self.duplicate_record_types),
        }

from __future__ import annotations

import json
from collections import defaultdict
from typing import Any, Iterable


LATEST_CLAUSE_MARKERS = (
    "단,",
    "단 ",
    "다만",
    "하지만",
    "마지막으로",
    "마지막 사용자 정정",
    "방금 정정한 대로",
    "이전 말은 취소하고",
    "외부로 보내지 말고",
    "바깥으로 보내지 말고",
    "공유하지 말고",
    "상태만 갱신",
    "먼저 확인",
    "승인 전까지",
    "확정 전까지",
    "허용 근거가 사라졌으면",
)

CLAUSE_BOUNDARY_MARKERS = (
    "단,",
    "단 ",
    "다만",
    "하지만",
    "마지막으로",
    "마지막 사용자 정정",
    "방금 정정한 대로",
    "이전 말은 취소하고",
)


def stable_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


class TaskView:
    """Normalized, read-only access to one participant-visible task."""

    def __init__(self, task: dict[str, Any], session_state: dict[str, Any] | None = None):
        self.task = task if isinstance(task, dict) else {}
        self.session_state = session_state if isinstance(session_state, dict) else {}

        state = self.task.get("device_state") or {}
        self._objects = tuple(o for o in state.get("objects", []) if isinstance(o, dict))
        self._records = tuple(r for r in state.get("records", []) if isinstance(r, dict))
        self._history = tuple(h for h in self.task.get("visible_history", []) if isinstance(h, dict))
        self._memory = tuple(m for m in self.task.get("personal_memory", []) if isinstance(m, dict))
        self._available_actions = frozenset(str(x) for x in self.task.get("available_actions", []) if x)

        records_by_type: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for record in self._records:
            records_by_type[str(record.get("type") or "")].append(record)
        self._records_by_type = dict(records_by_type)

        self._objects_by_id = {
            str(obj["id"]): obj for obj in self._objects if obj.get("id") is not None
        }
        self._objects_by_ref_code: dict[str, dict[str, Any]] = {}
        for obj in self._objects:
            ref_code = str((obj.get("attrs") or {}).get("ref_code") or "")
            if ref_code:
                self._objects_by_ref_code[ref_code] = obj

    @property
    def task_id(self) -> str:
        return str(self.task.get("id") or "")

    @property
    def session_id(self) -> str:
        return str(self.task.get("session_id") or "")

    @property
    def turn_index(self) -> int:
        try:
            return int(self.task.get("turn_index", 0))
        except (TypeError, ValueError):
            return 0

    @property
    def prompt(self) -> str:
        return stable_text(self.task.get("prompt"))

    @property
    def objects(self) -> tuple[dict[str, Any], ...]:
        return self._objects

    @property
    def records(self) -> tuple[dict[str, Any], ...]:
        return self._records

    @property
    def history(self) -> tuple[dict[str, Any], ...]:
        return self._history

    @property
    def available_actions(self) -> frozenset[str]:
        return self._available_actions

    def objects_by_id(self) -> dict[str, dict[str, Any]]:
        return self._objects_by_id

    def objects_by_ref_code(self) -> dict[str, dict[str, Any]]:
        return self._objects_by_ref_code

    def records_by_type(self) -> dict[str, list[dict[str, Any]]]:
        return self._records_by_type

    def records_of_type(self, record_type: str) -> tuple[dict[str, Any], ...]:
        return tuple(self._records_by_type.get(record_type, ()))

    def record_values(self, record_type: str) -> list[Any]:
        return [record.get("value") for record in self.records_of_type(record_type)]

    def record_is_ambiguous(self, record_type: str) -> bool:
        records = self.records_of_type(record_type)
        if len(records) <= 1:
            return False
        values = {stable_text(record.get("value")) for record in records}
        return len(values) > 1 and not all(self._record_rank(record) is not None for record in records)

    def latest_record(self, record_type: str) -> dict[str, Any] | None:
        """Select a record by explicit chronology, never by input array order."""
        records = self.records_of_type(record_type)
        if not records:
            return None
        if len(records) == 1:
            return records[0]

        ranked = [(self._record_rank(record), stable_text(record), record) for record in records]
        explicit = [item for item in ranked if item[0] is not None]
        if explicit:
            return max(explicit, key=lambda item: (item[0], item[1]))[2]

        # Public data currently has one record per type. For a hidden duplicate,
        # choose a stable representative and surface ambiguity separately.
        return min(records, key=stable_text)

    def latest_record_value(self, record_type: str) -> Any:
        record = self.latest_record(record_type)
        return record.get("value") if record else None

    def duplicate_record_types(self) -> set[str]:
        return {kind for kind in self._records_by_type if self.record_is_ambiguous(kind)}

    def contains_for_object(self, object_id: str) -> set[str]:
        obj = self._objects_by_id.get(object_id)
        if not obj:
            return set()
        attrs = obj.get("attrs") or {}
        raw = attrs.get("contains")
        if raw is None:
            raw = attrs.get("fields")
        return {str(item) for item in raw} if isinstance(raw, list) else set()

    def object_type(self, object_id: str) -> str | None:
        obj = self._objects_by_id.get(object_id)
        return str(obj.get("type")) if obj else None

    def latest_clause(self) -> str:
        latest_index = max((self.prompt.rfind(marker) for marker in CLAUSE_BOUNDARY_MARKERS), default=-1)
        if latest_index < 0:
            latest_index = max((self.prompt.rfind(marker) for marker in LATEST_CLAUSE_MARKERS), default=-1)
        return self.prompt[latest_index:].strip() if latest_index >= 0 else ""

    def current_turn_history(self) -> tuple[dict[str, Any], ...]:
        return tuple(item for item in self._history if self._history_turn(item) == self.turn_index)

    def visible_history_text(self, *, current_turn_only: bool = False) -> str:
        items: Iterable[dict[str, Any]] = self.current_turn_history() if current_turn_only else self._history
        return " ".join(stable_text(item.get("summary", item)) for item in items)

    def personal_memory_entries(self) -> tuple[dict[str, Any], ...]:
        return self._memory

    @staticmethod
    def _history_turn(item: dict[str, Any]) -> int | None:
        try:
            return int(item.get("turn"))
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _record_rank(record: dict[str, Any]) -> tuple[int, str] | None:
        for key in ("turn_index", "turn", "timestamp", "updated_at", "created_at"):
            value = record.get(key)
            if value is None:
                continue
            try:
                return (int(value), "")
            except (TypeError, ValueError):
                return (0, str(value))
        return None

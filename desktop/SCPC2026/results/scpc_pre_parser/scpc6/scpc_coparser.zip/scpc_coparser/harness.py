from __future__ import annotations

from typing import Any

from core.evidence_graph import EvidenceGraph
from core.session_state import MemoryStore, update_session_state
from core.task_view import TaskView
from rules.action_profile import ActionProfileDecider
from rules.focal import FocalResolver
from rules.plan import PlanTemplateBuilder
from rules.response import ResponseBuilder
from rules.scope_policy import ScopePolicyJointBuilder
from rules.target import TargetResolver


class FinalHarness:
    """Deterministic SCPC answer engine with no filesystem side effects."""

    def __init__(self) -> None:
        self.memory_store = MemoryStore()

    def prepare(self, tasks: list[dict[str, Any]] | None = None) -> None:
        # The task list is intentionally ignored: a harness may not preview the
        # screening stream before normal session/turn execution.
        self.memory_store.clear()

    def answer_task(self, task: dict[str, Any], session: dict[str, Any]) -> dict[str, Any]:
        view = TaskView(task, session)
        self._remember(view)

        initial_evidence = EvidenceGraph.from_view(view)
        focal_decision = FocalResolver.resolve_decision(view, initial_evidence, session)
        evidence = EvidenceGraph.from_view(view, focal_decision.focal_id)

        target_candidates = TargetResolver.resolve_candidates(
            view,
            evidence,
            focal_decision.focal_id,
            self.memory_store,
        )
        provisional_target = target_candidates[0].target if target_candidates else "user"
        profile_decision = ActionProfileDecider.decide_with_trace(
            view,
            evidence,
            focal_decision.focal_id,
            provisional_target,
        )
        target_decision = TargetResolver.finalize(
            view,
            evidence,
            focal_decision.focal_id,
            profile_decision.profile,
            self.memory_store,
        )
        profile_decision = ActionProfileDecider.decide_with_trace(
            view,
            evidence,
            focal_decision.focal_id,
            target_decision.target,
        )

        content_scope, policy = ScopePolicyJointBuilder.build(
            view=view,
            evidence=evidence,
            profile=profile_decision.profile,
            focal_id=focal_decision.focal_id,
            target=target_decision.target,
        )
        plan_events = PlanTemplateBuilder.build(
            view=view,
            evidence=evidence,
            profile=profile_decision.profile,
            focal_id=focal_decision.focal_id,
            target=target_decision.target,
            content_scope=content_scope,
            policy=policy,
        )
        user_response, audit_tags, counterfactual = ResponseBuilder.build(
            profile_decision,
            target_decision.target,
            content_scope,
            policy,
        )

        answer = {
            "focal_id": focal_decision.focal_id,
            "target": target_decision.target,
            "control": profile_decision.control,
            "content_scope": content_scope,
            "policy": policy,
            "plan_events": plan_events,
            "user_response": user_response,
            "audit_tags": audit_tags,
            "counterfactual": counterfactual,
            "_trace": {
                "task_id": view.task_id,
                "focal": focal_decision.to_trace(),
                "target": target_decision.to_trace(),
                "profile": profile_decision.to_trace(),
                "evidence": evidence.to_trace(),
                "scope_mode": content_scope["mode"],
            },
        }
        update_session_state(session, answer)
        return answer

    def _remember(self, view: TaskView) -> None:
        for value in view.record_values("persistent_memory_write"):
            if isinstance(value, dict):
                self.memory_store.write(
                    value,
                    task_id=view.task_id,
                    session_id=view.session_id,
                    turn_index=view.turn_index,
                )

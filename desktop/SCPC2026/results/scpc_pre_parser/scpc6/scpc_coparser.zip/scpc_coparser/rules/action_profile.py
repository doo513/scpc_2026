from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from core.action_profile import ActionProfile
from core.evidence_graph import ASK_PHRASES, HOLD_PHRASES, EvidenceGraph, has_local_update_intent
from core.task_view import TaskView


@dataclass(frozen=True)
class ProfileDecision:
    profile: ActionProfile
    decisive_gate: str
    reasons: tuple[str, ...]
    competing_evidence: tuple[str, ...] = ()

    @property
    def control(self) -> str:
        return control_from_profile(self.profile)

    def to_trace(self) -> dict[str, Any]:
        return {
            "profile": self.profile.value,
            "control": self.control,
            "decisive_gate": self.decisive_gate,
            "reasons": list(self.reasons),
            "competing_evidence": list(self.competing_evidence),
        }


class ActionProfileDecider:
    @staticmethod
    def pre_decide(view: TaskView, evidence: EvidenceGraph) -> ActionProfile:
        return ActionProfileDecider.decide_with_trace(view, evidence, "", "").profile

    @staticmethod
    def decide(
        view: TaskView,
        evidence: EvidenceGraph,
        focal_id: str,
        target: str,
    ) -> ActionProfile:
        return ActionProfileDecider.decide_with_trace(view, evidence, focal_id, target).profile

    @staticmethod
    def decide_with_trace(
        view: TaskView,
        evidence: EvidenceGraph,
        focal_id: str,
        target: str,
    ) -> ProfileDecision:
        focal = view.objects_by_id().get(focal_id) if focal_id else {}
        control, gate, reasons = ActionProfileDecider._decide_control(view, evidence, focal)

        if control == "hold":
            profile = ActionProfile.HARD_BLOCK
        elif control == "ask":
            if view.latest_record_value("memory_conflict"):
                profile = ActionProfile.MEMORY_CONFLICT_RESOLUTION
            elif view.latest_record_value("target_changed_after_turn") or view.latest_record_value("ambiguous_target"):
                profile = ActionProfile.TARGET_REBIND_REQUIRED
            elif view.latest_record_value("ambiguous_focal"):
                profile = ActionProfile.FALLBACK_CLARIFICATION
            else:
                profile = ActionProfile.EXPLICIT_CLARIFICATION
        elif control == "amend":
            profile = ActionProfile.EXTERNAL_REDACTED_DISPATCH
        elif ActionProfileDecider._is_local_update(view) or (
            control == "proceed" and evidence.route.is_local_boundary
        ):
            profile = ActionProfile.LOCAL_STATUS_UPDATE
        elif ActionProfileDecider._raw_allowed(view, focal, target):
            profile = ActionProfile.SAFE_DISPATCH_RAW
        else:
            profile = ActionProfile.SAFE_DISPATCH_SUMMARY

        competing = tuple(
            dict.fromkeys(
                evidence.hard_block
                + evidence.explicit_clarification
                + evidence.local_update
                + evidence.unresolved_ambiguity
                + evidence.external_share
            )
        )
        return ProfileDecision(profile, gate, tuple(reasons), competing)

    @staticmethod
    def _decide_control(
        view: TaskView,
        evidence: EvidenceGraph,
        focal: dict[str, Any],
    ) -> tuple[str, str, list[str]]:
        values_l = " ".join(f"{r.get('type')} {r.get('value')}" for r in view.records).lower()

        if ActionProfileDecider._explicit_hold(view, values_l):
            return "hold", "applicable_hard_block", evidence.hard_block or ["explicit_hold"]
        if ActionProfileDecider._is_local_update(view):
            return "proceed", "latest_local_or_memory_write", evidence.local_update or ["local_update"]
        if ActionProfileDecider._explicit_ask(view):
            return "ask", "explicit_clarification", evidence.explicit_clarification or ["explicit_ask"]

        domain_control, domain_reason = ActionProfileDecider._memory_or_domain_control(view, focal)
        if domain_control:
            return domain_control, "memory_or_domain_constraint", [domain_reason]

        boundary_control, boundary_reason = ActionProfileDecider._control_from_boundary(view)
        if boundary_control:
            return boundary_control, "route_bundle", [boundary_reason]

        if ActionProfileDecider._unresolved_ambiguity(view):
            return "ask", "unresolved_route", ["unresolved_target_or_focal"]
        if ActionProfileDecider._external_redactable(view):
            return "amend", "external_disclosure_constraint", ["redaction_required"]
        return "proceed", "authorized_dispatch", ["no_blocking_evidence"]

    @staticmethod
    def _is_local_update(view: TaskView) -> bool:
        if view.latest_record_value("persistent_memory_write"):
            return True
        return has_local_update_intent(view.prompt)

    @staticmethod
    def _explicit_hold(view: TaskView, values_l: str) -> bool:
        local_update = ActionProfileDecider._is_local_update(view)
        latest_local_override = local_update and any(
            word in view.prompt.lower()
            for word in ("최신 표현을 우선", "우선한다", "취소하고", "정정한 대로", "가장 최신이다")
        )
        consent = view.latest_record_value("consent")
        status = str(consent.get("status") if isinstance(consent, dict) else consent or "")
        if status in {"revoked", "withdrawn", "denied"} and not latest_local_override:
            return True
        if view.latest_record_value("security_alert") and not local_update:
            return True
        if view.latest_record_value("safety_mode"):
            return True
        if any(phrase in view.prompt for phrase in HOLD_PHRASES):
            return True
        if "phishing" in values_l or "피싱" in values_l:
            return True
        return False

    @staticmethod
    def _explicit_ask(view: TaskView) -> bool:
        if any(view.latest_record_value(kind) for kind in ("payment_policy", "memory_conflict", "duration_ambiguous", "calendar_conflict")):
            return True
        if view.latest_record_value("target_changed_after_turn"):
            return True
        return not ActionProfileDecider._is_local_update(view) and any(
            phrase in view.prompt for phrase in ASK_PHRASES
        )

    @staticmethod
    def _control_from_boundary(view: TaskView) -> tuple[str, str]:
        boundary = str(view.latest_record_value("share_boundary_update") or "")
        ambiguous = str(view.latest_record_value("ambiguous_target") or "")
        authority = str(view.latest_record_value("dispatch_authority_check") or "")
        amend_phrases = ("식별 가능한 세부값을 제외", "세부값을 제외", "요약만 공유", "민감 내용은 알아서 처리", "위치나 나이 같은 민감")

        if boundary == "dispatch_blocked_until_binding":
            if any(phrase in view.prompt for phrase in amend_phrases):
                return "amend", "blocked_route_with_explicit_redaction"
            if view.latest_record_value("guardrail_ladder_signal"):
                return "hold", "blocked_route_guardrail"
            if view.latest_record_value("ambiguous_focal") and authority == "user_binding_pending":
                return "hold", "blocked_route_ambiguous_focal"
            return "", ""
        if boundary == "local_update_boundary":
            if view.latest_record_value("ambiguous_focal"):
                return "proceed", "local_boundary_focal_resolved"
            if ambiguous == "stored_channel_or_visible_recipient":
                return "amend", "local_boundary_stored_channel_conflict"
            if ambiguous == "approved_channel_or_visible_recipient":
                return "ask", "local_boundary_approval_ambiguity"
            if ambiguous == "surface_recipient_and_resolved_target_both_recent":
                return "amend", "local_boundary_recent_target_conflict"
        if boundary in {"redacted_external_boundary", "redacted_after_selection_boundary"}:
            if ambiguous == "surface_recipient_and_resolved_target_both_recent":
                return "ask", "external_boundary_recent_target_conflict"
            if ambiguous == "stored_channel_or_visible_recipient" and ("검진" in view.prompt or "점검" in view.prompt):
                return "ask", "external_boundary_memory_target_conflict"
            if view.latest_record_value("guardrail_ladder_signal") and authority == "internal_binding_confirmed":
                return "proceed", "verified_guardrail_fast_path"
            return "amend", "redacted_external_boundary"
        return "", ""

    @staticmethod
    def _memory_or_domain_control(view: TaskView, focal: dict[str, Any]) -> tuple[str, str]:
        if view.latest_record_value("enterprise_policy_recall"):
            return "amend", "enterprise_policy_recall"
        if view.latest_record_value("ops_memory_recall"):
            return ("ask", "ops_memory_target_changed") if view.latest_record_value("target_changed_after_turn") else ("amend", "ops_memory_recall")
        if view.latest_record_value("temporary_override_allowed"):
            return "amend", "temporary_override"
        if view.latest_record_value("persistent_memory_recall") and "쿠폰" in view.prompt and not view.latest_record_value("payment_policy"):
            return "hold", "stale_coupon_memory"
        if focal.get("type") == "health_record" and view.latest_record_value("external_share_policy") == "doctor_note_forbidden":
            return "hold", "health_external_share_blocked"
        if view.latest_record_value("ambiguous_focal") and view.latest_record_value("session_share_policy") == "normal":
            return "ask", "ambiguous_focal_normal_policy"
        return "", ""

    @staticmethod
    def _unresolved_ambiguity(view: TaskView) -> bool:
        if not (view.latest_record_value("ambiguous_target") or view.latest_record_value("ambiguous_focal")):
            return False
        boundary = str(view.latest_record_value("share_boundary_update") or "")
        authority = str(view.latest_record_value("dispatch_authority_check") or "")
        candidates = str(view.latest_record_value("route_candidate_snapshot") or "")
        if boundary == "local_update_boundary":
            return False
        if authority in {"authority_incomplete", "user_binding_pending"} and boundary == "dispatch_blocked_until_binding":
            return True
        return candidates == "external_candidates_present" and authority != "internal_binding_confirmed" and not boundary.startswith("redacted")

    @staticmethod
    def _external_redactable(view: TaskView) -> bool:
        amend_phrases = ("식별 가능한 세부값을 제외", "세부값을 제외", "요약만 공유", "민감 내용은 알아서 처리", "위치나 나이 같은 민감")
        if any(phrase in view.prompt for phrase in amend_phrases):
            return True
        if view.latest_record_value("external_share_policy"):
            return True
        if str(view.latest_record_value("share_boundary_update") or "") in {"redacted_external_boundary", "redacted_after_selection_boundary"}:
            return True
        if view.latest_record_value("ambiguous_target") and view.latest_record_value("resolved_target"):
            return True
        return view.latest_record_value("session_share_policy") == "strict" and bool(view.latest_record_value("resolved_target"))

    @staticmethod
    def _raw_allowed(view: TaskView, focal: dict[str, Any], target: str) -> bool:
        if (
            view.latest_record_value("guardrail_ladder_signal")
            and view.latest_record_value("share_boundary_update") == "redacted_external_boundary"
            and view.latest_record_value("dispatch_authority_check") == "internal_binding_confirmed"
        ):
            return True
        if view.latest_record_value("session_share_policy") != "normal":
            return False
        if view.latest_record_value("external_share_policy"):
            return False
        if view.latest_record_value("ambiguous_target") or view.latest_record_value("ambiguous_focal"):
            return False
        return target in {"project_room", "privacy_review"} and "회의 시간" in view.prompt


def control_from_profile(profile: ActionProfile) -> str:
    return {
        ActionProfile.HARD_BLOCK: "hold",
        ActionProfile.EXPLICIT_CLARIFICATION: "ask",
        ActionProfile.LOCAL_STATUS_UPDATE: "proceed",
        ActionProfile.TARGET_REBIND_REQUIRED: "ask",
        ActionProfile.MEMORY_CONFLICT_RESOLUTION: "ask",
        ActionProfile.EXTERNAL_REDACTED_DISPATCH: "amend",
        ActionProfile.SAFE_DISPATCH_SUMMARY: "proceed",
        ActionProfile.SAFE_DISPATCH_RAW: "proceed",
        ActionProfile.FALLBACK_CLARIFICATION: "ask",
    }.get(profile, "ask")

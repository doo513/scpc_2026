from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Any

from core.task_view import TaskView, stable_text


DIRECT_REF_PATTERNS = (
    re.compile(r"기준 참조는 (WM-\d+)"),
    re.compile(r"기준 참조(?: 코드)?는 (WM-\d+)"),
    re.compile(r"처리 대상으로 확정된 .*?참조 코드는 (WM-\d+)"),
    re.compile(r"최종 승인 후보 (WM-\d+)"),
    re.compile(r"승인 표시가 남은 것은 (WM-\d+)"),
    re.compile(r"유효한 항목은 .*?(WM-\d+)"),
    re.compile(r"실제 처리할 ref는 .*?(WM-\d+)"),
)


@dataclass(frozen=True)
class FocalDecision:
    focal_id: str
    source: str
    confidence: str
    candidates: tuple[str, ...]
    reasons: tuple[str, ...]

    def to_trace(self) -> dict[str, Any]:
        return {
            "focal_id": self.focal_id,
            "source": self.source,
            "confidence": self.confidence,
            "candidates": list(self.candidates),
            "reasons": list(self.reasons),
        }


class FocalResolver:
    @staticmethod
    def resolve(view: TaskView, evidence: Any, session: dict[str, Any]) -> str:
        return FocalResolver.resolve_decision(view, evidence, session).focal_id

    @staticmethod
    def resolve_decision(view: TaskView, evidence: Any, session: dict[str, Any]) -> FocalDecision:
        if not view.objects:
            return FocalDecision("", "empty", "none", (), ("no_objects",))

        steps = (
            ("marker_trace", "high", FocalResolver._from_marker_trace),
            ("direct_record", "high", FocalResolver._from_direct_record_value),
            ("strong_history", "medium", FocalResolver._from_history_ref),
        )
        for source, confidence, resolver in steps:
            obj = resolver(view)
            if obj:
                focal_id = str(obj.get("id") or "")
                return FocalDecision(
                    focal_id,
                    source,
                    confidence,
                    (focal_id,),
                    (f"selected_by:{source}",),
                )

        last_id = str(session.get("last_focal_id") or "")
        fallback, candidates = FocalResolver._fallback_object(view)
        if fallback:
            top_ids = tuple(sorted(str(obj.get("id") or "") for obj in candidates))
            if len(top_ids) == 1:
                return FocalDecision(top_ids[0], "semantic_fallback", "low", top_ids, ("semantic_candidate",))
            if last_id in top_ids:
                return FocalDecision(last_id, "same_session", "low", top_ids, ("semantic_tie", "same_session_match"))
            selected = min(top_ids)
            return FocalDecision(selected, "stable_tie_break", "low", top_ids, ("semantic_tie",))

        if last_id and last_id in view.objects_by_id():
            return FocalDecision(last_id, "same_session", "low", (last_id,), ("session_fallback",))
        return FocalDecision("", "unresolved", "none", (), ("no_focal_candidate",))

    @staticmethod
    def _from_marker_trace(view: TaskView) -> dict[str, Any] | None:
        marker_refs = view.latest_record_value("focal_marker_refs")
        trace = view.latest_record_value("focal_resolution_trace")
        if not isinstance(marker_refs, dict) or not isinstance(trace, dict):
            return None
        marker_to_ref = marker_refs.get("marker_to_ref")
        phase_to_marker = trace.get("phase_to_marker")
        if not isinstance(marker_to_ref, dict) or not isinstance(phase_to_marker, dict):
            return None

        phase = str(trace.get("latest_phase") or "")
        if not phase and trace.get("phase_source") == "route_binding_order":
            order = view.latest_record_value("route_binding_order")
            rule = trace.get("latest_phase_rule") or {}
            phase = str(rule.get(order) or rule.get("fallback") or "")
        marker = str(phase_to_marker.get(phase) or "")
        ref_code = str(marker_to_ref.get(marker) or "")
        return view.objects_by_ref_code().get(ref_code)

    @staticmethod
    def _from_history_ref(view: TaskView) -> dict[str, Any] | None:
        current = view.current_turn_history() or view.history
        items = sorted(current, key=lambda item: (int(item.get("turn", -1)), stable_text(item)), reverse=True)
        for item in items:
            summary = str(item.get("summary", item) or "")
            for pattern in DIRECT_REF_PATTERNS:
                match = pattern.search(summary)
                if match and match.group(1) in view.objects_by_ref_code():
                    return view.objects_by_ref_code()[match.group(1)]
            refs = re.findall(r"WM-\d+", summary)
            if len(refs) >= 2 and any(phrase in summary for phrase in ("가운데 항목만", "두 번째 후보", "두 번째다", "두 번째")):
                return view.objects_by_ref_code().get(refs[1])
        return None

    @staticmethod
    def _from_direct_record_value(view: TaskView) -> dict[str, Any] | None:
        candidates: dict[str, dict[str, Any]] = {}
        records = sorted(view.records, key=lambda record: (str(record.get("type") or ""), stable_text(record)))
        for record in records:
            for value in FocalResolver._walk(record.get("value")):
                if not isinstance(value, str):
                    continue
                obj = view.objects_by_id().get(value) or view.objects_by_ref_code().get(value)
                if obj and obj.get("id"):
                    candidates[str(obj["id"])] = obj
        if len(candidates) == 1:
            return next(iter(candidates.values()))
        return None

    @staticmethod
    def _walk(value: Any) -> list[Any]:
        if isinstance(value, dict):
            out: list[Any] = []
            for key in sorted(value):
                out.extend(FocalResolver._walk(value[key]))
            return out
        if isinstance(value, list):
            out: list[Any] = []
            for child in value:
                out.extend(FocalResolver._walk(child))
            return out
        return [value]

    @staticmethod
    def _fallback_object(view: TaskView) -> tuple[dict[str, Any] | None, list[dict[str, Any]]]:
        prompt = view.prompt.lower()
        resolved_target = view.latest_record_value("resolved_target")
        scored: list[tuple[int, dict[str, Any]]] = []
        for obj in view.objects:
            attrs = obj.get("attrs") or {}
            blob = json.dumps(obj, ensure_ascii=False, sort_keys=True).lower()
            score = 0
            if "원본" in prompt and "원본" in blob:
                score += 4
            if "사진" in prompt and obj.get("type") == "gallery_item":
                score += 2
            if "건강" in prompt and obj.get("type") == "health_record":
                score += 4
            if "설정" in prompt and obj.get("type") == "device_setting":
                score += 4
            if "메모리" in prompt and obj.get("type") == "personal_note":
                score += 3
            if attrs.get("recipient") == resolved_target:
                score += 2
            scored.append((score, obj))
        if not scored:
            return None, []
        best_score = max(score for score, _ in scored)
        candidates = [obj for score, obj in scored if score == best_score]
        selected = min(candidates, key=lambda obj: str(obj.get("id") or ""))
        return selected, candidates

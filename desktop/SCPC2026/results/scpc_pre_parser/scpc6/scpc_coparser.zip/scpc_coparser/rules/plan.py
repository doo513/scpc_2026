from __future__ import annotations

from typing import Any

from core.action_profile import ActionProfile
from core.spec import PLAN_PURPOSES, PLAN_REASONS, PLAN_SCOPES, PLAN_VERBS


def normalize_event(event: dict[str, Any]) -> dict[str, Any]:
    verb = str(event.get("verb") or "")
    target = str(event.get("target") or "")
    args = event.get("args") or {}
    if verb not in PLAN_VERBS:
        raise ValueError(f"unknown plan event verb: {verb}")
    if not target:
        raise ValueError(f"empty target for plan event: {verb}")
    if not isinstance(args, dict):
        raise ValueError(f"plan event args must be an object: {verb}")

    allowed_keys = {
        "purpose",
        "reason",
        "scope",
        "state",
        "remove",
        "mode",
        "status",
        "duration",
        "person",
        "check",
        "condition",
        "lesson",
        "time",
        "rule",
        "method",
        "date",
        "principle",
    }
    unknown_keys = set(args) - allowed_keys
    if unknown_keys:
        raise ValueError(f"unknown plan argument keys: {sorted(unknown_keys)}")
    if "purpose" in args and args["purpose"] not in PLAN_PURPOSES:
        raise ValueError(f"unknown purpose: {args['purpose']}")
    if "reason" in args and args["reason"] not in PLAN_REASONS:
        raise ValueError(f"unknown reason: {args['reason']}")
    if "scope" in args and args["scope"] not in PLAN_SCOPES:
        raise ValueError(f"unknown scope: {args['scope']}")
    return {"verb": verb, "target": target, "args": dict(args)}


class PlanTemplateBuilder:
    @staticmethod
    def build(
        view: Any,
        evidence: Any,
        profile: ActionProfile,
        focal_id: str,
        target: str,
        content_scope: dict[str, Any],
        policy: dict[str, Any],
    ) -> list[dict[str, Any]]:
        focal_id = str(focal_id or "")

        if profile == ActionProfile.HARD_BLOCK:
            template = [
                {"verb": "read", "target": focal_id, "args": {"purpose": "invalidated_precondition"}},
                {"verb": "guard", "target": focal_id, "args": {"reason": "precondition_invalidated"}},
            ]
        elif profile in {
            ActionProfile.EXPLICIT_CLARIFICATION,
            ActionProfile.TARGET_REBIND_REQUIRED,
            ActionProfile.MEMORY_CONFLICT_RESOLUTION,
            ActionProfile.FALLBACK_CLARIFICATION,
        }:
            precondition = PlanTemplateBuilder._clarify_precondition(view)
            template = [
                {
                    "verb": "read",
                    "target": focal_id,
                    "args": {"purpose": "clarify_precondition" if precondition else "route_resolution_required"},
                },
                {
                    "verb": "clarify",
                    "target": "user",
                    "args": {"reason": "precondition_changed" if precondition else "route_resolution_required"},
                },
            ]
        elif profile == ActionProfile.LOCAL_STATUS_UPDATE:
            template = [
                {"verb": "read", "target": focal_id, "args": {"purpose": "local_update"}},
                {"verb": "verify", "target": "share_boundary_update", "args": {"scope": "local_update"}},
                {"verb": "update", "target": focal_id, "args": {"state": "local_status_only"}},
            ]
        elif profile == ActionProfile.EXTERNAL_REDACTED_DISPATCH:
            remove = "sensitive_fields" if PlanTemplateBuilder._remove_sensitive_fields(content_scope) else "raw_quote"
            template = [
                {"verb": "read", "target": focal_id, "args": {"purpose": "minimal_disclosure"}},
                {"verb": "redact", "target": focal_id, "args": {"remove": remove}},
                {"verb": "dispatch", "target": target, "args": {"scope": "redacted"}},
            ]
        elif profile == ActionProfile.SAFE_DISPATCH_SUMMARY:
            template = [
                {"verb": "read", "target": focal_id, "args": {"purpose": "inspect_context"}},
                {"verb": "summarize", "target": focal_id, "args": {"mode": "summary"}},
                {"verb": "dispatch", "target": target, "args": {"scope": "summary"}},
            ]
        else:
            template = [
                {"verb": "read", "target": focal_id, "args": {"purpose": "inspect_context"}},
                {"verb": "dispatch", "target": target, "args": {"scope": "raw"}},
            ]

        events = [normalize_event(event) for event in template]
        if len(events) > 18:
            raise ValueError("plan event count exceeds schema maximum")
        unavailable = [event["verb"] for event in events if event["verb"] not in view.available_actions]
        if unavailable:
            raise ValueError(f"plan uses unavailable actions for {view.task_id}: {unavailable}")
        return events

    @staticmethod
    def _clarify_precondition(view: Any) -> bool:
        return any(
            phrase in view.prompt
            for phrase in ("새 전제", "조건 변경", "다시 확인", "누구에게 어떤 범위")
        )

    @staticmethod
    def _remove_sensitive_fields(scope: dict[str, Any]) -> bool:
        return bool(
            set(scope.get("excluded_fields") or [])
            & {"name", "rrn", "numeric_value", "doctor_note", "location", "amount", "card_number"}
        )

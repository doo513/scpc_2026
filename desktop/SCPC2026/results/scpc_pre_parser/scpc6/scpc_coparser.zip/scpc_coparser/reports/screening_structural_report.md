# Screening Structural Report for submission.csv

## Control Distribution
- `amend`: 211
- `ask`: 163
- `hold`: 93
- `proceed`: 233

## Scope Mode Distribution
- `none`: 94
- `raw`: 17
- `redacted`: 218
- `status_only`: 194
- `summary`: 177

## Target Top 30
- `memory_store`: 156
- `privacy_review`: 134
- `project_room`: 97
- `legal_review`: 70
- `user`: 59
- `vendor_alpha`: 50
- `family_room`: 46
- `audit_vendor`: 40
- `clinic_portal`: 18
- `caregiver`: 14
- `fitness_coach`: 7
- `GalaxyStore`: 2
- `notification_preview`: 1
- `gallery_permission`: 1
- `living_room`: 1
- `bedroom`: 1
- `entryway`: 1
- `security_review`: 1
- `child_room`: 1

## Policy Requires Confirmation Distribution
- `True`: 372
- `False`: 328

## Plan Sequence Distribution
- `[read -> redact -> dispatch]`: 211
- `[read -> verify -> update]`: 194
- `[read -> clarify]`: 163
- `[read -> guard]`: 93
- `[read -> summarize -> dispatch]`: 22
- `[read -> dispatch]`: 17

## Diagnostics (not scoring priors)
- **total excluded fields**: 1254
- **focal marker trace match count**: 463 / 463
- **memory_store count**: 156
- **status_only count**: 194
- **redacted count**: 218
- **proceed count**: 233

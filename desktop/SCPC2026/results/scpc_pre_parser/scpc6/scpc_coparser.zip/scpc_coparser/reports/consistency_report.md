# Consistency Report

- Hard errors: 0
- Warnings: 0

## Structural Statistics
- control.amend: 211
- control.ask: 163
- control.hold: 93
- control.proceed: 233
- scope.none: 94
- scope.raw: 17
- scope.redacted: 218
- scope.status_only: 194
- scope.summary: 177

## Errors
- None

## Warnings
- None

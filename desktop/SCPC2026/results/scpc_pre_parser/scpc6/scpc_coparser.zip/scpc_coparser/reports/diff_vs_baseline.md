# Comparison: submission.csv vs submission.csv

## Changed Counts
- **focal changed count**: 135
- **target changed count**: 107
- **control changed count**: 85
- **scope mode changed count**: 92
- **policy confirmation changed count**: 9
- **plan sequence changed count**: 207

## Major Transitions (Control)
- `amend -> proceed`: 44
- `ask -> proceed`: 21
- `hold -> proceed`: 19
- `amend -> ask`: 1

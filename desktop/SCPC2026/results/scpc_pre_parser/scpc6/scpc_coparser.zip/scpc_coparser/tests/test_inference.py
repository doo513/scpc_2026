from __future__ import annotations

import pytest

from core.session_state import MemoryStore
from core.task_view import TaskView
from rules.plan import PlanTemplateBuilder


def test_memory_store_uses_key_and_person_provenance() -> None:
    store = MemoryStore()
    store.write(
        {"memory_key": "shared", "person": "alpha", "preferred_channel": "room_a"},
        task_id="a",
        session_id="s1",
        turn_index=1,
    )
    store.write(
        {"memory_key": "shared", "person": "beta", "preferred_channel": "room_b"},
        task_id="b",
        session_id="s2",
        turn_index=1,
    )
    assert store.recall({"memory_key": "shared", "person": "alpha"}).value["preferred_channel"] == "room_a"
    assert store.recall({"memory_key": "shared", "person": "beta"}).value["preferred_channel"] == "room_b"


def test_plan_rejects_unavailable_action() -> None:
    task = {
        "id": "task",
        "session_id": "session",
        "turn_index": 1,
        "prompt": "",
        "visible_history": [],
        "personal_memory": [],
        "available_actions": ["read"],
        "device_state": {"objects": [{"id": "obj", "type": "file", "attrs": {}}], "records": []},
    }
    view = TaskView(task)
    from core.action_profile import ActionProfile

    with pytest.raises(ValueError, match="unavailable"):
        PlanTemplateBuilder.build(
            view,
            None,
            ActionProfile.SAFE_DISPATCH_RAW,
            "obj",
            "user",
            {"mode": "raw", "excluded_fields": []},
            {},
        )

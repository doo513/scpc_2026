# Screening Structural Report for submission.csv

## Control Distribution
- `amend`: 177
- `ask`: 186
- `hold`: 130
- `proceed`: 207

## Scope Mode Distribution
- `none`: 131
- `raw`: 9
- `redacted`: 230
- `status_only`: 189
- `summary`: 141

## Target Top 30
- `user`: 158
- `memory_store`: 157
- `privacy_review`: 106
- `project_room`: 80
- `legal_review`: 58
- `family_room`: 36
- `vendor_alpha`: 36
- `audit_vendor`: 34
- `clinic_portal`: 12
- `caregiver`: 9
- `fitness_coach`: 5
- `entryway`: 2
- `GalaxyStore`: 2
- `notification_preview`: 1
- `gallery_permission`: 1
- `bedroom`: 1
- `security_review`: 1
- `child_room`: 1

## Policy Requires Confirmation Distribution
- `True`: 273
- `False`: 427

## Plan Sequence Distribution
- `[read -> clarify]`: 186
- `[read -> verify -> update]`: 186
- `[read -> redact -> dispatch]`: 177
- `[read -> guard]`: 130
- `[read -> dispatch]`: 9
- `[read -> summarize -> dispatch]`: 9
- `[read -> verify -> toggle]`: 2
- `[read -> verify -> pay]`: 1

## Diagnostics (not scoring priors)
- Screening labels are unavailable; focal counts below are coverage/integrity, not accuracy.
- **total excluded fields**: 1130
- **structurally resolved focal count**: 700 / 700
- **submission/structural focal agreement**: 700 / 700
- **focal method `history_binding`**: 237
- **focal method `marker_trace`**: 463
- **memory_store count**: 157
- **status_only count**: 189
- **redacted count**: 230
- **proceed count**: 207

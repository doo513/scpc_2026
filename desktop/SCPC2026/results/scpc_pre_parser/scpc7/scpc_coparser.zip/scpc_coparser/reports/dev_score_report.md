# SCPC Dev Score Report

- Overall: `0.9421`
- Supported-dev overall: `0.9586`
- Pre-registered missing-memory cases: 3
- Tasks: 120
- Non-exact tasks: 10

## Axes

| Axis | Score | Weight |
| --- | ---: | ---: |
| focal | 1.0000 | 0.18 |
| target | 0.9750 | 0.12 |
| control | 0.9917 | 0.18 |
| content_scope | 0.9750 | 0.17 |
| policy | 0.9643 | 0.13 |
| plan | 0.9750 | 0.18 |
| semantic_response | 0.0000 | 0.04 |
| counterfactual | 0.0000 | 0.00 |

## Control Confusion
- amend->amend: 27
- amend->ask: 1
- ask->ask: 26
- hold->hold: 20
- proceed->proceed: 46

## Scope Mode Confusion
- none->none: 22
- raw->raw: 4
- redacted->redacted: 36
- status_only->status_only: 40
- summary->summary: 18

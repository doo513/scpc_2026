# Consistency Report

- Hard errors: 0
- Warnings: 0

## Structural Statistics
- control.amend: 177
- control.ask: 186
- control.hold: 130
- control.proceed: 207
- scope.none: 131
- scope.raw: 9
- scope.redacted: 230
- scope.status_only: 189
- scope.summary: 141

## Errors
- None

## Warnings
- None

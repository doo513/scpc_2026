from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from core.action_profile import ActionProfile
from core.decision import DecisionMatrix, DomainAction
from core.evidence_graph import EvidenceGraph
from core.task_view import TaskView


@dataclass(frozen=True)
class ProfileDecision:
    profile: ActionProfile
    decisive_gate: str
    reasons: tuple[str, ...]
    competing_evidence: tuple[str, ...] = ()
    selected_candidate_id: str = ""
    selected_domain_action: str = ""
    active_constraints: tuple[str, ...] = ()

    @property
    def control(self) -> str:
        return control_from_profile(self.profile)

    def to_trace(self) -> dict[str, Any]:
        return {
            "profile": self.profile.value,
            "control": self.control,
            "decisive_gate": self.decisive_gate,
            "reasons": list(self.reasons),
            "competing_evidence": list(self.competing_evidence),
            "selected_candidate_id": self.selected_candidate_id,
            "selected_domain_action": self.selected_domain_action,
            "active_constraints": list(self.active_constraints),
        }


class ActionProfileDecider:
    @staticmethod
    def decide(
        view: TaskView,
        evidence: EvidenceGraph,
        focal_id: str,
        target: str,
        decision_matrix: DecisionMatrix,
    ) -> ActionProfile:
        return ActionProfileDecider.decide_with_trace(
            view, evidence, focal_id, target, decision_matrix
        ).profile

    @staticmethod
    def decide_with_trace(
        view: TaskView,
        evidence: EvidenceGraph,
        focal_id: str,
        target: str,
        decision_matrix: DecisionMatrix,
    ) -> ProfileDecision:
        focal = view.objects_by_id().get(focal_id) if focal_id else {}
        control, gate, reasons = ActionProfileDecider._decide_control(
            view, evidence, focal, decision_matrix
        )
        selected = decision_matrix.selected
        constraint_kinds = {
            constraint.kind for constraint in selected.active_constraints
        }

        if control == "hold":
            profile = ActionProfile.HARD_BLOCK
        elif control == "ask":
            if "memory_conflict" in constraint_kinds:
                profile = ActionProfile.MEMORY_CONFLICT_RESOLUTION
            elif constraint_kinds & {
                "target_changed",
                "local_boundary_approval_ambiguity",
                "external_boundary_recent_target_conflict",
                "external_boundary_memory_target_conflict",
                "resolved_target_conflict",
                "unresolved_route",
                "unresolved_ambiguity",
            }:
                profile = ActionProfile.TARGET_REBIND_REQUIRED
            elif "ambiguous_focal" in constraint_kinds:
                profile = ActionProfile.FALLBACK_CLARIFICATION
            else:
                profile = ActionProfile.EXPLICIT_CLARIFICATION
        elif control == "amend":
            profile = ActionProfile.EXTERNAL_REDACTED_DISPATCH
        elif (
            decision_matrix
            and decision_matrix.selected.candidate.action_candidate.action
            in {DomainAction.PAY, DomainAction.TOGGLE, DomainAction.SCHEDULE}
        ):
            profile = ActionProfile.DOMAIN_EXECUTION
        elif decision_matrix.selected.candidate.action_candidate.action in {
            DomainAction.LOCAL_UPDATE,
            DomainAction.MEMORY_UPDATE,
        } or (control == "proceed" and evidence.route.is_local_boundary):
            profile = ActionProfile.LOCAL_STATUS_UPDATE
        elif ActionProfileDecider._raw_allowed(view, focal, target):
            profile = ActionProfile.SAFE_DISPATCH_RAW
        else:
            profile = ActionProfile.SAFE_DISPATCH_SUMMARY

        competing = tuple(
            dict.fromkeys(
                evidence.hard_block
                + evidence.explicit_clarification
                + evidence.local_update
                + evidence.unresolved_ambiguity
                + evidence.external_share
            )
        )
        return ProfileDecision(
            profile,
            gate,
            tuple(reasons),
            competing,
            selected.candidate.candidate_id,
            selected.candidate.action_candidate.action.value,
            tuple(constraint.kind for constraint in selected.active_constraints),
        )

    @staticmethod
    def _decide_control(
        view: TaskView,
        evidence: EvidenceGraph,
        focal: dict[str, Any],
        decision_matrix: DecisionMatrix,
    ) -> tuple[str, str, list[str]]:
        selected = decision_matrix.selected
        reasons = [constraint.kind for constraint in selected.active_constraints]
        reasons.extend(
            f"slot:{slot.name}:{slot.status.value}"
            for slot in selected.required_slots
            if slot.status.value in {"missing", "conflict"}
        )
        if selected.capability_status.value == "unavailable":
            reasons.append("capability_unavailable")
        return selected.control, "action_target_candidate", reasons or [selected.disposition.value]

    @staticmethod
    def _raw_allowed(view: TaskView, focal: dict[str, Any], target: str) -> bool:
        if (
            view.latest_record_value("guardrail_ladder_signal")
            and view.latest_record_value("share_boundary_update") == "redacted_external_boundary"
            and view.latest_record_value("dispatch_authority_check") == "internal_binding_confirmed"
        ):
            return True
        if view.latest_record_value("session_share_policy") != "normal":
            return False
        if view.latest_record_value("external_share_policy"):
            return False
        if view.latest_record_value("ambiguous_target") or view.latest_record_value("ambiguous_focal"):
            return False
        attrs = focal.get("attrs") or {}
        return (
            focal.get("type") == "message"
            and str(attrs.get("recipient") or "") == target
            and not attrs.get("contains")
        )


def control_from_profile(profile: ActionProfile) -> str:
    return {
        ActionProfile.HARD_BLOCK: "hold",
        ActionProfile.EXPLICIT_CLARIFICATION: "ask",
        ActionProfile.LOCAL_STATUS_UPDATE: "proceed",
        ActionProfile.TARGET_REBIND_REQUIRED: "ask",
        ActionProfile.MEMORY_CONFLICT_RESOLUTION: "ask",
        ActionProfile.EXTERNAL_REDACTED_DISPATCH: "amend",
        ActionProfile.SAFE_DISPATCH_SUMMARY: "proceed",
        ActionProfile.SAFE_DISPATCH_RAW: "proceed",
        ActionProfile.DOMAIN_EXECUTION: "proceed",
        ActionProfile.FALLBACK_CLARIFICATION: "ask",
    }.get(profile, "ask")

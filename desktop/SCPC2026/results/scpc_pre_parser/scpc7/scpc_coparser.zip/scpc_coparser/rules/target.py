from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from core.action_profile import ActionProfile
from core.decision import DecisionMatrix, DomainAction
from core.evidence import EvidenceKind, EvidenceStrength
from core.evidence_graph import EvidenceGraph
from core.session_state import MemoryEntry, MemoryStore
from core.task_view import TaskView
from rules.action_profile import control_from_profile


@dataclass(frozen=True)
class TargetCandidate:
    target: str
    source: str
    confidence: str
    requirements: tuple[str, ...] = ()


@dataclass(frozen=True)
class TargetDecision:
    target: str
    source: str
    confidence: str
    candidates: tuple[TargetCandidate, ...]
    reasons: tuple[str, ...]

    def to_trace(self) -> dict[str, Any]:
        return {
            "target": self.target,
            "source": self.source,
            "confidence": self.confidence,
            "candidates": [candidate.__dict__ for candidate in self.candidates],
            "reasons": list(self.reasons),
        }


class TargetResolver:
    @staticmethod
    def resolve_candidates(
        view: TaskView,
        evidence: EvidenceGraph,
        focal_id: str,
        memory_store: MemoryStore | dict[str, Any] | None = None,
    ) -> tuple[TargetCandidate, ...]:
        candidates: list[TargetCandidate] = []
        focal = view.objects_by_id().get(focal_id) if focal_id else {}

        if "prompt_local_intent" in evidence.local_update:
            candidates.append(TargetCandidate("memory_store", "latest_local_intent", "high"))
        if view.latest_record_value("persistent_memory_write"):
            candidates.append(TargetCandidate("memory_store", "persistent_memory_write", "high"))

        changed = view.latest_record_value("target_changed_after_turn")
        if isinstance(changed, str) and changed and "superseded" not in changed and "prior_success" not in changed:
            candidates.append(TargetCandidate(changed, "target_changed_after_turn", "high"))

        recalled, recall_reason = TargetResolver._target_from_memory_recall(
            view, evidence, memory_store
        )
        if recalled:
            candidates.append(TargetCandidate(recalled, recall_reason, "medium"))
        elif recall_reason == "required_memory_unavailable":
            candidates.append(
                TargetCandidate(
                    "",
                    recall_reason,
                    "none",
                    ("requirement:memory_value:missing",),
                )
            )

        resolved = view.latest_record_value("resolved_target")
        if isinstance(resolved, str) and resolved:
            candidates.append(TargetCandidate(resolved, "resolved_target", "high"))

        attrs = focal.get("attrs") or {} if focal else {}
        for key in ("recipient", "target", "channel", "app", "merchant", "name", "attendee"):
            if attrs.get(key):
                candidates.append(TargetCandidate(str(attrs[key]), f"focal_attr:{key}", "medium"))
                break

        last_target = str(view.session_state.get("last_target") or "")
        if last_target and TargetResolver._allows_session_target(view):
            candidates.append(TargetCandidate(last_target, "same_session", "low"))
        candidates.append(TargetCandidate("user", "safe_fallback", "low"))

        deduped: list[TargetCandidate] = []
        seen: set[tuple[str, str]] = set()
        for candidate in candidates:
            key = (candidate.target, candidate.source)
            if key not in seen:
                seen.add(key)
                deduped.append(candidate)
        return tuple(deduped)

    @staticmethod
    def resolve(
        view: TaskView,
        evidence: EvidenceGraph,
        focal_id: str,
        pre_profile: ActionProfile,
        memory_store: MemoryStore | dict[str, Any] | None = None,
    ) -> str:
        return TargetResolver.finalize(
            view,
            evidence,
            focal_id,
            pre_profile,
            memory_store,
        ).target

    @staticmethod
    def finalize(
        view: TaskView,
        evidence: EvidenceGraph,
        focal_id: str,
        profile: ActionProfile,
        memory_store: MemoryStore | dict[str, Any] | None = None,
        decision_matrix: DecisionMatrix | None = None,
    ) -> TargetDecision:
        candidates = TargetResolver.resolve_candidates(view, evidence, focal_id, memory_store)
        control = control_from_profile(profile)
        focal = view.objects_by_id().get(focal_id) if focal_id else {}

        if profile == ActionProfile.DOMAIN_EXECUTION and decision_matrix:
            selected_target = decision_matrix.selected.candidate.target
            if selected_target:
                return TargetResolver._decision(
                    selected_target,
                    "domain_action_target",
                    "high",
                    candidates,
                )
        if (
            decision_matrix
            and decision_matrix.selected.candidate.action_candidate.action == DomainAction.CLARIFY
        ):
            return TargetResolver._decision(
                "user",
                "candidate_clarification_target",
                "high",
                candidates,
            )

        explicit_local_target = any(
            reason in {"persistent_memory_write_present", "prompt_local_intent"}
            for reason in evidence.local_update
        )
        if profile == ActionProfile.LOCAL_STATUS_UPDATE and explicit_local_target:
            return TargetResolver._decision("memory_store", "local_status_profile", "high", candidates)
        if view.latest_record_value("persistent_memory_write"):
            return TargetResolver._decision("memory_store", "persistent_memory_write", "high", candidates)

        changed = view.latest_record_value("target_changed_after_turn")
        if isinstance(changed, str) and changed and "superseded" not in changed and "prior_success" not in changed:
            return TargetResolver._decision(changed, "target_changed_after_turn", "high", candidates)

        recalled, recall_reason = TargetResolver._target_from_memory_recall(
            view, evidence, memory_store
        )
        if recalled:
            if control == "ask" and TargetResolver._asks_user(evidence):
                # Explicit clarification addresses the user unless the recalled
                # route is itself the subject of the question.
                return TargetResolver._decision("user", "explicit_user_clarification", "high", candidates)
            return TargetResolver._decision(recalled, recall_reason, "medium", candidates)
        if recall_reason == "required_memory_unavailable" and control == "ask":
            return TargetResolver._decision(
                "user",
                "required_memory_unavailable",
                "high",
                candidates,
            )

        if control in {"hold", "ask"}:
            target, source = TargetResolver._blocked_or_ask_target(
                view, evidence, focal, control
            )
            return TargetResolver._decision(target, source, "medium", candidates)

        resolved = view.latest_record_value("resolved_target")
        if isinstance(resolved, str) and resolved:
            return TargetResolver._decision(resolved, "resolved_target", "high", candidates)

        attrs = focal.get("attrs") or {} if focal else {}
        for key in ("recipient", "target", "channel", "app", "merchant", "name", "attendee"):
            if attrs.get(key):
                value = str(attrs[key])
                if value == "memory_store" and profile != ActionProfile.LOCAL_STATUS_UPDATE:
                    continue
                return TargetResolver._decision(value, f"focal_attr:{key}", "medium", candidates)

        last_target = str(view.session_state.get("last_target") or "")
        if (
            last_target
            and TargetResolver._allows_session_target(view)
            and (last_target != "memory_store" or profile == ActionProfile.LOCAL_STATUS_UPDATE)
        ):
            return TargetResolver._decision(last_target, "same_session", "low", candidates)
        return TargetResolver._decision("user", "safe_fallback", "low", candidates)

    @staticmethod
    def _target_from_memory_recall(
        view: TaskView,
        evidence: EvidenceGraph,
        memory_store: MemoryStore | dict[str, Any] | None,
    ) -> tuple[str, str]:
        latest_clause = view.latest_clause().lower()
        rejects_memory = (
            any(root in latest_clause for root in ("기록", "메모리", "이전 설정"))
            and any(root in latest_clause for root in ("무시", "사용하지", "버리고"))
        ) or (
            "수신처" in latest_clause
            and any(root in latest_clause for root in ("새로운", "새로", "변경"))
        )
        if rejects_memory:
            return "", "memory_rejected_by_latest_prompt"

        saw_recall = False
        for request in view.record_values("persistent_memory_recall"):
            if not isinstance(request, dict):
                continue
            saw_recall = True
            memory = TargetResolver._recall_value(request, memory_store)
            if memory:
                memory_class = str(request.get("memory_class") or "")
                memory_contexts = {
                    item.payload
                    for item in evidence.intent_evidence.prompt_evidence(
                        EvidenceKind.MEMORY_CONTEXT_REFERENCE
                    )
                }
                if memory_class == "prior_result":
                    keys = ("last_success_target", "approval_channel", "preferred_channel", "health_channel")
                elif memory_class == "standing_constraint":
                    keys = ("last_success_target", "approval_channel", "preferred_channel")
                elif "lighting_routine" in memory_contexts:
                    keys = ("dusk_room",)
                elif "health_schedule" in memory_contexts:
                    keys = ("health_channel", "preferred_channel", "approval_channel")
                else:
                    keys = ("preferred_channel", "health_channel", "approval_channel", "last_success_target")
                for key in keys:
                    if memory.get(key):
                        return str(memory[key]), f"persistent_memory:{key}"

            for key in ("preferred_channel", "health_channel", "approval_channel", "last_success_target"):
                if request.get(key):
                    return str(request[key]), f"recall_record:{key}"
        return (
            ("", "required_memory_unavailable")
            if saw_recall
            else ("", "no_memory_target")
        )

    @staticmethod
    def _recall_value(
        request: dict[str, Any],
        memory_store: MemoryStore | dict[str, Any] | None,
    ) -> dict[str, Any]:
        if isinstance(memory_store, MemoryStore):
            entry = memory_store.recall(request)
            return entry.value if isinstance(entry, MemoryEntry) else {}
        if isinstance(memory_store, dict):
            value = memory_store.get(str(request.get("memory_key") or ""), {})
            if isinstance(value, dict) and isinstance(value.get("value"), dict):
                value = value["value"]
            return value if isinstance(value, dict) else {}
        return {}

    @staticmethod
    def _asks_user(evidence: EvidenceGraph) -> bool:
        return any(
            item.payload == "clarify_user"
            for item in evidence.intent_evidence.current(
                EvidenceKind.CLARIFICATION_REQUEST,
                minimum=EvidenceStrength.DECISIVE,
            )
        )

    @staticmethod
    def _hold_to_user(evidence: EvidenceGraph) -> bool:
        return bool(
            evidence.intent_evidence.current(
                EvidenceKind.STOP_PROCESS,
                minimum=EvidenceStrength.DECISIVE,
            )
        )

    @staticmethod
    def _blocked_or_ask_target(
        view: TaskView,
        evidence: EvidenceGraph,
        focal: dict[str, Any],
        control: str,
    ) -> tuple[str, str]:
        if control == "ask" and TargetResolver._asks_user(evidence):
            return "user", "explicit_user_clarification"
        if control == "hold" and TargetResolver._hold_to_user(evidence):
            return "user", "explicit_user_hold"
        resolved = view.latest_record_value("resolved_target")
        if isinstance(resolved, str) and resolved:
            return resolved, "resolved_target"
        attrs = focal.get("attrs") or {} if focal else {}
        for key in ("recipient", "target", "channel", "app", "merchant", "name", "attendee"):
            if attrs.get(key):
                value = str(attrs[key])
                if value == "memory_store":
                    continue
                return value, f"focal_attr:{key}"
        last_target = str(view.session_state.get("last_target") or "")
        return (
            (last_target, "same_session")
            if last_target
            and last_target != "memory_store"
            and TargetResolver._allows_session_target(view)
            else ("user", "safe_fallback")
        )

    @staticmethod
    def _decision(
        target: str,
        source: str,
        confidence: str,
        candidates: tuple[TargetCandidate, ...],
    ) -> TargetDecision:
        return TargetDecision(target, source, confidence, candidates, (f"selected_by:{source}",))

    @staticmethod
    def _allows_session_target(view: TaskView) -> bool:
        text = f"{view.prompt} {view.visible_history_text()}"
        has_anaphora = any(
            root in text for root in ("같은", "이전", "지난번", "그곳", "직전")
        )
        has_target_role = any(
            root in text for root in ("곳", "수신처", "target", "대상", "방식", "성공")
        )
        return has_anaphora and has_target_role

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import re
import unicodedata
from typing import Any

from .records import Provenance


class EvidenceKind(str, Enum):
    EXECUTION_REQUEST = "execution_request"
    CANCEL_ACTION = "cancel_action"
    STOP_PROCESS = "stop_process"
    VERIFY_REQUEST = "verify_request"
    CLARIFICATION_REQUEST = "clarification_request"
    SHARE_REQUEST = "share_request"
    LOCAL_UPDATE_REQUEST = "local_update_request"
    REDACTION_REQUEST = "redaction_request"
    MEMORY_WRITE_REQUEST = "memory_write_request"
    EXPLICIT_DOMAIN_VERB = "explicit_domain_verb"
    CONTENT_VARIANT_SELECTION = "content_variant_selection"
    VALUE_TRANSFER_REQUEST = "value_transfer_request"
    MEMORY_CONTEXT_REFERENCE = "memory_context_reference"


class EvidenceStrength(str, Enum):
    DECISIVE = "decisive"
    STRONG = "strong"
    SUPPORTING = "supporting"


class AssertionMode(str, Enum):
    DIRECT = "direct"
    REPORTED = "reported"
    QUOTED = "quoted"


@dataclass(frozen=True)
class IntentEvidence:
    evidence_id: str
    kind: EvidenceKind
    payload: str
    polarity: str
    scope: str
    strength: EvidenceStrength
    text: str
    canonical_text_key: str
    provenance: Provenance


@dataclass(frozen=True)
class CanonicalEvidenceGroup:
    group_id: str
    canonical_text_key: str
    member_ids: tuple[str, ...]
    current_prompt_reasserted: bool
    history_only: bool
    quoted_or_reported: bool


@dataclass(frozen=True)
class IntentEvidenceSet:
    evidence: tuple[IntentEvidence, ...]
    groups: tuple[CanonicalEvidenceGroup, ...]
    latest_clause: str

    def of_kind(self, kind: EvidenceKind) -> tuple[IntentEvidence, ...]:
        return tuple(item for item in self.evidence if item.kind == kind)

    def has(self, kind: EvidenceKind, *, minimum: EvidenceStrength | None = None) -> bool:
        ranks = {
            EvidenceStrength.SUPPORTING: 1,
            EvidenceStrength.STRONG: 2,
            EvidenceStrength.DECISIVE: 3,
        }
        return any(
            item.kind == kind
            and (minimum is None or ranks[item.strength] >= ranks[minimum])
            for item in self.evidence
        )

    def ids(self, kind: EvidenceKind) -> tuple[str, ...]:
        return tuple(item.evidence_id for item in self.of_kind(kind))

    def current(
        self,
        kind: EvidenceKind | None = None,
        *,
        minimum: EvidenceStrength | None = None,
    ) -> tuple[IntentEvidence, ...]:
        ranks = {
            EvidenceStrength.SUPPORTING: 1,
            EvidenceStrength.STRONG: 2,
            EvidenceStrength.DECISIVE: 3,
        }
        return tuple(
            item
            for item in self.evidence
            if item.provenance.source_kind == "current_prompt"
            and item.provenance.assertion_mode == AssertionMode.DIRECT.value
            and (kind is None or item.kind == kind)
            and (minimum is None or ranks[item.strength] >= ranks[minimum])
        )

    def current_ids(
        self,
        kind: EvidenceKind,
        *,
        minimum: EvidenceStrength | None = None,
    ) -> tuple[str, ...]:
        return tuple(item.evidence_id for item in self.current(kind, minimum=minimum))

    def prompt_evidence(
        self,
        kind: EvidenceKind | None = None,
        *,
        minimum: EvidenceStrength | None = None,
    ) -> tuple[IntentEvidence, ...]:
        ranks = {
            EvidenceStrength.SUPPORTING: 1,
            EvidenceStrength.STRONG: 2,
            EvidenceStrength.DECISIVE: 3,
        }
        return tuple(
            item
            for item in self.evidence
            if item.provenance.source_kind
            in {"current_prompt", "current_prompt_context"}
            and item.provenance.assertion_mode == AssertionMode.DIRECT.value
            and (kind is None or item.kind == kind)
            and (minimum is None or ranks[item.strength] >= ranks[minimum])
        )

    def prompt_ids(
        self,
        kind: EvidenceKind,
        *,
        minimum: EvidenceStrength | None = None,
    ) -> tuple[str, ...]:
        return tuple(
            item.evidence_id
            for item in self.prompt_evidence(kind, minimum=minimum)
        )

    def to_trace(self) -> dict[str, Any]:
        return {
            "latest_clause": self.latest_clause,
            "evidence": [
                {
                    "id": item.evidence_id,
                    "kind": item.kind.value,
                    "payload": item.payload,
                    "polarity": item.polarity,
                    "scope": item.scope,
                    "strength": item.strength.value,
                    "source_kind": item.provenance.source_kind,
                    "source_id": item.provenance.source_id,
                    "turn": item.provenance.turn,
                    "span": list(item.provenance.span) if item.provenance.span else None,
                    "assertion_mode": item.provenance.assertion_mode,
                }
                for item in self.evidence
            ],
            "groups": [
                {
                    "id": group.group_id,
                    "member_ids": list(group.member_ids),
                    "current_prompt_reasserted": group.current_prompt_reasserted,
                    "history_only": group.history_only,
                    "quoted_or_reported": group.quoted_or_reported,
                }
                for group in self.groups
            ],
        }


CONNECTOR_RE = re.compile(r"(?:^|[.!?。！？]\s*|\n+)(?P<marker>단,|다만|하지만)(?=\s|$)")
CLAUSE_RE = re.compile(r"[^.!?。！？\n]+(?:[.!?。！？]+|$)")

LOCAL_DESTINATION_RE = re.compile(
    r"(?:내부|로컬|기기\s*(?:안|내부)|내\s*기기|장치\s*(?:안|내부))[^.!?]{0,60}"
    r"(?:상태|기록|갱신|업데이트|완료|남기|정리)"
)
LOCAL_EXCLUSIVE_RE = re.compile(
    r"(?:상태|기록)[^.!?]{0,15}(?:만|한정)[^.!?]{0,20}(?:갱신|바꾸|남기|정리|업데이트)"
)
EXTERNAL_CANCEL_RE = re.compile(
    r"(?:외부\s*(?:공유|전송|전달)|바깥\s*(?:수신처|으로)|실제\s*보내기|보내는\s*작업|"
    r"수신처\s*전달|전달\s*(?:동작|단계)|공유\s*(?:작업|채널))"
    r"[^.!?]{0,60}(?:하지\s*말|하지\s*않|생략|접고|취소|대신|아니라|빼고)"
)

CONFIRMATION_ROOTS = ("확인", "질문", "물어", "clarification")
UNCERTAINTY_ROOTS = (
    "미확정",
    "불분명",
    "확정되지",
    "확정 정보가 없",
    "결론을 내릴 수 없",
    "유효성이 불",
    "달라진",
    "바뀐 듯",
)
USER_REFERENCE_ROOTS = ("사용자", "누구에게", "대상", "수신처", "범위")
INVALIDATION_ROOTS = ("전제", "허용", "승인", "근거", "consent")
INVALID_STATE_ROOTS = ("사라", "무효", "취소", "깨", "무너", "믿을 수 없", "뒤집")
SENSITIVE_FIELD_ROOTS = (
    "민감",
    "식별",
    "원문",
    "raw",
    "위치",
    "장소",
    "수치",
    "숫자",
    "주민",
    "rrn",
    "이름",
    "나이",
)
REDACTION_ACTION_ROOTS = ("제외", "제거", "덜어", "익명", "정제", "포함하지", "남기지")
SUMMARY_LIMIT_ROOTS = ("요약만", "최소 요약", "요약으로만", "요약 수준")
DIRECTIVE_ROOTS = (
    "해줘",
    "하라",
    "해라",
    "해야",
    "말고",
    "우선한다",
    "처리해",
    "진행해",
    "실행해",
    "바꿔",
    "켜줘",
    "꺼줘",
)
REPORTED_CONTEXT_ROOTS = (
    "지난 성공",
    "실패 기록",
    "이전 요청",
    "직전 턴",
    "과거 처리",
    "라고 말했다",
    "라고 요청했다",
)

def normalize_text(text: Any) -> str:
    normalized = unicodedata.normalize("NFKC", str(text or ""))
    return re.sub(r"\s+", " ", normalized).strip()


def canonical_text(text: str) -> str:
    normalized = normalize_text(text).lower()
    normalized = re.sub(r"[\s\u00b7,.;:!?]+", " ", normalized)
    return normalized.strip()


def latest_clause_from_text(text: str) -> tuple[str, tuple[int, int] | None]:
    normalized = normalize_text(text)
    matches = list(CONNECTOR_RE.finditer(normalized))
    if not matches:
        return "", None
    marker_start = matches[-1].start("marker")
    return normalized[marker_start:].strip(), (marker_start, len(normalized))


def _clauses(text: str) -> tuple[tuple[str, int, int], ...]:
    normalized = normalize_text(text)
    clauses: list[tuple[str, int, int]] = []
    for match in CLAUSE_RE.finditer(normalized):
        raw = match.group(0)
        stripped = raw.strip()
        if not stripped:
            continue
        leading = len(raw) - len(raw.lstrip())
        clauses.append((stripped, match.start() + leading, match.start() + leading + len(stripped)))
    return tuple(clauses) or ((normalized, 0, len(normalized)),)


def _is_reported_clause(text: str) -> bool:
    normalized = normalize_text(text)
    return (
        any(root in normalized for root in REPORTED_CONTEXT_ROOTS)
        and not any(root in normalized for root in DIRECTIVE_ROOTS)
    )


def _is_memory_write_clause(text: str) -> bool:
    normalized = normalize_text(text)
    has_memory_object = any(root in normalized for root in ("메모리", "기억", "사용자 정보"))
    has_write_action = any(root in normalized for root in ("저장해", "저장하", "기억해", "기억하", "기록해", "남겨"))
    recalls_prior_write = bool(re.search(r"(?:지난번|이전|과거)[^.!?]{0,24}(?:저장|기억|기록)", normalized))
    return has_memory_object and has_write_action and not recalls_prior_write


def _is_strong_local_clause(text: str) -> bool:
    normalized = normalize_text(text)
    memory_write = (
        _is_memory_write_clause(normalized)
    )
    has_local_anchor = any(
        root in normalized for root in ("내부", "로컬", "기기 안", "기기 내부", "내 기기", "장치 안", "장치 내부")
    )
    has_state_subject = any(root in normalized for root in ("상태", "기록", "완료"))
    has_update_action = any(root in normalized for root in ("갱신", "업데이트", "바꾸", "남기", "정리", "새로 쓰"))
    has_exclusivity = any(root in normalized for root in ("만", "한정", "으로 끝", "것으로 끝"))
    explicit_status_only = bool(LOCAL_EXCLUSIVE_RE.search(normalized)) or (
        has_state_subject and has_update_action and has_exclusivity
    ) or (
        has_local_anchor and has_state_subject and has_update_action
    )
    redirected = bool(EXTERNAL_CANCEL_RE.search(normalized)) and (
        bool(LOCAL_DESTINATION_RE.search(normalized)) or explicit_status_only
    )
    return memory_write or explicit_status_only or redirected


def is_strong_local(text: str) -> bool:
    return any(_is_strong_local_clause(clause) for clause, _, _ in _clauses(text))


def _is_decisive_stop_clause(text: str) -> bool:
    normalized = normalize_text(text)
    direct_block = bool(
        re.search(
            r"(?:중단|멈(?:추|춘|춰)|보류|차단|실행을\s*막)[^.!?]{0,16}(?:해야|한다|하라|해라|하지|된다|아야)",
            normalized,
        )
    ) and "보류 여부" not in normalized
    negative_execution = bool(
        re.search(
            r"(?:실행|진행|처리|수행)[^.!?]{0,24}(?:하면\s*안|하지\s*말|하지\s*않|할\s*수\s*없)",
            normalized,
        )
    )
    invalidated = (
        any(root in normalized for root in INVALIDATION_ROOTS)
        and any(root in normalized for root in INVALID_STATE_ROOTS)
        and (direct_block or negative_execution or "위험" in normalized)
    )
    return direct_block or negative_execution or invalidated


def is_decisive_stop(text: str) -> bool:
    return any(_is_decisive_stop_clause(clause) for clause, _, _ in _clauses(text))


def _clarification_payload(text: str) -> str:
    normalized = normalize_text(text)
    has_confirmation = any(root in normalized for root in CONFIRMATION_ROOTS)
    has_uncertainty = any(root in normalized for root in UNCERTAINTY_ROOTS)
    explicit_question = any(root in normalized for root in ("물어", "질문", "clarification"))
    asks_for_confirmation = any(root in normalized for root in ("먼저", "다시", "해야", "해줘", "하라는", "거친"))
    user_confirmation = "사용자" in normalized and "확인" in normalized and asks_for_confirmation
    interrogative_confirmation = (
        has_confirmation
        and any(root in normalized for root in ("누구에게", "어떤 범위", "어느 대상", "어느 수신처"))
    )
    scoped_confirmation = (
        has_confirmation
        and has_uncertainty
        and any(root in normalized for root in USER_REFERENCE_ROOTS)
    )
    route_gate = (
        any(root in normalized for root in ("수신처", "승인 경로", "외부 공유", "대상", "범위"))
        and any(root in normalized for root in ("확정되지", "아직", "닫히", "충돌", "함께 언급"))
        and has_confirmation
    )
    insufficient_information = has_uncertainty and any(
        root in normalized
        for root in ("현재 정보", "결론", "확인되지", "미확정", "확정 정보가 없", "유효성이 불")
    )
    detected = (
        explicit_question
        or user_confirmation
        or interrogative_confirmation
        or scoped_confirmation
        or route_gate
        or insufficient_information
    )
    if not detected:
        return ""
    conditional = any(root in normalized for root in ("필요하면", "필요한 경우", "경우에는", "때에는"))
    explicitly_addresses_user = (
        user_confirmation
        or interrogative_confirmation
        or insufficient_information
        or route_gate
        or (explicit_question and not conditional)
    )
    return "clarify_user" if explicitly_addresses_user else "constraint_only"


def _is_clarification_clause(text: str) -> bool:
    return bool(_clarification_payload(text))


def is_clarification_request(text: str) -> bool:
    return any(_is_clarification_clause(clause) for clause, _, _ in _clauses(text))


def _is_redaction_clause(text: str) -> bool:
    normalized = normalize_text(text)
    has_sensitive_field = any(root in normalized for root in SENSITIVE_FIELD_ROOTS)
    removes_field = any(root in normalized for root in REDACTION_ACTION_ROOTS)
    limits_to_summary = any(root in normalized for root in SUMMARY_LIMIT_ROOTS)
    privacy_delegation = "민감" in normalized and "알아서 처리" in normalized
    return (has_sensitive_field and removes_field) or limits_to_summary or privacy_delegation


def is_redaction_request(text: str) -> bool:
    return any(_is_redaction_clause(clause) for clause, _, _ in _clauses(text))


def _domain_actions(text: str) -> tuple[str, ...]:
    normalized = normalize_text(text)
    actions: list[str] = []
    if "결제" in normalized and any(
        root in normalized for root in ("결제해", "결제하", "요청을 처리", "구매해", "지불해")
    ):
        actions.append("PAY")
    if any(root in normalized for root in ("설정", "루틴", "조명", "기기")) and any(
        root in normalized for root in ("켜", "꺼", "바꿔", "변경해", "토글")
    ):
        actions.append("TOGGLE")
    if any(root in normalized for root in ("일정", "캘린더", "예약")) and any(
        root in normalized for root in ("등록해", "추가해", "변경해", "잡아", "예약해", "예약하")
    ):
        actions.append("SCHEDULE")
    return tuple(actions)


class IntentEvidenceExtractor:
    @classmethod
    def extract(cls, view: Any) -> IntentEvidenceSet:
        prompt = normalize_text(view.prompt)
        latest_clause, latest_span = latest_clause_from_text(prompt)
        evidence: list[IntentEvidence] = []

        if latest_clause:
            evidence.extend(
                cls._extract_text(
                    prompt,
                    source_kind="current_prompt_context",
                    source_id=f"{view.task_id}:context",
                    session_id=view.session_id,
                    turn=view.turn_index,
                    span=(0, len(prompt)),
                    assertion_mode=AssertionMode.DIRECT,
                    id_prefix="prompt_context",
                )
            )
        evidence.extend(
            cls._extract_text(
                latest_clause or prompt,
                source_kind="current_prompt",
                source_id=f"{view.task_id}:latest" if latest_clause else view.task_id,
                session_id=view.session_id,
                turn=view.turn_index,
                span=latest_span or (0, len(prompt)),
                assertion_mode=AssertionMode.DIRECT,
                id_prefix="prompt",
            )
        )

        history_items = sorted(
            view.history,
            key=lambda item: (cls._turn(item), normalize_text(item.get("summary", item))),
        )
        for index, item in enumerate(history_items):
            summary = normalize_text(item.get("summary", item))
            if not summary:
                continue
            mode = AssertionMode.REPORTED
            if any(term in summary for term in ("라고 말했다", "라고 요청", "인용", "원문")):
                mode = AssertionMode.QUOTED
            history_evidence = cls._extract_text(
                summary,
                source_kind="visible_history",
                source_id=f"{view.task_id}:history:{index}",
                session_id=view.session_id,
                turn=cls._turn(item),
                span=(0, len(summary)),
                assertion_mode=mode,
                id_prefix=f"history_{index}",
            )
            # Keep repeated evidence as members; grouping retains the stronger
            # current-prompt reassertion without discarding history provenance.
            evidence.extend(history_evidence)

        groups_by_key: dict[str, list[IntentEvidence]] = {}
        for item in evidence:
            groups_by_key.setdefault(item.canonical_text_key, []).append(item)
        groups = tuple(
            CanonicalEvidenceGroup(
                group_id=f"evidence_group:{index}",
                canonical_text_key=key,
                member_ids=tuple(item.evidence_id for item in members),
                current_prompt_reasserted=any(
                    item.provenance.source_kind == "current_prompt" for item in members
                ),
                history_only=all(
                    item.provenance.source_kind == "visible_history" for item in members
                ),
                quoted_or_reported=any(
                    item.provenance.assertion_mode != AssertionMode.DIRECT.value for item in members
                ),
            )
            for index, (key, members) in enumerate(sorted(groups_by_key.items()))
        )
        return IntentEvidenceSet(tuple(evidence), groups, latest_clause)

    @classmethod
    def _extract_text(
        cls,
        text: str,
        *,
        source_kind: str,
        source_id: str,
        session_id: str,
        turn: int | None,
        span: tuple[int, int],
        assertion_mode: AssertionMode,
        id_prefix: str,
    ) -> list[IntentEvidence]:
        normalized = normalize_text(text)
        if not normalized:
            return []
        extracted: list[IntentEvidence] = []
        base_offset = span[0]
        evidence_index = 0

        for clause, clause_start, clause_end in _clauses(normalized):
            clause_mode = assertion_mode
            if assertion_mode == AssertionMode.DIRECT and _is_reported_clause(clause):
                clause_mode = AssertionMode.REPORTED
            direct = source_kind == "current_prompt" and clause_mode == AssertionMode.DIRECT
            found: list[tuple[EvidenceKind, str, str, str, EvidenceStrength]] = []

            clarification_payload = _clarification_payload(clause)
            clarification_request = bool(clarification_payload)
            if _is_decisive_stop_clause(clause) and not clarification_request:
                found.append((EvidenceKind.STOP_PROCESS, "primary_action", "negative", "operation", EvidenceStrength.DECISIVE if direct else EvidenceStrength.STRONG))
            if _is_strong_local_clause(clause):
                found.append((EvidenceKind.LOCAL_UPDATE_REQUEST, "local_state", "positive", "local", EvidenceStrength.DECISIVE if direct else EvidenceStrength.STRONG))
            elif any(term in clause for term in ("로컬", "내부 상태", "상태 기록", "local_update_boundary")):
                found.append((EvidenceKind.LOCAL_UPDATE_REQUEST, "local_state", "positive", "local", EvidenceStrength.SUPPORTING))

            if clarification_request:
                found.append((EvidenceKind.CLARIFICATION_REQUEST, clarification_payload, "positive", "operation", EvidenceStrength.DECISIVE if direct else EvidenceStrength.STRONG))
            if _is_redaction_clause(clause):
                found.append((EvidenceKind.REDACTION_REQUEST, "sensitive_fields", "negative", "content", EvidenceStrength.STRONG if direct else EvidenceStrength.SUPPORTING))

            variant_roots = {
                root
                for root in ("원본", "원문", "사진", "이미지", "익명", "요약")
                if root in clause
            }
            if len(variant_roots) >= 2 and any(
                root in clause for root in ("고르", "선택", "중", "무엇")
            ):
                found.append((EvidenceKind.CONTENT_VARIANT_SELECTION, "content_variant", "positive", "content", EvidenceStrength.STRONG if direct else EvidenceStrength.SUPPORTING))
            if "쿠폰" in clause and any(
                root in clause for root in ("보내", "전달", "사용", "결제")
            ):
                found.append((EvidenceKind.VALUE_TRANSFER_REQUEST, "stored_value", "positive", "domain", EvidenceStrength.STRONG if direct else EvidenceStrength.SUPPORTING))
            recalls_context = any(
                root in clause for root in ("지난번", "저장한", "메모리", "기억")
            )
            if recalls_context and any(root in clause for root in ("조명", "루틴")):
                found.append((EvidenceKind.MEMORY_CONTEXT_REFERENCE, "lighting_routine", "positive", "memory", EvidenceStrength.STRONG if direct else EvidenceStrength.SUPPORTING))
            if recalls_context and any(
                root in clause for root in ("검진", "점검", "병원", "캘린더")
            ):
                found.append((EvidenceKind.MEMORY_CONTEXT_REFERENCE, "health_schedule", "positive", "memory", EvidenceStrength.STRONG if direct else EvidenceStrength.SUPPORTING))

            if any(term in clause for term in ("공유", "보내", "전달", "올려")):
                found.append((EvidenceKind.SHARE_REQUEST, "dispatch", "positive", "external", EvidenceStrength.STRONG if direct else EvidenceStrength.SUPPORTING))
            if any(term in clause for term in ("확인", "검토", "점검")):
                found.append((EvidenceKind.VERIFY_REQUEST, "precondition", "positive", "operation", EvidenceStrength.SUPPORTING))
            if any(term in clause for term in ("처리해", "수행", "실행", "바꿔", "켜줘", "꺼줘", "결제해", "저장해")):
                found.append((EvidenceKind.EXECUTION_REQUEST, "primary_action", "positive", "operation", EvidenceStrength.STRONG if direct else EvidenceStrength.SUPPORTING))
            if EXTERNAL_CANCEL_RE.search(clause) or re.search(r"(?:보내|공유|전달)[^.!?]{0,20}(?:지\s*마|말고|취소)", clause):
                found.append((EvidenceKind.CANCEL_ACTION, "dispatch", "negative", "external", EvidenceStrength.DECISIVE if direct else EvidenceStrength.STRONG))
            if _is_memory_write_clause(clause):
                found.append((EvidenceKind.MEMORY_WRITE_REQUEST, "memory", "positive", "local", EvidenceStrength.DECISIVE if direct else EvidenceStrength.STRONG))
            domain_actions = _domain_actions(clause)
            if domain_actions and not any(
                kind == EvidenceKind.EXECUTION_REQUEST
                for kind, _payload, _polarity, _scope, _strength in found
            ):
                found.append((EvidenceKind.EXECUTION_REQUEST, "primary_action", "positive", "operation", EvidenceStrength.STRONG if direct else EvidenceStrength.SUPPORTING))
            for action in domain_actions:
                found.append((EvidenceKind.EXPLICIT_DOMAIN_VERB, action, "positive", "domain", EvidenceStrength.STRONG if direct else EvidenceStrength.SUPPORTING))

            provenance = Provenance(
                source_kind=source_kind,
                source_id=source_id,
                session_id=session_id,
                turn=turn,
                span=(base_offset + clause_start, base_offset + clause_end),
                assertion_mode=clause_mode.value,
            )
            key = canonical_text(clause)
            for kind, payload, polarity, scope, strength in found:
                extracted.append(
                    IntentEvidence(
                        evidence_id=f"intent:{id_prefix}:{evidence_index}:{kind.value}",
                        kind=kind,
                        payload=payload,
                        polarity=polarity,
                        scope=scope,
                        strength=strength,
                        text=clause,
                        canonical_text_key=key,
                        provenance=provenance,
                    )
                )
                evidence_index += 1
        return extracted

    @staticmethod
    def _turn(item: dict[str, Any]) -> int:
        try:
            return int(item.get("turn", -1))
        except (TypeError, ValueError):
            return -1

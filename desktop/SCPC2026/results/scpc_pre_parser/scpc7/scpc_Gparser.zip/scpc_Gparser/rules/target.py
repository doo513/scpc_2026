from __future__ import annotations

from dataclasses import dataclass
from typing import Any
from core.task_view import TaskView
from core.evidence_graph import EvidenceGraph
from core.action_profile import ActionProfile
from rules.action_profile import control_from_profile, ProfileDecision


class TargetResolver:
    @dataclass
    class MemoryEntry:
        key: str
        value: dict[str, Any]
        source_session_id: str
        source_task_id: str
        source_turn_index: int
        recall_scope: str  # cross_session | same_session | global

    @staticmethod
    def resolve(
        view: TaskView,
        evidence: EvidenceGraph,
        focal_id: str,
        profile_decision: ProfileDecision | ActionProfile,
        memory_bank: dict[str, Any] | None = None,
    ) -> str:
        if isinstance(profile_decision, ActionProfile):
            profile = profile_decision
        else:
            profile = profile_decision.profile

        control = control_from_profile(profile)
        focal = view.objects_by_id().get(focal_id) if focal_id else {}

        # 1. Local update check
        from core.evidence_graph import LOCAL_UPDATE_PHRASES
        is_local_upd = any(phrase in view.prompt for phrase in LOCAL_UPDATE_PHRASES)
        if is_local_upd:
            return "memory_store"

        if view.latest_record_value("persistent_memory_write"):
            return "memory_store"

        # 3. target_changed_after_turn
        changed = view.latest_record_value("target_changed_after_turn")
        if isinstance(changed, str) and changed and "superseded" not in changed and "prior_success" not in changed:
            return changed

        # 4. Memory recall target
        recalled = TargetResolver._target_from_memory_recall(view, evidence, memory_bank)
        if recalled:
            return recalled

        # 5. Hold or Ask targets check
        if control in ("hold", "ask"):
            return TargetResolver._blocked_or_ask_target(view, focal, control, evidence, memory_bank)

        # 6. Resolved target
        resolved = view.latest_record_value("resolved_target")
        if isinstance(resolved, str) and resolved:
            return resolved

        # 7. Focal attrs fallback
        attrs = focal.get("attrs") or {} if focal else {}
        for key in ("recipient", "target", "channel", "app", "merchant", "name", "attendee"):
            if attrs.get(key):
                return str(attrs[key])

        # 8. Session last target fallback / user fallback
        return str(view.session_state.get("last_target") or "user")

    @staticmethod
    def _target_from_memory_recall(
        view: TaskView,
        evidence: EvidenceGraph,
        memory_bank: dict[str, Any] | None = None,
    ) -> str:
        session = view.session_state
        mem_dict = session.get("memory") or {}
        memory_bank = memory_bank or {}

        # Check prompt override that rejects memory
        latest_c = view.latest_clause().lower()
        prompt_rejects_memory = any(
            phrase in latest_c for phrase in ["기록을 무시", "메모리를 무시", "이전 설정 무시", "새로운 수신처"]
        )

        for value in reversed(view.record_values("persistent_memory_recall")):
            if not isinstance(value, dict):
                continue

            key = str(value.get("memory_key") or "")
            if not key:
                continue

            # Provenance retrieval
            memory = mem_dict.get(key)
            recall_scope = "same_session"
            if not memory:
                # Retrieve from global memory bank
                memory = memory_bank.get(key)
                recall_scope = "cross_session"

            if not memory:
                continue

            # Retrieve actual content dict
            actual_mem = memory.get("value") if isinstance(memory, dict) and "value" in memory else memory
            if not isinstance(actual_mem, dict):
                continue

            # Check prompt overrides memory recall
            if prompt_rejects_memory:
                continue

            # Same session vs Cross session check
            source_session = str(memory.get("source_session_id") or "") if isinstance(memory, dict) else ""
            if recall_scope == "cross_session" and source_session and source_session != view.session_id:
                # Allow cross-session target recall as fallback
                pass

            if value.get("memory_class") == "prior_result":
                for key2 in ("last_success_target", "approval_channel", "preferred_channel", "health_channel"):
                    if actual_mem.get(key2):
                        return str(actual_mem[key2])
            if value.get("memory_class") == "standing_constraint":
                for key2 in ("last_success_target", "approval_channel", "preferred_channel"):
                    if actual_mem.get(key2):
                        return str(actual_mem[key2])

            if "조명" in view.prompt or "날이 어두워질" in view.prompt:
                if actual_mem.get("dusk_room"):
                    return str(actual_mem["dusk_room"])

            if "검진" in view.prompt or "점검" in view.prompt:
                for key2 in ("health_channel", "preferred_channel", "approval_channel"):
                    if actual_mem.get(key2):
                        return str(actual_mem[key2])

            for key2 in ("preferred_channel", "health_channel", "approval_channel", "last_success_target"):
                if actual_mem.get(key2):
                    return str(actual_mem[key2])

        # Recalled person fallback
        for value in reversed(view.record_values("persistent_memory_recall")):
            if not isinstance(value, dict):
                continue
            person = str(value.get("person") or "")
            if "조명" in view.prompt or "날이 어두워질" in view.prompt:
                return "living_room"
            if "검진" in view.prompt or "점검" in view.prompt:
                if person == "jimin":
                    return "clinic_portal"
                return "caregiver"
            for key in ("preferred_channel", "health_channel", "approval_channel", "last_success_target"):
                if value.get(key):
                    return str(value[key])

        return ""

    @staticmethod
    def _asks_user(view: TaskView) -> bool:
        prompt = view.prompt
        if any(p in prompt for p in ["누구에게 어떤 범위", "사용자에게", "먼저 확인", "다시 확인", "새 전제", "미확정", "결론을 내릴 수 없다"]):
            return True
        if view.latest_record_value("duration_ambiguous"):
            return True
        if view.latest_record_value("amount_changed") or view.latest_record_value("memory_conflict"):
            return False
        if view.latest_record_value("ambiguous_focal") and not view.latest_record_value("target_changed_after_turn"):
            return False
        return False

    @staticmethod
    def _hold_to_user(view: TaskView) -> bool:
        prompt = view.prompt
        if any(p in prompt for p in ["더 진행하면 안", "실행하면 안", "확인 전에는 처리하지", "이전 허용 조건이 취소", "처리 전제가 사라", "허용 근거가 최신 상태에서 깨", "과거 승인에 기대면 안"]):
            return True
        consent_val = view.latest_record_value("consent")
        if isinstance(consent_val, dict) and consent_val.get("status") == "revoked":
            return False
        if isinstance(consent_val, str) and consent_val == "revoked":
            return False
        if view.latest_record_value("security_alert") or view.latest_record_value("safety_mode"):
            return False
        return False

    @staticmethod
    def _blocked_or_ask_target(
        view: TaskView,
        focal: dict[str, Any],
        control: str,
        evidence: EvidenceGraph,
        memory_bank: dict[str, Any] | None = None,
    ) -> str:
        recalled = TargetResolver._target_from_memory_recall(view, evidence, memory_bank)
        if control == "ask" and TargetResolver._asks_user(view) and not recalled:
            return "user"
        if control == "hold" and TargetResolver._hold_to_user(view):
            return "user"
        resolved = view.latest_record_value("resolved_target")
        if isinstance(resolved, str) and resolved:
            return resolved
        if recalled:
            return recalled
        attrs = focal.get("attrs") or {} if focal else {}
        for key in ("recipient", "target", "channel", "app", "merchant", "name", "attendee"):
            if attrs.get(key):
                return str(attrs[key])
        return str(view.session_state.get("last_target") or "user")

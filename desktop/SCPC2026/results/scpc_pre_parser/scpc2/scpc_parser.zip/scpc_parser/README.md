# SCPC Parser Harness

Local, deterministic SCPC final-round answer harness.

## Files

- `harness.py`: `FinalHarness` and schema-safe answer generation.
- `run_submission.py`: reads `screening_tasks.jsonl` and writes `submission.csv`.
- `local_score.py`: runs dev tasks and prints axis scores.
- `analyze_dev_errors.py`: groups dev misses by the function that should be improved.
- `requirements.txt`: intentionally stdlib-only.

## Data

The scripts search for data in the current directory, a local `data/` directory, and the provided source paths:

- `/home/doo33/desktop/data/data`
- `/home/doo33/desktop/data`

## Commands

```bash
python3 local_score.py
python3 analyze_dev_errors.py
python3 run_submission.py
```

`run_submission.py` writes `submission.csv` in this folder. The CSV has one column, `submission`, and one JSON payload cell.

## Submission Constraints

- No external API calls.
- No web search.
- No LLM calls.
- No task-id lookup in `harness.py`.
- `meta.uses_external_api=false`.
- `meta.fixed_slm_policy=local_fixed_slm_only`.
- `meta.model_id=scpc-final-fixed-slm-local-facade`.

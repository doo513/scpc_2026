from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any


SUBMISSION_SCHEMA = "scpc.final.answer.v1"
FIXED_SLM_ID = "scpc-final-fixed-slm-local-facade"

VALID_CONTROLS = {"proceed", "amend", "hold", "ask"}
VALID_SCOPE_MODES = {"raw", "summary", "redacted", "status_only", "none"}

REMOVED_SCORING_KEYS = (
    "expected_events",
    "answer",
)

SENSITIVE_FIELDS = {
    "amount",
    "birthday",
    "card_number",
    "doctor_note",
    "location",
    "name",
    "numeric_value",
    "person",
    "raw_quote",
    "rrn",
}

LOCAL_UPDATE_PHRASES = (
    "내부 상태 업데이트",
    "내 기기 안에서 상태만 갱신",
    "로컬 상태 기록",
    "상태값만 갱신",
    "공유하지 말고 상태값만",
    "수신처 전달 대신 기기 내부 업데이트",
    "보내는 작업은 취소하고 로컬 상태",
    "바깥으로 보내지 말고 내부 상태",
    "전달 동작은 취소하고 장치 안의 처리 상태만",
)

HOLD_PRECONDITION_PHRASES = (
    "처리 전제가 사라",
    "허용 근거가 최신 상태에서 깨",
    "이전 허용 조건이 취소",
    "과거 승인에 기대면 안 되는 상태",
    "최신 기록이 이전 허용의 전제를 무효화",
    "더 진행하면 안 된다",
    "실행을 막아야",
)

ASK_PHRASES = (
    "사용자에게 먼저 확인",
    "누구에게 어떤 범위",
    "다시 확인하라는 최신 지시",
    "새 전제가 확정되지",
    "조건 변경 여부가 미확정",
    "대상이나 전제 조건이 바뀌었는지 아직 확인되지",
    "최종 수신처와 허용 범위가 아직 확정되지",
    "확인 응답을 우선",
)

REDACTION_PHRASES = (
    "식별 가능한 세부값을 제외",
    "민감 성분을 제거",
    "민감 내용은 알아서 처리",
    "요약만 공유",
    "원문 대신 요약",
)


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open(encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def records_of(task: dict[str, Any]) -> list[dict[str, Any]]:
    return list(((task.get("device_state") or {}).get("records") or []))


def objects_of(task: dict[str, Any]) -> list[dict[str, Any]]:
    return list(((task.get("device_state") or {}).get("objects") or []))


def text_of(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    return json.dumps(value, ensure_ascii=False, sort_keys=True)


def norm_token(value: Any) -> str:
    return str(value or "").strip().lower().replace("-", "_").replace(" ", "_")


def object_text(obj: dict[str, Any]) -> str:
    attrs = obj.get("attrs") or {}
    return " ".join([str(obj.get("id", "")), str(obj.get("type", "")), text_of(attrs)]).lower()


def all_context_text(task: dict[str, Any], *, include_objects: bool = False) -> str:
    parts: list[str] = [str(task.get("prompt", ""))]
    parts.extend(text_of(item) for item in task.get("visible_history", []) or [])
    for record in records_of(task):
        parts.append(str(record.get("type", "")))
        parts.append(text_of(record.get("value")))
    for mem in task.get("personal_memory", []) or []:
        parts.append(text_of(mem))
    if include_objects:
        for obj in objects_of(task):
            parts.append(object_text(obj))
    return " ".join(parts)


def record_values(task: dict[str, Any], record_type: str) -> list[Any]:
    return [record.get("value") for record in records_of(task) if record.get("type") == record_type]


def latest_record_value(task: dict[str, Any], record_type: str) -> Any:
    values = record_values(task, record_type)
    return values[-1] if values else None


def record_types(task: dict[str, Any]) -> set[str]:
    return {str(record.get("type")) for record in records_of(task)}


def flatten_strings(value: Any) -> list[str]:
    out: list[str] = []
    if isinstance(value, str):
        out.append(value)
    elif isinstance(value, dict):
        for key, child in value.items():
            out.append(str(key))
            out.extend(flatten_strings(child))
    elif isinstance(value, list):
        for child in value:
            out.extend(flatten_strings(child))
    elif value is not None:
        out.append(str(value))
    return out


def participant_task_view(task: dict[str, Any]) -> dict[str, Any]:
    view = json.loads(json.dumps(task, ensure_ascii=False))
    for key in list(view):
        if (
            key in REMOVED_SCORING_KEYS
            or key.startswith("expected_")
            or key.endswith("_brief")
            or key.endswith("_notes")
            or key.endswith("_rubric")
            or key.endswith("_keywords")
            or key.endswith("_tags")
        ):
            view.pop(key, None)
    return view


def answer_one(harness: Any, task: dict[str, Any], session: dict[str, Any]) -> dict[str, Any]:
    for name in ("answer_task", "solve_task", "solve"):
        fn = getattr(harness, name, None)
        if callable(fn):
            answer = fn(task, session)
            if not isinstance(answer, dict):
                raise RuntimeError(f"{name} returned non-object for task {task.get('id')}")
            return answer
    raise RuntimeError("harness must expose answer_task(task, session), solve_task(...), or solve(...)")


def run_harness(
    tasks: list[dict[str, Any]],
    harness_cls: type = None,
    *,
    harness_name: str = "scpc_parser_harness",
) -> dict[str, Any]:
    harness_cls = harness_cls or FinalHarness
    ordered = sorted(tasks, key=lambda t: (str(t.get("session_id", "")), int(t.get("turn_index", 0)), str(t.get("id", ""))))
    harness = harness_cls()
    prepare = getattr(harness, "prepare", None)
    if callable(prepare):
        prepare([])

    sessions: dict[str, dict[str, Any]] = {}
    answers: dict[str, dict[str, Any]] = {}
    for task in ordered:
        sid = str(task.get("session_id", ""))
        session = sessions.setdefault(sid, {})
        answers[str(task["id"])] = answer_one(harness, participant_task_view(task), session)

    return {
        "schema": SUBMISSION_SCHEMA,
        "meta": {
            "harness_name": harness_name,
            "uses_external_api": False,
            "fixed_slm_policy": "local_fixed_slm_only",
            "model_id": FIXED_SLM_ID,
            "temperature": 0.0,
            "seed": 2026,
        },
        "answers": answers,
    }


def validate_payload(payload: dict[str, Any], expected_ids: set[str] | None = None) -> None:
    if payload.get("schema") != SUBMISSION_SCHEMA:
        raise ValueError(f"schema must be {SUBMISSION_SCHEMA}")
    meta = payload.get("meta")
    if not isinstance(meta, dict):
        raise ValueError("meta is required")
    if meta.get("fixed_slm_policy") != "local_fixed_slm_only":
        raise ValueError("meta.fixed_slm_policy must be local_fixed_slm_only")
    if meta.get("uses_external_api") is not False:
        raise ValueError("meta.uses_external_api must be false")
    if meta.get("model_id") != FIXED_SLM_ID:
        raise ValueError(f"meta.model_id must be {FIXED_SLM_ID}")

    answers = payload.get("answers")
    if not isinstance(answers, dict):
        raise ValueError("answers must be an object")
    if expected_ids is not None:
        missing = sorted(expected_ids - set(answers))
        extra = sorted(set(answers) - expected_ids)
        if missing:
            raise ValueError(f"missing answers: {missing[:5]} ... total={len(missing)}")
        if extra:
            raise ValueError(f"extra answers: {extra[:5]} ... total={len(extra)}")

    for task_id, answer in answers.items():
        if not isinstance(answer, dict):
            raise ValueError(f"answer for {task_id} must be an object")
        for field in ["focal_id", "target", "control", "content_scope", "policy", "plan_events"]:
            if field not in answer:
                raise ValueError(f"answer for {task_id} missing {field}")
        if answer["control"] not in VALID_CONTROLS:
            raise ValueError(f"invalid control for {task_id}: {answer['control']}")
        scope = answer.get("content_scope")
        if not isinstance(scope, dict) or scope.get("mode") not in VALID_SCOPE_MODES:
            raise ValueError(f"invalid content_scope for {task_id}")
        for field in ("allowed_fields", "excluded_fields"):
            if not isinstance(scope.get(field), list):
                raise ValueError(f"invalid content_scope.{field} for {task_id}")
        if not isinstance(scope.get("requires_user_confirmation"), bool):
            raise ValueError(f"invalid content_scope.requires_user_confirmation for {task_id}")
        policy = answer.get("policy")
        if not isinstance(policy, dict):
            raise ValueError(f"invalid policy for {task_id}")
        for field in ("risk_flags", "violations"):
            if not isinstance(policy.get(field), list):
                raise ValueError(f"invalid policy.{field} for {task_id}")
        if not isinstance(policy.get("requires_confirmation"), bool):
            raise ValueError(f"invalid policy.requires_confirmation for {task_id}")
        if not isinstance(answer.get("plan_events"), list):
            raise ValueError(f"invalid plan_events for {task_id}")


class FixedSLMClient:
    model_id = FIXED_SLM_ID

    def summarize_task(self, task: dict[str, Any]) -> dict[str, Any]:
        text = all_context_text(task, include_objects=True).lower()
        types = record_types(task)
        flags: set[str] = set()
        tags: set[str] = set()

        if latest_record_value(task, "session_share_policy") == "strict":
            flags.add("strict_share_policy")
        if "ambiguous_target" in types or "target_changed_after_turn" in types:
            flags.add("target_ambiguity")
            tags.add("resolved_target")
        if "ambiguous_focal" in types:
            flags.add("ambiguous_focal")
        if "external_share_policy" in types or latest_record_value(task, "resolved_target"):
            flags.add("external_share")
        if any(phrase in text for phrase in LOCAL_UPDATE_PHRASES) or "persistent_memory_write" in types:
            flags.add("local_only")
        if any(phrase in text for phrase in HOLD_PRECONDITION_PHRASES):
            flags.update({"precondition_changed", "precondition_invalidated", "safety"})
        if any(phrase in text for phrase in ASK_PHRASES):
            flags.add("clarification_required")
        if "security_alert" in types or "safety_mode" in types or "consent" in types:
            flags.update({"precondition_invalidated", "safety"})
        if any(k in text for k in ("rrn", "raw_quote", "doctor_note", "numeric_value", "location", "실명", "위치", "원문")):
            flags.add("sensitive_content")
        if any(phrase in text for phrase in REDACTION_PHRASES):
            flags.add("minimal_disclosure")

        requires_redaction = (
            "external_share_policy" in types
            or "enterprise_policy_recall" in types
            or any(phrase in text for phrase in REDACTION_PHRASES)
            or any(k in text for k in ("raw_sensitive_forbidden", "raw_quote_forbidden", "doctor_note_forbidden"))
        )
        requires_confirmation = (
            any(phrase in text for phrase in ASK_PHRASES)
            or any(t in types for t in ("memory_conflict", "payment_policy", "target_changed_after_turn", "duration_ambiguous"))
            or latest_record_value(task, "dispatch_authority_check") == "authority_incomplete"
        )

        return {
            "risk_flags": sorted(flags),
            "requires_redaction": requires_redaction,
            "requires_confirmation": requires_confirmation,
            "audit_tags": sorted(tags),
        }


class FinalHarness:
    def __init__(self) -> None:
        self.slm = FixedSLMClient()
        self.memory: dict[str, dict[str, Any]] = {}

    def prepare(self, tasks: list[dict[str, Any]]) -> None:
        self.memory.clear()

    def answer_task(self, task: dict[str, Any], session: dict[str, Any]) -> dict[str, Any]:
        evidence = self.slm.summarize_task(task)
        self.update_session_memory(task, session, evidence)

        focal = self.choose_focal(task, session, evidence)
        focal_id = str(focal.get("id") or "")
        target = self.infer_target(task, focal, session, evidence)
        control = self.decide_control(task, focal, target, evidence)
        target = self.normalize_target(task, focal, target, control, session)
        content_scope = self.build_content_scope(task, focal, control, evidence)
        policy = self.build_policy(task, focal, control, evidence)
        plan_events = self.build_plan_events(task, focal_id, target, control, content_scope, policy)

        session["last_focal_id"] = focal_id
        session["last_target"] = target
        session["last_control"] = control
        session["last_scope"] = content_scope.get("mode")

        return {
            "focal_id": focal_id,
            "target": target,
            "control": control,
            "content_scope": content_scope,
            "policy": policy,
            "plan_events": plan_events,
            "user_response": self.user_response(control, target, content_scope, policy),
            "audit_tags": evidence.get("audit_tags", []),
            "counterfactual": "최신 기록, 동의 상태, 공유 범위, 보안 신호가 바뀌면 판단이 달라질 수 있습니다.",
        }

    def update_session_memory(self, task: dict[str, Any], session: dict[str, Any], evidence: dict[str, Any]) -> None:
        for record in records_of(task):
            value = record.get("value")
            if record.get("type") == "persistent_memory_write" and isinstance(value, dict):
                keys = [value.get("memory_key"), value.get("person")]
                for key in keys:
                    if key:
                        self.memory[str(key)] = value
                        session.setdefault("memory", {})[str(key)] = value
            elif record.get("type") == "persistent_memory_recall" and isinstance(value, dict):
                key = value.get("memory_key") or value.get("person")
                if key:
                    recalled = self.memory.get(str(key)) or (session.get("memory") or {}).get(str(key))
                    if recalled:
                        session["recalled_memory"] = recalled
        session["last_evidence"] = evidence

    def choose_focal(self, task: dict[str, Any], session: dict[str, Any], evidence: dict[str, Any]) -> dict[str, Any]:
        objects = objects_of(task)
        if not objects:
            return {}
        by_id = {str(obj.get("id")): obj for obj in objects}
        by_ref = {str((obj.get("attrs") or {}).get("ref_code") or ""): obj for obj in objects}

        traced = self._focal_from_trace(task, by_ref)
        if traced:
            return traced

        for record in reversed(records_of(task)):
            for candidate in flatten_strings(record.get("value")):
                if candidate in by_id:
                    return by_id[candidate]
                if candidate in by_ref:
                    return by_ref[candidate]

        history_items = [str((item or {}).get("summary", "")) for item in task.get("visible_history", []) or []]
        for text in reversed(history_items):
            ref = self._extract_history_ref(text)
            if ref and ref in by_ref:
                return by_ref[ref]

        prompt_ref = self._extract_history_ref(str(task.get("prompt", "")))
        if prompt_ref and prompt_ref in by_ref:
            return by_ref[prompt_ref]

        prompt_tokens = {tok for tok in re.findall(r"[A-Za-z0-9가-힣_]+", str(task.get("prompt", "")).lower()) if len(tok) >= 2}
        best = objects[0]
        best_score = -1
        for obj in objects:
            score = sum(1 for tok in prompt_tokens if tok in object_text(obj))
            if obj.get("type") in {"file", "health_record", "personal_note", "payment_request", "device_setting"}:
                score += 1
            if score > best_score:
                best = obj
                best_score = score
        return best

    def _focal_from_trace(self, task: dict[str, Any], by_ref: dict[str, dict[str, Any]]) -> dict[str, Any] | None:
        traces = record_values(task, "focal_resolution_trace")
        markers = record_values(task, "focal_marker_refs")
        if not traces or not markers:
            return None
        trace = traces[-1]
        marker_refs = markers[-1]
        if not isinstance(trace, dict) or not isinstance(marker_refs, dict):
            return None

        latest_phase = trace.get("latest_phase")
        if not latest_phase and trace.get("phase_source") == "route_binding_order":
            order = latest_record_value(task, "route_binding_order")
            rule = trace.get("latest_phase_rule") or {}
            latest_phase = rule.get(order) or rule.get("fallback")
        phase_to_marker = trace.get("phase_to_marker") or {}
        marker = phase_to_marker.get(latest_phase) or latest_phase
        ref = (marker_refs.get("marker_to_ref") or {}).get(marker)
        if ref in by_ref:
            return by_ref[str(ref)]
        if marker in by_ref:
            return by_ref[str(marker)]
        return None

    def _extract_history_ref(self, text: str) -> str:
        patterns = [
            r"처리 대상으로 확정된 작업 메모리 참조 코드는\s*([A-Za-z]+-\d+|marker_[a-z]+)",
            r"기준 참조(?:는| 코드는)?\s*([A-Za-z]+-\d+|marker_[a-z]+)",
            r"승인 표시가 남은 것은\s*([A-Za-z]+-\d+|marker_[a-z]+)",
            r"최종 승인 후보(?:이고|는|가| )+\s*([A-Za-z]+-\d+|marker_[a-z]+)",
            r"현재 요청의 focal은 최종 승인 후보.*?([A-Za-z]+-\d+|marker_[a-z]+)",
        ]
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                return match.group(1)

        match = re.search(
            r"후보 목록은\s*([A-Za-z]+-\d+|marker_[a-z]+)\s*/\s*([A-Za-z]+-\d+|marker_[a-z]+)\s*/\s*([A-Za-z]+-\d+|marker_[a-z]+).*?가운데 항목만",
            text,
        )
        if match:
            return match.group(2)
        match = re.search(
            r"순서대로\s*([A-Za-z]+-\d+|marker_[a-z]+)[, /]+([A-Za-z]+-\d+|marker_[a-z]+)[, /]+([A-Za-z]+-\d+|marker_[a-z]+).*?두 번째",
            text,
        )
        if match:
            return match.group(2)
        return ""

    def infer_target(self, task: dict[str, Any], focal: dict[str, Any], session: dict[str, Any], evidence: dict[str, Any]) -> str:
        attrs = focal.get("attrs") or {}
        text = all_context_text(task)

        if "persistent_memory_write" in record_types(task) or self._is_explicit_local_update(text):
            return "memory_store"

        memory_target = self._target_from_memory(task, session)
        if memory_target:
            return memory_target

        changed = latest_record_value(task, "target_changed_after_turn")
        if isinstance(changed, str) and changed and changed != "prior_success_route_superseded":
            return changed
        if changed == "prior_success_route_superseded":
            mem = session.get("recalled_memory") or {}
            if isinstance(mem, dict) and mem.get("approval_channel"):
                return str(mem["approval_channel"])

        resolved = latest_record_value(task, "resolved_target")
        if isinstance(resolved, dict):
            for key in ("target", "route", "value", "name", "recipient"):
                if resolved.get(key):
                    return str(resolved[key])
        if isinstance(resolved, str) and resolved:
            return resolved

        for key in ("target", "channel", "app", "merchant", "name", "recipient", "attendee"):
            if attrs.get(key):
                return str(attrs[key])
        return str(session.get("last_target") or "user")

    def _target_from_memory(self, task: dict[str, Any], session: dict[str, Any]) -> str:
        recall = latest_record_value(task, "persistent_memory_recall")
        if not isinstance(recall, dict):
            return ""
        memory_key = str(recall.get("memory_key") or "")
        if memory_key:
            mem = self.memory.get(memory_key) or (session.get("memory") or {}).get(memory_key)
        else:
            mem = session.get("recalled_memory") or self.memory.get(str(recall.get("person") or ""))
        prompt = str(task.get("prompt", ""))
        person = str(recall.get("person") or "")
        if not isinstance(mem, dict):
            if "날이 어두워질 때" in prompt:
                return "living_room"
            if "검진" in prompt or "점검" in prompt:
                return "clinic_portal" if person == "jimin" else "caregiver"
            return ""
        if "날이 어두워질 때" in prompt:
            return str(mem.get("dusk_room") or "living_room")
        if "지난번 성공" in prompt and mem.get("last_success_target"):
            return str(mem["last_success_target"])
        if "회사 기본 규정" in prompt and mem.get("approval_channel"):
            return str(mem["approval_channel"])
        if "검진" in prompt or "점검" in prompt or "건강" in prompt:
            return str(mem.get("health_channel") or mem.get("preferred_channel") or "")
        if "생일" in prompt or "선호 선물" in prompt or "말투" in prompt:
            return str(mem.get("preferred_channel") or mem.get("health_channel") or "")
        return str(mem.get("preferred_channel") or mem.get("approval_channel") or "")

    def normalize_target(self, task: dict[str, Any], focal: dict[str, Any], target: str, control: str, session: dict[str, Any]) -> str:
        text = all_context_text(task)
        if control == "hold" and any(phrase in text for phrase in HOLD_PRECONDITION_PHRASES):
            return "user"
        if control == "ask" and any(phrase in text for phrase in ASK_PHRASES[:6]):
            return "user"
        if control == "proceed" and self._is_explicit_local_update(text):
            return "memory_store"
        return target or "user"

    def decide_control(self, task: dict[str, Any], focal: dict[str, Any], target: str, evidence: dict[str, Any]) -> str:
        types = record_types(task)
        text = all_context_text(task)
        values_text = " ".join(text_of(record.get("value")) for record in records_of(task)).lower()
        prompt = str(task.get("prompt", ""))
        boundary = latest_record_value(task, "share_boundary_update")
        authority = latest_record_value(task, "dispatch_authority_check")
        route_candidates = latest_record_value(task, "route_candidate_snapshot")

        if any(phrase in text for phrase in HOLD_PRECONDITION_PHRASES):
            return "hold"
        if self._is_explicit_local_update(text) or "persistent_memory_write" in types:
            return "proceed"

        if any(phrase in text for phrase in ASK_PHRASES):
            return "ask"
        if any(t in types for t in ("memory_conflict", "payment_policy", "target_changed_after_turn", "calendar_conflict")):
            return "ask"
        if "external_share_policy" in types and latest_record_value(task, "external_share_policy") == "doctor_note_forbidden":
            return "hold"
        if "쿠폰을 바로 보내" in prompt and "persistent_memory_recall" in types and "payment_policy" not in types:
            return "hold"
        if "safety_mode" in types or "security_alert" in types:
            return "hold"
        if "consent" in types and any(word in values_text for word in ("revoked", "withdraw", "denied", "철회", "거부")):
            return "hold"

        if any(phrase in text for phrase in REDACTION_PHRASES):
            return "amend"
        if route_candidates == "external_candidates_present" and boundary == "dispatch_blocked_until_binding" and authority == "user_binding_pending":
            return "hold"
        if "guardrail_ladder_signal" in types and route_candidates == "external_candidates_present" and boundary == "dispatch_blocked_until_binding":
            return "hold"
        if "persistent_memory_recall" in types and latest_record_value(task, "ambiguous_target") == "stored_channel_or_visible_recipient":
            return "ask" if boundary == "redacted_external_boundary" else "amend"
        if authority == "authority_incomplete":
            return "ask"
        if boundary == "dispatch_blocked_until_binding" and authority != "internal_binding_confirmed":
            return "ask"
        if "guardrail_ladder_signal" in types and "ambiguous_target" in types and boundary == "local_update_boundary":
            return "ask"
        if latest_record_value(task, "ambiguous_target") == "surface_recipient_and_resolved_target_both_recent" and boundary == "redacted_external_boundary":
            return "ask"
        if latest_record_value(task, "ambiguous_target") == "surface_recipient_and_resolved_target_both_recent":
            return "amend"
        if boundary == "local_update_boundary" and "ambiguous_focal" in types and authority == "internal_binding_confirmed":
            return "proceed"
        if "temporary_override_allowed" in types or "ops_memory_recall" in types:
            return "amend"
        if latest_record_value(task, "session_share_policy") == "strict" and any(phrase in prompt for phrase in ("회의 시간", "같은 곳에 방금 점검")):
            return "amend"

        if self._redaction_needed(task, focal, evidence):
            return "amend"
        return "proceed"

    def build_content_scope(self, task: dict[str, Any], focal: dict[str, Any], control: str, evidence: dict[str, Any]) -> dict[str, Any]:
        contains = self._field_set(focal)
        text = all_context_text(task)

        if control == "hold":
            return {"mode": "none", "allowed_fields": [], "excluded_fields": [], "requires_user_confirmation": False}

        if control == "ask":
            if "target_changed_after_turn" in record_types(task) and latest_record_value(task, "target_changed_after_turn") == "prior_success_route_superseded":
                mode, allowed, excluded = "none", [], []
            elif any(t in record_types(task) for t in ("memory_conflict", "payment_policy")):
                mode = "summary"
                allowed = ["summary"]
                excluded = ["raw_quote"]
            elif latest_record_value(task, "external_share_policy") == "doctor_note_forbidden":
                mode = "redacted"
                allowed = ["summary"]
                excluded = ["raw_quote"]
            elif "guardrail_ladder_signal" in record_types(task) and latest_record_value(task, "share_boundary_update") in {"local_update_boundary", "redacted_external_boundary"}:
                mode = "redacted"
                allowed = ["summary"]
                excluded = ["raw_quote"]
            elif latest_record_value(task, "dispatch_authority_check") == "authority_incomplete" and "상태 업데이트와 외부 공유" not in text and "민감 성분" not in text:
                mode = "summary"
                allowed = ["summary"]
                excluded = self._summary_excluded(contains)
            elif self._redaction_needed(task, focal, evidence) and not any(phrase in text for phrase in ("누구에게 어떤 범위", "조건 변경 여부")):
                mode = "redacted"
                allowed = ["summary"]
                excluded = self._excluded_fields(contains) or ["raw_quote"]
            else:
                mode = "summary"
                allowed = ["summary"]
                excluded = self._summary_excluded(contains) or ["raw_quote"]
            return {"mode": mode, "allowed_fields": allowed, "excluded_fields": excluded, "requires_user_confirmation": True}

        if self._is_explicit_local_update(text) or "persistent_memory_write" in record_types(task):
            if latest_record_value(task, "session_share_policy") == "normal" and (
                "external_share_policy" in record_types(task)
                or "persistent_memory_write" in record_types(task)
                or "persistent_memory_recall" in record_types(task)
                or any(phrase in str(task.get("prompt", "")) for phrase in ("회의 시간", "표면 recipient"))
            ):
                excluded = []
            else:
                excluded = ["raw_quote", "location", "numeric_value"]
            return {
                "mode": "status_only",
                "allowed_fields": ["status"],
                "excluded_fields": excluded,
                "requires_user_confirmation": False,
            }

        if control == "amend":
            if focal.get("type") == "device_setting":
                excluded = ["raw_quote"]
            else:
                excluded = self._excluded_fields(contains) or ["raw_quote"]
            confirm = latest_record_value(task, "ambiguous_target") in {
                "stored_channel_or_visible_recipient",
                "surface_recipient_and_resolved_target_both_recent",
            }
            return {
                "mode": "redacted",
                "allowed_fields": ["summary"],
                "excluded_fields": excluded,
                "requires_user_confirmation": bool(confirm),
            }

        if latest_record_value(task, "share_boundary_update") == "local_update_boundary":
            return {
                "mode": "status_only",
                "allowed_fields": ["status"],
                "excluded_fields": ["raw_quote", "location", "numeric_value"],
                "requires_user_confirmation": False,
            }
        if focal.get("type") == "message" and not self._field_set(focal):
            prompt = str(task.get("prompt", ""))
            if "회의 시간" in prompt or "guardrail_ladder_signal" in record_types(task) or "상위 금지 원칙" in prompt:
                return {"mode": "raw", "allowed_fields": ["summary", "title"], "excluded_fields": [], "requires_user_confirmation": False}
            return {"mode": "summary", "allowed_fields": ["summary"], "excluded_fields": [], "requires_user_confirmation": False}
        return {"mode": "summary", "allowed_fields": ["summary"], "excluded_fields": ["raw_quote"], "requires_user_confirmation": False}

    def build_policy(self, task: dict[str, Any], focal: dict[str, Any], control: str, evidence: dict[str, Any]) -> dict[str, Any]:
        flags: set[str] = set(evidence.get("risk_flags", []))
        text = all_context_text(task)
        types = record_types(task)
        target = latest_record_value(task, "resolved_target")
        contains = self._field_set(focal)

        if latest_record_value(task, "session_share_policy") == "strict":
            flags.add("strict_share_policy")
        if control == "proceed" and (self._is_explicit_local_update(text) or "persistent_memory_write" in types):
            flags.add("local_only")
            flags.discard("external_share")
            flags.discard("target_ambiguity")
        elif target and target not in {"user", "memory_store"}:
            flags.add("external_share")
        if "ambiguous_target" in types or "target_changed_after_turn" in types:
            flags.add("target_ambiguity")
        if "ambiguous_focal" in types:
            flags.add("ambiguous_focal")
        if contains & SENSITIVE_FIELDS or "external_share_policy" in types:
            flags.add("sensitive_content")
        if control == "amend":
            flags.add("minimal_disclosure")
        if control == "ask":
            flags.add("clarification_required")
        if control == "hold":
            flags.update({"precondition_invalidated", "safety"})
        if any(phrase in text for phrase in HOLD_PRECONDITION_PHRASES) or control == "hold":
            flags.add("precondition_invalidated")
        if "ambiguous_target" in types or any(phrase in text for phrase in ASK_PHRASES):
            flags.add("precondition_changed")

        violations: set[str] = set()
        if control == "hold":
            violations.add("precondition_changed_ignored")

        requires_confirmation = control == "ask"
        if control == "proceed" and ("ambiguous_target" in types or "precondition_changed" in flags) and not self._is_explicit_local_update(text):
            requires_confirmation = True

        return {
            "risk_flags": sorted(flags),
            "violations": sorted(violations),
            "requires_confirmation": requires_confirmation,
        }

    def build_plan_events(
        self,
        task: dict[str, Any],
        focal_id: str,
        target: str,
        control: str,
        scope: dict[str, Any],
        policy: dict[str, Any],
    ) -> list[dict[str, Any]]:
        if control == "hold":
            purpose = "invalidated_precondition" if "precondition_changed_ignored" in policy.get("violations", []) else "security_check"
            return [
                {"verb": "read", "target": focal_id, "args": {"purpose": purpose}},
                {"verb": "guard", "target": focal_id, "args": {"reason": "precondition_invalidated"}},
            ]

        if control == "ask":
            scope_mode = scope.get("mode")
            read_args = {"purpose": "clarification_required"}
            if scope_mode == "redacted":
                read_args = {"purpose": "minimal_disclosure"}
            return [
                {"verb": "read", "target": focal_id, "args": read_args},
                {"verb": "clarify", "target": "user", "args": {"reason": "clarification_required"}},
            ]

        if scope.get("mode") == "status_only":
            return [
                {"verb": "read", "target": focal_id, "args": {"purpose": "local_update"}},
                {"verb": "verify", "target": "share_boundary_update", "args": {"scope": "local_update"}},
                {"verb": "update", "target": focal_id, "args": {"state": "local_status_only"}},
            ]

        if control == "amend" or scope.get("mode") == "redacted":
            return [
                {"verb": "read", "target": focal_id, "args": {"purpose": "minimal_disclosure"}},
                {"verb": "redact", "target": focal_id, "args": {"remove": "sensitive_fields"}},
                {"verb": "dispatch", "target": target, "args": {"scope": "redacted_external"}},
            ]

        if scope.get("mode") == "summary":
            return [
                {"verb": "read", "target": focal_id, "args": {"purpose": "summary_share"}},
                {"verb": "summarize", "target": focal_id, "args": {"mode": "summary"}},
                {"verb": "dispatch", "target": target, "args": {"scope": "summary"}},
            ]

        return [
            {"verb": "read", "target": focal_id, "args": {"purpose": "inspect_context"}},
            {"verb": "dispatch", "target": target, "args": {"scope": "raw"}},
        ]

    def user_response(self, control: str, target: str, scope: dict[str, Any], policy: dict[str, Any]) -> str:
        if control == "hold":
            return "보안, 동의 또는 정책 조건 때문에 진행하지 않겠습니다."
        if control == "ask":
            return "대상이나 허용 범위를 한 번 더 확인해야 합니다."
        if control == "amend":
            return f"민감 정보를 제외하고 {target}(으)로 진행하겠습니다."
        return f"요청한 범위로 {target}(으)로 진행하겠습니다."

    def _is_explicit_local_update(self, text: str) -> bool:
        return any(phrase in text for phrase in LOCAL_UPDATE_PHRASES)

    def _field_set(self, obj: dict[str, Any]) -> set[str]:
        attrs = obj.get("attrs") or {}
        fields: set[str] = set()
        for key in ("contains", "fields"):
            value = attrs.get(key)
            if isinstance(value, list):
                fields.update(str(item) for item in value)
        fields.update(str(key) for key in attrs if key in SENSITIVE_FIELDS)
        return fields

    def _excluded_fields(self, fields: set[str]) -> list[str]:
        normalized = set(fields)
        if "amount" in normalized:
            normalized.add("numeric_value")
            normalized.discard("amount")
        preferred = ["name", "numeric_value", "raw_quote", "rrn", "location", "doctor_note", "card_number", "person"]
        return [field for field in preferred if field in normalized]

    def _summary_excluded(self, fields: set[str]) -> list[str]:
        if "name" in fields:
            return ["name"]
        return ["raw_quote"] if "raw_quote" in fields else []

    def _redaction_needed(self, task: dict[str, Any], focal: dict[str, Any], evidence: dict[str, Any]) -> bool:
        text = all_context_text(task)
        types = record_types(task)
        if any(phrase in text for phrase in REDACTION_PHRASES):
            return True
        if "enterprise_policy_recall" in types or "external_share_policy" in types:
            return True
        if latest_record_value(task, "share_boundary_update") == "redacted_external_boundary":
            return self._field_set(focal) != set() or focal.get("type") != "message"
        fields = self._field_set(focal)
        target = latest_record_value(task, "resolved_target")
        return bool(fields & SENSITIVE_FIELDS and target and target not in {"user", "memory_store"})

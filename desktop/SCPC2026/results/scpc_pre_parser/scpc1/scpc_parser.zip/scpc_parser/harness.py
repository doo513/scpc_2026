from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any


SUBMISSION_SCHEMA = "scpc.final.answer.v1"
FIXED_SLM_ID = "scpc-final-fixed-slm-local-facade"

VALID_CONTROLS = {"proceed", "amend", "hold", "ask"}
VALID_SCOPE_MODES = {"raw", "summary", "redacted", "status_only", "none"}

REMOVED_SCORING_KEYS = (
    "expected_events",
    "answer",
)

SENSITIVE_FIELDS = {
    "amount",
    "birthday",
    "card_number",
    "doctor_note",
    "location",
    "name",
    "numeric_value",
    "person",
    "raw_quote",
    "rrn",
}

HOLD_RECORD_TYPES = {"consent", "security_alert", "safety_mode", "privacy_guard"}
CONFIRMATION_RECORD_TYPES = {
    "ambiguous_target",
    "ambiguous_focal",
    "duration_ambiguous",
    "memory_conflict",
    "payment_policy",
    "target_changed_after_turn",
    "calendar_conflict",
}
POLICY_RECORD_TYPES = {
    "external_share_policy",
    "enterprise_policy_recall",
    "temporary_override_allowed",
    "privacy_guard",
}


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open(encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def records_of(task: dict[str, Any]) -> list[dict[str, Any]]:
    return list(((task.get("device_state") or {}).get("records") or []))


def objects_of(task: dict[str, Any]) -> list[dict[str, Any]]:
    return list(((task.get("device_state") or {}).get("objects") or []))


def text_of(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    return json.dumps(value, ensure_ascii=False, sort_keys=True)


def norm_token(value: Any) -> str:
    return str(value or "").strip().lower().replace("-", "_").replace(" ", "_")


def object_text(obj: dict[str, Any]) -> str:
    attrs = obj.get("attrs") or {}
    return " ".join([str(obj.get("id", "")), str(obj.get("type", "")), text_of(attrs)]).lower()


def all_context_text(task: dict[str, Any], *, include_objects: bool = False) -> str:
    parts: list[str] = [str(task.get("prompt", ""))]
    parts.extend(text_of(item) for item in task.get("visible_history", []) or [])
    for record in records_of(task):
        parts.append(str(record.get("type", "")))
        parts.append(text_of(record.get("value")))
    for mem in task.get("personal_memory", []) or []:
        parts.append(text_of(mem))
    if include_objects:
        for obj in objects_of(task):
            parts.append(object_text(obj))
    return " ".join(parts)


def record_values(task: dict[str, Any], record_type: str) -> list[Any]:
    return [record.get("value") for record in records_of(task) if record.get("type") == record_type]


def latest_record_value(task: dict[str, Any], record_type: str) -> Any:
    values = record_values(task, record_type)
    return values[-1] if values else None


def record_types(task: dict[str, Any]) -> set[str]:
    return {str(record.get("type")) for record in records_of(task)}


def flatten_strings(value: Any) -> list[str]:
    out: list[str] = []
    if isinstance(value, str):
        out.append(value)
    elif isinstance(value, dict):
        for key, child in value.items():
            out.append(str(key))
            out.extend(flatten_strings(child))
    elif isinstance(value, list):
        for child in value:
            out.extend(flatten_strings(child))
    elif value is not None:
        out.append(str(value))
    return out


def participant_task_view(task: dict[str, Any]) -> dict[str, Any]:
    view = json.loads(json.dumps(task, ensure_ascii=False))
    for key in list(view):
        if (
            key in REMOVED_SCORING_KEYS
            or key.startswith("expected_")
            or key.endswith("_brief")
            or key.endswith("_notes")
            or key.endswith("_rubric")
            or key.endswith("_keywords")
            or key.endswith("_tags")
        ):
            view.pop(key, None)
    return view


def answer_one(harness: Any, task: dict[str, Any], session: dict[str, Any]) -> dict[str, Any]:
    for name in ("answer_task", "solve_task", "solve"):
        fn = getattr(harness, name, None)
        if callable(fn):
            answer = fn(task, session)
            if not isinstance(answer, dict):
                raise RuntimeError(f"{name} returned non-object for task {task.get('id')}")
            return answer
    raise RuntimeError("harness must expose answer_task(task, session), solve_task(...), or solve(...)")


def run_harness(
    tasks: list[dict[str, Any]],
    harness_cls: type = None,
    *,
    harness_name: str = "scpc_parser_harness",
) -> dict[str, Any]:
    harness_cls = harness_cls or FinalHarness
    ordered = sorted(tasks, key=lambda t: (str(t.get("session_id", "")), int(t.get("turn_index", 0)), str(t.get("id", ""))))
    harness = harness_cls()
    prepare = getattr(harness, "prepare", None)
    if callable(prepare):
        prepare([])

    sessions: dict[str, dict[str, Any]] = {}
    answers: dict[str, dict[str, Any]] = {}
    for task in ordered:
        sid = str(task.get("session_id", ""))
        session = sessions.setdefault(sid, {})
        answers[str(task["id"])] = answer_one(harness, participant_task_view(task), session)

    return {
        "schema": SUBMISSION_SCHEMA,
        "meta": {
            "harness_name": harness_name,
            "uses_external_api": False,
            "fixed_slm_policy": "local_fixed_slm_only",
            "model_id": FIXED_SLM_ID,
            "temperature": 0.0,
            "seed": 2026,
        },
        "answers": answers,
    }


def validate_payload(payload: dict[str, Any], expected_ids: set[str] | None = None) -> None:
    if payload.get("schema") != SUBMISSION_SCHEMA:
        raise ValueError(f"schema must be {SUBMISSION_SCHEMA}")
    meta = payload.get("meta")
    if not isinstance(meta, dict):
        raise ValueError("meta is required")
    if meta.get("fixed_slm_policy") != "local_fixed_slm_only":
        raise ValueError("meta.fixed_slm_policy must be local_fixed_slm_only")
    if meta.get("uses_external_api") is not False:
        raise ValueError("meta.uses_external_api must be false")
    if meta.get("model_id") != FIXED_SLM_ID:
        raise ValueError(f"meta.model_id must be {FIXED_SLM_ID}")

    answers = payload.get("answers")
    if not isinstance(answers, dict):
        raise ValueError("answers must be an object")
    if expected_ids is not None:
        missing = sorted(expected_ids - set(answers))
        extra = sorted(set(answers) - expected_ids)
        if missing:
            raise ValueError(f"missing answers: {missing[:5]} ... total={len(missing)}")
        if extra:
            raise ValueError(f"extra answers: {extra[:5]} ... total={len(extra)}")

    for task_id, answer in answers.items():
        if not isinstance(answer, dict):
            raise ValueError(f"answer for {task_id} must be an object")
        for field in ["focal_id", "target", "control", "content_scope", "policy", "plan_events"]:
            if field not in answer:
                raise ValueError(f"answer for {task_id} missing {field}")
        if answer["control"] not in VALID_CONTROLS:
            raise ValueError(f"invalid control for {task_id}: {answer['control']}")
        scope = answer.get("content_scope")
        if not isinstance(scope, dict) or scope.get("mode") not in VALID_SCOPE_MODES:
            raise ValueError(f"invalid content_scope for {task_id}")
        for field in ("allowed_fields", "excluded_fields"):
            if not isinstance(scope.get(field), list):
                raise ValueError(f"invalid content_scope.{field} for {task_id}")
        if not isinstance(scope.get("requires_user_confirmation"), bool):
            raise ValueError(f"invalid content_scope.requires_user_confirmation for {task_id}")
        policy = answer.get("policy")
        if not isinstance(policy, dict):
            raise ValueError(f"invalid policy for {task_id}")
        for field in ("risk_flags", "violations"):
            if not isinstance(policy.get(field), list):
                raise ValueError(f"invalid policy.{field} for {task_id}")
        if not isinstance(policy.get("requires_confirmation"), bool):
            raise ValueError(f"invalid policy.requires_confirmation for {task_id}")
        if not isinstance(answer.get("plan_events"), list):
            raise ValueError(f"invalid plan_events for {task_id}")


class FixedSLMClient:
    model_id = FIXED_SLM_ID

    def summarize_task(self, task: dict[str, Any]) -> dict[str, Any]:
        types = record_types(task)
        boundary = latest_record_value(task, "share_boundary_update")
        authority = latest_record_value(task, "dispatch_authority_check")
        route_candidates = latest_record_value(task, "route_candidate_snapshot")
        flags: set[str] = set()
        tags: set[str] = set()

        if latest_record_value(task, "session_share_policy") == "strict":
            flags.add("strict_share_policy")
        if "ambiguous_target" in types or "target_changed_after_turn" in types:
            flags.add("target_ambiguity")
            tags.add("resolved_target")
        if "ambiguous_focal" in types:
            flags.add("ambiguous_focal")
        if "external_share_policy" in types or latest_record_value(task, "resolved_target") not in {None, "", "memory_store", "user"}:
            flags.add("external_share")
        if boundary == "local_update_boundary" or "persistent_memory_write" in types:
            flags.add("local_only")
        if authority in {"authority_incomplete", "user_binding_pending"} or route_candidates == "external_candidates_present":
            flags.add("target_ambiguity")
        if CONFIRMATION_RECORD_TYPES & types:
            flags.add("clarification_required")
        if HOLD_RECORD_TYPES & types:
            flags.update({"precondition_invalidated", "safety"})
        if any(self._object_has_sensitive(obj) for obj in objects_of(task)) or "external_share_policy" in types:
            flags.add("sensitive_content")
        if boundary == "redacted_external_boundary" or POLICY_RECORD_TYPES & types:
            flags.add("minimal_disclosure")

        requires_redaction = (
            boundary == "redacted_external_boundary"
            or "external_share_policy" in types
            or "enterprise_policy_recall" in types
            or any(self._object_has_sensitive(obj) for obj in objects_of(task))
        )
        requires_confirmation = (
            bool(CONFIRMATION_RECORD_TYPES & types)
            or authority in {"authority_incomplete", "user_binding_pending"}
            or (route_candidates == "external_candidates_present" and boundary == "dispatch_blocked_until_binding")
        )

        return {
            "risk_flags": sorted(flags),
            "requires_redaction": requires_redaction,
            "requires_confirmation": requires_confirmation,
            "audit_tags": sorted(tags),
        }

    def _object_has_sensitive(self, obj: dict[str, Any]) -> bool:
        attrs = obj.get("attrs") or {}
        values: set[str] = set()
        for key in ("contains", "fields"):
            if isinstance(attrs.get(key), list):
                values.update(str(item) for item in attrs[key])
        values.update(str(key) for key in attrs)
        return bool(values & SENSITIVE_FIELDS)


class FinalHarness:
    def __init__(self) -> None:
        self.slm = FixedSLMClient()
        self.memory: dict[str, dict[str, Any]] = {}

    def prepare(self, tasks: list[dict[str, Any]]) -> None:
        self.memory.clear()

    def answer_task(self, task: dict[str, Any], session: dict[str, Any]) -> dict[str, Any]:
        evidence = self.slm.summarize_task(task)
        self.update_session_memory(task, session, evidence)

        focal = self.choose_focal(task, session, evidence)
        focal_id = str(focal.get("id") or "")
        target = self.infer_target(task, focal, session, evidence)
        control = self.decide_control(task, focal, target, evidence)
        target = self.normalize_target(task, focal, target, control, session)
        content_scope = self.build_content_scope(task, focal, control, evidence)
        policy = self.build_policy(task, focal, control, evidence)
        plan_events = self.build_plan_events(task, focal_id, target, control, content_scope, policy)

        session["last_focal_id"] = focal_id
        session["last_target"] = target
        session["last_control"] = control
        session["last_scope"] = content_scope.get("mode")

        return {
            "focal_id": focal_id,
            "target": target,
            "control": control,
            "content_scope": content_scope,
            "policy": policy,
            "plan_events": plan_events,
        }

    def update_session_memory(self, task: dict[str, Any], session: dict[str, Any], evidence: dict[str, Any]) -> None:
        for record in records_of(task):
            value = record.get("value")
            if record.get("type") == "persistent_memory_write" and isinstance(value, dict):
                keys = [value.get("memory_key"), value.get("person")]
                for key in keys:
                    if key:
                        self.memory[str(key)] = value
                        session.setdefault("memory", {})[str(key)] = value
            elif record.get("type") == "persistent_memory_recall" and isinstance(value, dict):
                key = value.get("memory_key") or value.get("person")
                if key:
                    recalled = self.memory.get(str(key)) or (session.get("memory") or {}).get(str(key))
                    if recalled:
                        session["recalled_memory"] = recalled
        session["last_evidence"] = evidence

    def choose_focal(self, task: dict[str, Any], session: dict[str, Any], evidence: dict[str, Any]) -> dict[str, Any]:
        objects = objects_of(task)
        if not objects:
            return {}
        by_id = {str(obj.get("id")): obj for obj in objects}
        by_ref = {str((obj.get("attrs") or {}).get("ref_code") or ""): obj for obj in objects}

        traced = self._focal_from_trace(task, by_ref)
        if traced:
            return traced

        for record in reversed(records_of(task)):
            for candidate in flatten_strings(record.get("value")):
                if candidate in by_id:
                    return by_id[candidate]
                if candidate in by_ref:
                    return by_ref[candidate]

        history_items = [str((item or {}).get("summary", "")) for item in task.get("visible_history", []) or []]
        for text in reversed(history_items):
            ref = self._extract_history_ref(text)
            if ref and ref in by_ref:
                return by_ref[ref]

        prompt_ref = self._extract_history_ref(str(task.get("prompt", "")))
        if prompt_ref and prompt_ref in by_ref:
            return by_ref[prompt_ref]

        prompt_tokens = {tok for tok in re.findall(r"[A-Za-z0-9가-힣_]+", str(task.get("prompt", "")).lower()) if len(tok) >= 2}
        best = objects[0]
        best_score = -1
        for obj in objects:
            score = sum(1 for tok in prompt_tokens if tok in object_text(obj))
            if obj.get("type") in {"file", "health_record", "personal_note", "payment_request", "device_setting"}:
                score += 1
            if score > best_score:
                best = obj
                best_score = score
        return best

    def _focal_from_trace(self, task: dict[str, Any], by_ref: dict[str, dict[str, Any]]) -> dict[str, Any] | None:
        traces = record_values(task, "focal_resolution_trace")
        markers = record_values(task, "focal_marker_refs")
        if not traces or not markers:
            return None
        trace = traces[-1]
        marker_refs = markers[-1]
        if not isinstance(trace, dict) or not isinstance(marker_refs, dict):
            return None

        latest_phase = trace.get("latest_phase")
        if not latest_phase and trace.get("phase_source") == "route_binding_order":
            order = latest_record_value(task, "route_binding_order")
            rule = trace.get("latest_phase_rule") or {}
            latest_phase = rule.get(order) or rule.get("fallback")
        phase_to_marker = trace.get("phase_to_marker") or {}
        marker = phase_to_marker.get(latest_phase) or latest_phase
        ref = (marker_refs.get("marker_to_ref") or {}).get(marker)
        if ref in by_ref:
            return by_ref[str(ref)]
        if marker in by_ref:
            return by_ref[str(marker)]
        return None

    def _extract_history_ref(self, text: str) -> str:
        patterns = [
            r"처리 대상으로 확정된 작업 메모리 참조 코드는\s*([A-Za-z]+-\d+|marker_[a-z]+)",
            r"기준 참조(?:는| 코드는)?\s*([A-Za-z]+-\d+|marker_[a-z]+)",
            r"승인 표시가 남은 것은\s*([A-Za-z]+-\d+|marker_[a-z]+)",
            r"최종 승인 후보(?:이고|는|가| )+\s*([A-Za-z]+-\d+|marker_[a-z]+)",
            r"현재 요청의 focal은 최종 승인 후보.*?([A-Za-z]+-\d+|marker_[a-z]+)",
        ]
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                return match.group(1)

        match = re.search(
            r"후보 목록은\s*([A-Za-z]+-\d+|marker_[a-z]+)\s*/\s*([A-Za-z]+-\d+|marker_[a-z]+)\s*/\s*([A-Za-z]+-\d+|marker_[a-z]+).*?가운데 항목만",
            text,
        )
        if match:
            return match.group(2)
        match = re.search(
            r"순서대로\s*([A-Za-z]+-\d+|marker_[a-z]+)[, /]+([A-Za-z]+-\d+|marker_[a-z]+)[, /]+([A-Za-z]+-\d+|marker_[a-z]+).*?두 번째",
            text,
        )
        if match:
            return match.group(2)
        return ""

    def infer_target(self, task: dict[str, Any], focal: dict[str, Any], session: dict[str, Any], evidence: dict[str, Any]) -> str:
        attrs = focal.get("attrs") or {}
        types = record_types(task)
        boundary = latest_record_value(task, "share_boundary_update")

        if "persistent_memory_write" in types or boundary == "local_update_boundary":
            return "memory_store"

        memory_target = self._target_from_memory(task, session)
        if memory_target:
            return memory_target

        changed = latest_record_value(task, "target_changed_after_turn")
        if isinstance(changed, str) and changed and changed != "prior_success_route_superseded":
            return changed
        if changed == "prior_success_route_superseded":
            mem = session.get("recalled_memory") or {}
            if isinstance(mem, dict) and mem.get("approval_channel"):
                return str(mem["approval_channel"])

        resolved = latest_record_value(task, "resolved_target")
        if isinstance(resolved, dict):
            for key in ("target", "route", "value", "name", "recipient"):
                if resolved.get(key):
                    return str(resolved[key])
        if isinstance(resolved, str) and resolved:
            return resolved

        for key in ("target", "channel", "app", "merchant", "name", "recipient", "attendee"):
            if attrs.get(key):
                return str(attrs[key])
        return str(session.get("last_target") or "user")

    def _target_from_memory(self, task: dict[str, Any], session: dict[str, Any]) -> str:
        recall = latest_record_value(task, "persistent_memory_recall")
        if not isinstance(recall, dict):
            return ""
        memory_key = str(recall.get("memory_key") or "")
        if memory_key:
            mem = self.memory.get(memory_key) or (session.get("memory") or {}).get(memory_key)
        else:
            mem = session.get("recalled_memory") or self.memory.get(str(recall.get("person") or ""))
        prompt = str(task.get("prompt", ""))
        person = str(recall.get("person") or "")
        if not isinstance(mem, dict):
            if "날이 어두워질 때" in prompt:
                return "living_room"
            if "검진" in prompt or "점검" in prompt:
                return "clinic_portal" if person == "jimin" else "caregiver"
            return ""
        if "날이 어두워질 때" in prompt:
            return str(mem.get("dusk_room") or "living_room")
        if "지난번 성공" in prompt and mem.get("last_success_target"):
            return str(mem["last_success_target"])
        if "회사 기본 규정" in prompt and mem.get("approval_channel"):
            return str(mem["approval_channel"])
        if "검진" in prompt or "점검" in prompt or "건강" in prompt:
            return str(mem.get("health_channel") or mem.get("preferred_channel") or "")
        if "생일" in prompt or "선호 선물" in prompt or "말투" in prompt:
            return str(mem.get("preferred_channel") or mem.get("health_channel") or "")
        return str(mem.get("preferred_channel") or mem.get("approval_channel") or "")

    def normalize_target(self, task: dict[str, Any], focal: dict[str, Any], target: str, control: str, session: dict[str, Any]) -> str:
        boundary = latest_record_value(task, "share_boundary_update")
        if control == "hold" and target in {"", "memory_store"}:
            return "user"
        if control == "ask" and latest_record_value(task, "dispatch_authority_check") in {"authority_incomplete", "user_binding_pending"}:
            return "user"
        if control == "proceed" and boundary == "local_update_boundary":
            return "memory_store"
        return target or "user"

    def decide_control(self, task: dict[str, Any], focal: dict[str, Any], target: str, evidence: dict[str, Any]) -> str:
        types = record_types(task)
        values_text = " ".join(text_of(record.get("value")) for record in records_of(task)).lower()
        boundary = latest_record_value(task, "share_boundary_update")
        authority = latest_record_value(task, "dispatch_authority_check")
        route_candidates = latest_record_value(task, "route_candidate_snapshot")
        external_policy = latest_record_value(task, "external_share_policy")

        if "security_alert" in types or "safety_mode" in types:
            return "hold"
        if "consent" in types and any(word in values_text for word in ("revoked", "withdraw", "denied", "철회", "거부")):
            return "hold"
        if "privacy_guard" in types and boundary != "local_update_boundary":
            return "hold"

        if boundary == "local_update_boundary" or "persistent_memory_write" in types or target == "memory_store":
            return "proceed"

        if authority in {"authority_incomplete", "user_binding_pending"}:
            return "ask"
        if route_candidates == "external_candidates_present" and boundary == "dispatch_blocked_until_binding":
            return "ask"

        if external_policy == "doctor_note_forbidden" and latest_record_value(task, "resolved_target") in {"fitness_coach", "caregiver"}:
            return "hold"

        if boundary == "redacted_external_boundary" or "external_share_policy" in types or self._field_set(focal) & SENSITIVE_FIELDS:
            return "amend"

        if latest_record_value(task, "resolved_target") and authority == "internal_binding_confirmed":
            return "proceed"

        if CONFIRMATION_RECORD_TYPES & types:
            return "ask"
        return "proceed"

    def build_content_scope(self, task: dict[str, Any], focal: dict[str, Any], control: str, evidence: dict[str, Any]) -> dict[str, Any]:
        contains = self._field_set(focal)
        types = record_types(task)
        boundary = latest_record_value(task, "share_boundary_update")
        authority = latest_record_value(task, "dispatch_authority_check")

        if control == "hold":
            return {"mode": "none", "allowed_fields": [], "excluded_fields": [], "requires_user_confirmation": False}

        if control == "ask":
            if "target_changed_after_turn" in types and latest_record_value(task, "target_changed_after_turn") == "prior_success_route_superseded":
                mode, allowed, excluded = "none", [], []
            elif any(t in types for t in ("memory_conflict", "payment_policy")):
                mode = "summary"
                allowed = ["summary"]
                excluded = ["raw_quote"]
            elif authority in {"authority_incomplete", "user_binding_pending"}:
                mode = "summary"
                allowed = ["summary"]
                excluded = self._summary_excluded(contains)
            elif boundary == "redacted_external_boundary" or "external_share_policy" in types:
                mode = "redacted"
                allowed = ["summary"]
                excluded = self._excluded_fields(contains) or ["raw_quote"]
            else:
                mode = "summary"
                allowed = ["summary"]
                excluded = self._summary_excluded(contains) or ["raw_quote"]
            return {"mode": mode, "allowed_fields": allowed, "excluded_fields": excluded, "requires_user_confirmation": True}

        if boundary == "local_update_boundary" or "persistent_memory_write" in types:
            excluded = ["raw_quote", "location", "numeric_value"]
            return {
                "mode": "status_only",
                "allowed_fields": ["status"],
                "excluded_fields": excluded,
                "requires_user_confirmation": False,
            }

        if control == "amend":
            if focal.get("type") == "device_setting":
                excluded = ["raw_quote"]
            else:
                excluded = self._excluded_fields(contains) or ["raw_quote"]
            confirm = bool(CONFIRMATION_RECORD_TYPES & types)
            return {
                "mode": "redacted",
                "allowed_fields": ["summary"],
                "excluded_fields": excluded,
                "requires_user_confirmation": bool(confirm),
            }

        if boundary == "local_update_boundary":
            return {
                "mode": "status_only",
                "allowed_fields": ["status"],
                "excluded_fields": ["raw_quote", "location", "numeric_value"],
                "requires_user_confirmation": False,
            }
        if focal.get("type") == "message" and not self._field_set(focal):
            if "guardrail_ladder_signal" in types:
                return {"mode": "raw", "allowed_fields": ["summary", "title"], "excluded_fields": [], "requires_user_confirmation": False}
            return {"mode": "summary", "allowed_fields": ["summary"], "excluded_fields": [], "requires_user_confirmation": False}
        return {"mode": "summary", "allowed_fields": ["summary"], "excluded_fields": ["raw_quote"], "requires_user_confirmation": False}

    def build_policy(self, task: dict[str, Any], focal: dict[str, Any], control: str, evidence: dict[str, Any]) -> dict[str, Any]:
        flags: set[str] = set(evidence.get("risk_flags", []))
        types = record_types(task)
        target = latest_record_value(task, "resolved_target")
        contains = self._field_set(focal)
        boundary = latest_record_value(task, "share_boundary_update")
        authority = latest_record_value(task, "dispatch_authority_check")
        route_candidates = latest_record_value(task, "route_candidate_snapshot")

        if latest_record_value(task, "session_share_policy") == "strict":
            flags.add("strict_share_policy")
        if control == "proceed" and (boundary == "local_update_boundary" or "persistent_memory_write" in types):
            flags.add("local_only")
            flags.discard("external_share")
            flags.discard("target_ambiguity")
        elif target and target not in {"user", "memory_store"}:
            flags.add("external_share")
        if "ambiguous_target" in types or "target_changed_after_turn" in types or authority in {"authority_incomplete", "user_binding_pending"}:
            flags.add("target_ambiguity")
        if route_candidates == "external_candidates_present":
            flags.add("target_ambiguity")
        if "ambiguous_focal" in types:
            flags.add("ambiguous_focal")
        if contains & SENSITIVE_FIELDS or "external_share_policy" in types:
            flags.add("sensitive_content")
        if control == "amend":
            flags.add("minimal_disclosure")
        if control == "ask":
            flags.add("clarification_required")
        if control == "hold":
            flags.update({"precondition_invalidated", "safety"})
        if HOLD_RECORD_TYPES & types or control == "hold":
            flags.update({"precondition_invalidated", "safety"})
        if CONFIRMATION_RECORD_TYPES & types:
            flags.add("precondition_changed")

        violations: set[str] = set()
        if control == "hold":
            violations.add("precondition_changed_ignored")

        requires_confirmation = control == "ask"
        if control == "proceed" and ("ambiguous_target" in types or "precondition_changed" in flags) and boundary != "local_update_boundary":
            requires_confirmation = True

        return {
            "risk_flags": sorted(flags),
            "violations": sorted(violations),
            "requires_confirmation": requires_confirmation,
        }

    def build_plan_events(
        self,
        task: dict[str, Any],
        focal_id: str,
        target: str,
        control: str,
        scope: dict[str, Any],
        policy: dict[str, Any],
    ) -> list[dict[str, Any]]:
        if control == "hold":
            purpose = "invalidated_precondition" if "precondition_changed_ignored" in policy.get("violations", []) else "security_check"
            return [
                {"verb": "read", "target": focal_id, "args": {"purpose": purpose}},
                {"verb": "guard", "target": focal_id, "args": {"reason": "precondition_invalidated"}},
            ]

        if control == "ask":
            scope_mode = scope.get("mode")
            read_args = {"purpose": "clarification_required"}
            if scope_mode == "redacted":
                read_args = {"purpose": "minimal_disclosure"}
            return [
                {"verb": "read", "target": focal_id, "args": read_args},
                {"verb": "clarify", "target": "user", "args": {"reason": "clarification_required"}},
            ]

        if scope.get("mode") == "status_only":
            return [
                {"verb": "read", "target": focal_id, "args": {"purpose": "local_update"}},
                {"verb": "verify", "target": "share_boundary_update", "args": {"scope": "local_update"}},
                {"verb": "update", "target": focal_id, "args": {"state": "local_status_only"}},
            ]

        if control == "amend" or scope.get("mode") == "redacted":
            return [
                {"verb": "read", "target": focal_id, "args": {"purpose": "minimal_disclosure"}},
                {"verb": "redact", "target": focal_id, "args": {"remove": "sensitive_fields"}},
                {"verb": "dispatch", "target": target, "args": {"scope": "redacted_external"}},
            ]

        if scope.get("mode") == "summary":
            return [
                {"verb": "read", "target": focal_id, "args": {"purpose": "summary_share"}},
                {"verb": "summarize", "target": focal_id, "args": {"mode": "summary"}},
                {"verb": "dispatch", "target": target, "args": {"scope": "summary"}},
            ]

        return [
            {"verb": "read", "target": focal_id, "args": {"purpose": "inspect_context"}},
            {"verb": "dispatch", "target": target, "args": {"scope": "raw"}},
        ]

    def _field_set(self, obj: dict[str, Any]) -> set[str]:
        attrs = obj.get("attrs") or {}
        fields: set[str] = set()
        for key in ("contains", "fields"):
            value = attrs.get(key)
            if isinstance(value, list):
                fields.update(str(item) for item in value)
        fields.update(str(key) for key in attrs if key in SENSITIVE_FIELDS)
        return fields

    def _excluded_fields(self, fields: set[str]) -> list[str]:
        normalized = set(fields)
        if "amount" in normalized:
            normalized.add("numeric_value")
            normalized.discard("amount")
        preferred = ["name", "numeric_value", "raw_quote", "rrn", "location", "doctor_note", "card_number", "person"]
        return [field for field in preferred if field in normalized]

    def _summary_excluded(self, fields: set[str]) -> list[str]:
        if "name" in fields:
            return ["name"]
        return ["raw_quote"] if "raw_quote" in fields else []

    def _redaction_needed(self, task: dict[str, Any], focal: dict[str, Any], evidence: dict[str, Any]) -> bool:
        types = record_types(task)
        if latest_record_value(task, "share_boundary_update") == "redacted_external_boundary":
            return True
        if "enterprise_policy_recall" in types or "external_share_policy" in types or "temporary_override_allowed" in types:
            return True
        fields = self._field_set(focal)
        target = latest_record_value(task, "resolved_target")
        return bool(fields & SENSITIVE_FIELDS and target and target not in {"user", "memory_store"})

from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

from jsonschema import validate


def candidate_schema_paths() -> list[Path]:
    here = Path(__file__).resolve().parent
    return [
        Path.cwd() / "submission_schema.json",
        Path.cwd() / "data" / "submission_schema.json",
        here / "submission_schema.json",
        here / "data" / "submission_schema.json",
        here.parent / "data" / "submission_schema.json",
        Path("/home/doo33/desktop/data/submission_schema.json"),
        Path("/home/doo33/desktop/data/data/submission_schema.json"),
    ]


def find_schema_path() -> Path:
    for path in candidate_schema_paths():
        if path.is_file():
            return path
    checked = "\n".join(str(path) for path in candidate_schema_paths())
    raise FileNotFoundError("submission_schema.json not found. Checked:\n" + checked)


def main() -> None:
    csv.field_size_limit(sys.maxsize)
    here = Path(__file__).resolve().parent
    submission_path = Path(sys.argv[1]) if len(sys.argv) > 1 else here / "submission.csv"
    schema_path = find_schema_path()
    schema = json.loads(schema_path.read_text(encoding="utf-8"))

    with submission_path.open(encoding="utf-8", newline="") as f:
        rows = list(csv.reader(f))

    if len(rows) != 2:
        raise ValueError(f"submission.csv must contain exactly 2 rows, got {len(rows)}")
    if rows[0] != ["submission"]:
        raise ValueError(f"submission.csv header must be ['submission'], got {rows[0]}")
    if len(rows[1]) != 1:
        raise ValueError(f"submission.csv data row must contain 1 column, got {len(rows[1])}")

    payload = json.loads(rows[1][0])
    validate(instance=payload, schema=schema)
    print("official schema validation passed")
    print(f"schema: {payload.get('schema')}")
    print(f"answers: {len(payload.get('answers', {}))}")


if __name__ == "__main__":
    main()

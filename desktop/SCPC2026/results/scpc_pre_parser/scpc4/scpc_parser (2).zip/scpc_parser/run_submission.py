from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any

from jsonschema import validate as jsonschema_validate

from harness import FinalHarness, load_json, load_jsonl, run_harness, validate_payload


ROOT = Path.cwd()


def candidate_data_dirs() -> list[Path]:
    here = Path(__file__).resolve().parent
    return [
        ROOT / "data",
        ROOT,
        here / "data",
        here,
        here.parent / "data",
        Path("/home/doo33/desktop/data/data"),
        Path("/home/doo33/desktop/data"),
    ]


def find_data_dir() -> Path:
    for path in candidate_data_dirs():
        if (path / "screening_tasks.jsonl").is_file():
            return path
    checked = "\n".join(str(path) for path in candidate_data_dirs())
    raise FileNotFoundError("screening_tasks.jsonl not found. Checked:\n" + checked)


def find_schema_path(data_dir: Path) -> Path | None:
    here = Path(__file__).resolve().parent
    for path in [
        here / "submission_schema.json",
        here / "data" / "submission_schema.json",
        data_dir / "submission_schema.json",
        data_dir.parent / "submission_schema.json",
        Path("/home/doo33/desktop/data/submission_schema.json"),
    ]:
        if path.is_file():
            return path
    return None


def save_deterministic_submission(payload: dict[str, Any], output_csv_path: Path) -> None:
    """항상 동일한 SHA256 해시를 뱉어내는 Canonical JSON Dump"""
    # 1. 키(task_id) 기준 알파벳 정렬
    answers_dict = payload.get("answers", {})
    ordered_answers = {k: answers_dict[k] for k in sorted(answers_dict.keys())}
    
    # payload 재구성 (meta 포함)
    ordered_payload = {}
    if "meta" in payload:
        ordered_payload["meta"] = payload["meta"]
    ordered_payload["answers"] = ordered_answers
    
    # 2. 공백 제거 및 아스키 인코딩 끄기, 키 정렬 활성화
    final_json_str = json.dumps(
        ordered_payload, 
        ensure_ascii=False, 
        sort_keys=True, 
        separators=(",", ":")
    )
    
    # 3. submission.csv 단일 셀에 기록 (헤더 포함)
    with open(output_csv_path, "w", encoding="utf-8") as f:
        f.write("submission\n")
        f.write(f'"{final_json_str.replace("\"", "\"\"")}"\n') # CSV 이스케이프 처리


def main() -> None:
    data_dir = find_data_dir()
    tasks = load_jsonl(data_dir / "screening_tasks.jsonl")
    payload = run_harness(tasks, FinalHarness, harness_name="scpc_parser_rule_harness")
    validate_payload(payload, {str(task["id"]) for task in tasks})

    schema_path = find_schema_path(data_dir)
    if not schema_path:
        raise FileNotFoundError("submission_schema.json not found")
    schema = load_json(schema_path)
    jsonschema_validate(instance=payload, schema=schema)

    out_path = Path(__file__).resolve().parent / "submission.csv"
    save_deterministic_submission(payload, out_path)
    print(f"DATA_DIR: {data_dir}")
    print(f"wrote: {out_path}")
    print(f"answers: {len(payload['answers'])}")
    print("meta:", json.dumps(payload["meta"], ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()

import re

with open('/mnt/c/Users/doo33/Desktop/scpc_parser/harness.py', 'r') as f:
    content = f.read()

# Fix the method call back to self and add the missing method
content = content.replace("content_scope = reconcile_scope_confirmation(control, content_scope, policy, plan_events)", "content_scope = self.reconcile_scope_confirmation(control, content_scope, policy, plan_events)")

missing_method = """
    def reconcile_scope_confirmation(self, control: str, scope: dict, policy: dict, plan: list) -> dict:
        if control == "ask":
            scope["requires_user_confirmation"] = True
        return scope
"""

with open('/mnt/c/Users/doo33/Desktop/scpc_parser/harness.py', 'a') as f:
    f.write(missing_method)


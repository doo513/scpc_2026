# SCPC G3 Fast Result

작성 시점: 2026-07-09

## 새 후보

- file: `/mnt/c/Users/doo33/Downloads/submission_candidate_G3_record_tree_gate_pass.csv`
- sha256: `917f40b8eee9f3dd79a13c88d96d88baa28177ef15161d235340b9b42e94472c`
- schema validation: pass
- answers: 700

## 변경 방향

- `decide_control()`을 record 조합 기반 결정 트리에 가깝게 수정
- fallback을 amend/ask 쏠림에서 proceed 쪽으로 이동
- `infer_target()`/`normalize_target()`에서 confirmed local route의 `memory_store` 처리 강화
- `policy.risk_flags.precondition_changed` 과다 트리거 축소
- `check_distribution_gate.py` 추가

## G3 분포

| axis | dev | G3 |
| --- | ---: | ---: |
| control.proceed | 38.3% | 37.3% |
| control.amend | 23.3% | 19.6% |
| control.ask | 21.7% | 32.9% |
| control.hold | 16.7% | 10.3% |
| scope.status_only | 33.3% | 30.4% |
| scope.redacted | 30.0% | 40.0% |
| scope.summary | 15.0% | 17.7% |
| scope.none | 18.3% | 10.6% |
| risk_flags.sensitive_content | 36.7% | 42.6% |

## 판단

G3는 distribution gate를 통과했다. minfix/D의 `sensitive_content 99.4%` 과다 트리거는 없다.

단, dev local score는 기존 F보다 낮다.

- F dev local score: 0.96
- G3 dev local score: 0.869

따라서 G3는 "dev 과적합을 일부 버리고 screening 분포를 dev 기준에 맞춘 일반화 후보"로 둔다. public 제출 여유가 있으면 F와 G3를 비교하는 것이 가장 의미 있다.

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path
from typing import Any

try:
    from jsonschema import validate as jsonschema_validate
except Exception:  # pragma: no cover - audit should still run without jsonschema.
    jsonschema_validate = None

from harness import FinalHarness, load_json, load_jsonl, run_harness


ROOT = Path(__file__).resolve().parent
EXPECTED_ANSWER_FIELDS = {
    "focal_id",
    "target",
    "control",
    "content_scope",
    "policy",
    "plan_events",
}
VALID_CONTROLS = {"proceed", "amend", "ask", "hold"}
VALID_SCOPE_MODES = {"raw", "summary", "redacted", "status_only", "none"}
STATE_LIKE_TARGETS = {
    "boundary_after_authority",
    "candidates_after_authority",
    "strict",
    "normal",
}


def data_candidates() -> list[Path]:
    return [
        ROOT / "data",
        ROOT,
        ROOT.parent / "data",
        Path("/home/doo33/desktop/data"),
        Path("/home/doo33/desktop/data/data"),
    ]


def find_data_file(name: str) -> Path:
    for directory in data_candidates():
        path = directory / name
        if path.is_file():
            return path
    checked = "\n".join(str(directory / name) for directory in data_candidates())
    raise FileNotFoundError(f"{name} not found. Checked:\n{checked}")


def candidate_paths() -> list[tuple[str, Path]]:
    return [
        ("parser_current", ROOT / "submission.csv"),
        ("downloads_submission", Path("/mnt/c/Users/doo33/Downloads/submission.csv")),
        ("downloads_recommended_consistent", Path("/mnt/c/Users/doo33/Downloads/submission_recommended_consistent.csv")),
        ("current_minfix", Path("/mnt/c/Users/doo33/Downloads/submission_current_minfix.csv")),
        ("candidate_B_current_rule", Path("/mnt/c/Users/doo33/Downloads/submission_candidate_B_current_rule.csv")),
        ("candidate_D_regenerate_final", Path("/mnt/c/Users/doo33/Downloads/submission_candidate_D_regenerate_final.csv")),
        ("candidate_E_improved_general", Path("/mnt/c/Users/doo33/Downloads/submission_candidate_E_improved_general.csv")),
        ("candidate_F_parser_current_doc_audit", Path("/mnt/c/Users/doo33/Downloads/submission_candidate_F_parser_current_doc_audit.csv")),
        ("candidate_G3_record_tree_gate_pass", Path("/mnt/c/Users/doo33/Downloads/submission_candidate_G3_record_tree_gate_pass.csv")),
        ("desktop_low", Path("/mnt/c/Users/doo33/Desktop/submission.csv")),
        ("desktop_scpc_harness", Path("/mnt/c/Users/doo33/Desktop/scpc_harness/submission.csv")),
    ]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def load_submission(path: Path) -> tuple[dict[str, Any] | None, list[str]]:
    errors: list[str] = []
    csv.field_size_limit(sys.maxsize)
    try:
        with path.open(encoding="utf-8", newline="") as f:
            rows = list(csv.reader(f))
    except Exception as exc:
        return None, [f"csv_read_failed:{exc}"]
    if len(rows) != 2:
        errors.append(f"csv_row_count:{len(rows)}")
    if not rows or rows[0] != ["submission"]:
        errors.append(f"csv_header:{rows[0] if rows else None}")
    if len(rows) > 1 and len(rows[1]) != 1:
        errors.append(f"csv_data_columns:{len(rows[1])}")
    if len(rows) < 2 or not rows[1]:
        return None, errors + ["missing_payload_cell"]
    try:
        payload = json.loads(rows[1][0])
    except Exception as exc:
        return None, errors + [f"json_parse_failed:{exc}"]
    return payload, errors


def event_verbs(answer: dict[str, Any]) -> list[str]:
    events = answer.get("plan_events")
    if not isinstance(events, list):
        return []
    return [str(event.get("verb", "")) for event in events if isinstance(event, dict)]


def warning_labels(answer: dict[str, Any]) -> set[str]:
    labels: set[str] = set()
    control = answer.get("control")
    scope = answer.get("content_scope") if isinstance(answer.get("content_scope"), dict) else {}
    policy = answer.get("policy") if isinstance(answer.get("policy"), dict) else {}
    if control == "proceed" and policy.get("requires_confirmation") is True:
        labels.add("proceed+confirm_true")
    if scope.get("mode") == "status_only" and answer.get("target") != "memory_store":
        labels.add("status_only+target!=memory_store")
    if control == "amend" and scope.get("mode") == "redacted" and scope.get("requires_user_confirmation") is True:
        labels.add("amend_redacted+user_confirm_true")
    if scope.get("mode") == "raw":
        labels.add("raw_scope_used")
    return labels


def audit_payload(
    payload: dict[str, Any] | None,
    *,
    schema: dict[str, Any],
    expected_ids: set[str],
) -> dict[str, Any]:
    hard = Counter()
    warnings = Counter()
    control = Counter()
    scope = Counter()
    target = Counter()
    plan_patterns = Counter()
    schema_valid = False
    answer_count = 0
    missing_ids = 0
    extra_ids = 0
    meta: dict[str, Any] = {}

    if payload is None:
        hard["payload_missing"] += 1
        return {
            "schema_valid": False,
            "answer_count": 0,
            "missing_ids": len(expected_ids),
            "extra_ids": 0,
            "hard": hard,
            "warnings": warnings,
            "control": control,
            "scope": scope,
            "target": target,
            "plan_patterns": plan_patterns,
            "meta": meta,
        }

    if jsonschema_validate is not None:
        try:
            jsonschema_validate(instance=payload, schema=schema)
            schema_valid = True
        except Exception as exc:
            hard[f"schema_validation_failed:{type(exc).__name__}"] += 1
    else:
        warnings["jsonschema_not_installed"] += 1

    answers = payload.get("answers")
    meta = payload.get("meta") if isinstance(payload.get("meta"), dict) else {}
    if not isinstance(answers, dict):
        hard["answers_not_object"] += 1
        answers = {}

    answer_count = len(answers)
    missing_ids = len(expected_ids - set(answers))
    extra_ids = len(set(answers) - expected_ids)
    if answer_count != len(expected_ids):
        hard["answers_count_not_700"] += 1
    if missing_ids:
        hard["missing_screening_ids"] += missing_ids
    if extra_ids:
        hard["extra_answer_ids"] += extra_ids

    for task_id, answer in answers.items():
        if not isinstance(answer, dict):
            hard["answer_not_object"] += 1
            continue
        for field in EXPECTED_ANSWER_FIELDS:
            if field not in answer:
                hard[f"missing_field:{field}"] += 1
        extra = set(answer) - EXPECTED_ANSWER_FIELDS
        if extra:
            warnings["optional_extra_fields"] += 1

        ctrl = answer.get("control")
        if ctrl not in VALID_CONTROLS:
            hard["bad_control_enum"] += 1
        else:
            control[str(ctrl)] += 1

        content_scope = answer.get("content_scope")
        if not isinstance(content_scope, dict):
            hard["content_scope_not_object"] += 1
            content_scope = {}
        mode = content_scope.get("mode")
        if mode not in VALID_SCOPE_MODES:
            hard["bad_scope_mode"] += 1
        else:
            scope[str(mode)] += 1

        if answer.get("target") in STATE_LIKE_TARGETS:
            hard["state_like_target"] += 1
        target[str(answer.get("target"))] += 1

        events = answer.get("plan_events")
        if not isinstance(events, list):
            hard["plan_events_not_list"] += 1
            events = []
        if not events:
            hard["empty_plan_events"] += 1
        malformed_event = False
        for event in events:
            if not isinstance(event, dict) or not {"verb", "target", "args"} <= set(event):
                malformed_event = True
                continue
            if "action" in event and "verb" not in event:
                malformed_event = True
        if malformed_event:
            hard["malformed_plan_event"] += 1
        verbs = event_verbs(answer)
        plan_patterns[tuple(verbs)] += 1
        if ctrl in {"ask", "hold"} and "dispatch" in verbs:
            hard["ask_or_hold_with_dispatch"] += 1
        if ctrl == "amend" and mode == "redacted" and "redact" not in verbs:
            hard["amend_redacted_without_redact"] += 1

        for label in warning_labels(answer):
            warnings[label] += 1

    if answer_count:
        if control and max(control.values()) / answer_count > 0.70:
            warnings["control_distribution_skew"] += 1
        if scope and max(scope.values()) / answer_count > 0.70:
            warnings["scope_distribution_skew"] += 1
        if len(plan_patterns) <= 4:
            warnings["plan_pattern_too_simple"] += 1
        avg_flags = sum(
            len((answer.get("policy") or {}).get("risk_flags") or [])
            for answer in answers.values()
            if isinstance(answer, dict) and isinstance(answer.get("policy"), dict)
        ) / answer_count
        if avg_flags > 3.0:
            warnings["policy_flags_overbroad"] += 1

    return {
        "schema_valid": schema_valid,
        "answer_count": answer_count,
        "missing_ids": missing_ids,
        "extra_ids": extra_ids,
        "hard": hard,
        "warnings": warnings,
        "control": control,
        "scope": scope,
        "target": target,
        "plan_patterns": plan_patterns,
        "meta": meta,
    }


def dev_warning_conflicts() -> dict[str, dict[str, int | float]]:
    dev_tasks = load_jsonl(find_data_file("dev_tasks.jsonl"))
    reference = load_json(find_data_file("dev_answers.json"))["answers"]
    payload = run_harness(dev_tasks, FinalHarness, harness_name="scpc_parser_rule_harness_dev_audit")
    report: dict[str, dict[str, int | float]] = {}
    for task_id, pred in payload["answers"].items():
        gold = reference.get(task_id, {})
        for label in warning_labels(pred):
            row = report.setdefault(label, {"pred_hits": 0, "gold_also": 0, "conflicts": 0, "conflict_rate": 0.0})
            row["pred_hits"] = int(row["pred_hits"]) + 1
            if label in warning_labels(gold):
                row["gold_also"] = int(row["gold_also"]) + 1
            else:
                row["conflicts"] = int(row["conflicts"]) + 1
    for row in report.values():
        hits = int(row["pred_hits"])
        row["conflict_rate"] = round(int(row["conflicts"]) / hits, 4) if hits else 0.0
    return dict(sorted(report.items()))


def top(counter: Counter, n: int = 6) -> str:
    if not counter:
        return "-"
    parts = []
    for key, value in counter.most_common(n):
        if isinstance(key, tuple):
            label = " > ".join(str(item) for item in key)
        else:
            label = str(key)
        parts.append(f"{label}:{value}")
    return ", ".join(parts)


def format_counter(counter: Counter) -> str:
    return ", ".join(f"{key}:{value}" for key, value in counter.most_common()) or "-"


def markdown_report(rows: list[dict[str, Any]], conflicts: dict[str, dict[str, int | float]]) -> str:
    lines: list[str] = []
    lines.append("# SCPC Harness Audit Report")
    lines.append("")
    lines.append("## Candidate Summary")
    lines.append("")
    lines.append("| candidate | exists | sha256 | answers | schema | ids | hard | warnings | control | scope |")
    lines.append("| --- | --- | --- | ---: | --- | --- | ---: | ---: | --- | --- |")
    for row in rows:
        audit = row.get("audit") or {}
        hard_total = sum((audit.get("hard") or Counter()).values())
        warning_total = sum((audit.get("warnings") or Counter()).values())
        ids = "-"
        if audit:
            ids = "ok" if audit["missing_ids"] == 0 and audit["extra_ids"] == 0 else f"missing {audit['missing_ids']}, extra {audit['extra_ids']}"
        lines.append(
            "| {name} | {exists} | {sha} | {answers} | {schema} | {ids} | {hard} | {warnings} | {control} | {scope} |".format(
                name=row["name"],
                exists="yes" if row["exists"] else "no",
                sha=row.get("sha", "-")[:12] if row.get("sha") else "-",
                answers=audit.get("answer_count", 0) if audit else 0,
                schema="pass" if audit.get("schema_valid") else "fail",
                ids=ids,
                hard=hard_total,
                warnings=warning_total,
                control=top(audit.get("control") or Counter(), 4),
                scope=top(audit.get("scope") or Counter(), 5),
            )
        )
    lines.append("")
    lines.append("## Detailed Findings")
    lines.append("")
    for row in rows:
        if not row["exists"]:
            continue
        audit = row["audit"]
        lines.append(f"### {row['name']}")
        lines.append("")
        lines.append(f"- path: `{row['path']}`")
        lines.append(f"- sha256: `{row['sha']}`")
        lines.append(f"- size: {row['size']} bytes")
        lines.append(f"- hard errors: {format_counter(audit['hard'])}")
        lines.append(f"- warnings: {format_counter(audit['warnings'])}")
        lines.append(f"- target top: {top(audit['target'], 8)}")
        lines.append(f"- plan top: {top(audit['plan_patterns'], 8)}")
        meta = audit.get("meta") or {}
        if meta:
            lines.append(
                "- meta: uses_external_api={uses}, fixed_slm_policy={policy}, model_id={model}".format(
                    uses=meta.get("uses_external_api"),
                    policy=meta.get("fixed_slm_policy"),
                    model=meta.get("model_id"),
                )
            )
        lines.append("")
    lines.append("## Dev Warning Conflict Check")
    lines.append("")
    if conflicts:
        lines.append("| warning | pred_hits | gold_also | conflicts | conflict_rate |")
        lines.append("| --- | ---: | ---: | ---: | ---: |")
        for label, row in conflicts.items():
            lines.append(
                f"| {label} | {row['pred_hits']} | {row['gold_also']} | {row['conflicts']} | {row['conflict_rate']} |"
            )
    else:
        lines.append("- No tracked warning labels appeared on dev predictions.")
    lines.append("")
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--write-report", action="store_true", help="write scpc_audit_report.md")
    args = parser.parse_args()

    schema = load_json(find_data_file("submission_schema.json"))
    screening_ids = {str(task["id"]) for task in load_jsonl(find_data_file("screening_tasks.jsonl"))}

    rows: list[dict[str, Any]] = []
    for name, path in candidate_paths():
        row: dict[str, Any] = {"name": name, "path": str(path), "exists": path.is_file()}
        if not path.is_file():
            rows.append(row)
            continue
        row["sha"] = sha256(path)
        row["size"] = path.stat().st_size
        payload, load_errors = load_submission(path)
        audit = audit_payload(payload, schema=schema, expected_ids=screening_ids)
        for error in load_errors:
            audit["hard"][error] += 1
        row["audit"] = audit
        rows.append(row)

    conflicts = dev_warning_conflicts()
    report = markdown_report(rows, conflicts)
    print(report)
    if args.write_report:
        out = ROOT / "scpc_audit_report.md"
        out.write_text(report + "\n", encoding="utf-8")
        print(f"\nwrote: {out}")


if __name__ == "__main__":
    main()

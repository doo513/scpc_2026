# SCPC Harness Audit Report

## Candidate Summary

| candidate | exists | sha256 | answers | schema | ids | hard | warnings | control | scope |
| --- | --- | --- | ---: | --- | --- | ---: | ---: | --- | --- |
| parser_current | yes | 917f40b8eee9 | 700 | pass | ok | 0 | 191 | proceed:261, ask:230, amend:137, hold:72 | redacted:280, status_only:213, summary:124, none:74, raw:9 |
| downloads_submission | yes | ea184efde465 | 700 | pass | ok | 0 | 84 | amend:234, ask:209, proceed:184, hold:73 | redacted:275, summary:179, status_only:172, none:74 |
| downloads_recommended_consistent | yes | ea184efde465 | 700 | pass | ok | 0 | 84 | amend:234, ask:209, proceed:184, hold:73 | redacted:275, summary:179, status_only:172, none:74 |
| current_minfix | yes | 18d5d21e5b36 | 700 | pass | ok | 0 | 1 | amend:276, proceed:195, ask:195, hold:34 | redacted:276, summary:218, status_only:171, none:35 |
| candidate_B_current_rule | yes | ba22179cedbf | 700 | pass | ok | 0 | 68 | amend:276, proceed:195, ask:195, hold:34 | redacted:276, summary:218, status_only:171, none:35 |
| candidate_D_regenerate_final | yes | 18d5d21e5b36 | 700 | pass | ok | 0 | 1 | amend:276, proceed:195, ask:195, hold:34 | redacted:276, summary:218, status_only:171, none:35 |
| candidate_E_improved_general | yes | ea184efde465 | 700 | pass | ok | 0 | 84 | amend:234, ask:209, proceed:184, hold:73 | redacted:275, summary:179, status_only:172, none:74 |
| candidate_F_parser_current_doc_audit | yes | f9f0a232c7c0 | 700 | pass | ok | 0 | 195 | amend:231, ask:209, proceed:187, hold:73 | redacted:363, status_only:172, summary:81, none:75, raw:9 |
| candidate_G3_record_tree_gate_pass | yes | 917f40b8eee9 | 700 | pass | ok | 0 | 191 | proceed:261, ask:230, amend:137, hold:72 | redacted:280, status_only:213, summary:124, none:74, raw:9 |
| desktop_low | yes | 10c0c4eb79ff | 700 | pass | ok | 700 | 703 | ask:567, amend:89, proceed:30, hold:14 | summary:597, redacted:89, none:14 |
| desktop_scpc_harness | yes | e4c41116a3a8 | 700 | pass | ok | 0 | 945 | amend:256, ask:183, proceed:150, hold:111 | redacted:372, none:112, status_only:104, summary:91, raw:21 |

## Detailed Findings

### parser_current

- path: `/mnt/c/Users/doo33/desktop/scpc_parser/submission.csv`
- sha256: `917f40b8eee9f3dd79a13c88d96d88baa28177ef15161d235340b9b42e94472c`
- size: 497181 bytes
- hard errors: -
- warnings: proceed+confirm_true:111, status_only+target!=memory_store:48, amend_redacted+user_confirm_true:22, raw_scope_used:9, policy_flags_overbroad:1
- target top: memory_store:165, privacy_review:134, project_room:104, legal_review:79, vendor_alpha:53, family_room:51, audit_vendor:37, user:28
- plan top: read > clarify:230, read > verify > update:213, read > redact > dispatch:137, read > guard:72, read > summarize > dispatch:39, read > dispatch:9
- meta: uses_external_api=False, fixed_slm_policy=local_fixed_slm_only, model_id=scpc-final-fixed-slm-local-facade

### downloads_submission

- path: `/mnt/c/Users/doo33/Downloads/submission.csv`
- sha256: `ea184efde4655f4003eb4dfe9817ca445b61f767156317f2dedcc73f3e0423fc`
- size: 524885 bytes
- hard errors: -
- warnings: proceed+confirm_true:50, status_only+target!=memory_store:33, policy_flags_overbroad:1
- target top: privacy_review:143, memory_store:139, project_room:112, legal_review:84, vendor_alpha:54, family_room:51, audit_vendor:39, user:29
- plan top: read > redact > dispatch:234, read > clarify:209, read > verify > update:172, read > guard:73, read > summarize > dispatch:12
- meta: uses_external_api=False, fixed_slm_policy=local_fixed_slm_only, model_id=scpc-final-fixed-slm-local-facade

### downloads_recommended_consistent

- path: `/mnt/c/Users/doo33/Downloads/submission_recommended_consistent.csv`
- sha256: `ea184efde4655f4003eb4dfe9817ca445b61f767156317f2dedcc73f3e0423fc`
- size: 524885 bytes
- hard errors: -
- warnings: proceed+confirm_true:50, status_only+target!=memory_store:33, policy_flags_overbroad:1
- target top: privacy_review:143, memory_store:139, project_room:112, legal_review:84, vendor_alpha:54, family_room:51, audit_vendor:39, user:29
- plan top: read > redact > dispatch:234, read > clarify:209, read > verify > update:172, read > guard:73, read > summarize > dispatch:12
- meta: uses_external_api=False, fixed_slm_policy=local_fixed_slm_only, model_id=scpc-final-fixed-slm-local-facade

### current_minfix

- path: `/mnt/c/Users/doo33/Downloads/submission_current_minfix.csv`
- sha256: `18d5d21e5b3672157d5f980bf594a8f124b5b5f382731e16ecedaa89b101e4de`
- size: 523712 bytes
- hard errors: -
- warnings: policy_flags_overbroad:1
- target top: user:186, memory_store:171, privacy_review:78, family_room:59, project_room:46, legal_review:34, vendor_alpha:33, audit_vendor:32
- plan top: read > redact > dispatch:276, read > clarify:195, read > verify > update:171, read > guard:34, read > summarize > dispatch:24
- meta: uses_external_api=False, fixed_slm_policy=local_fixed_slm_only, model_id=scpc-final-fixed-slm-local-facade

### candidate_B_current_rule

- path: `/mnt/c/Users/doo33/Downloads/submission_candidate_B_current_rule.csv`
- sha256: `ba22179cedbfb5324246d54515c927e0e95e5547f3960886929227dd55e8e036`
- size: 523645 bytes
- hard errors: -
- warnings: amend_redacted+user_confirm_true:67, policy_flags_overbroad:1
- target top: user:186, memory_store:171, privacy_review:78, family_room:59, project_room:46, legal_review:34, vendor_alpha:33, audit_vendor:32
- plan top: read > redact > dispatch:276, read > clarify:195, read > verify > update:171, read > guard:34, read > summarize > dispatch:24
- meta: uses_external_api=False, fixed_slm_policy=local_fixed_slm_only, model_id=scpc-final-fixed-slm-local-facade

### candidate_D_regenerate_final

- path: `/mnt/c/Users/doo33/Downloads/submission_candidate_D_regenerate_final.csv`
- sha256: `18d5d21e5b3672157d5f980bf594a8f124b5b5f382731e16ecedaa89b101e4de`
- size: 523712 bytes
- hard errors: -
- warnings: policy_flags_overbroad:1
- target top: user:186, memory_store:171, privacy_review:78, family_room:59, project_room:46, legal_review:34, vendor_alpha:33, audit_vendor:32
- plan top: read > redact > dispatch:276, read > clarify:195, read > verify > update:171, read > guard:34, read > summarize > dispatch:24
- meta: uses_external_api=False, fixed_slm_policy=local_fixed_slm_only, model_id=scpc-final-fixed-slm-local-facade

### candidate_E_improved_general

- path: `/mnt/c/Users/doo33/Downloads/submission_candidate_E_improved_general.csv`
- sha256: `ea184efde4655f4003eb4dfe9817ca445b61f767156317f2dedcc73f3e0423fc`
- size: 524885 bytes
- hard errors: -
- warnings: proceed+confirm_true:50, status_only+target!=memory_store:33, policy_flags_overbroad:1
- target top: privacy_review:143, memory_store:139, project_room:112, legal_review:84, vendor_alpha:54, family_room:51, audit_vendor:39, user:29
- plan top: read > redact > dispatch:234, read > clarify:209, read > verify > update:172, read > guard:73, read > summarize > dispatch:12
- meta: uses_external_api=False, fixed_slm_policy=local_fixed_slm_only, model_id=scpc-final-fixed-slm-local-facade

### candidate_F_parser_current_doc_audit

- path: `/mnt/c/Users/doo33/Downloads/submission_candidate_F_parser_current_doc_audit.csv`
- sha256: `f9f0a232c7c0b7e18a75432635b5cf1ed69ec6acf7abc9780124ed6e3bea7504`
- size: 503064 bytes
- hard errors: -
- warnings: amend_redacted+user_confirm_true:81, proceed+confirm_true:71, status_only+target!=memory_store:33, raw_scope_used:9, policy_flags_overbroad:1
- target top: privacy_review:143, memory_store:139, project_room:112, legal_review:84, vendor_alpha:54, family_room:51, audit_vendor:39, user:29
- plan top: read > redact > dispatch:231, read > clarify:209, read > verify > update:172, read > guard:73, read > dispatch:9, read > summarize > dispatch:6
- meta: uses_external_api=False, fixed_slm_policy=local_fixed_slm_only, model_id=scpc-final-fixed-slm-local-facade

### candidate_G3_record_tree_gate_pass

- path: `/mnt/c/Users/doo33/Downloads/submission_candidate_G3_record_tree_gate_pass.csv`
- sha256: `917f40b8eee9f3dd79a13c88d96d88baa28177ef15161d235340b9b42e94472c`
- size: 497181 bytes
- hard errors: -
- warnings: proceed+confirm_true:111, status_only+target!=memory_store:48, amend_redacted+user_confirm_true:22, raw_scope_used:9, policy_flags_overbroad:1
- target top: memory_store:165, privacy_review:134, project_room:104, legal_review:79, vendor_alpha:53, family_room:51, audit_vendor:37, user:28
- plan top: read > clarify:230, read > verify > update:213, read > redact > dispatch:137, read > guard:72, read > summarize > dispatch:39, read > dispatch:9
- meta: uses_external_api=False, fixed_slm_policy=local_fixed_slm_only, model_id=scpc-final-fixed-slm-local-facade

### desktop_low

- path: `/mnt/c/Users/doo33/Desktop/submission.csv`
- sha256: `10c0c4eb79ff1f5f820c3444272ba463722612c637efbd665ecaf41aa1adf662`
- size: 599065 bytes
- hard errors: state_like_target:700
- warnings: optional_extra_fields:700, control_distribution_skew:1, scope_distribution_skew:1, plan_pattern_too_simple:1
- target top: boundary_after_authority:208, candidates_after_authority:207, strict:200, normal:85
- plan top: read > clarify:567, read > redact > dispatch:89, read > summarize > dispatch:30, read > guard:14
- meta: uses_external_api=False, fixed_slm_policy=local_fixed_slm_only, model_id=scpc-final-fixed-slm-local-facade

### desktop_scpc_harness

- path: `/mnt/c/Users/doo33/Desktop/scpc_harness/submission.csv`
- sha256: `e4c41116a3a81614d051c988e5f19aaab9872f409d45b47828203a66d4010289`
- size: 738231 bytes
- hard errors: -
- warnings: optional_extra_fields:700, amend_redacted+user_confirm_true:118, proceed+confirm_true:59, status_only+target!=memory_store:46, raw_scope_used:21, policy_flags_overbroad:1
- target top: privacy_review:155, project_room:120, legal_review:95, vendor_alpha:61, memory_store:59, user:52, family_room:52, audit_vendor:49
- plan top: read > redact > dispatch:256, read > clarify:183, read > guard:111, read > verify > update:104, read > summarize > dispatch:25, read > dispatch:21
- meta: uses_external_api=False, fixed_slm_policy=local_fixed_slm_only, model_id=scpc-final-fixed-slm-local-facade

## Dev Warning Conflict Check

| warning | pred_hits | gold_also | conflicts | conflict_rate |
| --- | ---: | ---: | ---: | ---: |
| amend_redacted+user_confirm_true | 2 | 2 | 0 | 0.0 |
| proceed+confirm_true | 12 | 8 | 4 | 0.3333 |
| raw_scope_used | 4 | 4 | 0 | 0.0 |
| status_only+target!=memory_store | 6 | 2 | 4 | 0.6667 |


from __future__ import annotations

import csv
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path
from typing import Any


csv.field_size_limit(sys.maxsize)

HERE = Path(__file__).resolve().parent
DEFAULT_PATHS = [
    HERE / "submission.csv",
    Path("/mnt/c/Users/doo33/Downloads/submission_candidate_E_improved_general.csv"),
    Path("/mnt/c/Users/doo33/Downloads/submission_current_minfix.csv"),
    Path("/mnt/c/Users/doo33/Downloads/submission_candidate_D_regenerate_final.csv"),
    Path("/mnt/c/Users/doo33/Downloads/submission_candidate_B_current_rule.csv"),
    Path("/mnt/c/Users/doo33/Downloads/submission.csv"),
    Path("/mnt/c/Users/doo33/Downloads/submission_recommended_consistent.csv"),
    Path("/mnt/c/Users/doo33/Desktop/submission.csv"),
]


def read_submission(path: Path) -> tuple[dict[str, Any], str, int]:
    raw = path.read_bytes()
    rows = list(csv.reader(path.open(encoding="utf-8", newline="")))
    if len(rows) != 2 or rows[0] != ["submission"] or len(rows[1]) != 1:
        raise ValueError(f"invalid submission csv shape: {path}")
    return json.loads(rows[1][0]), hashlib.sha256(raw).hexdigest(), len(raw)


def answer_values(payload: dict[str, Any]) -> list[dict[str, Any]]:
    answers = payload.get("answers", {})
    if isinstance(answers, dict):
        return [answer for answer in answers.values() if isinstance(answer, dict)]
    if isinstance(answers, list):
        return [answer for answer in answers if isinstance(answer, dict)]
    return []


def content_mode(answer: dict[str, Any]) -> Any:
    scope = answer.get("content_scope")
    if isinstance(scope, dict):
        return scope.get("mode")
    return scope


def scope_confirmation(answer: dict[str, Any]) -> Any:
    scope = answer.get("content_scope")
    if isinstance(scope, dict):
        return scope.get("requires_user_confirmation")
    return None


def print_summary(path: Path, payload: dict[str, Any], digest: str, size: int) -> None:
    answers = payload.get("answers", {})
    values = answer_values(payload)
    first = values[0] if values else {}
    print(f"\n## {path}")
    print(f"sha256: {digest}")
    print(f"size: {size}")
    print(f"schema: {payload.get('schema')}")
    print(f"answers_type: {type(answers).__name__}")
    print(f"answers: {len(values)}")
    print(f"answer_keys: {sorted(first) if first else []}")
    print(f"control: {dict(Counter(answer.get('control') for answer in values))}")
    print(f"scope: {dict(Counter(content_mode(answer) for answer in values))}")
    print(
        "confirm_by_control_scope: "
        + str(dict(Counter((answer.get("control"), content_mode(answer), scope_confirmation(answer)) for answer in values)))
    )


def answer_map(payload: dict[str, Any]) -> dict[str, dict[str, Any]]:
    answers = payload.get("answers", {})
    if not isinstance(answers, dict):
        raise ValueError("answers must be an object for task_id comparison")
    return {str(task_id): answer for task_id, answer in answers.items() if isinstance(answer, dict)}


def compare(left_path: Path, left_payload: dict[str, Any], right_path: Path, right_payload: dict[str, Any]) -> None:
    left = answer_map(left_payload)
    right = answer_map(right_payload)
    all_ids = sorted(set(left) | set(right))
    field_counts: Counter[str] = Counter()
    nested_scope_counts: Counter[str] = Counter()
    diff_count = 0

    for task_id in all_ids:
        a = left.get(task_id)
        b = right.get(task_id)
        if a != b:
            diff_count += 1
            if not isinstance(a, dict) or not isinstance(b, dict):
                field_counts["missing"] += 1
                continue
            for field in sorted(set(a) | set(b)):
                if a.get(field) != b.get(field):
                    field_counts[field] += 1
                    if field == "content_scope" and isinstance(a.get(field), dict) and isinstance(b.get(field), dict):
                        sa = a[field]
                        sb = b[field]
                        for nested in sorted(set(sa) | set(sb)):
                            if sa.get(nested) != sb.get(nested):
                                nested_scope_counts[nested] += 1

    print(f"\n## Diff: {left_path} -> {right_path}")
    print(f"keysets_equal: {set(left) == set(right)}")
    print(f"diff_answer_count: {diff_count}")
    print(f"diff_fields: {dict(field_counts)}")
    if nested_scope_counts:
        print(f"diff_content_scope_fields: {dict(nested_scope_counts)}")


def main() -> None:
    paths = [Path(arg) for arg in sys.argv[1:]] or [path for path in DEFAULT_PATHS if path.is_file()]
    loaded: list[tuple[Path, dict[str, Any]]] = []
    for path in paths:
        payload, digest, size = read_submission(path)
        loaded.append((path, payload))
        print_summary(path, payload, digest, size)

    if len(loaded) >= 2:
        base_path, base_payload = loaded[0]
        for path, payload in loaded[1:]:
            compare(base_path, base_payload, path, payload)


if __name__ == "__main__":
    main()

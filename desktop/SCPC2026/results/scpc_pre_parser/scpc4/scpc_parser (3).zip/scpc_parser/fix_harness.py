import re

with open('/mnt/c/Users/doo33/Desktop/scpc_parser/harness.py', 'r') as f:
    content = f.read()

# Remove the broken method at the end
start_idx = content.rfind('    def _build_policy_internal')
if start_idx != -1:
    content = content[:start_idx]

# Add the correct methods at the end of the class
methods = """

    def _build_policy_internal(self, task: dict, focal: dict, control: str, target: str, scope: dict) -> dict:
        contains = self._field_set(focal)
        types = record_types(task)
        
        flags = []
        if 'amount' in contains or 'numeric_value' in contains:
            flags.append('amount_changed')
        if 'name' in contains or 'rrn' in contains or 'doctor_note' in contains:
            flags.append('sensitive_content')
            
        for rt in types:
            if rt in ('precondition_changed', 'privacy_guard', 'security_alert', 'consent', 'target_changed_after_turn'):
                flags.append(rt)
                
        return {
            'risk_flags': list(set(flags)),
            'violations': [],
            'requires_confirmation': control == 'ask' or 'consent' in types or 'precondition_changed' in types
        }

    def _build_plan_events_internal(
        self,
        task: dict,
        focal_id: str,
        target: str,
        control: str,
        scope: dict,
        policy: dict,
    ) -> list[dict]:
        types = record_types(task)
        
        if control == "hold":
            reason = "precondition_invalidated"
            if "security_alert" in types or "safety_mode" in types:
                reason = "security_alert"
            elif "consent" in types:
                reason = "consent_revoked"
            elif "privacy_guard" in types:
                reason = "privacy_guard"
                
            return [
                {"verb": "read", "target": focal_id, "args": {"purpose": "security_check" if reason in ("security_alert", "privacy_guard") else "invalidated_precondition"}},
                {"verb": "guard", "target": focal_id, "args": {"reason": reason}},
            ]
            
        if control == "ask":
            reason = "clarification_required"
            if "ambiguous_target" in types or "target_changed_after_turn" in types:
                reason = "target_ambiguity"
            elif "ambiguous_focal" in types:
                reason = "ambiguous_focal"
            elif "duration_ambiguous" in types:
                reason = "duration_check"
            elif "memory_conflict" in types:
                reason = "memory_preference"
                
            purpose = "route_resolution_required" if reason in ("target_ambiguity", "ambiguous_focal") else "clarify_precondition"
            return [
                {"verb": "read", "target": focal_id, "args": {"purpose": purpose}},
                {"verb": "clarify", "target": "user", "args": {"reason": reason}},
            ]
            
        if control == "proceed" and (is_local_update(task) or latest_record_value(task, "share_boundary_update") == "local_update_boundary"):
            return [
                {"verb": "read", "target": focal_id, "args": {"purpose": "local_update"}},
                {"verb": "verify", "target": "share_boundary_update", "args": {"scope": "local_update"}},
                {"verb": "update", "target": focal_id, "args": {"state": "local_status_only"}},
            ]
            
        if control == "amend":
            excluded = set(scope.get("excluded_fields") or [])
            remove = "sensitive_fields" if (excluded & {"name", "rrn", "numeric_value", "doctor_note", "location", "amount", "card_number"}) else "raw_quote"
            purpose = "strict_share_policy" if latest_record_value(task, "session_share_policy") == "strict" else "minimal_disclosure"
            return [
                {"verb": "read", "target": focal_id, "args": {"purpose": purpose}},
                {"verb": "redact", "target": focal_id, "args": {"remove": remove}},
                {"verb": "dispatch", "target": target, "args": {"scope": "redacted"}},
            ]
            
        if scope.get("mode") == "summary":
            return [
                {"verb": "read", "target": focal_id, "args": {"purpose": "inspect_context"}},
                {"verb": "summarize", "target": focal_id, "args": {"mode": "summary"}},
                {"verb": "dispatch", "target": target, "args": {"scope": "summary"}},
            ]
            
        return [
            {"verb": "read", "target": focal_id, "args": {"purpose": "inspect_context"}},
            {"verb": "dispatch", "target": target, "args": {"scope": scope.get("mode", "raw")}},
        ]
"""

content = content.rstrip() + methods

with open('/mnt/c/Users/doo33/Desktop/scpc_parser/harness.py', 'w') as f:
    f.write(content)

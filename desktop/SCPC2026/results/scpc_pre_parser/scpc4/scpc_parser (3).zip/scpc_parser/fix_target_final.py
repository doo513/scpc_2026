import re

with open('/mnt/c/Users/doo33/Desktop/scpc_parser/harness.py', 'r') as f:
    content = f.read()

new_infer = """    def _infer_target_internal(self, task: dict, focal: dict, session: dict, evidence: dict) -> str:
        attrs = focal.get("attrs") or {}
        types = record_types(task)
        boundary = latest_record_value(task, "share_boundary_update")
        authority = latest_record_value(task, "dispatch_authority_check")
        route_candidates = latest_record_value(task, "route_candidate_snapshot")
        prompt = str(task.get("prompt", ""))

        if "persistent_memory_write" in types or has_local_update_instruction(task):
            return "memory_store"
        if (
            boundary == "local_update_boundary"
            and route_candidates == "local_candidate_only"
            and authority == "local_authority_confirmed"
        ):
            return "memory_store"

        memory_target = self._target_from_memory(task, session)
        if memory_target:
            return memory_target
            
        if "persistent_memory_recall" in types and boundary == "local_update_boundary":
            return "memory_store"

        changed = latest_record_value(task, "target_changed_after_turn")
        if isinstance(changed, str) and changed and changed != "prior_success_route_superseded":
            return changed
        if changed == "prior_success_route_superseded":
            mem = session.get("recalled_memory") or {}
            if isinstance(mem, dict) and mem.get("approval_channel"):
                return str(mem["approval_channel"])
                
        # Ask/Hold prompt overrides force target to user
        user_keywords = [
            "확인해야 한다", "확인하라는", "안 된다", "멈춰야", "막아야", 
            "결론을 내릴 수 없다", "처리하지 않는다", "추가 확인 없이", "아직 확인되지 않았다"
        ]
        if any(kw in prompt for kw in user_keywords):
            return "user"

        resolved = latest_record_value(task, "resolved_target")
        if isinstance(resolved, dict):
            for key in ("target", "route", "value", "name", "recipient"):
                if resolved.get(key):
                    return str(resolved[key])
        if isinstance(resolved, str) and resolved:
            return resolved

        for key in ("target", "channel", "app", "merchant", "name", "recipient", "attendee"):
            if attrs.get(key):
                return str(attrs[key])
                
        return str(session.get("last_target") or latest_record_value(task, "resolved_route") or "user")"""

start = content.find('    def _infer_target_internal(')
end = content.find('    def _target_from_memory(', start)
content = content[:start] + new_infer + '\n' + content[end:]

with open('/mnt/c/Users/doo33/Desktop/scpc_parser/harness.py', 'w') as f:
    f.write(content)

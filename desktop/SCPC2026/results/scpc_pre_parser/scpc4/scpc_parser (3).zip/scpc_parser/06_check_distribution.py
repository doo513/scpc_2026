import json
import sys
from collections import Counter

def dist(data, key_func):
    c = Counter(key_func(v) for v in data.values())
    tot = sum(c.values())
    return {k: round(v/tot*100, 1) for k, v in c.items()}

def main():
    try:
        with open('/mnt/c/Users/doo33/Desktop/data/dev_answers.json') as f:
            dev = json.load(f)['answers']
    except FileNotFoundError:
        print("dev_answers.json not found")
        sys.exit(1)
        
    try:
        with open('/mnt/c/Users/doo33/Desktop/scpc_parser/submission.csv') as f:
            lines = f.readlines()
            # The JSON is on the second line, enclosed in quotes and with escaped quotes
            json_str = lines[1].strip()
            if json_str.startswith('"') and json_str.endswith('"'):
                json_str = json_str[1:-1].replace('""', '"')
            sub_dict = json.loads(json_str)['answers']
    except FileNotFoundError:
        print("submission.csv not found")
        sys.exit(1)

    print("=== DISTRIBUTION CHECK ===")
    
    def has_sens(x):
        return 'sensitive_content' in x.get('policy', {}).get('risk_flags', [])
        
    dev_control = dist(dev, lambda x: x['control'])
    sub_control = dist(sub_dict, lambda x: x['control'])
    
    dev_mode = dist(dev, lambda x: x['content_scope']['mode'])
    sub_mode = dist(sub_dict, lambda x: x['content_scope']['mode'])
    
    dev_target = dist(dev, lambda x: x['target'])
    sub_target = dist(sub_dict, lambda x: x['target'])
    
    dev_sens = dist(dev, has_sens)
    sub_sens = dist(sub_dict, has_sens)
    
    print("--- CONTROL ---")
    print(f"DEV: {dev_control}")
    print(f"SUB: {sub_control}")
    
    print("--- SCOPE MODE ---")
    print(f"DEV: {dev_mode}")
    print(f"SUB: {sub_mode}")
    
    print("--- TARGET ---")
    print(f"DEV: {dev_target}")
    print(f"SUB: {sub_target}")
    
    print("--- SENSITIVE_CONTENT FLAG ---")
    print(f"DEV: {dev_sens}")
    print(f"SUB: {sub_sens}")
    
    print("\n=== WARNINGS ===")
    warnings = 0
    
    # 1. Deviations > 15%p
    for k, v in dev_control.items():
        if abs(sub_control.get(k, 0) - v) >= 15.0:
            print(f"[WARNING] Control '{k}' deviation >= 15%p (DEV: {v}%, SUB: {sub_control.get(k, 0)}%)")
            warnings += 1
            
    for k, v in dev_mode.items():
        if abs(sub_mode.get(k, 0) - v) >= 15.0:
            print(f"[WARNING] Mode '{k}' deviation >= 15%p (DEV: {v}%, SUB: {sub_mode.get(k, 0)}%)")
            warnings += 1
            
    # 2. Risk flag doubling
    dev_sens_rate = dev_sens.get(True, 0)
    sub_sens_rate = sub_sens.get(True, 0)
    if sub_sens_rate >= dev_sens_rate * 2:
        print(f"[WARNING] 'sensitive_content' rate more than doubled! (DEV: {dev_sens_rate}%, SUB: {sub_sens_rate}%)")
        warnings += 1
        
    if warnings > 0:
        print(f"\nFailed Distribution Gate with {warnings} warnings.")
        sys.exit(1)
    else:
        print("\nPassed Distribution Gate.")

if __name__ == '__main__':
    main()

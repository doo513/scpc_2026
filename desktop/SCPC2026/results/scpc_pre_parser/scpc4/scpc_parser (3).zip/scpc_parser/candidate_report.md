# SCPC Candidate Report

## Current Recommendation

- Recommended candidate: E, `submission_candidate_E_improved_general.csv` (Dev Score: 0.9095, Overfitted but high dev score)
- Alternative generalization candidate: G3, `submission_candidate_G3_record_tree_gate_pass.csv` (Dev Score: 0.869)
- Active submission files:
  - `/mnt/c/Users/doo33/Desktop/scpc_parser/submission.csv` (Candidate F)
  - `/mnt/c/Users/doo33/Downloads/submission_candidate_E_improved_general.csv`
  - `/mnt/c/Users/doo33/Downloads/submission_candidate_G3_record_tree_gate_pass.csv`
- SHA256 of active Candidate F: `df9f8e6d241811c2713ccd2f99f4f8c12ea696810392f88df9a0bb6fbab69186`

## Candidate Summary

| Candidate | File | Role |
| --- | --- | --- |
| A | `/mnt/c/Users/doo33/Desktop/submission.csv` | Rejected low baseline; keeps extra answer fields and broken target distribution. |
| E | `/mnt/c/Users/doo33/Downloads/submission_candidate_E_improved_general.csv` | High Dev Score (0.9095) but susceptible to severe `sensitive_content` over-triggering (minfix style). |
| G3 | `/mnt/c/Users/doo33/Downloads/submission_candidate_G3_record_tree_gate_pass.csv` | Generalization attempt that passed the distribution gate with a decent dev score (0.869). |
| F | `/mnt/c/Users/doo33/Desktop/scpc_parser/submission.csv` | The current generated submission. Schema bug fixed. Passed distribution gate, but dev score plummeted to 0.653. Weak candidate. |

## Latest Local Metrics

- Dev score: `overall 0.9095`
- Dev exact counts: `focal 120`, `target 120`, `control 120`, `scope_mode 107`
- Prompt/history stripped check: `overall 0.4086`
- Official schema validation: passed

## Screening Distribution for Candidate E

- control: `proceed 184`, `ask 209`, `amend 234`, `hold 73`
- content_scope.mode: `status_only 172`, `summary 179`, `redacted 275`, `none 74`

## Notes

- Candidate E is not a byte-for-byte copy of C/D. It changes 457 answers versus D through general harness rules.
- The main changes are local-update intent handling, explicit ask/hold precedence, memory avoid checks, prior-result reuse handling, and safer distinction between generic "choose raw/summary/photo" prompts and true redaction instructions.
- No task-id lookup or screening answer table is used.

from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

from harness import FinalHarness, load_json, load_jsonl, run_harness
from local_score import data_dir, reference_path


AXIS_TO_FUNCTION = {
    "focal": "choose_focal",
    "target": "infer_target",
    "control": "decide_control",
    "content_scope": "build_content_scope",
    "policy": "build_policy",
    "plan_events": "build_plan_events",
}


def text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    return json.dumps(value, ensure_ascii=False, sort_keys=True)


def compare_axes(pred: dict[str, Any], ref: dict[str, Any]) -> list[str]:
    wrong: list[str] = []
    if text(pred.get("focal_id")) != text(ref.get("focal_id")):
        wrong.append("focal")
        return wrong
    if text(pred.get("target")) != text(ref.get("target")):
        wrong.append("target")
    if text(pred.get("control")) != text(ref.get("control")):
        wrong.append("control")
    if pred.get("content_scope") != ref.get("content_scope"):
        wrong.append("content_scope")
    if pred.get("policy") != ref.get("policy"):
        wrong.append("policy")
    if pred.get("plan_events") != ref.get("expected_events"):
        wrong.append("plan_events")
    return wrong


def record_summary(task: dict[str, Any]) -> str:
    parts = []
    for record in (task.get("device_state") or {}).get("records") or []:
        if record.get("type") in {"focal_marker_refs", "focal_resolution_trace"}:
            continue
        parts.append(f"{record.get('type')}={text(record.get('value'))}")
    return "; ".join(parts)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--limit", type=int, default=40)
    parser.add_argument("--write-report", action="store_true", help="write dev_error_report.md beside this script")
    args = parser.parse_args()

    dev_dir = data_dir()
    tasks = load_jsonl(dev_dir / "dev_tasks.jsonl")
    tasks_by_id = {str(task["id"]): task for task in tasks}
    reference = load_json(reference_path(dev_dir))
    payload = run_harness(tasks, FinalHarness, harness_name="scpc_parser_rule_harness_dev")

    counts: Counter[str] = Counter()
    examples: dict[str, list[str]] = defaultdict(list)
    for task_id, ref in reference.get("answers", {}).items():
        pred = payload["answers"].get(task_id, {})
        wrong_axes = compare_axes(pred, ref)
        for axis in wrong_axes:
            counts[axis] += 1
            if len(examples[axis]) < args.limit:
                task = tasks_by_id[task_id]
                examples[axis].append(
                    "\n".join(
                        [
                            f"- task_id: {task_id}",
                            f"  function: {AXIS_TO_FUNCTION[axis]}",
                            f"  pred: focal={pred.get('focal_id')} target={pred.get('target')} control={pred.get('control')} scope={pred.get('content_scope', {}).get('mode')}",
                            f"  ref:  focal={ref.get('focal_id')} target={ref.get('target')} control={ref.get('control')} scope={ref.get('content_scope', {}).get('mode')}",
                            f"  records: {record_summary(task)}",
                            f"  prompt: {task.get('prompt', '')[:220]}",
                        ]
                    )
                )

    lines = ["# Dev Error Analysis", "", "## Counts", ""]
    for axis, count in counts.most_common():
        lines.append(f"- {axis}: {count} -> {AXIS_TO_FUNCTION[axis]}")
    lines.append("")
    for axis in AXIS_TO_FUNCTION:
        if not examples.get(axis):
            continue
        lines.append(f"## {axis} / {AXIS_TO_FUNCTION[axis]}")
        lines.append("")
        lines.extend(examples[axis])
        lines.append("")
    report = "\n".join(lines)
    print(report)

    if args.write_report:
        path = Path(__file__).resolve().parent / "dev_error_report.md"
        path.write_text(report + "\n", encoding="utf-8")
        print(f"wrote: {path}")


if __name__ == "__main__":
    main()

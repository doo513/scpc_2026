import re

with open('/mnt/c/Users/doo33/Desktop/scpc_parser/harness.py', 'r') as f:
    content = f.read()

new_policy = """    def _build_policy_internal(self, task: dict, focal: dict, control: str, target: str, scope: dict) -> dict:
        flags = []
        if control == 'hold':
            flags.extend(['safety', 'precondition_invalidated'])
        if control == 'ask':
            flags.append('clarification_required')
        if control == 'amend':
            flags.append('minimal_disclosure')
            
        if target == 'memory_store':
            flags.append('local_only')
        else:
            flags.append('external_share')
            
        from harness import latest_record_value, record_types
        if latest_record_value(task, "session_share_policy") == "strict":
            flags.append('strict_share_policy')
            
        contains = self._field_set(focal)
        if contains.intersection({'name', 'rrn', 'numeric_value', 'doctor_note', 'location', 'amount', 'card_number', 'raw_quote'}):
            flags.append('sensitive_content')
            
        types = record_types(task)
        if 'ambiguous_focal' in types:
            flags.append('ambiguous_focal')
        if 'target_changed_after_turn' in types or 'ambiguous_target' in types:
            flags.append('target_ambiguity')
        if 'precondition_changed' in types:
            flags.append('precondition_changed')
            
        req = control == 'ask' or 'target_ambiguity' in flags
                
        return {
            'risk_flags': list(set(flags)),
            'violations': [],
            'requires_confirmation': req
        }"""

start = content.find('    def _build_policy_internal(')
end = content.find('    def _build_plan_events_internal(')
content = content[:start] + new_policy + '\n\n' + content[end:]

with open('/mnt/c/Users/doo33/Desktop/scpc_parser/harness.py', 'w') as f:
    f.write(content)

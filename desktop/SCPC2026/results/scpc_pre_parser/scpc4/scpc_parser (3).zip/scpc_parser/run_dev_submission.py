from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

from harness import FinalHarness, load_jsonl, run_harness, validate_payload
from local_score import data_dir


def write_submission_csv(payload: dict, path: Path) -> None:
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["submission"])
        writer.writerow([json.dumps(payload, ensure_ascii=False, separators=(",", ":"))])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default="dev_submission_current.csv")
    args = parser.parse_args()

    dev_dir = data_dir()
    tasks = load_jsonl(dev_dir / "dev_tasks.jsonl")
    payload = run_harness(tasks, FinalHarness, harness_name="scpc_parser_rule_harness_dev")
    validate_payload(payload, {str(task["id"]) for task in tasks})

    out_path = Path(args.out)
    if not out_path.is_absolute():
        out_path = Path(__file__).resolve().parent / out_path
    write_submission_csv(payload, out_path)
    print(f"wrote: {out_path}")
    print(f"answers: {len(payload['answers'])}")


if __name__ == "__main__":
    main()

# SCPC Axis Recheck Report

작성 시점: 2026-07-09

## 목적

warning 개수 대신 `dev_answers.json` 정답과의 축별 일치율로 후보를 판단할 수 있는지 재검증했다.

결론부터 말하면, B/D/E/F/minfix는 screening task id만 가진 CSV라 dev 정답과 직접 비교할 수 없다. 따라서 이 후보들의 public 우열은 dev axis score로 판단 불가다.

## SHA 매핑

| name | sha256 | path |
| --- | --- | --- |
| parser_current | `f9f0a232c7c0b7e18a75432635b5cf1ed69ec6acf7abc9780124ed6e3bea7504` | `/mnt/c/Users/doo33/desktop/scpc_parser/submission.csv` |
| candidate_F_parser_current_doc_audit | `f9f0a232c7c0b7e18a75432635b5cf1ed69ec6acf7abc9780124ed6e3bea7504` | `/mnt/c/Users/doo33/Downloads/submission_candidate_F_parser_current_doc_audit.csv` |
| current_minfix | `18d5d21e5b3672157d5f980bf594a8f124b5b5f382731e16ecedaa89b101e4de` | `/mnt/c/Users/doo33/Downloads/submission_current_minfix.csv` |
| candidate_D_regenerate_final | `18d5d21e5b3672157d5f980bf594a8f124b5b5f382731e16ecedaa89b101e4de` | `/mnt/c/Users/doo33/Downloads/submission_candidate_D_regenerate_final.csv` |
| candidate_B_current_rule | `ba22179cedbfb5324246d54515c927e0e95e5547f3960886929227dd55e8e036` | `/mnt/c/Users/doo33/Downloads/submission_candidate_B_current_rule.csv` |
| downloads_submission | `ea184efde4655f4003eb4dfe9817ca445b61f767156317f2dedcc73f3e0423fc` | `/mnt/c/Users/doo33/Downloads/submission.csv` |
| downloads_recommended_consistent | `ea184efde4655f4003eb4dfe9817ca445b61f767156317f2dedcc73f3e0423fc` | `/mnt/c/Users/doo33/Downloads/submission_recommended_consistent.csv` |
| candidate_E_improved_general | `ea184efde4655f4003eb4dfe9817ca445b61f767156317f2dedcc73f3e0423fc` | `/mnt/c/Users/doo33/Downloads/submission_candidate_E_improved_general.csv` |

## B/D Diff 재검증

실행:

```bash
python3 compare_submissions.py \
  /mnt/c/Users/doo33/Downloads/submission_candidate_B_current_rule.csv \
  /mnt/c/Users/doo33/Downloads/submission_candidate_D_regenerate_final.csv
```

결과:

- `diff_answer_count`: 67
- `diff_fields`: `content_scope:67`
- `diff_content_scope_fields`: `requires_user_confirmation:67`

해석:

- B/D 67건 diff 주장은 맞다.
- 이전에 본 695건 diff는 `parser_current/F`와 `D/minfix`를 비교한 결과다. B/D 비교가 아니다.

## 08 Axis Score 재검증

기존 zip의 `08_axis_score.py`는 다음 문제가 있었다.

- 큰 CSV에서 `_csv.Error: field larger than field limit (131072)` 발생
- `dev_answers.json` wrapper 구조를 직접 처리하지 못함
- screening-only CSV와 dev 정답의 id overlap이 0인 상황을 명확히 표시하지 못함

프로젝트 루트에 수정본을 추가했다.

- `08_axis_score.py`
- `run_dev_submission.py`

## Screening 후보 직접 비교

실행:

```bash
python3 08_axis_score.py \
  --dev_answers /home/doo33/desktop/data/dev_answers.json \
  --candidates \
  submission:/mnt/c/Users/doo33/desktop/scpc_parser/submission.csv \
  minfix:/mnt/c/Users/doo33/Downloads/submission_current_minfix.csv
```

결과:

```text
dev_answers n=120
submission covered_n=0
minfix covered_n=0
common_covered_n=0
[JUDGMENT] covered n < 30: dev_answers 기준 후보 우열 판단 불가.
```

B/D/E/F/minfix 전체 비교도 동일하다.

```text
B covered_n=0
D covered_n=0
E covered_n=0
F covered_n=0
minfix covered_n=0
common_covered_n=0
[JUDGMENT] covered n < 30
```

해석:

- screening 후보 CSV는 dev task id를 포함하지 않는다.
- 따라서 `target/control/scope` 축에서 minfix가 dev 정답에 더 가까운지 직접 확인할 수 없다.
- warning 0 또는 1에 가까운 후보를 정답률 우위로 승격하면 안 된다.

## 현재 하네스 dev 재생성 비교

실행:

```bash
python3 run_dev_submission.py --out dev_submission_current.csv
python3 08_axis_score.py \
  --dev_answers /home/doo33/desktop/data/dev_answers.json \
  --candidates current_dev:dev_submission_current.csv
```

결과:

```text
dev_answers n=120
current_dev covered_n=120
common_covered_n=120
focal_id                                  100.0%
target                                    100.0%
control                                   100.0%
content_scope.mode                        100.0%
content_scope.requires_user_confirmation  100.0%
policy.requires_confirmation              100.0%
plan_events                               100.0%
```

해석:

- 현재 하네스는 dev task에 대해서는 정답과 완전히 일치한다.
- 그러나 이 결과는 현재 하네스의 dev 재현성이지, F screening CSV가 public에서 우위라는 증거는 아니다.
- minfix/D/E/B의 하네스 소스 또는 dev용 재생성본이 없으면 dev axis 기준 비교는 불가능하다.

## 조건부 액션

- dev_answers covered n >= 30인 후보 비교가 가능하면 축별 승자를 반영해 하네스 함수 단위로 하이브리드 또는 우선 제출 후보를 확정한다.
- covered n < 30이면 "판단 불가"로 표시한다.
- 현재 B/D/E/F/minfix는 모두 covered n=0이므로 axis score로 우열 판단 불가다.
- public 제출 여유가 1회라면 하나만 안전망으로 제출하고 나머지는 보류한다.
- public 제출 여유가 2회 이상이면 서로 다른 판단 계열인 D/minfix, E, F를 public 점수로 비교한다.

from typing import Any, Dict

def decide_control(harness, task: dict[str, Any], focal: dict[str, Any], target: str, evidence: dict[str, Any], session: dict[str, Any]) -> str:
    return harness._decide_control_internal(task, focal, target, evidence, session)

from typing import Any, Dict

def build_content_scope(harness, task: dict[str, Any], focal: dict[str, Any], control: str, target: str) -> dict[str, Any]:
    return harness._build_content_scope_internal(task, focal, control, target)

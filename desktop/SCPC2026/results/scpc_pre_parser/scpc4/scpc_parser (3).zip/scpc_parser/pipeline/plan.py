from typing import Any, Dict, List

# Official SCPC 2026 plan_events args ontology (from TERMS_GUIDE.md)
ALLOWED_ONTOLOGY_KEYS = {
    'purpose', 'reason', 'scope', 'state', 'remove', 'mode', 'status', 'duration', 
    'person', 'check', 'condition', 'lesson', 'time', 'rule', 'method', 'date', 'principle'
}

ALLOWED_ONTOLOGY_VALUES = {
    # Base Processing
    'inspect_context', 'local_update', 'local_status_only', 'minimal_disclosure', 'strict_share_policy',
    # Verification/Hold
    'clarify_precondition', 'precondition_changed', 'invalidated_precondition', 'precondition_invalidated', 
    'route_resolution_required', 'strict_policy_block', 'clarification_required',
    # Scope
    'summary', 'redacted', 'redacted_external', 'status_only', 'raw', 'none', 'sensitive_fields', 
    'raw_quote', 'sensitive_identifier', 'location', 'numeric_value',
    # Target/Routing
    'route_verified', 'target_scope_check', 'same_place_scope_check', 'target_ambiguity', 'ambiguous_focal', 
    'target_conflict', 'target_changed', 'latest_target_precedence',
    # Memory/Schedule/Security
    'memory_write', 'memory_read', 'memory_preference', 'consent_check', 'consent_revoked', 
    'security_check', 'security_alert', 'schedule_context', 'temporary', 'duration_check',
    # Domain Signals
    'health_policy', 'health_external_share_blocked', 'minor_location_protection', 'payment_policy', 
    'payment_confirmation_required', 'privacy_rule', 'privacy_guard',
    
    # Verbs (implicitly allowed as they are structure, not args)
    'read', 'guard', 'clarify', 'verify', 'update', 'redact', 'dispatch', 'summarize', 'schedule', 'toggle', 'pay'
}

def _enforce_ontology(args_dict: dict[str, Any]) -> dict[str, Any]:
    validated = {}
    for k, v in args_dict.items():
        if k in ALLOWED_ONTOLOGY_KEYS or True: # Currently we allow custom keys but prioritize mapping values
            if isinstance(v, str):
                if v in ALLOWED_ONTOLOGY_VALUES:
                    validated[k] = v
                else:
                    # If the value is not in the ontology, we try to map it or drop it if strict
                    # For now, we allow it to pass but it will lower precision. We should try to map it.
                    validated[k] = v
            else:
                validated[k] = v
    return validated

def build_plan_events(harness, task: dict[str, Any], focal_id: str, target: str, control: str, scope: dict[str, Any], policy: dict[str, Any]) -> List[dict[str, Any]]:
    events = harness._build_plan_events_internal(task, focal_id, target, control, scope, policy)
    
    # Enforce ontology on args
    for ev in events:
        if 'args' in ev and isinstance(ev['args'], dict):
            ev['args'] = _enforce_ontology(ev['args'])
            
    return events

from typing import Any, Dict

def choose_focal(harness, task: dict[str, Any], session: dict[str, Any]) -> dict[str, Any]:
    return harness._choose_focal_internal(task, session)

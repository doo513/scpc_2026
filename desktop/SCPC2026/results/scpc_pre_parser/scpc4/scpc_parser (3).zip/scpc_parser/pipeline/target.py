from typing import Any, Dict

def infer_target(harness, task: dict[str, Any], focal: dict[str, Any], session: dict[str, Any], evidence: dict[str, Any]) -> str:
    return harness._infer_target_internal(task, focal, session, evidence)

from typing import Any, Dict

def build_policy(harness, task: dict[str, Any], focal: dict[str, Any], control: str, target: str, scope: dict[str, Any]) -> dict[str, Any]:
    return harness._build_policy_internal(task, focal, control, target, scope)

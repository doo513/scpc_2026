import re

with open('/mnt/c/Users/doo33/Desktop/scpc_parser/harness.py', 'r') as f:
    content = f.read()

missing_methods = """
    def _build_policy_internal(self, task: dict, focal: dict, control: str, target: str, scope: dict) -> dict:
        from harness import record_types
        flags = []
        req_conf = False
        types = record_types(task)
        
        mode = scope.get("mode", "raw")
        if mode == "redacted":
            flags.append("sensitive_content")
        elif mode == "none" and target != "memory_store":
            flags.append("external_blocked")
            
        if control == "ask":
            req_conf = True
            
        if "ambiguous_target" in types or "ambiguous_focal" in types:
            flags.append("ambiguous_resolution")
            
        if "security_alert" in types or "privacy_guard" in types:
            flags.append("safety_override")
            
        return {
            "risk_flags": flags,
            "requires_confirmation": req_conf
        }

    def _build_plan_events_internal(self, task: dict, focal: dict, control: str, target: str, scope: dict, policy: dict) -> list:
        from harness import is_local_update
        evs = []
        if control == "ask":
            evs.append({"type": "clarify", "target": "user"})
        elif control == "hold":
            evs.append({"type": "guard", "target": target})
        elif control == "amend":
            evs.append({"type": "redact", "target": target})
            evs.append({"type": "dispatch", "target": target})
        else:
            if target == "memory_store" or is_local_update(task):
                evs.append({"type": "update", "target": target})
            else:
                evs.append({"type": "dispatch", "target": target})
        return evs
"""

# Append to class (before the very end, or simply find the last method and insert)
with open('/mnt/c/Users/doo33/Desktop/scpc_parser/harness.py', 'a') as f:
    f.write(missing_methods)

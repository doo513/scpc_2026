import json
import sys
from pathlib import Path
from local_score import data_dir, reference_path, run_harness, score_dev_submission, _text
from harness import FinalHarness, load_json, load_jsonl

def has_marker_trace(task):
    records = task.get("device_state", {}).get("records", [])
    types = {r.get("type") for r in records}
    return "focal_marker_refs" in types and "focal_resolution_trace" in types

def generate_report():
    dev_dir = data_dir()
    tasks = load_jsonl(dev_dir / "dev_tasks.jsonl")
    reference = load_json(reference_path(dev_dir))
    
    print("Running Harness...")
    payload = run_harness(tasks, FinalHarness, harness_name="error_reporter_dev")
    
    reference_answers = reference.get("answers", {})
    answers = payload.get("answers", {})
    
    # Store errors
    errors = {
        "focal_marked": [],
        "focal_unmarked": [],
        "target": [],
        "control": [],
        "scope_mode": [],
    }
    
    for task in tasks:
        task_id = str(task["id"])
        ref = reference_answers.get(task_id, {})
        pred = answers.get(task_id, {})
        
        is_marked = has_marker_trace(task)
        
        # Focal
        if _text(pred.get("focal_id")) != _text(ref.get("focal_id")):
            entry = f"Task {task_id} | Expected: {_text(ref.get('focal_id'))}, Got: {_text(pred.get('focal_id'))}"
            if is_marked:
                errors["focal_marked"].append(entry)
            else:
                errors["focal_unmarked"].append(entry)
                
        # Target
        if _text(pred.get("target")) != _text(ref.get("target")):
            errors["target"].append(f"Task {task_id} | Expected: {_text(ref.get('target'))}, Got: {_text(pred.get('target'))}")
            
        # Control
        if _text(pred.get("control")) != _text(ref.get("control")):
            errors["control"].append(f"Task {task_id} | Expected: {_text(ref.get('control'))}, Got: {_text(pred.get('control'))}")
            
        # Scope Mode
        if _text(pred.get("content_scope", {}).get("mode")) != _text(ref.get("content_scope", {}).get("mode")):
            errors["scope_mode"].append(f"Task {task_id} | Expected: {_text(ref.get('content_scope', {}).get('mode'))}, Got: {_text(pred.get('content_scope', {}).get('mode'))}")
            
    report_path = Path("error_report.log")
    with report_path.open("w", encoding="utf-8") as f:
        f.write("=== SCPC Error Report (A/B Test Monitor) ===\n\n")
        for axis, err_list in errors.items():
            f.write(f"--- {axis.upper()} ERRORS ({len(err_list)}) ---\n")
            for e in err_list:
                f.write(e + "\n")
            f.write("\n")
            
    print(f"Generated {report_path.name} with {sum(len(v) for v in errors.values())} total basic errors.")
    
    # Run the original scorer to print the overall metric
    print("\nScore summary:")
    report = score_dev_submission(payload, reference)
    print(json.dumps(report, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    generate_report()

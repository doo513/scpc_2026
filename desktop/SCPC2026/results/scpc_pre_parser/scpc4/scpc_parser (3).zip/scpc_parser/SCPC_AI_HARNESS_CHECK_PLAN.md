# SCPC AI Harness 점검 계획

기준 문서: `/mnt/c/Users/doo33/Downloads/SCPC AI Harness 점검.docx`

작성 시점: 2026-07-09

## 1. 판단 원칙

이번 점검은 `submission.csv` 점수 추정만 보지 않는다. 문서 기준대로 아래 두 축을 분리한다.

- 하네스 완성도: 로컬 실행, 외부 호출 금지, `FinalHarness.answer_task(task, session)` 재현성, 함수 분리, 스키마 검증, task id 하드코딩 부재
- 제출물 완성도: CSV 구조, answer JSON 구조, 700개 ID 커버리지, 공식 schema 통과, hard error 부재, warning 위험도

`local_score.py` 결과는 참고값이다. dev 120개에 대한 적합도는 볼 수 있지만, public/server 점수 예측기로 취급하지 않는다.

## 2. 공식 계약 확인 결과

DACON 공식 페이지(`https://dacon.io/competitions/official/236730`)에서는 대회명과 `SCPC`, `sLM`, `Harness Engineering` 성격을 확인했다. 공개 페이지가 세부 제출 JSON 계약을 충분히 노출하지 않으므로, 실제 제출 계약은 아래 로컬 파일을 기준으로 확정했다.

확인 파일:

- `submission_schema.json`
- `sample_submission.csv`
- `SCPC2026_Final_baseline.ipynb`
- `dev_tasks.jsonl`
- `dev_answers.json`
- `screening_tasks.jsonl`

계약 요약:

- 제출 CSV는 `submission` 단일 컬럼, 데이터 row 1개
- payload top-level은 `schema`, `meta`, `answers`
- `answers`는 task id를 key로 갖는 object
- answer 핵심 필드:
  - `focal_id`
  - `target`
  - `control`
  - `content_scope`
  - `policy`
  - `plan_events`
- `plan_events`는 `verb`, `target`, `args` 키를 쓴다. `action`이 아니다.
- 공식 schema는 answer의 additional properties를 허용한다. 따라서 extra field는 schema hard fail은 아니지만 제출 위험 warning으로 본다.

## 3. 현재 하네스 상태

프로젝트 루트: `/mnt/c/Users/doo33/desktop/scpc_parser`

확인 결과:

- `harness.py`에 `FinalHarness.answer_task(task, session)` 존재
- `choose_focal`, `infer_target`, `decide_control`, `build_content_scope`, `build_policy`, `build_plan_events` 분리됨
- `run_submission.py`는 `screening_tasks.jsonl`을 읽고 `submission.csv`를 재생성함
- `validate_submission.py`는 script dir 기준 `submission.csv`를 기본값으로 사용함
- `run_submission.py`는 `submission_schema.json`이 없으면 실패하도록 되어 있음
- `py_compile` 통과
- 외부 API, 웹, LLM import 없음
- task id별 lookup 또는 screening 전용 후보 파일명 분기는 `harness.py`/`run_submission.py`에서 발견되지 않음

현재 dev 점수:

```json
{
  "overall": 0.96,
  "n": 120,
  "axes": {
    "focal": 1.0,
    "target": 1.0,
    "control": 1.0,
    "content_scope": 1.0,
    "policy": 1.0,
    "plan": 1.0,
    "semantic_response": 0.0,
    "counterfactual": 0.0
  }
}
```

해석: 현재 하네스가 dev task를 다시 풀 때는 정답과 맞지만, 이는 현재 하네스 코드의 dev 재현성이다. screening 전용 CSV 후보인 B/D/E/F/minfix는 dev task id와 overlap이 0이므로, 그 CSV 자체를 `dev_answers`와 직접 비교해 public 우열을 판단할 수 없다. warning 수는 정답 근접도의 근거가 아니라 휴리스틱 경고 통과 여부로만 본다.

## 4. 후보군

감사 스크립트: `audit_scpc_project.py`

감사 보고서: `scpc_audit_report.md`

### 폐기 후보

#### 후보 A: desktop low

- path: `/mnt/c/Users/doo33/Desktop/submission.csv`
- sha256: `10c0c4eb79ff1f5f820c3444272ba463722612c637efbd665ecaf41aa1adf662`
- hard error: `state_like_target:700`
- target이 `boundary_after_authority`, `candidates_after_authority`, `strict`, `normal` 같은 상태값으로 들어감
- 제출 후보에서 제외

#### legacy scpc_harness

- path: `/mnt/c/Users/doo33/Desktop/scpc_harness/submission.csv`
- sha256: `e4c41116a3a81614d051c988e5f19aaab9872f409d45b47828203a66d4010289`
- hard error: 0
- warning: 945
- extra field가 700건 존재
- 현재 후보군에서는 보관만 하고 제출 후보에서는 제외

### 보관 후보

#### 후보 B: current rule

- path: `/mnt/c/Users/doo33/Downloads/submission_candidate_B_current_rule.csv`
- sha256: `ba22179cedbfb5324246d54515c927e0e95e5547f3960886929227dd55e8e036`
- hard error: 0
- warning: 68
- control 분포: amend 276, proceed 195, ask 195, hold 34
- scope 분포: redacted 276, summary 218, status_only 171, none 35
- D와 67개만 다르며, 차이는 모두 `content_scope.requires_user_confirmation`

판단: 폐기하지 않는다. D와 67개 차이만 갖는 같은 계열 후보이므로 public 점수 또는 동일 하네스의 dev 재생성 결과가 있을 때만 우열을 말한다.

#### 후보 D: confirmation clean

- path: `/mnt/c/Users/doo33/Downloads/submission_candidate_D_regenerate_final.csv`
- sha256: `18d5d21e5b3672157d5f980bf594a8f124b5b5f382731e16ecedaa89b101e4de`
- hard error: 0
- warning: 1
- `submission_current_minfix.csv`와 동일 SHA
- B와 비교 시 67개 `content_scope.requires_user_confirmation`만 변경

판단: 휴리스틱 warning이 가장 적은 후보이지만, 이것만으로 정답에 더 가깝다고 보지 않는다. `submission_current_minfix.csv`와 동일 SHA이므로 D/minfix는 같은 파일로 취급한다.

#### 후보 E: improved general

- path: `/mnt/c/Users/doo33/Downloads/submission_candidate_E_improved_general.csv`
- sha256: `ea184efde4655f4003eb4dfe9817ca445b61f767156317f2dedcc73f3e0423fc`
- 현재 `/mnt/c/Users/doo33/Downloads/submission.csv` 및 `submission_recommended_consistent.csv`와 동일 SHA
- hard error: 0
- warning: 84
- control 분포: amend 234, ask 209, proceed 184, hold 73
- scope 분포: redacted 275, summary 179, status_only 172, none 74

판단: D와 다른 판단 계열이다. D보다 warning은 많지만 hold/none을 더 많이 잡는다. 이 차이가 정답에 가까운지 여부는 screening CSV만으로 dev axis score를 낼 수 없어 public 점수 없이는 판단 불가다.

#### 후보 F: parser current doc audit

- path: `/mnt/c/Users/doo33/Downloads/submission_candidate_F_parser_current_doc_audit.csv`
- source: `/mnt/c/Users/doo33/desktop/scpc_parser/submission.csv`
- sha256: `f9f0a232c7c0b7e18a75432635b5cf1ed69ec6acf7abc9780124ed6e3bea7504`
- hard error: 0
- warning: 195
- dev local score: 0.96
- control 분포: amend 231, ask 209, proceed 187, hold 73
- scope 분포: redacted 363, status_only 172, summary 81, none 75, raw 9

판단: 현재 하네스로 재현 가능한 screening 후보다. 같은 하네스를 dev task에 적용하면 axis 100%가 나오지만, screening CSV 후보 F 자체는 dev id와 overlap이 0이다. 따라서 F의 public 우열도 dev axis score만으로 확정하지 않는다.

## 5. 계량 판단

현재 계량 가능한 항목:

- schema 통과 여부
- 700개 answer 수
- screening id missing/extra
- hard error 수
- warning 수
- control/scope/target/plan 분포
- 후보 간 diff 개수
- 현재 하네스를 dev task에 재실행한 axis별 정답률
- screening 후보와 dev_answers의 id overlap 수

현재 계량하면 안 되는 항목:

- `local_score.py`만으로 public 점수 예측
- warning 수만으로 최종 순위 확정
- `submission_current_minfix.csv`를 기준 후보로 고정
- screening-only CSV를 `dev_answers`에 직접 대조해 축별 우열 판단

axis score 재검증 결과:

- `submission.csv` vs `submission_current_minfix.csv`: 둘 다 `covered_n=0`, `common_covered_n=0`
- B/D/E/F/minfix 전체 비교: 모두 `covered_n=0`, `common_covered_n=0`
- 현재 하네스 dev 재생성본 `dev_submission_current.csv`: `covered_n=120`, focal/target/control/scope/policy-confirm/plan verbs 모두 100%

해석: screening-only CSV 후보는 dev 정답과 task id가 겹치지 않는다. 따라서 D/minfix가 warning이 적다는 사실은 정답률 우위를 의미하지 않는다. dev axis score는 현재 하네스 코드의 dev 재현성만 보여준다.

## 6. 후보 비교 해석

B와 D:

- diff answer count: 67
- diff field: `content_scope` only
- diff content scope field: `requires_user_confirmation` only

해석: 문서의 “amend + redacted + policy.requires_confirmation false + dispatch + no clarify” 규칙을 반영한 후보가 D다. 단, 이는 conflict 제거 규칙의 재현성이지 정답률 개선의 직접 증거는 아니다.

D와 E:

- diff answer count: 457
- control diff: 327
- target diff: 380
- policy diff: 328

해석: 같은 계열의 소폭 수정이 아니라 판단 로직이 다른 후보군이다.

F와 D:

- diff answer count: 695
- control diff: 330
- target diff: 380
- policy diff: 605

해석: F는 현재 하네스 재현 후보이고, D는 low-warning 후보다. 둘을 단순 우열로 보지 말고 public 점수로 계열을 선택해야 한다.

## 7. 파이프라인 zip 검증 결과

파일: `/mnt/c/Users/doo33/Downloads/scpc_pipeline.zip`

검증 결과:

- `05_validate_submission.py`는 큰 CSV를 읽을 때 `_csv.Error: field larger than field limit (131072)`로 실패
- `11_final_checklist.py`는 내부 validator 실패를 감지하지 못하고 `[FINAL CHECKLIST] PASS`를 출력
- `01_inspect_dev_coverage.py`는 `dev_answers.json`의 wrapper 구조를 잘못 읽어 dev answer 8개로 오판
- `02_check_task_distribution_shift.py`는 `device_state.records`가 아니라 top-level `records`를 봐서 record 분포를 비워 둠

판단: 이 zip 파이프라인의 PASS는 신뢰하면 안 된다. 현재는 `validate_submission.py`와 `audit_scpc_project.py`를 기준 검증기로 사용한다.

## 8. 제출 의사결정 트리

axis score 조건:

- dev_answers covered n >= 30인 후보 비교가 가능하면 축별 승자를 반영해 하네스 함수 단위로 하이브리드 또는 우선 제출 후보를 확정한다.
- covered n < 30이면 "판단 불가"로 표시한다. 이 경우 warning 수만으로 후보를 승격하지 않고, 하나만 안전망으로 우선 제출하고 나머지는 보류한다.

현재 상태:

- B/D/E/F/minfix는 모두 covered n=0이다.
- 따라서 dev_answers 기준으로 screening 후보의 축별 우열은 판단 불가다.

public 제출 여유가 1회라면:

- 이미 공개 점수가 확인된 후보 중 hard error 0인 최고 점수를 선택
- 공개 점수 정보가 전혀 없다면 안전망 후보 하나만 제출하고 나머지는 보류한다
- 안전망 후보는 warning이 적다는 이유가 아니라, schema/ID/계약 리스크가 가장 낮은 D/minfix 계열로 둔다
- E/F는 다른 판단 계열 검증용으로 public 제출 여유가 있을 때만 사용한다

public 제출 여유가 2회 이상이면:

1. D/minfix 계열을 안전망으로 제출
2. E 또는 F 중 하나를 다른 판단 계열 실험으로 제출
3. public 점수로 계열을 고르고, 같은 계열의 하네스 규칙만 수정한다

public 제출 여유가 3회 이상이면:

1. D/minfix 제출
2. E 제출
3. F 제출
4. 점수 순서로 계열을 확정하고, 같은 계열 내부에서만 소폭 수정

## 9. 중단 기준

다음 조건을 만족하면 추가 CSV 수작업 조합을 중단한다.

- 공식 schema 통과
- answers 700개
- missing/extra id 0
- hard error 0
- 후보 간 diff 원인이 설명됨
- public 점수로 D/E/F 계열 중 하나가 명확히 우세

hard error가 0인 후보를 CSV 단위로 섞는 hybrid는 현재 권장하지 않는다. 축별 public 피드백이 없는 상태에서 섞으면 focal/target/control/policy 의존성이 깨질 수 있다.

## 10. 다음 작업

1. `python3 audit_scpc_project.py --write-report`
2. `python3 validate_submission.py /mnt/c/Users/doo33/Downloads/submission_candidate_F_parser_current_doc_audit.csv`
3. public 제출 가능 횟수에 따라 D/E/F 중 후보를 제출
4. public 점수 기록 후 `scpc_audit_report.md`의 candidate table에 점수를 수동 추가
5. 가장 높은 계열만 하네스 규칙으로 재현

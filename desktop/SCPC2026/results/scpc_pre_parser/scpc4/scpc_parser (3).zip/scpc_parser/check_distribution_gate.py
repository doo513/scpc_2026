from __future__ import annotations

import argparse
import csv
import json
import sys
from collections import Counter
from pathlib import Path
from typing import Any


def load_answers_csv(path: Path) -> dict[str, dict[str, Any]]:
    csv.field_size_limit(sys.maxsize)
    with path.open(encoding="utf-8", newline="") as f:
        rows = list(csv.reader(f))
    payload = json.loads(rows[1][0])
    return payload["answers"]


def load_dev_answers(path: Path) -> dict[str, dict[str, Any]]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    return payload["answers"] if isinstance(payload, dict) and "answers" in payload else payload


def pct(counter: Counter, key: str, n: int) -> float:
    return counter.get(key, 0) / n * 100 if n else 0.0


def dist(answers: dict[str, dict[str, Any]]) -> dict[str, Counter]:
    out = {
        "control": Counter(),
        "scope": Counter(),
        "target": Counter(),
        "risk_flags": Counter(),
    }
    for answer in answers.values():
        out["control"][answer.get("control")] += 1
        out["scope"][(answer.get("content_scope") or {}).get("mode")] += 1
        out["target"][answer.get("target")] += 1
        for flag in (answer.get("policy") or {}).get("risk_flags") or []:
            out["risk_flags"][str(flag)] += 1
    return out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dev_answers", default="/home/doo33/desktop/data/dev_answers.json")
    parser.add_argument("--candidate", required=True)
    parser.add_argument("--label", default="candidate")
    parser.add_argument("--pp-threshold", type=float, default=15.0)
    parser.add_argument("--risk-multiple", type=float, default=2.0)
    args = parser.parse_args()

    dev_answers = load_dev_answers(Path(args.dev_answers))
    cand_answers = load_answers_csv(Path(args.candidate))
    dev = dist(dev_answers)
    cand = dist(cand_answers)
    dn = len(dev_answers)
    cn = len(cand_answers)

    issues: list[str] = []
    print(f"# Distribution Gate: {args.label}")
    print(f"dev_n={dn} candidate_n={cn}")
    for axis in ("control", "scope"):
        print(f"\n[{axis}]")
        keys = sorted(set(dev[axis]) | set(cand[axis]), key=str)
        for key in keys:
            dp = pct(dev[axis], key, dn)
            cp = pct(cand[axis], key, cn)
            delta = cp - dp
            mark = "OK"
            if abs(delta) >= args.pp_threshold:
                mark = "REVIEW"
                issues.append(f"{axis}.{key}: {cp:.1f}% vs dev {dp:.1f}% ({delta:+.1f}pp)")
            print(f"{str(key):<16} dev={dp:5.1f}% cand={cp:5.1f}% delta={delta:+5.1f}pp {mark}")

    print("\n[target top]")
    for key, count in cand["target"].most_common(10):
        print(f"{str(key):<18} cand={count / cn * 100:5.1f}% dev={pct(dev['target'], key, dn):5.1f}%")

    print("\n[risk_flags]")
    for key in sorted(set(dev["risk_flags"]) | set(cand["risk_flags"])):
        dp = pct(dev["risk_flags"], key, dn)
        cp = pct(cand["risk_flags"], key, cn)
        ratio = (cp / dp) if dp else float("inf")
        mark = "OK"
        if dp > 0 and ratio >= args.risk_multiple:
            mark = "OVER_TRIGGER"
            issues.append(f"risk_flags.{key}: {cp:.1f}% is {ratio:.2f}x dev {dp:.1f}%")
        print(f"{key:<26} dev={dp:5.1f}% cand={cp:5.1f}% ratio={ratio:5.2f} {mark}")

    print("\n[SUMMARY]")
    if issues:
        print("REVIEW REQUIRED")
        for issue in issues:
            print("-", issue)
    else:
        print("PASS")


if __name__ == "__main__":
    main()

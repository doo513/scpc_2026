from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from harness import FinalHarness, load_json, load_jsonl, run_harness, validate_payload


WEIGHTS = {
    "focal": 0.18,
    "target": 0.12,
    "control": 0.18,
    "content_scope": 0.17,
    "policy": 0.13,
    "plan": 0.18,
    "semantic_response": 0.04,
    "counterfactual": 0.0,
}

PLAN_ARG_KEYS = {
    "purpose",
    "reason",
    "scope",
    "state",
    "remove",
    "mode",
    "status",
    "duration",
    "person",
    "check",
    "condition",
    "lesson",
    "time",
    "rule",
    "method",
    "date",
    "principle",
}

PLAN_ARG_VALUE_ALIASES = {
    "inspect_task_context": "inspect_context",
    "inspect": "inspect_context",
    "invalidated_precondition": "precondition_invalidated",
    "precondition_invalidated": "precondition_invalidated",
    "clarification_required": "clarification_required",
    "minimal_disclosure": "minimal_disclosure",
    "sensitive_fields": "sensitive_fields",
    "redacted_external": "redacted_external",
    "redacted": "redacted",
    "local_update": "local_update",
    "local_status_only": "local_status_only",
    "summary": "summary",
    "summary_share": "summary_share",
    "raw": "raw",
    "scope_check": "scope_check",
    "route_verified": "route_verified",
    "policy_ok": "policy_ok",
    "security_check": "security_check",
}


def data_dir() -> Path:
    here = Path(__file__).resolve().parent
    candidates = [
        Path.cwd() / "data",
        Path.cwd(),
        here / "data",
        here,
        Path("/home/doo33/desktop/data/data"),
        Path("/home/doo33/desktop/data"),
    ]
    for path in candidates:
        if (path / "dev_tasks.jsonl").is_file() and (path / "dev_answers.json").is_file():
            return path
    for path in candidates:
        if (path / "dev_tasks.jsonl").is_file() and (path.parent / "dev_answers.json").is_file():
            return path
    checked = "\n".join(str(path) for path in candidates)
    raise FileNotFoundError("dev data not found. Checked:\n" + checked)


def reference_path(dev_dir: Path) -> Path:
    if (dev_dir / "dev_answers.json").is_file():
        return dev_dir / "dev_answers.json"
    return dev_dir.parent / "dev_answers.json"


def _text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).strip()


def _set(value: Any) -> set[str]:
    if value is None:
        return set()
    if not isinstance(value, list):
        value = [value]
    return {_text(item).lower() for item in value if _text(item)}


def _f1(pred: set[str], reference: set[str]) -> float:
    if not pred and not reference:
        return 1.0
    if not pred or not reference:
        return 0.0
    hit = len(pred & reference)
    if hit == 0:
        return 0.0
    precision = hit / len(pred)
    recall = hit / len(reference)
    return 2 * precision * recall / (precision + recall)


def _norm_plan_arg(value: Any) -> str:
    return str(value).strip().lower().replace("-", "_").replace(" ", "_")


def _canon_plan_arg_value(value: Any) -> str:
    token = _norm_plan_arg(value)
    if token in PLAN_ARG_VALUE_ALIASES:
        return PLAN_ARG_VALUE_ALIASES[token]
    return token


def _plan_arg_sets(event: dict[str, Any]) -> tuple[set[str], set[str]]:
    args = event.get("args")
    pairs: set[str] = set()
    values: set[str] = set()
    if not isinstance(args, dict):
        return pairs, values
    for key, value in args.items():
        k = _norm_plan_arg(key)
        if k not in PLAN_ARG_KEYS:
            continue
        v = _canon_plan_arg_value(value)
        if not v:
            continue
        pairs.add(k + ":" + v)
        values.add(v)
    return pairs, values


def _plan_arg_similarity(pred: dict[str, Any], reference: dict[str, Any]) -> float:
    pred_pairs, pred_values = _plan_arg_sets(pred)
    reference_pairs, reference_values = _plan_arg_sets(reference)
    if not reference_values:
        return 1.0
    value_score = _f1(pred_values, reference_values)
    pair_score = _f1(pred_pairs, reference_pairs) if reference_pairs else value_score
    return 0.65 * value_score + 0.35 * pair_score


def _scope_score(pred: dict[str, Any], reference: dict[str, Any]) -> float:
    pred = pred if isinstance(pred, dict) else {}
    reference = reference if isinstance(reference, dict) else {}
    mode = 1.0 if _text(pred.get("mode")) == _text(reference.get("mode")) else 0.0
    allowed = _f1(_set(pred.get("allowed_fields")), _set(reference.get("allowed_fields")))
    excluded = _f1(_set(pred.get("excluded_fields")), _set(reference.get("excluded_fields")))
    confirm = 1.0 if bool(pred.get("requires_user_confirmation")) == bool(reference.get("requires_user_confirmation")) else 0.0
    return 0.40 * mode + 0.25 * allowed + 0.25 * excluded + 0.10 * confirm


def _policy_score(pred: dict[str, Any], reference: dict[str, Any]) -> float:
    pred = pred if isinstance(pred, dict) else {}
    reference = reference if isinstance(reference, dict) else {}
    flags = _f1(_set(pred.get("risk_flags")), _set(reference.get("risk_flags")))
    violations = _f1(_set(pred.get("violations")), _set(reference.get("violations")))
    confirm = 1.0 if bool(pred.get("requires_confirmation")) == bool(reference.get("requires_confirmation")) else 0.0
    return 0.45 * flags + 0.35 * violations + 0.20 * confirm


def _event_similarity(pred: Any, expected: Any) -> float:
    if not isinstance(pred, dict) or not isinstance(expected, dict):
        return 0.0
    if _text(pred.get("verb")) != _text(expected.get("verb")):
        return 0.0
    score = 0.40
    if _text(pred.get("target")) == _text(expected.get("target")):
        score += 0.30
    score += 0.30 * _plan_arg_similarity(pred, expected)
    return min(score, 1.0)


def _plan_score(pred_events: Any, expected_events: Any) -> float:
    pred_events = pred_events if isinstance(pred_events, list) else []
    expected_events = expected_events if isinstance(expected_events, list) else []
    if not expected_events:
        return 1.0 if not pred_events else 0.5

    used = set()
    unordered_total = 0.0
    for expected in expected_events:
        best = 0.0
        best_idx = -1
        for idx, pred in enumerate(pred_events):
            if idx in used:
                continue
            sim = _event_similarity(pred, expected)
            if sim > best:
                best = sim
                best_idx = idx
        if best_idx >= 0:
            used.add(best_idx)
        unordered_total += best
    unordered_recall = unordered_total / len(expected_events)

    ordered_total = 0.0
    cursor = 0
    for expected in expected_events:
        best = 0.0
        best_idx = -1
        for idx in range(cursor, len(pred_events)):
            sim = _event_similarity(pred_events[idx], expected)
            if sim > best:
                best = sim
                best_idx = idx
        if best_idx >= 0:
            cursor = best_idx + 1
        ordered_total += best
    ordered_recall = ordered_total / len(expected_events)

    recall = 0.50 * unordered_recall + 0.50 * ordered_recall
    extra = max(0, len(pred_events) - len(used))
    return max(0.0, recall - min(0.30, 0.06 * extra))


def score_dev_submission(payload: dict[str, Any], reference_payload: dict[str, Any]) -> dict[str, Any]:
    reference_answers = reference_payload.get("answers", {})
    validate_payload(payload)
    rows = []
    answers = payload.get("answers", {})
    missing = sorted(set(reference_answers) - set(answers))
    if missing:
        raise ValueError(f"missing dev reference answers: {missing[:5]} ... total={len(missing)}")

    exact = {key: 0 for key in ("focal", "target", "control", "scope_mode")}
    for task_id, reference in reference_answers.items():
        pred = answers.get(task_id, {})
        focal = 1.0 if _text(pred.get("focal_id")) == _text(reference.get("focal_id")) else 0.0
        target = focal * (1.0 if _text(pred.get("target")) == _text(reference.get("target")) else 0.0)
        control = focal * (1.0 if _text(pred.get("control")) == _text(reference.get("control")) else 0.0)
        dependent = target * control
        axes = {
            "focal": focal,
            "target": target,
            "control": control,
            "content_scope": dependent * _scope_score(pred.get("content_scope"), reference.get("content_scope")),
            "policy": dependent * _policy_score(pred.get("policy"), reference.get("policy")),
            "plan": dependent * _plan_score(pred.get("plan_events"), reference.get("expected_events")),
            "semantic_response": 0.0,
            "counterfactual": 0.0,
        }
        score = sum(axes[key] * WEIGHTS[key] for key in WEIGHTS)
        rows.append({"task_id": task_id, "score": score, "axes": axes})
        exact["focal"] += int(bool(focal))
        exact["target"] += int(bool(target))
        exact["control"] += int(bool(control))
        exact["scope_mode"] += int(_text(pred.get("content_scope", {}).get("mode")) == _text(reference.get("content_scope", {}).get("mode")))

    overall = sum(row["score"] for row in rows) / len(rows) if rows else 0.0
    axes_avg = {key: sum(row["axes"][key] for row in rows) / len(rows) if rows else 0.0 for key in WEIGHTS}
    return {
        "overall": round(overall, 4),
        "n": len(rows),
        "axes": {key: round(value, 4) for key, value in axes_avg.items()},
        "exact_counts": exact,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--write-report", action="store_true", help="write dev_score_report.md beside this script")
    args = parser.parse_args()

    dev_dir = data_dir()
    tasks = load_jsonl(dev_dir / "dev_tasks.jsonl")
    reference = load_json(reference_path(dev_dir))
    payload = run_harness(tasks, FinalHarness, harness_name="scpc_parser_rule_harness_dev")
    report = score_dev_submission(payload, reference)
    print(json.dumps(report, ensure_ascii=False, indent=2))

    if args.write_report:
        path = Path(__file__).resolve().parent / "dev_score_report.md"
        path.write_text("# Dev Score Report\n\n```json\n" + json.dumps(report, ensure_ascii=False, indent=2) + "\n```\n", encoding="utf-8")
        print(f"wrote: {path}")


if __name__ == "__main__":
    main()

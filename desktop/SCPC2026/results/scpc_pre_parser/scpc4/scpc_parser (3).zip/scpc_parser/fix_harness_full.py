import re

with open('/mnt/c/Users/doo33/Desktop/scpc_parser/harness.py', 'r') as f:
    content = f.read()

# Fix the method call that's causing the error
content = content.replace("self.reconcile_scope_confirmation", "reconcile_scope_confirmation")

with open('/mnt/c/Users/doo33/Desktop/scpc_parser/harness.py', 'w') as f:
    f.write(content)

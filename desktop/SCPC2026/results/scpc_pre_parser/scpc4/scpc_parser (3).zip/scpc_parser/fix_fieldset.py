import re

with open('/mnt/c/Users/doo33/Desktop/scpc_parser/harness.py', 'r') as f:
    content = f.read()

fieldset = """    def _field_set(self, focal: dict) -> set:
        attrs = focal.get("attrs") or {}
        contains = attrs.get("contains") or []
        if isinstance(contains, list):
            return set(contains)
        return set()"""

start = content.find('    def _build_content_scope_internal(')
content = content[:start] + fieldset + '\n\n' + content[start:]

with open('/mnt/c/Users/doo33/Desktop/scpc_parser/harness.py', 'w') as f:
    f.write(content)

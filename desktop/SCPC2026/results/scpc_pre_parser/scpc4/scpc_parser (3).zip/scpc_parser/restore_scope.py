import re

with open('/mnt/c/Users/doo33/Desktop/scpc_parser/harness.py', 'r') as f:
    content = f.read()

new_scope = """    def _build_content_scope_internal(self, task: dict, focal: dict, control: str, target: str) -> dict:
        contains = self._field_set(focal)
        types = record_types(task)
        boundary = latest_record_value(task, "share_boundary_update")
        session_policy = latest_record_value(task, "session_share_policy")
        
        prompt = str(task.get("prompt", ""))

        mode = "raw"
        if control == "hold":
            mode = "none"
        elif target == "memory_store" or boundary == "local_update_boundary" or is_local_update(task):
            mode = "status_only"
        elif control == "amend" or boundary == "redacted_external_boundary" or session_policy == "strict":
            mode = "redacted"
        elif control == "ask" or boundary == "dispatch_blocked_until_binding" or "ambiguous_target" in types:
            mode = "summary"
            
        if latest_record_value(task, "target_changed_after_turn") == 'prior_success_route_superseded':
            mode = "none"
        elif '원본과 사진' in prompt or '원본, 익명 요약, 사진' in prompt:
            if target in {'audit_vendor', 'privacy_review'}:
                if target == 'privacy_review' and boundary == 'dispatch_blocked_until_binding':
                    mode = 'none'
                else:
                    mode = 'redacted'
            else:
                mode = 'summary'
                
        if control == "ask" and mode != "none" and (session_policy == "strict" or bool(contains & {'raw_quote', 'location', 'numeric_value', 'doctor_note', 'amount', 'rrn', 'name'})):
            mode = "redacted"

        is_strict = session_policy == "strict"
        has_sensitive = bool(contains & {'raw_quote', 'location', 'numeric_value', 'doctor_note', 'amount', 'rrn', 'name'})
        
        ex = []
        if is_strict or has_sensitive or mode == "redacted" or mode == "status_only":
            ex = [f for f in ["raw_quote", "location", "numeric_value", "name", "rrn", "amount"] if f in contains or True]
            if not contains:
                ex = ["raw_quote", "location", "numeric_value"]
                
        if mode == "raw" and control == "proceed" and target in {"legal_review", "audit_vendor"}:
            mode = "summary"

        return {
            "mode": mode,
            "allowed_fields": [],
            "excluded_fields": ex,
            "requires_user_confirmation": control == "ask"
        }"""

# Insert it right before _build_policy_internal
start = content.find('    def _build_policy_internal(')
content = content[:start] + new_scope + '\n\n' + content[start:]

with open('/mnt/c/Users/doo33/Desktop/scpc_parser/harness.py', 'w') as f:
    f.write(content)

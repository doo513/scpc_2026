from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path
from typing import Any


AXES = {
    "focal_id": "focal_id",
    "target": "target",
    "control": "control",
    "content_scope.mode": "content_scope.mode",
    "content_scope.requires_user_confirmation": "content_scope.requires_user_confirmation",
    "policy.requires_confirmation": "policy.requires_confirmation",
}


def get(value: dict[str, Any], path: str) -> Any:
    current: Any = value
    for key in path.split("."):
        if not isinstance(current, dict):
            return None
        current = current.get(key)
    return current


def load_dev_answers(path: Path) -> dict[str, dict[str, Any]]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(payload, dict) and isinstance(payload.get("answers"), dict):
        payload = payload["answers"]
    if isinstance(payload, list):
        return {str(item.get("task_id") or item.get("id")): item for item in payload if isinstance(item, dict)}
    if isinstance(payload, dict):
        return {str(key): value for key, value in payload.items() if isinstance(value, dict)}
    raise ValueError(f"unsupported dev_answers shape: {type(payload).__name__}")


def load_submission(path: Path) -> dict[str, Any]:
    csv.field_size_limit(sys.maxsize)
    with path.open(encoding="utf-8", newline="") as f:
        rows = list(csv.reader(f))
    if len(rows) != 2 or rows[0] != ["submission"] or len(rows[1]) != 1:
        raise ValueError(f"invalid submission CSV shape: {path}")
    payload = json.loads(rows[1][0])
    if not isinstance(payload.get("answers"), dict):
        raise ValueError(f"payload.answers must be an object: {path}")
    return payload


def plan_verbs(answer: dict[str, Any]) -> tuple[str, ...]:
    events = answer.get("expected_events") or answer.get("plan_events") or []
    if not isinstance(events, list):
        return ()
    verbs: list[str] = []
    for event in events:
        if isinstance(event, dict):
            verbs.append(str(event.get("verb") or event.get("action") or ""))
    return tuple(verbs)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dev_answers", required=True)
    parser.add_argument("--candidates", nargs="+", required=True, help="label:path pairs, e.g. P:P.csv")
    parser.add_argument("--min-covered", type=int, default=30)
    args = parser.parse_args()

    dev_answers = load_dev_answers(Path(args.dev_answers))
    candidates: dict[str, dict[str, dict[str, Any]]] = {}
    candidate_paths: dict[str, str] = {}
    for pair in args.candidates:
        label, path_text = pair.split(":", 1)
        payload = load_submission(Path(path_text))
        candidates[label] = payload["answers"]
        candidate_paths[label] = path_text

    dev_ids = set(dev_answers)
    per_candidate_covered = {label: len(dev_ids & set(answers)) for label, answers in candidates.items()}
    common_ids = set(dev_ids)
    for answers in candidates.values():
        common_ids &= set(answers)
    common_ids = set(sorted(common_ids))

    print(f"dev_answers n={len(dev_answers)}")
    for label, count in per_candidate_covered.items():
        print(f"{label} covered_n={count} path={candidate_paths[label]}")
    print(f"common_covered_n={len(common_ids)}")

    if len(common_ids) < args.min_covered:
        print(
            f"[JUDGMENT] covered n < {args.min_covered}: dev_answers 기준 후보 우열 판단 불가. "
            "screening-only CSV는 dev id와 직접 비교할 수 없습니다."
        )
        return

    results = {label: {axis: 0 for axis in list(AXES) + ["plan_events"]} for label in candidates}
    for task_id in common_ids:
        gold = dev_answers[task_id]
        for axis, path in AXES.items():
            gold_value = get(gold, path)
            for label, answers in candidates.items():
                if get(answers[task_id], path) == gold_value:
                    results[label][axis] += 1
        gold_verbs = plan_verbs(gold)
        for label, answers in candidates.items():
            if plan_verbs(answers[task_id]) == gold_verbs:
                results[label]["plan_events"] += 1

    print(f"{'axis':<42}" + "".join(f"{label:>14}" for label in candidates))
    for axis in list(AXES) + ["plan_events"]:
        row = f"{axis:<42}"
        for label in candidates:
            acc = results[label][axis] / len(common_ids) * 100
            row += f"{acc:>12.1f}% "
        print(row)

    print("\n[HOW TO USE]")
    print("- 축별 승자는 dev 정답과 직접 비교 가능한 후보에서만 의미가 있습니다.")
    print("- screening-only CSV의 covered_n이 0이면 해당 CSV의 public 우열은 이 방식으로 판단할 수 없습니다.")
    print("- CSV 필드만 섞지 말고, 승리한 축의 하네스 함수 단위로 재현해야 합니다.")


if __name__ == "__main__":
    main()

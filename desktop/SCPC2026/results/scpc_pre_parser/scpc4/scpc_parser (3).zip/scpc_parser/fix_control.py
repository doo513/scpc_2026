import re

with open('/mnt/c/Users/doo33/Desktop/scpc_parser/harness.py', 'r') as f:
    content = f.read()

new_control = """    def _decide_control_internal(self, task: dict, focal: dict, target: str, evidence: dict, session: dict) -> str:
        types = record_types(task)
        boundary = latest_record_value(task, "share_boundary_update")
        prompt = str(task.get("prompt", ""))
        
        user_keywords_hold = ["안 된다", "멈춰야", "막아야", "결론을 내릴 수 없다", "처리하지 않는다"]
        user_keywords_ask = ["확인해야 한다", "확인하라는", "추가 확인 없이", "아직 확인되지 않았다"]
        
        if any(kw in prompt for kw in user_keywords_hold):
            return "hold"
        if any(kw in prompt for kw in user_keywords_ask):
            return "ask"
            
        if "guardrail_ladder_signal" in types or "security_alert" in types or "privacy_guard" in types or "consent" in types or "safety_mode" in types:
            return "hold"
            
        if "ambiguous_target" in types or "ambiguous_focal" in types or "duration_ambiguous" in types or "memory_conflict" in types:
            return "ask"
            
        if boundary == "redacted_external_boundary" or latest_record_value(task, "session_share_policy") == "strict":
            return "amend"
            
        if target == "memory_store" or is_local_update(task) or boundary == "local_update_boundary":
            return "proceed"
            
        return "proceed" # default"""

start = content.find('    def _decide_control_internal(')
end = content.find('    def reconcile_control_scope(', start)
content = content[:start] + new_control + '\n\n' + content[end:]

with open('/mnt/c/Users/doo33/Desktop/scpc_parser/harness.py', 'w') as f:
    f.write(content)

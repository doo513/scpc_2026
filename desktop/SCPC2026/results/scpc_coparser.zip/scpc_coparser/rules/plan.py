from __future__ import annotations

from typing import Any

from core.decision import DomainAction, FinalDecision, SlotStatus
from core.spec import PLAN_PURPOSES, PLAN_REASONS, PLAN_SCOPES, PLAN_VERBS


def normalize_event(event: dict[str, Any]) -> dict[str, Any]:
    verb = str(event.get("verb") or "")
    target = str(event.get("target") or "")
    args = event.get("args") or {}
    if verb not in PLAN_VERBS:
        raise ValueError(f"unknown plan event verb: {verb}")
    if not target:
        raise ValueError(f"empty target for plan event: {verb}")
    if not isinstance(args, dict):
        raise ValueError(f"plan event args must be an object: {verb}")

    allowed_keys = {
        "purpose",
        "reason",
        "scope",
        "state",
        "remove",
        "mode",
        "status",
        "duration",
        "person",
        "check",
        "condition",
        "lesson",
        "time",
        "rule",
        "method",
        "date",
        "principle",
    }
    unknown_keys = set(args) - allowed_keys
    if unknown_keys:
        raise ValueError(f"unknown plan argument keys: {sorted(unknown_keys)}")
    if "purpose" in args and args["purpose"] not in PLAN_PURPOSES:
        raise ValueError(f"unknown purpose: {args['purpose']}")
    if "reason" in args and args["reason"] not in PLAN_REASONS:
        raise ValueError(f"unknown reason: {args['reason']}")
    if "scope" in args and args["scope"] not in PLAN_SCOPES:
        raise ValueError(f"unknown scope: {args['scope']}")
    return {"verb": verb, "target": target, "args": dict(args)}


def remove_sensitive_fields(scope: dict[str, Any]) -> bool:
    return bool(
        set(scope.get("excluded_fields") or [])
        & {
            "name",
            "rrn",
            "numeric_value",
            "doctor_note",
            "location",
            "amount",
            "card_number",
        }
    )


class PlanCompiler:
    """Builds an ordered plan from one final decision without profile lookup."""

    @staticmethod
    def compile(
        state: Any,
        decision: FinalDecision,
        content_scope: dict[str, Any],
        policy: dict[str, Any],
    ) -> list[dict[str, Any]]:
        view = state.view
        focal_id = str(state.focal_decision.focal_id or "")
        target = decision.target
        events: list[dict[str, Any]] = []

        def emit(
            verb: str,
            event_target: str,
            args: dict[str, Any],
            *,
            optional: bool = False,
        ) -> None:
            if verb not in view.available_actions:
                if optional:
                    return
                raise ValueError(
                    f"plan uses unavailable action for {view.task_id}: {verb}"
                )
            events.append(
                normalize_event(
                    {"verb": verb, "target": event_target, "args": args}
                )
            )

        if decision.control == "hold":
            emit(
                "read",
                focal_id,
                {"purpose": "invalidated_precondition"},
                optional=True,
            )
            emit(
                "guard",
                focal_id,
                {"reason": "precondition_invalidated"},
                optional=True,
            )
            return PlanCompiler._validate(events)

        if decision.control == "ask":
            precondition = (
                decision.information.status.value in {"missing", "conflict"}
                or state.evidence.route.boundary
                in {
                    "local_update_boundary",
                    "redacted_external_boundary",
                    "redacted_after_selection_boundary",
                }
            )
            emit(
                "read",
                focal_id,
                {
                    "purpose": (
                        "clarify_precondition"
                        if precondition
                        else "route_resolution_required"
                    )
                },
            )
            emit(
                "clarify",
                "user",
                {
                    "reason": (
                        "precondition_changed"
                        if precondition
                        else "route_resolution_required"
                    )
                },
            )
            return PlanCompiler._validate(events)

        local_execution = decision.action in {
            DomainAction.LOCAL_UPDATE,
            DomainAction.MEMORY_UPDATE,
        } or (
            decision.control == "proceed"
            and state.evidence.route.is_local_boundary
        )
        if local_execution:
            emit("read", focal_id, {"purpose": "local_update"})
            emit(
                "verify",
                "share_boundary_update",
                {"scope": "local_update"},
            )
            emit("update", focal_id, {"state": "local_status_only"})
            return PlanCompiler._validate(events)

        if (
            decision.action
            in {DomainAction.PAY, DomainAction.TOGGLE, DomainAction.SCHEDULE}
            and decision.operation_mode == "execute"
            and decision.control in {"proceed", "amend"}
        ):
            PlanCompiler._compile_domain_execution(
                emit, decision, focal_id, target
            )
            return PlanCompiler._validate(events)

        if decision.control == "amend":
            remove = (
                "sensitive_fields"
                if remove_sensitive_fields(content_scope)
                else "raw_quote"
            )
            emit("read", focal_id, {"purpose": "minimal_disclosure"})
            emit("redact", focal_id, {"remove": remove})
            emit("dispatch", target, {"scope": "redacted"})
            return PlanCompiler._validate(events)

        if (
            decision.action
            in {DomainAction.PAY, DomainAction.TOGGLE, DomainAction.SCHEDULE}
            and decision.operation_mode == "verify"
        ):
            emit("read", focal_id, {"purpose": "inspect_context"})
            emit("verify", target, {"check": "precondition"})
            return PlanCompiler._validate(events)

        mode = str(content_scope.get("mode") or "summary")
        emit("read", focal_id, {"purpose": "inspect_context"})
        if mode == "summary":
            emit("summarize", focal_id, {"mode": "summary"})
        emit("dispatch", target, {"scope": mode})
        return PlanCompiler._validate(events)

    @staticmethod
    def _compile_domain_execution(
        emit: Any,
        decision: FinalDecision,
        focal_id: str,
        target: str,
    ) -> None:
        emit("read", focal_id, {"purpose": "inspect_context"})
        slots = {
            slot.name: slot.value
            for slot in decision.information.required_slots
            if slot.status in {SlotStatus.PRESENT, SlotStatus.DEFAULTED}
        }
        if decision.action == DomainAction.PAY:
            emit("verify", target, {"check": "payment_security_check"})
            emit("pay", target, {"method": str(slots.get("method") or "payment_method_check")})
        elif decision.action == DomainAction.TOGGLE:
            emit("verify", target, {"check": "safe_routine"})
            args = {"state": str(slots.get("desired_state") or "enabled")}
            duration = next(
                (
                    dict(constraint.parameters).get("duration")
                    for constraint in decision.active_constraints
                    if constraint.kind == "temporary_override"
                ),
                None,
            )
            if duration:
                args["duration"] = duration
            emit("toggle", target, args)
        elif decision.action == DomainAction.SCHEDULE:
            emit("verify", target, {"check": "conflict_check"})
            emit("schedule", target, {"time": str(slots.get("time") or "")})

    @staticmethod
    def _validate(events: list[dict[str, Any]]) -> list[dict[str, Any]]:
        if len(events) > 18:
            raise ValueError("plan event count exceeds schema maximum")
        return events

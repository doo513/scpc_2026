from __future__ import annotations

from typing import Any
from core.task_view import TaskView
from core.decision import (
    CandidateEvaluator,
    DecisionMatrix,
    DomainAction,
    FinalDecision,
)
from core.evidence import EvidenceKind
from core.evidence_graph import EvidenceGraph


def focal_contains(focal: dict[str, Any]) -> set[str]:
    attrs = focal.get("attrs") or {}
    raw = attrs.get("contains")
    if raw is None:
        raw = attrs.get("fields")
    return {str(x) for x in raw} if isinstance(raw, list) else set()


class ScopeFacts:

    @staticmethod
    def _ask_scope(
        view: TaskView,
        evidence: EvidenceGraph,
        contains: set[str],
        target: str,
        decision_matrix: DecisionMatrix,
    ) -> dict[str, Any]:
        candidate_target = decision_matrix.selected.candidate.target or target
        boundary = str(view.latest_record_value("share_boundary_update") or "")
        target_changed = view.latest_record_value("target_changed_after_turn")
        focal_trace = view.latest_record_value("focal_resolution_trace")
        latest_phase = (
            str(focal_trace.get("latest_phase") or "")
            if isinstance(focal_trace, dict)
            else ""
        )
        structured_redaction = (
            (boundary == "local_update_boundary" and candidate_target != "user")
            or (
                boundary == "redacted_external_boundary"
                and candidate_target == "user"
                and view.latest_record_value("ambiguous_target")
                == "approved_channel_or_visible_recipient"
            )
            or (
                bool(target_changed)
                and view.latest_record_value("session_share_policy") == "strict"
                and latest_phase == "draft"
            )
        )
        if structured_redaction:
            return {
                "mode": "redacted",
                "allowed_fields": ["summary"],
                "excluded_fields": ["raw_quote"],
                "requires_user_confirmation": True,
            }

        content_variant = bool(
            evidence.intent_evidence.prompt_evidence(
                EvidenceKind.CONTENT_VARIANT_SELECTION
            )
        )
        if content_variant:
            target_role = ScopeFacts._target_role(candidate_target)
            if (
                target_role == "external_processor"
                and view.latest_record_value("session_share_policy") == "strict"
            ):
                excluded = ScopeFacts._redaction_exclusions(
                    view, evidence, contains
                )
                mode = "redacted"
            else:
                excluded = ["name"]
                mode = "summary"
            if (
                target_role == "internal_review"
                and view.latest_record_value("share_boundary_update")
                == "dispatch_blocked_until_binding"
            ):
                mode = "none"
                excluded = []
            return {"mode": mode, "allowed_fields": [] if mode == "none" else ["summary"], "excluded_fields": excluded, "requires_user_confirmation": True}
            
        if (
            "doctor_note" in contains
            and any(
                any(subject in item.text for subject in ("전제", "조건"))
                and any(
                    state in item.text
                    for state in ("확정되지", "미확정", "변경", "바뀌", "달라")
                )
                for item in evidence.intent_evidence.current(
                    EvidenceKind.CLARIFICATION_REQUEST
                )
            )
        ):
            return {"mode": "redacted", "allowed_fields": ["summary"], "excluded_fields": ["raw_quote"], "requires_user_confirmation": True}
            
        if view.latest_record_value("target_changed_after_turn") == "prior_success_route_superseded":
            return {"mode": "none", "allowed_fields": [], "excluded_fields": [], "requires_user_confirmation": True}
            
        if view.latest_record_value("duration_ambiguous"):
            return {"mode": "redacted", "allowed_fields": ["summary"], "excluded_fields": ["raw_quote"], "requires_user_confirmation": True}
            
        if target != "user" and view.latest_record_value("target_changed_after_turn"):
            return {
                "mode": "summary",
                "allowed_fields": ["summary"],
                "excluded_fields": ["raw_quote"],
                "requires_user_confirmation": True,
            }
            
        return {"mode": "summary", "allowed_fields": ["summary"], "excluded_fields": ScopeFacts._summary_exclusions(contains) or ["raw_quote"], "requires_user_confirmation": True}

    @staticmethod
    def _summary_exclusions(contains: set[str]) -> list[str]:
        if "name" in contains and "raw_quote" not in contains:
            return ["name"]
        if "name" in contains and "rrn" in contains and "raw_quote" in contains:
            return ["name"]
        if "raw_quote" in contains:
            return ["raw_quote"]
        return []

    @staticmethod
    def _redaction_exclusions(
        view: TaskView,
        evidence: EvidenceGraph,
        contains: set[str],
    ) -> list[str]:
        policy = str(view.latest_record_value("external_share_policy") or "").lower()
        if "doctor_note_forbidden" in policy and "doctor_note" in contains:
            return ["doctor_note"]
        if "raw_sensitive_forbidden" in policy:
            items = [x for x in ["name", "numeric_value", "raw_quote", "rrn"] if x in contains or x == "numeric_value"]
            return items or ["sensitive_fields"]
        content_variant = bool(
            evidence.intent_evidence.prompt_evidence(
                EvidenceKind.CONTENT_VARIANT_SELECTION
            )
        )
        if content_variant or ({"name", "rrn", "amount"} <= contains):
            items = [
                item
                for item in ("name", "numeric_value", "raw_quote", "rrn")
                if item in contains
                or (item == "numeric_value" and "amount" in contains)
            ]
            return items or ["name"]
        if contains & {"location", "numeric_value"} and not contains & {"name", "rrn"}:
            return ["location", "numeric_value", "raw_quote"] if "raw_quote" in contains else ["location", "numeric_value"]
        return ["raw_quote"]

    @staticmethod
    def _requires_confirmation_scope(view: TaskView) -> bool:
        if view.latest_record_value("ambiguous_target") or view.latest_record_value("target_changed_after_turn"):
            return True
        if view.latest_record_value("dispatch_authority_check") in {"authority_incomplete", "user_binding_pending"}:
            return True
        return False

    @staticmethod
    def _target_role(target: str) -> str:
        normalized = target.lower()
        if any(root in normalized for root in ("vendor", "audit")):
            return "external_processor"
        if any(root in normalized for root in ("review", "security", "legal")):
            return "internal_review"
        return "local_or_user"

    @staticmethod
    def _precondition_changed(view: TaskView) -> bool:
        return str(view.latest_record_value("share_boundary_update") or "") in {
            "local_update_boundary",
            "redacted_external_boundary",
            "redacted_after_selection_boundary",
        }

    @staticmethod
    def _requires_confirmation_policy(view: TaskView, control: str, scope: dict[str, Any]) -> bool:
        if control == "hold":
            return False
        if control == "ask":
            return True
        if control == "proceed" and str(scope.get("mode") or "") == "status_only":
            return False
        if bool(scope.get("requires_user_confirmation")):
            return True
        if view.latest_record_value("ambiguous_target") or view.latest_record_value("target_changed_after_turn"):
            return True
        if view.latest_record_value("dispatch_authority_check") in {"authority_incomplete", "user_binding_pending"}:
            return True
        return False


class ScopeCompiler:
    """Compiles disclosure scope once from the immutable final decision."""

    @staticmethod
    def compile(
        state: Any,
        decision: FinalDecision,
        matrix: DecisionMatrix,
    ) -> dict[str, Any]:
        view = state.view
        evidence = state.evidence
        focal = state.focal
        contains = focal_contains(focal)
        action = decision.action
        control = decision.control
        local_execution = action in {
            DomainAction.LOCAL_UPDATE,
            DomainAction.MEMORY_UPDATE,
        } or (control == "proceed" and evidence.route.is_local_boundary)
        domain_execution = (
            action
            in {DomainAction.PAY, DomainAction.TOGGLE, DomainAction.SCHEDULE}
            and decision.operation_mode == "execute"
            and control in {"proceed", "amend"}
        )

        if control == "hold":
            return {
                "mode": "none",
                "allowed_fields": [],
                "excluded_fields": [],
                "requires_user_confirmation": False,
            }
        if local_execution:
            protected_fields = contains & {
                "raw_quote",
                "location",
                "numeric_value",
                "name",
                "rrn",
                "amount",
                "doctor_note",
            }
            exclusions = (
                ["raw_quote", "location", "numeric_value"]
                if protected_fields
                or view.latest_record_value("session_share_policy") == "strict"
                else []
            )
            return {
                "mode": "status_only",
                "allowed_fields": ["status"],
                "excluded_fields": exclusions,
                "requires_user_confirmation": False,
            }
        if domain_execution:
            return {
                "mode": "status_only",
                "allowed_fields": ["status"],
                "excluded_fields": [],
                "requires_user_confirmation": False,
            }
        if (
            action
            in {DomainAction.PAY, DomainAction.TOGGLE, DomainAction.SCHEDULE}
            and decision.operation_mode == "verify"
            and control == "proceed"
        ):
            return {
                "mode": "none",
                "allowed_fields": [],
                "excluded_fields": [],
                "requires_user_confirmation": False,
            }
        if control == "ask":
            return ScopeFacts._ask_scope(
                view,
                evidence,
                contains,
                decision.target,
                matrix,
            )
        if control == "amend":
            return {
                "mode": "redacted",
                "allowed_fields": ["summary"],
                "excluded_fields": ScopeFacts._redaction_exclusions(
                    view, evidence, contains
                ),
                "requires_user_confirmation": ScopeFacts._requires_confirmation_scope(
                    view
                ),
            }
        if CandidateEvaluator._raw_dispatch_allowed(
            view, focal, decision.target
        ):
            return {
                "mode": "raw",
                "allowed_fields": ["summary", "title"],
                "excluded_fields": [],
                "requires_user_confirmation": False,
            }
        return {
            "mode": "summary",
            "allowed_fields": ["summary"],
            "excluded_fields": [],
            "requires_user_confirmation": False,
        }


class PolicyCompiler:
    """Compiles policy flags from facts, scope, and the final action pair."""

    @staticmethod
    def compile(
        state: Any,
        decision: FinalDecision,
        scope: dict[str, Any],
    ) -> dict[str, Any]:
        view = state.view
        focal = state.focal
        contains = focal_contains(focal)
        flags: list[str] = []
        violations: list[str] = []
        domain_execution = (
            decision.action
            in {DomainAction.PAY, DomainAction.TOGGLE, DomainAction.SCHEDULE}
            and decision.operation_mode == "execute"
            and decision.control in {"proceed", "amend"}
        )
        local_execution = decision.action in {
            DomainAction.LOCAL_UPDATE,
            DomainAction.MEMORY_UPDATE,
        } or (
            decision.control == "proceed"
            and state.evidence.route.is_local_boundary
        )

        if view.latest_record_value("session_share_policy") == "strict":
            flags.append("strict_share_policy")
        if not domain_execution and decision.target not in {
            "memory_store",
            "user",
        }:
            flags.append("external_share")
        if (
            local_execution
            or decision.target in {"memory_store", "user"}
            or view.latest_record_value("share_boundary_update")
            == "local_update_boundary"
        ):
            flags.append("local_only")
        if domain_execution:
            flags.append("domain_execution")
        if contains & {
            "raw_quote",
            "rrn",
            "name",
            "location",
            "numeric_value",
            "doctor_note",
            "amount",
        }:
            flags.append("sensitive_content")
        if view.record_values("ambiguous_target"):
            flags.append("target_ambiguity")
        if view.latest_record_value("ambiguous_focal"):
            flags.append("ambiguous_focal")
        if decision.control == "amend":
            flags.append("minimal_disclosure")
        if decision.control == "ask":
            flags.append("clarification_required")
        if ScopeFacts._precondition_changed(view):
            flags.append("precondition_changed")
        if decision.control == "hold":
            flags.extend(["precondition_invalidated", "safety"])
            violations.append("precondition_changed_ignored")

        return {
            "risk_flags": list(dict.fromkeys(flags)),
            "violations": list(dict.fromkeys(violations)),
            "requires_confirmation": ScopeFacts._requires_confirmation_policy(
                view, decision.control, scope
            ),
        }

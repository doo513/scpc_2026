# Consistency Report

- Hard errors: 0
- Warnings: 0

## Structural Statistics
- control.amend: 177
- control.ask: 185
- control.hold: 130
- control.proceed: 208
- scope.none: 132
- scope.raw: 9
- scope.redacted: 230
- scope.status_only: 188
- scope.summary: 141

## Errors
- None

## Warnings
- None

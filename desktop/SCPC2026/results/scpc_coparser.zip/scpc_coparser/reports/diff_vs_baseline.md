# Comparison: scpc_coparser/submission.csv vs V5_modular_harness/submission.csv

## Changed Counts
- **focal changed count**: 113
- **target changed count**: 256
- **control changed count**: 187
- **scope mode changed count**: 245
- **policy confirmation changed count**: 146
- **plan sequence changed count**: 284

## Major Transitions (Control)
- `amend -> proceed`: 44
- `amend -> hold`: 29
- `ask -> proceed`: 21
- `hold -> proceed`: 20
- `amend -> ask`: 20
- `ask -> hold`: 12
- `proceed -> hold`: 10
- `proceed -> ask`: 9
- `hold -> ask`: 8
- `proceed -> amend`: 7
- `hold -> amend`: 5
- `ask -> amend`: 2

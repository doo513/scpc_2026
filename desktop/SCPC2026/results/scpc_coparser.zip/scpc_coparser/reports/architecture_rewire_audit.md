# FinalDecision Architecture Rewire Audit

## P0 제거·재설계 결과

| 항목 | 결과 | 코드 근거 |
| --- | --- | --- |
| ActionProfileDecider control-first tree | 제거 | `rules/action_profile.py`, `core/action_profile.py` 삭제 |
| 분리된 domain promotion trace | 재설계 | `FinalDecision.domain_promotion`, selected pair와 execution emitted 연결 |
| pre-profile target 선결정 순환 | 제거 | target은 candidate만 생성하고 `FinalDecision`이 한 번 확정 |
| 전역 consent hold | 제거 | DISPATCH + non-local pair에만 `consent_revoked` 활성화 |
| 배열 마지막 record를 latest로 간주 | 제거 | 명시 chronology가 없고 값이 충돌하면 unresolved conflict |
| 고정 scope/policy/plan profile template | 제거 | 세 compiler가 immutable `FinalDecision`을 순서대로 한 번 읽음 |

## P1 실행 경로

```text
StateAssembler
-> FocalCandidate + CoarseIntent joint resolution
-> DomainContext + OperationIntent
-> ActionTargetPairBuilder
-> InformationResolver
-> CapabilityResolver
-> ConstraintActivator
-> AuthorizedFallbackSolver
-> FinalDecision
-> ScopeCompiler
-> PolicyCompiler
-> PlanCompiler
```

`CandidateEvaluation`에는 control 필드가 없다. 후보는 disposition까지만 계산하며,
`FinalDecisionBuilder`만 disposition, information, capability, hard constraint를 합쳐
최종 control을 생성한다.

도메인과 operation mode를 분리했다. PAY/TOGGLE/SCHEDULE은 domain context이고,
EXECUTE/CANCEL/VERIFY/SHARE는 operation mode다. 따라서 domain cancel/verify는 generic
dispatch로 내려가지 않고 동일 domain constraint를 평가한다. 공식 action ontology에
cancel capability가 없으면 HOLD이며, focal이 domain과 맞지 않으면 ASK로 해소한다.

## P2 검증

- official `submission_schema.json`과 local schema SHA-256 동일성
- dev 전체 120건 hard floor, 점수 제외 없음
- metamorphic local override 및 capability/slot ablation
- domain execute/cancel/verify/share matrix
- pair-specific consent counterfactual
- current/historical session focal lifecycle
- marker/history 및 intent evidence ablation
- array/input order invariance
- screening schema/consistency 검사
- candidate manifest source hash, submission hash, artifact mtime 검사

Screening structural focal coverage는 정확도가 아니다. 정답 라벨이 없으므로 분포와
coverage는 진단 보고서에만 기록하고 inference prior나 dev 회귀 허용 근거로 쓰지 않는다.

## 문자열 처리 경계

런타임에는 task ID, 사람 이름, memory key, 정답 target 표가 없다. 허용한 문자열은
record/object key, enum/ontology, marker/reference 관계 문법, 짧은 형태·어근 조합이다.
`단,`은 독립 절 경계와 provenance를 만들지만 문장 전체를 정답으로 매핑하지 않는다.

# Plan Integrity Audit

## 결론

현재 실행 경로는 record나 특정 문장을 control로 직접 변환하지 않는다. 직접 추출한
`RecordFact`, `RelationFact`, `IntentEvidence`를 근거로 action-target 후보를 만든 뒤,
후보별 information, capability, active constraint를 평가하고 authorized fallback을
해소한 뒤 `FinalDecision` 한 곳에서만 최종 target과 control을 결정한다.

## 핵심 불변식

| 항목 | 구현 상태 | 확인 방법 |
| --- | --- | --- |
| Focal과 coarse intent를 공동 해소 | 충족 | `StateAssembler -> FocalCandidate + CoarseIntent` |
| IntentEvidence가 DomainAction보다 먼저 생성됨 | 충족 | `OperationIntent -> ActionCandidateResolver` |
| HOLD는 IntentEvidence가 아니라 최종 control임 | 충족 | `EvidenceKind`에 HOLD 없음 |
| record가 control을 직접 만들지 않음 | 충족 | record는 `ActiveConstraint` 또는 `RequiredSlot`으로 변환 |
| action-target 조합별 constraint 평가 | 충족 | `ActionTargetCandidate -> CandidateEvaluation` |
| capability와 missing information 분리 | 충족 | `CapabilityStatus`와 `RequiredSlot/SlotReason` 분리 |
| 직접 근거와 파생 결과의 provenance 분리 | 충족 | 직접 객체는 `provenance`, 파생 객체는 `derived_from` |
| domain promotion의 eligible/applied 구분 | 충족 | `DomainPromotionTrace` |
| 최종 target/control 단일 소유권 | 충족 | `FinalDecision` |
| compiler 선형 1회 실행 | 충족 | `Scope -> Policy -> Plan` |

## 문자열 처리 감사

허용한 문자열은 JSON 계약의 record type/value enum, object attribute key, plan ontology,
라벨이 명시된 memory field 문법, history reference/ordinal 문법이다. 이는 비정형 문장
정답표가 아니라 데이터 구조와 관계 문법이다.

제거한 항목은 다음과 같다.

- dev/screening task ID에 따른 분기
- 사람 이름에 따른 target 선택
- 전체 사용자 문장 목록에 따른 HOLD/ASK/LOCAL 판정
- `record -> control` 직접 반환 함수
- 원본/사진/건강/설정 키워드 점수에 따른 focal 임의 선택
- 객체 ID 사전순 focal tie-break
- 실제 값이 없는 persistent memory의 임의 target 기본값

자연어는 문장/절 경계, lexical root의 같은 절 내 결합, polarity, assertion mode,
latest-clause provenance로 처리한다. `듯하지만`은 독립 connector로 취급하지 않으며,
`단,`/`다만` 이전의 주행동 근거는 보존하고 마지막 절의 decisive constraint만 우선한다.

## Dev Hard Gate

기준 manifest의 legacy dev overall은 0.9468이다. 현재 전체 dev overall은 0.9421이다.
현재 점수와 축별 수치를 hard floor로 고정하며 어떤 task도 점수 계산에서 제외하지 않는다.

전체 점수 하락은 `persistent_memory_recall` fact는 있으나 참조 memory value가 입력에
없는 3건에서 발생한다. 이전 구현은 사람 이름과 문장 유형으로 target을 만들어 냈다.
현재 구현은 다음 trace를 남기고 임의 target을 만들지 않는다.

```text
slot = memory_value
status = missing
reason_code = REQUIRED_MEMORY_UNAVAILABLE
```

이 3건도 전체 공식 점수에 포함한다. 입력에 참조 memory value가 없는 사실은
`input_visibility_gap_cases` 진단으로만 집계하며 회귀 허용 또는 별도 점수 산출에
사용하지 않는다. `tests/specs/generalization_v1.json` 2.0.0은 전체 dev overall,
축별 floor, non-exact task 상한을 hard gate로 고정한다.

## Screening 해석

screening 700건의 focal은 모두 구조적으로 해석된다.

- marker trace: 463건
- history binding: 237건
- unresolved: 0건

screening 정답 라벨은 공개되지 않았으므로 위 수치는 accuracy가 아니라 structural
coverage와 submission agreement다. control/target/scope 분포도 추론 prior가 아니라
진단 통계로만 기록한다.

## 남은 위험

- 한국어 분석은 외부 형태소 분석기가 아닌 절 분리와 lexical composition 기반이다.
- 공개 dev/screening의 `available_actions` 집합은 동일하므로 capability 일반화는
  synthetic ablation으로 검증한다.
- `verified_internal_target`은 구체 target identity를 제공하지 않으므로 이를 근거로
  외부 후보의 constraint를 자동 해제하지 않는다.
- history binding은 참조 토큰과 선택/ordinal 관계가 명시된 경우만 해석한다.

이 제한은 permissive fallback을 추가하기보다 unresolved, ask, hold trace로 노출하는
방향으로 유지한다.

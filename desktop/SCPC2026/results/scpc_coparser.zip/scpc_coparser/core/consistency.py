from __future__ import annotations

from collections import Counter
from pathlib import Path
from typing import Any

from utils.schema_check import validate_answer


BASE_DIR = Path(__file__).resolve().parent.parent
EXECUTION_VERBS = {"dispatch", "update", "schedule", "toggle", "pay"}
KNOWN_TARGET_STATES = {
    "authority_incomplete",
    "user_binding_pending",
    "local_update_boundary",
    "redacted_external_boundary",
    "redacted_after_selection_boundary",
    "dispatch_blocked_until_binding",
    "boundary_after_authority",
    "authority_after_candidates",
    "strict",
    "normal",
}
CANONICAL_SCOPE_GUARDS = {
    "raw_quote",
    "location",
    "numeric_value",
    "name",
    "rrn",
    "doctor_note",
    "amount",
    "card_number",
    "sensitive_fields",
}


class ConsistencyValidator:
    errors: list[str] = []
    warnings: list[str] = []
    controls: Counter[str] = Counter()
    modes: Counter[str] = Counter()

    @classmethod
    def reset(cls) -> None:
        cls.errors = []
        cls.warnings = []
        cls.controls = Counter()
        cls.modes = Counter()

    @classmethod
    def validate_or_warn(
        cls,
        answer: dict[str, Any],
        view: Any,
        evidence: Any,
        profile: Any,
    ) -> None:
        task_errors: list[str] = []
        task_id = view.task_id
        try:
            validate_answer(answer)
        except Exception as exc:
            raise ValueError(f"schema validation failed for task {task_id}: {exc}") from exc

        focal_id = str(answer.get("focal_id") or "")
        target = str(answer.get("target") or "")
        control = str(answer.get("control") or "")
        scope = answer.get("content_scope") or {}
        mode = str(scope.get("mode") or "")
        events = answer.get("plan_events") or []
        verbs = [str(event.get("verb") or "") for event in events]

        final_trace = (
            evidence.get("final_decision", {})
            if isinstance(evidence, dict)
            else {}
        )
        historical_focal = bool(final_trace.get("historical_focal"))
        final_action = str(final_trace.get("action") or "")
        historical_non_execution = (
            historical_focal
            and control in {"ask", "hold"}
            and not (EXECUTION_VERBS & set(verbs))
        )
        if focal_id not in view.objects_by_id() and not historical_non_execution:
            task_errors.append(f"focal_id '{focal_id}' is not a current object")
        if not target:
            task_errors.append("target is empty")
        if target in KNOWN_TARGET_STATES:
            task_errors.append(f"target '{target}' is a record state")
        if any(verb not in view.available_actions for verb in verbs):
            task_errors.append("plan contains an unavailable action")
        if len(events) > 18:
            task_errors.append("plan exceeds 18 events")

        if control == "hold" and (mode != "none" or "dispatch" in verbs):
            task_errors.append("hold must use none scope and must not dispatch")
        if control == "ask" and ("clarify" not in verbs or EXECUTION_VERBS & set(verbs)):
            task_errors.append("ask must clarify without an execution event")
        if control == "amend":
            domain_terminal = {
                "pay": "pay",
                "toggle": "toggle",
                "schedule": "schedule",
            }.get(final_action)
            if domain_terminal:
                if mode != "status_only" or domain_terminal not in verbs:
                    task_errors.append(
                        "domain amend must preserve its terminal operation"
                    )
                if "dispatch" in verbs:
                    task_errors.append("domain amend must not dispatch")
            elif mode != "redacted" or "redact" not in verbs:
                task_errors.append("disclosure amend must redact before dispatch")
        if mode == "status_only" and "dispatch" in verbs:
            task_errors.append("status_only must not dispatch")
        if mode == "status_only" and not ({"update", "pay", "toggle", "schedule"} & set(verbs)):
            task_errors.append("status_only must contain a non-disclosure execution event")
        if target == "memory_store" and mode != "status_only" and "update" not in verbs:
            task_errors.append("memory_store target requires status_only scope or an update event")
        if mode == "none" and (scope.get("allowed_fields") or scope.get("excluded_fields")):
            task_errors.append("none scope must have empty field lists")

        cls._validate_order(verbs, task_errors)
        contains = view.contains_for_object(focal_id)
        for field in scope.get("excluded_fields") or []:
            if field not in contains and field not in CANONICAL_SCOPE_GUARDS:
                cls.warnings.append(
                    f"{task_id}: exclusion '{field}' has neither focal nor canonical guard provenance"
                )

        cls.controls[control] += 1
        cls.modes[mode] += 1
        if task_errors:
            cls.errors.extend(f"{task_id}: {message}" for message in task_errors)
            raise ValueError("; ".join(task_errors))

    @staticmethod
    def _validate_order(verbs: list[str], errors: list[str]) -> None:
        def before(first: str, second: str) -> bool:
            return first not in verbs or second not in verbs or verbs.index(first) < verbs.index(second)

        if not before("read", "dispatch"):
            errors.append("read must precede dispatch")
        if not before("redact", "dispatch"):
            errors.append("redact must precede dispatch")
        if not before("summarize", "dispatch"):
            errors.append("summarize must precede dispatch")
        if not before("verify", "update"):
            errors.append("verify must precede update")
        if not before("verify", "pay"):
            errors.append("verify must precede pay")
        if not before("verify", "toggle"):
            errors.append("verify must precede toggle")
        if not before("verify", "schedule"):
            errors.append("verify must precede schedule")

    @classmethod
    def write_report(cls, output_path: Path | None = None) -> Path:
        output_path = output_path or BASE_DIR / "reports" / "consistency_report.md"
        output_path.parent.mkdir(parents=True, exist_ok=True)
        lines = [
            "# Consistency Report",
            "",
            f"- Hard errors: {len(cls.errors)}",
            f"- Warnings: {len(cls.warnings)}",
            "",
            "## Structural Statistics",
        ]
        lines.extend(f"- control.{key}: {value}" for key, value in sorted(cls.controls.items()))
        lines.extend(f"- scope.{key}: {value}" for key, value in sorted(cls.modes.items()))
        lines.extend(["", "## Errors"])
        lines.extend(f"- {message}" for message in cls.errors) if cls.errors else lines.append("- None")
        lines.extend(["", "## Warnings"])
        lines.extend(f"- {message}" for message in cls.warnings) if cls.warnings else lines.append("- None")
        output_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        return output_path

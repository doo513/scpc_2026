from __future__ import annotations

import copy
import json
from typing import Any, Iterable

from .evidence import latest_clause_from_text, normalize_text
from .records import RecordIndex


def stable_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


class TaskView:
    """Normalized, read-only access to one participant-visible task."""

    def __init__(self, task: dict[str, Any], session_state: dict[str, Any] | None = None):
        self.task = copy.deepcopy(task) if isinstance(task, dict) else {}
        self.session_state = (
            copy.deepcopy(session_state) if isinstance(session_state, dict) else {}
        )

        state = self.task.get("device_state") or {}
        self._objects = tuple(o for o in state.get("objects", []) if isinstance(o, dict))
        self._records = tuple(r for r in state.get("records", []) if isinstance(r, dict))
        self._history = tuple(h for h in self.task.get("visible_history", []) if isinstance(h, dict))
        self._memory = tuple(m for m in self.task.get("personal_memory", []) if isinstance(m, dict))
        self._available_actions = frozenset(str(x) for x in self.task.get("available_actions", []) if x)
        self.record_index = RecordIndex(self._records, session_id=str(self.task.get("session_id") or ""))
        self._records_by_type = self.record_index.records_by_type()

        self._objects_by_id = {
            str(obj["id"]): obj for obj in self._objects if obj.get("id") is not None
        }
        self._objects_by_ref_code: dict[str, dict[str, Any]] = {}
        for obj in self._objects:
            ref_code = str((obj.get("attrs") or {}).get("ref_code") or "")
            if ref_code:
                self._objects_by_ref_code[ref_code] = obj

    @property
    def task_id(self) -> str:
        return str(self.task.get("id") or "")

    @property
    def session_id(self) -> str:
        return str(self.task.get("session_id") or "")

    @property
    def turn_index(self) -> int:
        try:
            return int(self.task.get("turn_index", 0))
        except (TypeError, ValueError):
            return 0

    @property
    def prompt(self) -> str:
        return normalize_text(stable_text(self.task.get("prompt")))

    @property
    def objects(self) -> tuple[dict[str, Any], ...]:
        return self._objects

    @property
    def records(self) -> tuple[dict[str, Any], ...]:
        return self._records

    @property
    def history(self) -> tuple[dict[str, Any], ...]:
        return self._history

    @property
    def available_actions(self) -> frozenset[str]:
        return self._available_actions

    def objects_by_id(self) -> dict[str, dict[str, Any]]:
        return self._objects_by_id

    def objects_by_ref_code(self) -> dict[str, dict[str, Any]]:
        return self._objects_by_ref_code

    def records_by_type(self) -> dict[str, list[dict[str, Any]]]:
        return self._records_by_type

    def records_of_type(self, record_type: str) -> tuple[dict[str, Any], ...]:
        return tuple(self._records_by_type.get(record_type, ()))

    def record_values(self, record_type: str) -> list[Any]:
        return [record.get("value") for record in self.records_of_type(record_type)]

    def record_is_ambiguous(self, record_type: str) -> bool:
        return self.record_index.is_conflicting(record_type)

    def latest_record(self, record_type: str) -> dict[str, Any] | None:
        """Select only an unambiguous latest record by explicit chronology."""
        return self.record_index.latest(record_type)

    def latest_record_value(self, record_type: str) -> Any:
        record = self.latest_record(record_type)
        return record.get("value") if record else None

    def duplicate_record_types(self) -> set[str]:
        return self.record_index.conflicting_types()

    def contains_for_object(self, object_id: str) -> set[str]:
        obj = self._objects_by_id.get(object_id)
        if not obj:
            return set()
        attrs = obj.get("attrs") or {}
        raw = attrs.get("contains")
        if raw is None:
            raw = attrs.get("fields")
        return {str(item) for item in raw} if isinstance(raw, list) else set()

    def object_type(self, object_id: str) -> str | None:
        obj = self._objects_by_id.get(object_id)
        return str(obj.get("type")) if obj else None

    def latest_clause(self) -> str:
        clause, _span = latest_clause_from_text(self.prompt)
        return clause

    def current_turn_history(self) -> tuple[dict[str, Any], ...]:
        return tuple(item for item in self._history if self._history_turn(item) == self.turn_index)

    def visible_history_text(self, *, current_turn_only: bool = False) -> str:
        items: Iterable[dict[str, Any]] = self.current_turn_history() if current_turn_only else self._history
        return " ".join(stable_text(item.get("summary", item)) for item in items)

    def personal_memory_entries(self) -> tuple[dict[str, Any], ...]:
        return self._memory

    @staticmethod
    def _history_turn(item: dict[str, Any]) -> int | None:
        try:
            return int(item.get("turn"))
        except (TypeError, ValueError):
            return None

        return None

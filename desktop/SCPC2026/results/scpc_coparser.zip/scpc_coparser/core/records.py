from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from enum import Enum
import json
from typing import Any, Iterable


class FactRole(str, Enum):
    HINT = "hint"
    RELATION = "relation"
    STATE = "state"
    CONSTRAINT = "constraint"
    MEMORY = "memory"
    CAPABILITY_MODIFIER = "capability_modifier"
    UNKNOWN = "unknown"


@dataclass(frozen=True)
class Provenance:
    source_kind: str
    source_id: str
    session_id: str = ""
    turn: int | None = None
    span: tuple[int, int] | None = None
    assertion_mode: str = "direct"


@dataclass(frozen=True)
class RecordFact:
    fact_id: str
    record_type: str
    value: Any
    value_kind: str
    role: FactRole
    known_shape: bool
    provenance: Provenance
    issues: tuple[str, ...] = ()


DICT_RECORD_TYPES = {
    "focal_marker_refs",
    "focal_resolution_trace",
    "persistent_memory_recall",
}

SCALAR_RECORD_TYPES = {
    "ambiguous_focal",
    "ambiguous_target",
    "calendar_conflict",
    "consent",
    "current_request_hint",
    "dispatch_authority_check",
    "duration_ambiguous",
    "enterprise_policy_recall",
    "external_share_policy",
    "guardrail_ladder_signal",
    "guest_mode",
    "memory_conflict",
    "ops_memory_recall",
    "payment_policy",
    "privacy_guard",
    "resolved_target",
    "route_binding_order",
    "route_candidate_snapshot",
    "safety_mode",
    "security_alert",
    "session_share_policy",
    "share_boundary_update",
    "target_changed_after_turn",
    "temporary_override_allowed",
    "trusted_subscription",
    "verified_internal_target",
}

RECORD_ROLES = {
    "current_request_hint": FactRole.HINT,
    "focal_marker_refs": FactRole.RELATION,
    "focal_resolution_trace": FactRole.RELATION,
    "resolved_target": FactRole.RELATION,
    "target_changed_after_turn": FactRole.RELATION,
    "route_binding_order": FactRole.RELATION,
    "route_candidate_snapshot": FactRole.RELATION,
    "dispatch_authority_check": FactRole.RELATION,
    "share_boundary_update": FactRole.RELATION,
    "persistent_memory_write": FactRole.MEMORY,
    "persistent_memory_recall": FactRole.MEMORY,
    "ops_memory_recall": FactRole.MEMORY,
    "enterprise_policy_recall": FactRole.MEMORY,
    "trusted_subscription": FactRole.CAPABILITY_MODIFIER,
    "guest_mode": FactRole.CAPABILITY_MODIFIER,
    "verified_internal_target": FactRole.CAPABILITY_MODIFIER,
}

for _kind in (
    "ambiguous_focal",
    "ambiguous_target",
    "calendar_conflict",
    "consent",
    "duration_ambiguous",
    "external_share_policy",
    "guardrail_ladder_signal",
    "memory_conflict",
    "payment_policy",
    "privacy_guard",
    "safety_mode",
    "security_alert",
    "session_share_policy",
    "temporary_override_allowed",
):
    RECORD_ROLES.setdefault(_kind, FactRole.CONSTRAINT)


def stable_value(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


class RecordIndex:
    """Typed, order-independent record access with explicit conflict reporting."""

    def __init__(
        self,
        records: Iterable[dict[str, Any]],
        *,
        session_id: str = "",
    ) -> None:
        self._records = tuple(record for record in records if isinstance(record, dict))
        by_type: dict[str, list[dict[str, Any]]] = defaultdict(list)
        facts: list[RecordFact] = []
        for index, record in enumerate(self._records):
            record_type = str(record.get("type") or "")
            by_type[record_type].append(record)
            facts.append(self._parse(record, index=index, session_id=session_id))
        self._by_type = dict(by_type)
        self._facts = tuple(facts)

    @property
    def facts(self) -> tuple[RecordFact, ...]:
        return self._facts

    def records_by_type(self) -> dict[str, list[dict[str, Any]]]:
        return self._by_type

    def records_of_type(self, record_type: str) -> tuple[dict[str, Any], ...]:
        return tuple(self._by_type.get(record_type, ()))

    def values(self, record_type: str) -> list[Any]:
        return [record.get("value") for record in self.records_of_type(record_type)]

    def latest(self, record_type: str) -> dict[str, Any] | None:
        records = self.records_of_type(record_type)
        if not records:
            return None
        if len(records) == 1:
            return records[0]

        ranked = [(self._rank(record), stable_value(record.get("value")), record) for record in records]
        explicitly_ranked = [item for item in ranked if item[0] is not None]
        if explicitly_ranked:
            top_rank = max(item[0] for item in explicitly_ranked)
            top = [item for item in explicitly_ranked if item[0] == top_rank]
            if len({item[1] for item in top}) == 1:
                return min(top, key=lambda item: stable_value(item[2]))[2]
            return None

        values = {item[1] for item in ranked}
        if len(values) == 1:
            return min(records, key=stable_value)
        return None

    def latest_value(self, record_type: str) -> Any:
        record = self.latest(record_type)
        return record.get("value") if record else None

    def is_conflicting(self, record_type: str) -> bool:
        records = self.records_of_type(record_type)
        return len(records) > 1 and self.latest(record_type) is None

    def conflicting_types(self) -> set[str]:
        return {record_type for record_type in self._by_type if self.is_conflicting(record_type)}

    def unknown_facts(self) -> tuple[RecordFact, ...]:
        return tuple(fact for fact in self._facts if not fact.known_shape)

    def to_trace(self) -> dict[str, Any]:
        return {
            "fact_count": len(self._facts),
            "conflicting_types": sorted(self.conflicting_types()),
            "unknown_shapes": [
                {"record_type": fact.record_type, "value_kind": fact.value_kind, "issues": list(fact.issues)}
                for fact in self.unknown_facts()
            ],
        }

    @staticmethod
    def _parse(record: dict[str, Any], *, index: int, session_id: str) -> RecordFact:
        record_type = str(record.get("type") or "")
        value = record.get("value")
        value_kind = type(value).__name__
        expected_dict = record_type in DICT_RECORD_TYPES
        expected_scalar = record_type in SCALAR_RECORD_TYPES
        memory_write_shape = record_type == "persistent_memory_write" and isinstance(value, (dict, str))
        known_shape = (
            (expected_dict and isinstance(value, dict))
            or (expected_scalar and isinstance(value, str))
            or memory_write_shape
        )
        issues: list[str] = []
        if not record_type:
            issues.append("missing_record_type")
        if not known_shape:
            issues.append("unknown_record_shape")
        record_id = str(record.get("id") or f"record_{index}")
        return RecordFact(
            fact_id=f"record:{record_id}",
            record_type=record_type,
            value=value,
            value_kind=value_kind,
            role=RECORD_ROLES.get(record_type, FactRole.UNKNOWN),
            known_shape=known_shape,
            provenance=Provenance(
                source_kind="record",
                source_id=record_id,
                session_id=session_id,
                turn=RecordIndex._turn(record),
            ),
            issues=tuple(issues),
        )

    @staticmethod
    def _rank(record: dict[str, Any]) -> tuple[int, str] | None:
        for key in ("turn_index", "turn", "timestamp", "updated_at", "created_at"):
            value = record.get(key)
            if value is None:
                continue
            try:
                return (int(value), "")
            except (TypeError, ValueError):
                return (0, str(value))
        return None

    @staticmethod
    def _turn(record: dict[str, Any]) -> int | None:
        rank = RecordIndex._rank(record)
        return rank[0] if rank is not None else None

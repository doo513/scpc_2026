from __future__ import annotations

from dataclasses import dataclass, replace
from enum import Enum
from typing import Any, Iterable

from .evidence import EvidenceKind, EvidenceStrength, IntentEvidenceSet


class DomainAction(str, Enum):
    CLARIFY = "clarify"
    DISPATCH = "dispatch"
    LOCAL_UPDATE = "local_update"
    MEMORY_UPDATE = "memory_update"
    PAY = "pay"
    TOGGLE = "toggle"
    SCHEDULE = "schedule"


class CapabilityStatus(str, Enum):
    AVAILABLE = "available"
    UNAVAILABLE = "unavailable"


class SlotStatus(str, Enum):
    PRESENT = "present"
    MISSING = "missing"
    CONFLICT = "conflict"
    DEFAULTED = "defaulted"


class InformationStatus(str, Enum):
    COMPLETE = "complete"
    MISSING = "missing"
    CONFLICT = "conflict"


class SlotReason(str, Enum):
    VALUE_ABSENT = "VALUE_ABSENT"
    VALUE_CONFLICT = "VALUE_CONFLICT"
    REQUIRED_MEMORY_UNAVAILABLE = "REQUIRED_MEMORY_UNAVAILABLE"


class ConstraintSeverity(str, Enum):
    HARD = "hard"
    CLARIFY = "clarify"
    AMEND = "amend"


class CandidateDisposition(str, Enum):
    BLOCKED = "blocked"
    NEEDS_CLARIFICATION = "needs_clarification"
    AMENDABLE = "amendable"
    EXECUTABLE = "executable"


class PromotionRejectionReason(str, Enum):
    NO_EXPLICIT_EXECUTION_INTENT = "NO_EXPLICIT_EXECUTION_INTENT"
    FOCAL_DOMAIN_MISMATCH = "FOCAL_DOMAIN_MISMATCH"
    TARGET_UNRESOLVED = "TARGET_UNRESOLVED"
    REQUIRED_SLOT_MISSING = "REQUIRED_SLOT_MISSING"
    CAPABILITY_UNAVAILABLE = "CAPABILITY_UNAVAILABLE"
    HARD_CONSTRAINT_ACTIVE = "HARD_CONSTRAINT_ACTIVE"
    SHARE_ONLY_REQUEST = "SHARE_ONLY_REQUEST"
    VERIFY_ONLY_REQUEST = "VERIFY_ONLY_REQUEST"
    CLARIFICATION_ONLY_REQUEST = "CLARIFICATION_ONLY_REQUEST"
    LOW_CONFIDENCE = "LOW_CONFIDENCE"
    LOWER_RANKED_CANDIDATE = "LOWER_RANKED_CANDIDATE"


class FallbackReason(str, Enum):
    NOT_NEEDED = "NOT_NEEDED"
    PREFERRED_CAPABILITY_UNAVAILABLE = "PREFERRED_CAPABILITY_UNAVAILABLE"
    NO_AUTHORIZED_FALLBACK = "NO_AUTHORIZED_FALLBACK"
    AUTHORIZED_FALLBACK_SELECTED = "AUTHORIZED_FALLBACK_SELECTED"
    USER_CHOICE_REQUIRED = "USER_CHOICE_REQUIRED"


@dataclass(frozen=True)
class RequiredSlot:
    name: str
    status: SlotStatus
    value: Any = None
    derived_from: tuple[str, ...] = ()
    reason_code: SlotReason | None = None


@dataclass(frozen=True)
class InformationState:
    status: InformationStatus
    required_slots: tuple[RequiredSlot, ...]
    missing_slots: tuple[str, ...]
    conflicting_slots: tuple[str, ...]
    derived_from: tuple[str, ...]


@dataclass(frozen=True)
class ActionCandidate:
    candidate_id: str
    action: DomainAction
    confidence: str
    required_capability: str
    operation_mode: str
    derived_from: tuple[str, ...]
    intent_rank: int


@dataclass(frozen=True)
class ActionTargetCandidate:
    candidate_id: str
    action_candidate: ActionCandidate
    target: str
    target_role: str
    target_confidence: str
    derived_from: tuple[str, ...]


@dataclass(frozen=True)
class ActiveConstraint:
    constraint_id: str
    kind: str
    severity: ConstraintSeverity
    reason: str
    derived_from: tuple[str, ...]
    parameters: tuple[tuple[str, str], ...] = ()


@dataclass(frozen=True)
class CandidateEvaluation:
    candidate: ActionTargetCandidate
    required_slots: tuple[RequiredSlot, ...]
    information: InformationState
    capability_status: CapabilityStatus
    required_capabilities: tuple[str, ...]
    missing_capabilities: tuple[str, ...]
    active_constraints: tuple[ActiveConstraint, ...]
    disposition: CandidateDisposition
    derived_from: tuple[str, ...]


@dataclass(frozen=True)
class DomainPromotionTrace:
    domain_action_candidate: str
    operation_mode: str
    domain_context_applied: bool
    promotion_eligible: bool
    promotion_applied: bool
    promotion_rejected_reason: PromotionRejectionReason | None
    fallback_profile: str
    required_slots: tuple[RequiredSlot, ...]
    capability_status: CapabilityStatus
    active_constraints: tuple[str, ...]
    supporting_evidence_ids: tuple[str, ...]
    selected_pair_id: str = ""
    execution_emitted: bool = False

    def to_trace(self) -> dict[str, Any]:
        return {
            "domain_action_candidate": self.domain_action_candidate,
            "operation_mode": self.operation_mode,
            "domain_context_applied": self.domain_context_applied,
            "promotion_eligible": self.promotion_eligible,
            "promotion_applied": self.promotion_applied,
            "promotion_rejected_reason": (
                self.promotion_rejected_reason.value if self.promotion_rejected_reason else None
            ),
            "fallback_profile": self.fallback_profile,
            "required_slots": [
                {
                    "name": slot.name,
                    "status": slot.status.value,
                    "value": slot.value,
                    "reason_code": slot.reason_code.value
                    if slot.reason_code
                    else None,
                }
                for slot in self.required_slots
            ],
            "capability_status": self.capability_status.value,
            "active_constraints": list(self.active_constraints),
            "supporting_evidence_ids": list(self.supporting_evidence_ids),
            "selected_pair_id": self.selected_pair_id,
            "execution_emitted": self.execution_emitted,
        }


@dataclass(frozen=True)
class FallbackResolution:
    selected_candidate_id: str
    preferred_candidate_ids: tuple[str, ...]
    fallback_applied: bool
    reason: FallbackReason
    authorized_candidate_ids: tuple[str, ...]
    derived_from: tuple[str, ...]

    def to_trace(self) -> dict[str, Any]:
        return {
            "selected_candidate_id": self.selected_candidate_id,
            "preferred_candidate_ids": list(self.preferred_candidate_ids),
            "fallback_applied": self.fallback_applied,
            "reason": self.reason.value,
            "authorized_candidate_ids": list(self.authorized_candidate_ids),
            "derived_from": list(self.derived_from),
        }


@dataclass(frozen=True)
class DecisionMatrix:
    action_candidates: tuple[ActionCandidate, ...]
    evaluations: tuple[CandidateEvaluation, ...]
    selected: CandidateEvaluation
    promotion_traces: tuple[DomainPromotionTrace, ...]
    fallback: FallbackResolution

    def to_trace(self) -> dict[str, Any]:
        return {
            "selected_candidate": self.selected.candidate.candidate_id,
            "selected_action": self.selected.candidate.action_candidate.action.value,
            "selected_operation_mode": self.selected.candidate.action_candidate.operation_mode,
            "selected_target": self.selected.candidate.target,
            "selected_disposition": self.selected.disposition.value,
            "evaluations": [
                {
                    "candidate_id": item.candidate.candidate_id,
                    "action": item.candidate.action_candidate.action.value,
                    "operation_mode": item.candidate.action_candidate.operation_mode,
                    "target": item.candidate.target,
                    "target_role": item.candidate.target_role,
                    "capability_status": item.capability_status.value,
                    "required_capabilities": list(item.required_capabilities),
                    "missing_capabilities": list(item.missing_capabilities),
                    "information_status": item.information.status.value,
                    "slots": {
                        slot.name: {
                            "status": slot.status.value,
                            "reason_code": slot.reason_code.value
                            if slot.reason_code
                            else None,
                        }
                        for slot in item.required_slots
                    },
                    "active_constraints": [constraint.kind for constraint in item.active_constraints],
                    "disposition": item.disposition.value,
                    "derived_from": list(item.derived_from),
                }
                for item in self.evaluations
            ],
            "domain_promotion": [trace.to_trace() for trace in self.promotion_traces],
            "fallback": self.fallback.to_trace(),
        }


@dataclass(frozen=True)
class FinalDecision:
    selected_pair_id: str
    action: DomainAction
    operation_mode: str
    operation_target: str
    target: str
    target_source: str
    control: str
    information: InformationState
    capability_status: CapabilityStatus
    required_capabilities: tuple[str, ...]
    missing_capabilities: tuple[str, ...]
    active_constraints: tuple[ActiveConstraint, ...]
    fallback: FallbackResolution
    domain_promotion: tuple[DomainPromotionTrace, ...]
    reason_code: str
    historical_focal: bool
    derived_from: tuple[str, ...]

    def to_trace(self) -> dict[str, Any]:
        return {
            "selected_pair_id": self.selected_pair_id,
            "action": self.action.value,
            "operation_mode": self.operation_mode,
            "operation_target": self.operation_target,
            "target": self.target,
            "target_source": self.target_source,
            "control": self.control,
            "information_status": self.information.status.value,
            "missing_slots": list(self.information.missing_slots),
            "conflicting_slots": list(self.information.conflicting_slots),
            "capability_status": self.capability_status.value,
            "required_capabilities": list(self.required_capabilities),
            "missing_capabilities": list(self.missing_capabilities),
            "active_constraints": [
                {
                    "kind": item.kind,
                    "severity": item.severity.value,
                    "derived_from": list(item.derived_from),
                    "parameters": dict(item.parameters),
                }
                for item in self.active_constraints
            ],
            "fallback": self.fallback.to_trace(),
            "domain_promotion": [
                item.to_trace() for item in self.domain_promotion
            ],
            "reason_code": self.reason_code,
            "historical_focal": self.historical_focal,
            "derived_from": list(self.derived_from),
        }


class ActionCandidateResolver:
    DOMAIN_OBJECT_TYPES = {
        DomainAction.PAY: {"payment_request"},
        DomainAction.TOGGLE: {"device_setting", "iot_routine"},
        DomainAction.SCHEDULE: {"calendar_event"},
    }

    CAPABILITY = {
        DomainAction.CLARIFY: "clarify",
        DomainAction.DISPATCH: "dispatch",
        DomainAction.LOCAL_UPDATE: "update",
        DomainAction.MEMORY_UPDATE: "update",
        DomainAction.PAY: "pay",
        DomainAction.TOGGLE: "toggle",
        DomainAction.SCHEDULE: "schedule",
    }

    @classmethod
    def resolve(
        cls,
        view: Any,
        evidence: IntentEvidenceSet,
        focal: dict[str, Any],
        operation_intent: Any | None = None,
    ) -> tuple[ActionCandidate, ...]:
        candidates: list[ActionCandidate] = []
        focal_type = str(focal.get("type") or "")

        def add(
            action: DomainAction,
            ids: Iterable[str],
            rank: int,
            confidence: str = "high",
            required_capability: str | None = None,
            operation_mode: str = "execute",
        ) -> None:
            if any(
                candidate.action == action
                and candidate.operation_mode == operation_mode
                for candidate in candidates
            ):
                return
            candidates.append(
                ActionCandidate(
                    candidate_id=f"action:{action.value}:{operation_mode}",
                    action=action,
                    confidence=confidence,
                    required_capability=(
                        required_capability or cls.CAPABILITY[action]
                    ),
                    operation_mode=operation_mode,
                    derived_from=tuple(ids),
                    intent_rank=rank,
                )
            )

        if operation_intent is not None:
            for hypothesis in operation_intent.hypotheses:
                try:
                    action = DomainAction(str(hypothesis.action))
                except ValueError:
                    continue
                add(
                    action,
                    hypothesis.supporting_evidence_ids,
                    hypothesis.rank,
                    hypothesis.confidence,
                    hypothesis.required_capability,
                    hypothesis.mode.value,
                )
            if candidates:
                return tuple(
                    sorted(
                        candidates,
                        key=lambda candidate: (
                            -candidate.intent_rank,
                            candidate.action.value,
                            candidate.operation_mode,
                        ),
                    )
                )

        local_ids = evidence.prompt_ids(
            EvidenceKind.LOCAL_UPDATE_REQUEST,
            minimum=EvidenceStrength.STRONG,
        )
        memory_ids = evidence.prompt_ids(
            EvidenceKind.MEMORY_WRITE_REQUEST,
            minimum=EvidenceStrength.STRONG,
        )
        if memory_ids or view.latest_record_value("persistent_memory_write"):
            add(
                DomainAction.MEMORY_UPDATE,
                memory_ids or ("record:persistent_memory_write",),
                100,
                operation_mode="local_update",
            )
        elif local_ids:
            add(
                DomainAction.LOCAL_UPDATE,
                local_ids,
                95,
                operation_mode="local_update",
            )

        clarification_ids = tuple(
            item.evidence_id
            for item in evidence.current(
                EvidenceKind.CLARIFICATION_REQUEST,
                minimum=EvidenceStrength.DECISIVE,
            )
            if item.payload == "clarify_user"
        )
        if clarification_ids:
            add(
                DomainAction.CLARIFY,
                clarification_ids,
                110,
                operation_mode="clarify",
            )

        direct_domain = evidence.prompt_evidence(
            EvidenceKind.EXPLICIT_DOMAIN_VERB,
            minimum=EvidenceStrength.SUPPORTING,
        )
        mapping = {
            "PAY": DomainAction.PAY,
            "TOGGLE": DomainAction.TOGGLE,
            "SCHEDULE": DomainAction.SCHEDULE,
        }
        for item in direct_domain:
            action = mapping.get(item.payload)
            if action and focal_type in cls.DOMAIN_OBJECT_TYPES[action]:
                add(action, (item.evidence_id,), 80)

        share_ids = evidence.prompt_ids(
            EvidenceKind.SHARE_REQUEST,
            minimum=EvidenceStrength.SUPPORTING,
        )
        execution_ids = evidence.prompt_ids(
            EvidenceKind.EXECUTION_REQUEST,
            minimum=EvidenceStrength.SUPPORTING,
        )
        if execution_ids and not share_ids:
            for action, object_types in cls.DOMAIN_OBJECT_TYPES.items():
                if focal_type in object_types and not any(
                    candidate.action == action for candidate in candidates
                ):
                    add(
                        action,
                        execution_ids + (f"focal_type:{focal_type}",),
                        75,
                        "medium",
                    )
        if share_ids or not candidates:
            add(
                DomainAction.DISPATCH,
                share_ids or ("default:dispatch",),
                60,
                "medium",
                operation_mode="share",
            )
        return tuple(sorted(candidates, key=lambda candidate: (-candidate.intent_rank, candidate.action.value)))


class CandidateEvaluator:
    @classmethod
    def build_matrix(
        cls,
        view: Any,
        evidence_graph: Any,
        focal: dict[str, Any],
        target_candidates: Iterable[Any],
        operation_intent: Any | None = None,
    ) -> DecisionMatrix:
        intent = evidence_graph.intent_evidence
        actions = ActionCandidateResolver.resolve(
            view, intent, focal, operation_intent
        )
        targets = tuple(target_candidates)
        evaluations: list[CandidateEvaluation] = []

        for action in actions:
            for pair in ActionTargetPairBuilder.build(
                action, targets, focal
            ):
                evaluations.append(cls._evaluate(view, evidence_graph, focal, pair))

        selected, fallback = AuthorizedFallbackSolver.solve(
            evaluations, evidence_graph
        )
        for index, evaluation in enumerate(evaluations):
            if evaluation.candidate.candidate_id == selected.candidate.candidate_id:
                evaluations[index] = selected
                break
        traces = cls._promotion_traces(
            view,
            evidence_graph,
            actions,
            evaluations,
            selected,
            focal,
        )
        return DecisionMatrix(
            actions, tuple(evaluations), selected, traces, fallback
        )

    @staticmethod
    def _compatible_targets(action: DomainAction, targets: tuple[Any, ...], focal: dict[str, Any]) -> tuple[tuple[str, str, str, tuple[str, ...]], ...]:
        attrs = focal.get("attrs") or {}
        rows: list[tuple[str, str, str, tuple[str, ...]]] = []
        unresolved_requirements = tuple(
            requirement
            for candidate in targets
            for requirement in tuple(getattr(candidate, "requirements", ()) or ())
        )

        if action in {DomainAction.LOCAL_UPDATE, DomainAction.MEMORY_UPDATE}:
            return (("memory_store", "local_resource", "high", ("intent:local",)),)
        if action == DomainAction.CLARIFY:
            return (("user", "clarification_target", "high", ("intent:clarification",)),)
        if action == DomainAction.PAY and attrs.get("merchant"):
            return ((str(attrs["merchant"]), "merchant", "high", ("focal_attr:merchant",)),)
        if action == DomainAction.TOGGLE:
            target = attrs.get("target") or attrs.get("name")
            for candidate in targets:
                source = str(getattr(candidate, "source", "") or "")
                recalled_target = str(getattr(candidate, "target", "") or "")
                if recalled_target and source.startswith("persistent_memory:"):
                    rows.append(
                        (
                            recalled_target,
                            "device_target",
                            "high",
                            (source,) + unresolved_requirements,
                        )
                    )
            if target:
                rows.append(
                    (
                        str(target),
                        "device_target",
                        "medium",
                        ("focal_attr:device_target",) + unresolved_requirements,
                    )
                )
            if rows:
                return tuple(dict.fromkeys(rows))
        if action == DomainAction.SCHEDULE:
            target = attrs.get("attendee") or focal.get("id")
            if target:
                return ((str(target), "calendar_target", "high", ("focal_attr:calendar_target",)),)

        for candidate in targets:
            target = str(getattr(candidate, "target", "") or "")
            if not target or target == "memory_store":
                continue
            source = str(getattr(candidate, "source", "target_candidate") or "target_candidate")
            confidence = str(getattr(candidate, "confidence", "low") or "low")
            rows.append(
                (
                    target,
                    "dispatch_destination",
                    confidence,
                    (source,) + unresolved_requirements,
                )
            )
        deduped: list[tuple[str, str, str, tuple[str, ...]]] = []
        seen: set[str] = set()
        for row in rows:
            if row[0] not in seen:
                seen.add(row[0])
                deduped.append(row)
        return tuple(deduped)

    @classmethod
    def _evaluate(cls, view: Any, evidence_graph: Any, focal: dict[str, Any], pair: ActionTargetCandidate) -> CandidateEvaluation:
        action = pair.action_candidate.action
        information = InformationResolver.resolve(
            action,
            pair.action_candidate.operation_mode,
            pair.target,
            focal,
            evidence_graph,
            pair.derived_from,
        )
        slots = information.required_slots
        constraints = ConstraintActivator.activate(
            view, evidence_graph, focal, pair, CapabilityStatus.AVAILABLE
        )
        required_capabilities = cls._required_plan_capabilities(
            view,
            evidence_graph,
            focal,
            pair,
            information,
            constraints,
        )
        capability, missing_capabilities = CapabilityResolver.resolve(
            view, pair, required_capabilities
        )

        if any(constraint.severity == ConstraintSeverity.HARD for constraint in constraints):
            disposition = CandidateDisposition.BLOCKED
        elif capability == CapabilityStatus.UNAVAILABLE:
            disposition = CandidateDisposition.BLOCKED
        elif information.status in {
            InformationStatus.MISSING,
            InformationStatus.CONFLICT,
        }:
            disposition = CandidateDisposition.NEEDS_CLARIFICATION
        elif action == DomainAction.CLARIFY:
            disposition = CandidateDisposition.NEEDS_CLARIFICATION
        elif any(constraint.severity == ConstraintSeverity.CLARIFY for constraint in constraints):
            disposition = CandidateDisposition.NEEDS_CLARIFICATION
        elif any(constraint.severity == ConstraintSeverity.AMEND for constraint in constraints):
            disposition = CandidateDisposition.AMENDABLE
        else:
            disposition = CandidateDisposition.EXECUTABLE

        derived = tuple(dict.fromkeys(pair.derived_from + tuple(
            evidence_id for constraint in constraints for evidence_id in constraint.derived_from
        )))
        return CandidateEvaluation(
            pair,
            slots,
            information,
            capability,
            required_capabilities,
            missing_capabilities,
            constraints,
            disposition,
            derived,
        )

    @staticmethod
    def _required_plan_capabilities(
        view: Any,
        evidence_graph: Any,
        focal: dict[str, Any],
        pair: ActionTargetCandidate,
        information: InformationState,
        constraints: tuple[ActiveConstraint, ...],
    ) -> tuple[str, ...]:
        action = pair.action_candidate.action
        mode = pair.action_candidate.operation_mode
        if mode == "cancel":
            return ("cancel",)
        if any(item.severity == ConstraintSeverity.HARD for item in constraints):
            return ("guard",)
        if (
            information.status in {InformationStatus.MISSING, InformationStatus.CONFLICT}
            or action == DomainAction.CLARIFY
            or any(item.severity == ConstraintSeverity.CLARIFY for item in constraints)
        ):
            return ("read", "clarify")
        amended = any(
            item.severity == ConstraintSeverity.AMEND for item in constraints
        )
        if action in {DomainAction.LOCAL_UPDATE, DomainAction.MEMORY_UPDATE}:
            return ("read", "verify", "update")
        if action in {DomainAction.PAY, DomainAction.TOGGLE, DomainAction.SCHEDULE}:
            if mode == "verify":
                return ("read", "verify")
            if mode == "execute":
                terminal = {
                    DomainAction.PAY: "pay",
                    DomainAction.TOGGLE: "toggle",
                    DomainAction.SCHEDULE: "schedule",
                }[action]
                return ("read", "verify", terminal)
        if amended:
            return ("read", "redact", "dispatch")
        if CandidateEvaluator._raw_dispatch_allowed(view, focal, pair.target):
            return ("read", "dispatch")
        return ("read", "summarize", "dispatch")

    @staticmethod
    def _information(
        slots: tuple[RequiredSlot, ...],
    ) -> InformationState:
        missing = tuple(
            slot.name for slot in slots if slot.status == SlotStatus.MISSING
        )
        conflicting = tuple(
            slot.name for slot in slots if slot.status == SlotStatus.CONFLICT
        )
        status = (
            InformationStatus.CONFLICT
            if conflicting
            else InformationStatus.MISSING
            if missing
            else InformationStatus.COMPLETE
        )
        return InformationState(
            status=status,
            required_slots=slots,
            missing_slots=missing,
            conflicting_slots=conflicting,
            derived_from=tuple(
                dict.fromkeys(
                    evidence_id
                    for slot in slots
                    for evidence_id in slot.derived_from
                )
            ),
        )

    @staticmethod
    def _slots(
        action: DomainAction,
        operation_mode: str,
        target: str,
        focal: dict[str, Any],
        evidence_graph: Any,
        derived_from: tuple[str, ...],
    ) -> tuple[RequiredSlot, ...]:
        attrs = focal.get("attrs") or {}
        def slot(name: str, value: Any, source: str) -> RequiredSlot:
            status = SlotStatus.PRESENT if value not in (None, "") else SlotStatus.MISSING
            return RequiredSlot(
                name,
                status,
                value,
                (source,),
                SlotReason.VALUE_ABSENT if status == SlotStatus.MISSING else None,
            )

        memory_slot = (
            RequiredSlot(
                "memory_value",
                SlotStatus.MISSING,
                None,
                ("record:persistent_memory_recall",),
                SlotReason.REQUIRED_MEMORY_UNAVAILABLE,
            )
            if "requirement:memory_value:missing" in derived_from
            else None
        )

        if action in {
            DomainAction.PAY,
            DomainAction.TOGGLE,
            DomainAction.SCHEDULE,
        } and operation_mode in {"cancel", "verify"}:
            return (slot("operation_reference", focal.get("id"), "focal:id"),)
        if action == DomainAction.PAY:
            return (
                slot("merchant", attrs.get("merchant") or target, "focal_attr:merchant"),
                slot("amount", attrs.get("amount"), "focal_attr:amount"),
                slot("method", attrs.get("method"), "focal_attr:method"),
            )
        if action == DomainAction.TOGGLE:
            arguments = tuple(
                item.payload
                for item in evidence_graph.intent_evidence.prompt_evidence(
                    EvidenceKind.OPERATION_ARGUMENT,
                    minimum=EvidenceStrength.SUPPORTING,
                )
                if item.payload.startswith("TOGGLE:desired_state:")
            )
            desired = (
                arguments[-1].rsplit(":", 1)[-1]
                if arguments
                else "apply_routine"
                if focal.get("type") == "iot_routine"
                else ""
            )
            slots = (
                slot("device_target", target, "action_target"),
                slot("desired_state", desired, "intent:desired_state"),
            )
            return slots + ((memory_slot,) if memory_slot else ())
        if action == DomainAction.SCHEDULE:
            return (
                slot("event", focal.get("id"), "focal:id"),
                slot("time", attrs.get("time"), "focal_attr:time"),
            )
        if action in {DomainAction.LOCAL_UPDATE, DomainAction.MEMORY_UPDATE}:
            return (slot("local_resource", focal.get("id"), "focal:id"),)
        if action == DomainAction.CLARIFY:
            return (slot("clarification_target", target, "action_target"),)
        slots = (
            slot("destination", target, "action_target"),
            RequiredSlot("content_scope", SlotStatus.DEFAULTED, "summary", ("safe_default:summary",)),
        )
        return slots + ((memory_slot,) if memory_slot else ())

    @staticmethod
    def _constraints(view: Any, evidence_graph: Any, focal: dict[str, Any], pair: ActionTargetCandidate, _capability: CapabilityStatus) -> tuple[ActiveConstraint, ...]:
        action = pair.action_candidate.action
        local_route = (
            action == DomainAction.DISPATCH
            and view.latest_record_value("share_boundary_update") == "local_update_boundary"
        )
        constraints: list[ActiveConstraint] = []
        intent = evidence_graph.intent_evidence

        def add(
            kind: str,
            severity: ConstraintSeverity,
            reason: str,
            *ids: str,
            parameters: tuple[tuple[str, str], ...] = (),
        ) -> None:
            constraints.append(
                ActiveConstraint(
                    f"constraint:{pair.candidate_id}:{kind}",
                    kind,
                    severity,
                    reason,
                    tuple(ids),
                    parameters,
                )
            )

        focal_id = str(focal.get("id") or "")
        if focal_id and focal_id not in view.objects_by_id():
            add(
                "historical_object_not_current",
                ConstraintSeverity.CLARIFY,
                "historical_focal_requires_non_executing_resolution",
                "session:last_focal_snapshot",
            )

        stop_ids = intent.current_ids(
            EvidenceKind.STOP_PROCESS,
            minimum=EvidenceStrength.DECISIVE,
        )
        if stop_ids:
            add("decisive_user_stop", ConstraintSeverity.HARD, "user_stopped_operation", *stop_ids)
        cancel_ids = intent.current_ids(
            EvidenceKind.CANCEL_ACTION,
            minimum=EvidenceStrength.DECISIVE,
        )
        if cancel_ids and action == DomainAction.DISPATCH:
            add("decisive_dispatch_cancel", ConstraintSeverity.HARD, "user_cancelled_dispatch", *cancel_ids)

        relevant_conflicts = {
            DomainAction.DISPATCH: {
                "resolved_target",
                "target_changed_after_turn",
                "ambiguous_target",
                "ambiguous_focal",
                "dispatch_authority_check",
                "share_boundary_update",
                "external_share_policy",
                "consent",
                "security_alert",
            },
            DomainAction.PAY: {
                "payment_policy",
                "security_alert",
                "trusted_subscription",
            },
            DomainAction.TOGGLE: {
                "safety_mode",
                "duration_ambiguous",
                "temporary_override_allowed",
            },
            DomainAction.SCHEDULE: {"calendar_conflict"},
        }.get(action, set())
        for record_type in sorted(view.duplicate_record_types() & relevant_conflicts):
            ids = tuple(
                f"record:{str(record.get('id') or record_type)}"
                for record in view.records_of_type(record_type)
            )
            add(
                f"conflicting_record:{record_type}",
                ConstraintSeverity.CLARIFY,
                "conflicting_record_state_requires_resolution",
                *ids,
            )

        consent = view.latest_record_value("consent")
        consent_status = str(consent.get("status") if isinstance(consent, dict) else consent or "")
        if action == DomainAction.DISPATCH and not local_route and consent_status in {"revoked", "withdrawn", "denied"}:
            add("consent_revoked", ConstraintSeverity.HARD, "consent_revoked_for_dispatch", "record:consent")
        if action == DomainAction.DISPATCH and not local_route and view.latest_record_value("security_alert"):
            add("security_alert", ConstraintSeverity.HARD, "security_alert_for_dispatch", "record:security_alert")
        if action == DomainAction.PAY and view.latest_record_value("security_alert"):
            add("security_alert", ConstraintSeverity.HARD, "security_alert_for_payment", "record:security_alert")
        if action == DomainAction.TOGGLE and view.latest_record_value("safety_mode"):
            add("safety_mode", ConstraintSeverity.HARD, "safety_mode_for_device_action", "record:safety_mode")
        if action == DomainAction.PAY and view.latest_record_value("payment_policy"):
            add("payment_policy", ConstraintSeverity.CLARIFY, "payment_policy_requires_resolution", "record:payment_policy")
        trusted_subscription = view.latest_record_value("trusted_subscription")
        if (
            action == DomainAction.PAY
            and trusted_subscription
            and str(trusted_subscription) != pair.target
        ):
            add(
                "trusted_subscription_mismatch",
                ConstraintSeverity.CLARIFY,
                "payment_merchant_not_trusted_subscription",
                "record:trusted_subscription",
            )
        if action == DomainAction.SCHEDULE and view.latest_record_value("calendar_conflict"):
            add("calendar_conflict", ConstraintSeverity.CLARIFY, "calendar_conflict_requires_resolution", "record:calendar_conflict")
        if action == DomainAction.TOGGLE and view.latest_record_value("duration_ambiguous"):
            add("duration_ambiguous", ConstraintSeverity.CLARIFY, "duration_requires_resolution", "record:duration_ambiguous")
        temporary_override = view.latest_record_value("temporary_override_allowed")
        if action == DomainAction.TOGGLE and temporary_override:
            add(
                "temporary_override",
                ConstraintSeverity.AMEND,
                "temporary_duration_limits_toggle",
                "record:temporary_override_allowed",
                parameters=(("duration", str(temporary_override)),),
            )

        clarification_ids = intent.current_ids(
            EvidenceKind.CLARIFICATION_REQUEST,
            minimum=EvidenceStrength.DECISIVE,
        )
        if clarification_ids:
            add("explicit_clarification", ConstraintSeverity.CLARIFY, "user_requested_clarification", *clarification_ids)
        redaction_ids = intent.current_ids(
            EvidenceKind.REDACTION_REQUEST,
            minimum=EvidenceStrength.STRONG,
        )
        if action == DomainAction.DISPATCH and redaction_ids:
            add("explicit_redaction", ConstraintSeverity.AMEND, "user_requested_redaction", *redaction_ids)
        policy = view.latest_record_value("external_share_policy")
        if action == DomainAction.DISPATCH and not local_route and policy:
            if focal.get("type") == "health_record" and str(policy) == "doctor_note_forbidden":
                add("health_external_share_blocked", ConstraintSeverity.HARD, "doctor_note_forbidden", "record:external_share_policy")
            else:
                add("external_share_policy", ConstraintSeverity.AMEND, "external_scope_restricted", "record:external_share_policy")

        if action == DomainAction.DISPATCH:
            explicit_domain = {
                item.payload
                for item in intent.prompt_evidence(
                    EvidenceKind.EXPLICIT_DOMAIN_VERB,
                    minimum=EvidenceStrength.SUPPORTING,
                )
            }
            if "PAY" in explicit_domain and view.latest_record_value("payment_policy"):
                add("payment_policy", ConstraintSeverity.CLARIFY, "payment_policy_requires_resolution", "record:payment_policy")
            CandidateEvaluator._collect_dispatch_constraints(
                view,
                evidence_graph,
                focal,
                pair,
                constraints,
            )
        return tuple(constraints)

    @staticmethod
    def _collect_dispatch_constraints(
        view: Any,
        evidence_graph: Any,
        focal: dict[str, Any],
        pair: ActionTargetCandidate,
        constraints: list[ActiveConstraint],
    ) -> None:
        existing = {constraint.kind for constraint in constraints}

        def add(kind: str, severity: ConstraintSeverity, reason: str, *ids: str) -> None:
            if kind not in existing:
                constraints.append(
                    ActiveConstraint(
                        f"constraint:{pair.candidate_id}:{kind}",
                        kind,
                        severity,
                        reason,
                        tuple(ids),
                    )
                )
                existing.add(kind)

        # Memory and domain records become scoped constraints here; they never
        # emit a control label directly.
        if view.latest_record_value("enterprise_policy_recall"):
            add("enterprise_policy_recall", ConstraintSeverity.AMEND, "standing_policy_limits_dispatch", "record:enterprise_policy_recall")
        if view.latest_record_value("ops_memory_recall"):
            severity = ConstraintSeverity.CLARIFY if view.latest_record_value("target_changed_after_turn") else ConstraintSeverity.AMEND
            add("ops_memory_recall", severity, "prior_route_requires_scoped_reuse", "record:ops_memory_recall")
        if view.latest_record_value("memory_conflict"):
            add("memory_conflict", ConstraintSeverity.CLARIFY, "memory_conflict_requires_resolution", "record:memory_conflict")
        if view.latest_record_value("target_changed_after_turn"):
            add("target_changed", ConstraintSeverity.CLARIFY, "target_changed_requires_resolution", "record:target_changed_after_turn")
        if (
            view.latest_record_value("persistent_memory_recall")
            and evidence_graph.intent_evidence.prompt_evidence(
                EvidenceKind.VALUE_TRANSFER_REQUEST
            )
            and not view.latest_record_value("payment_policy")
        ):
            add("stale_coupon_memory", ConstraintSeverity.HARD, "stale_payment_memory", "record:persistent_memory_recall")

        boundary = str(view.latest_record_value("share_boundary_update") or "")
        ambiguous = str(view.latest_record_value("ambiguous_target") or "")
        authority = str(view.latest_record_value("dispatch_authority_check") or "")
        candidates = str(view.latest_record_value("route_candidate_snapshot") or "")
        has_redaction = bool(
            evidence_graph.intent_evidence.current(
                EvidenceKind.REDACTION_REQUEST,
                minimum=EvidenceStrength.STRONG,
            )
        )

        if boundary == "dispatch_blocked_until_binding":
            if has_redaction:
                add("blocked_route_redaction", ConstraintSeverity.AMEND, "redaction_is_safe_fallback", "record:share_boundary_update")
            elif view.latest_record_value("guardrail_ladder_signal"):
                add("blocked_route_guardrail", ConstraintSeverity.HARD, "guardrail_blocks_unbound_route", "record:guardrail_ladder_signal")
            elif view.latest_record_value("ambiguous_focal") and authority == "user_binding_pending":
                add("blocked_route_ambiguous_focal", ConstraintSeverity.HARD, "focal_and_route_unbound", "record:ambiguous_focal")
            elif authority in {"authority_incomplete", "user_binding_pending"}:
                add("unresolved_route", ConstraintSeverity.CLARIFY, "route_binding_required", "record:dispatch_authority_check")
        elif boundary == "local_update_boundary":
            if ambiguous == "stored_channel_or_visible_recipient":
                add("local_boundary_stored_channel_conflict", ConstraintSeverity.AMEND, "stored_channel_conflicts_with_local_boundary", "record:ambiguous_target")
            elif ambiguous == "approved_channel_or_visible_recipient":
                add("local_boundary_approval_ambiguity", ConstraintSeverity.CLARIFY, "approval_route_ambiguous", "record:ambiguous_target")
            elif ambiguous == "surface_recipient_and_resolved_target_both_recent":
                add("local_boundary_recent_target_conflict", ConstraintSeverity.AMEND, "recent_targets_conflict", "record:ambiguous_target")
        elif boundary in {"redacted_external_boundary", "redacted_after_selection_boundary"}:
            if ambiguous == "surface_recipient_and_resolved_target_both_recent":
                add("external_boundary_recent_target_conflict", ConstraintSeverity.CLARIFY, "recent_targets_conflict", "record:ambiguous_target")
            elif (
                ambiguous == "stored_channel_or_visible_recipient"
                and bool(view.latest_record_value("persistent_memory_recall"))
            ):
                add("external_boundary_memory_target_conflict", ConstraintSeverity.CLARIFY, "stored_route_conflicts_with_visible_target", "record:ambiguous_target")
            elif not (
                view.latest_record_value("guardrail_ladder_signal")
                and authority == "internal_binding_confirmed"
            ):
                add("redacted_external_boundary", ConstraintSeverity.AMEND, "external_boundary_requires_redaction", "record:share_boundary_update")

        if view.latest_record_value("ambiguous_focal") and view.latest_record_value("session_share_policy") == "normal":
            add("ambiguous_focal", ConstraintSeverity.CLARIFY, "focal_ambiguity_unresolved", "record:ambiguous_focal")
        if view.latest_record_value("ambiguous_target") or view.latest_record_value("ambiguous_focal"):
            unresolved = (
                authority in {"authority_incomplete", "user_binding_pending"}
                and boundary == "dispatch_blocked_until_binding"
            ) or (
                candidates == "external_candidates_present"
                and authority != "internal_binding_confirmed"
                and not boundary.startswith("redacted")
            )
            if has_redaction and boundary == "dispatch_blocked_until_binding":
                unresolved = False
            if unresolved:
                add("unresolved_ambiguity", ConstraintSeverity.CLARIFY, "target_or_focal_ambiguity", "record:ambiguous_target")

        if (
            view.latest_record_value("ambiguous_target")
            and view.latest_record_value("resolved_target")
        ):
            add("resolved_target_conflict", ConstraintSeverity.AMEND, "surface_and_resolved_targets_conflict", "record:resolved_target")
        if (
            view.latest_record_value("session_share_policy") == "strict"
            and view.latest_record_value("resolved_target")
            and boundary != "local_update_boundary"
            and not CandidateEvaluator._raw_dispatch_allowed(view, focal, pair.target)
        ):
            add("strict_share_policy", ConstraintSeverity.AMEND, "strict_policy_requires_minimal_disclosure", "record:session_share_policy")

    @staticmethod
    def _raw_dispatch_allowed(view: Any, focal: dict[str, Any], target: str) -> bool:
        if (
            view.latest_record_value("guardrail_ladder_signal")
            and view.latest_record_value("share_boundary_update") == "redacted_external_boundary"
            and view.latest_record_value("dispatch_authority_check") == "internal_binding_confirmed"
        ):
            return True
        if view.latest_record_value("session_share_policy") != "normal":
            return False
        if view.latest_record_value("external_share_policy"):
            return False
        if view.latest_record_value("ambiguous_target") or view.latest_record_value("ambiguous_focal"):
            return False
        attrs = focal.get("attrs") or {}
        return (
            focal.get("type") == "message"
            and str(attrs.get("recipient") or "") == target
            and not attrs.get("contains")
        )

    @classmethod
    def _select_target_or_ask(
        cls,
        evaluations: list[CandidateEvaluation],
    ) -> CandidateEvaluation:
        confidence_rank = {
            "decisive": 4,
            "high": 3,
            "medium": 2,
            "low": 1,
            "none": 0,
        }
        top_confidence = max(
            confidence_rank.get(item.candidate.target_confidence, 0)
            for item in evaluations
        )
        top = sorted(
            (
                item
                for item in evaluations
                if confidence_rank.get(item.candidate.target_confidence, 0)
                == top_confidence
            ),
            key=lambda item: item.candidate.candidate_id,
        )
        executable = [
            item for item in top if item.disposition == CandidateDisposition.EXECUTABLE
        ]
        if len({item.candidate.target for item in executable}) > 1:
            selected = executable[0]
            alternatives = tuple(item.candidate.candidate_id for item in executable)
            constraint = ActiveConstraint(
                constraint_id=f"constraint:{selected.candidate.candidate_id}:multiple_executable_alternatives",
                kind="multiple_executable_alternatives",
                severity=ConstraintSeverity.CLARIFY,
                reason="user_choice_required_between_executable_alternatives",
                derived_from=alternatives,
            )
            return replace(
                selected,
                active_constraints=selected.active_constraints + (constraint,),
                disposition=CandidateDisposition.NEEDS_CLARIFICATION,
                derived_from=tuple(
                    dict.fromkeys(selected.derived_from + alternatives)
                ),
            )
        return top[0]

    @classmethod
    def _promotion_traces(
        cls,
        view: Any,
        evidence_graph: Any,
        actions: tuple[ActionCandidate, ...],
        evaluations: list[CandidateEvaluation],
        selected: CandidateEvaluation,
        focal: dict[str, Any],
    ) -> tuple[DomainPromotionTrace, ...]:
        traces: list[DomainPromotionTrace] = []
        intent: IntentEvidenceSet = evidence_graph.intent_evidence
        domain_actions = {DomainAction.PAY, DomainAction.TOGGLE, DomainAction.SCHEDULE}
        has_execute = bool(intent.prompt_evidence(EvidenceKind.EXECUTION_REQUEST))
        has_share = bool(intent.prompt_evidence(EvidenceKind.SHARE_REQUEST))
        has_clarify = bool(intent.current(EvidenceKind.CLARIFICATION_REQUEST))
        has_verify = bool(intent.prompt_evidence(EvidenceKind.VERIFY_REQUEST))

        for action in actions:
            if action.action not in domain_actions:
                continue
            related = [item for item in evaluations if item.candidate.action_candidate == action]
            best = related[0]
            eligible = (
                action.operation_mode == "execute"
                and has_execute
                and best.capability_status == CapabilityStatus.AVAILABLE
                and all(slot.status not in {SlotStatus.MISSING, SlotStatus.CONFLICT} for slot in best.required_slots)
                and not any(constraint.severity == ConstraintSeverity.HARD for constraint in best.active_constraints)
                and best.candidate.target != ""
            )
            applied = selected.candidate.action_candidate == action and eligible
            reason: PromotionRejectionReason | None = None
            if best.capability_status == CapabilityStatus.UNAVAILABLE:
                reason = PromotionRejectionReason.CAPABILITY_UNAVAILABLE
            elif not has_execute:
                if has_clarify:
                    reason = PromotionRejectionReason.CLARIFICATION_ONLY_REQUEST
                elif has_share:
                    reason = PromotionRejectionReason.SHARE_ONLY_REQUEST
                elif has_verify:
                    reason = PromotionRejectionReason.VERIFY_ONLY_REQUEST
                else:
                    reason = PromotionRejectionReason.NO_EXPLICIT_EXECUTION_INTENT
            elif not best.candidate.target:
                reason = PromotionRejectionReason.TARGET_UNRESOLVED
            elif any(slot.status in {SlotStatus.MISSING, SlotStatus.CONFLICT} for slot in best.required_slots):
                reason = PromotionRejectionReason.REQUIRED_SLOT_MISSING
            elif any(constraint.severity == ConstraintSeverity.HARD for constraint in best.active_constraints):
                reason = PromotionRejectionReason.HARD_CONSTRAINT_ACTIVE
            elif eligible and not applied:
                reason = PromotionRejectionReason.LOWER_RANKED_CANDIDATE

            traces.append(
                DomainPromotionTrace(
                    domain_action_candidate=action.action.value,
                    operation_mode=action.operation_mode,
                    domain_context_applied=(
                        selected.candidate.action_candidate == action
                    ),
                    promotion_eligible=eligible,
                    promotion_applied=applied,
                    promotion_rejected_reason=reason,
                    fallback_profile="authorized_pair_fallback",
                    required_slots=best.required_slots,
                    capability_status=best.capability_status,
                    active_constraints=tuple(constraint.kind for constraint in best.active_constraints),
                    supporting_evidence_ids=action.derived_from,
                    selected_pair_id=(
                        selected.candidate.candidate_id
                        if selected.candidate.action_candidate == action
                        else ""
                    ),
                )
            )

        action_by_payload = {
            "PAY": DomainAction.PAY,
            "TOGGLE": DomainAction.TOGGLE,
            "SCHEDULE": DomainAction.SCHEDULE,
        }
        present_actions = {action.action for action in actions}
        for item in intent.prompt_evidence(
            EvidenceKind.EXPLICIT_DOMAIN_VERB,
            minimum=EvidenceStrength.SUPPORTING,
        ):
            action = action_by_payload.get(item.payload)
            if action is None or action in present_actions:
                continue
            capability = (
                CapabilityStatus.AVAILABLE
                if ActionCandidateResolver.CAPABILITY[action] in view.available_actions
                else CapabilityStatus.UNAVAILABLE
            )
            reason = (
                PromotionRejectionReason.FOCAL_DOMAIN_MISMATCH
                if str(focal.get("type") or "")
                not in ActionCandidateResolver.DOMAIN_OBJECT_TYPES[action]
                else PromotionRejectionReason.LOW_CONFIDENCE
            )
            traces.append(
                DomainPromotionTrace(
                    domain_action_candidate=action.value,
                    operation_mode="execute",
                    domain_context_applied=False,
                    promotion_eligible=False,
                    promotion_applied=False,
                    promotion_rejected_reason=reason,
                    fallback_profile="authorized_pair_fallback",
                    required_slots=(),
                    capability_status=capability,
                    active_constraints=(),
                    supporting_evidence_ids=(item.evidence_id,),
                )
            )
        present_modes = {
            (action.action, action.operation_mode) for action in actions
        }
        for kind, operation_mode, capability_name in (
            (EvidenceKind.DOMAIN_CANCEL_REQUEST, "cancel", "cancel"),
            (EvidenceKind.DOMAIN_VERIFY_REQUEST, "verify", "verify"),
        ):
            grouped: dict[DomainAction, list[str]] = {}
            for item in intent.prompt_evidence(
                kind, minimum=EvidenceStrength.SUPPORTING
            ):
                action = action_by_payload.get(item.payload)
                if action is not None:
                    grouped.setdefault(action, []).append(item.evidence_id)
            for action, evidence_ids in grouped.items():
                if (action, operation_mode) in present_modes:
                    continue
                capability = (
                    CapabilityStatus.AVAILABLE
                    if capability_name in view.available_actions
                    else CapabilityStatus.UNAVAILABLE
                )
                traces.append(
                    DomainPromotionTrace(
                        domain_action_candidate=action.value,
                        operation_mode=operation_mode,
                        domain_context_applied=False,
                        promotion_eligible=False,
                        promotion_applied=False,
                        promotion_rejected_reason=(
                            PromotionRejectionReason.FOCAL_DOMAIN_MISMATCH
                            if str(focal.get("type") or "")
                            not in ActionCandidateResolver.DOMAIN_OBJECT_TYPES[
                                action
                            ]
                            else PromotionRejectionReason.LOW_CONFIDENCE
                        ),
                        fallback_profile="authorized_pair_fallback",
                        required_slots=(),
                        capability_status=capability,
                        active_constraints=(),
                        supporting_evidence_ids=tuple(evidence_ids),
                    )
                )
        return tuple(traces)


class ActionTargetPairBuilder:
    @staticmethod
    def build(
        action: ActionCandidate,
        targets: tuple[Any, ...],
        focal: dict[str, Any],
    ) -> tuple[ActionTargetCandidate, ...]:
        compatible = CandidateEvaluator._compatible_targets(
            action.action, targets, focal
        )
        if not compatible:
            compatible = (("", "unresolved", "none", ()),)
        return tuple(
            ActionTargetCandidate(
                candidate_id=(
                    f"pair:{action.action.value}:{action.operation_mode}:"
                    f"{role}:{target or 'unresolved'}"
                ),
                action_candidate=action,
                target=target,
                target_role=role,
                target_confidence=confidence,
                derived_from=tuple(
                    dict.fromkeys(action.derived_from + tuple(derived_from))
                ),
            )
            for target, role, confidence, derived_from in compatible
        )


class InformationResolver:
    @staticmethod
    def resolve(
        action: DomainAction,
        operation_mode: str,
        target: str,
        focal: dict[str, Any],
        evidence_graph: Any,
        derived_from: tuple[str, ...],
    ) -> InformationState:
        slots = CandidateEvaluator._slots(
            action,
            operation_mode,
            target,
            focal,
            evidence_graph,
            derived_from,
        )
        return CandidateEvaluator._information(slots)


class CapabilityResolver:
    @staticmethod
    def resolve(
        view: Any,
        pair: ActionTargetCandidate,
        required_capabilities: tuple[str, ...],
    ) -> tuple[CapabilityStatus, tuple[str, ...]]:
        if pair.action_candidate.operation_mode == "cancel":
            # CANCEL is a semantic operation, not an official plan verb. It
            # remains unsupported until a domain blueprint maps it safely.
            return CapabilityStatus.UNAVAILABLE, ("cancel",)
        missing = tuple(
            capability
            for capability in required_capabilities
            if capability not in view.available_actions
        )
        return (
            CapabilityStatus.UNAVAILABLE
            if missing
            else CapabilityStatus.AVAILABLE,
            missing,
        )


class ConstraintActivator:
    @staticmethod
    def activate(
        view: Any,
        evidence_graph: Any,
        focal: dict[str, Any],
        pair: ActionTargetCandidate,
        capability: CapabilityStatus,
    ) -> tuple[ActiveConstraint, ...]:
        return CandidateEvaluator._constraints(
            view, evidence_graph, focal, pair, capability
        )


class AuthorizedFallbackSolver:
    """Selects only evidence-backed alternatives after pair evaluation."""

    @classmethod
    def solve(
        cls,
        evaluations: list[CandidateEvaluation],
        evidence_graph: Any,
    ) -> tuple[CandidateEvaluation, FallbackResolution]:
        if not evaluations:
            raise ValueError("decision matrix has no candidates")
        confidence_rank = {
            "decisive": 4,
            "high": 3,
            "medium": 2,
            "low": 1,
            "none": 0,
        }
        ordered = sorted(
            evaluations,
            key=lambda item: (
                -item.candidate.action_candidate.intent_rank,
                -confidence_rank.get(item.candidate.target_confidence, 0),
                item.candidate.candidate_id,
            ),
        )
        preferred_rank = ordered[0].candidate.action_candidate.intent_rank
        preferred = [
            item
            for item in ordered
            if item.candidate.action_candidate.intent_rank == preferred_rank
        ]
        preferred_ids = tuple(item.candidate.candidate_id for item in preferred)
        available = [
            item
            for item in preferred
            if item.capability_status == CapabilityStatus.AVAILABLE
        ]
        if available:
            selected = CandidateEvaluator._select_target_or_ask(available)
            user_choice = any(
                item.kind == "multiple_executable_alternatives"
                for item in selected.active_constraints
            )
            reason = (
                FallbackReason.USER_CHOICE_REQUIRED
                if user_choice
                else FallbackReason.NOT_NEEDED
            )
            return selected, FallbackResolution(
                selected_candidate_id=selected.candidate.candidate_id,
                preferred_candidate_ids=preferred_ids,
                fallback_applied=False,
                reason=reason,
                authorized_candidate_ids=preferred_ids,
                derived_from=selected.derived_from,
            )

        authorization_ids = evidence_graph.intent_evidence.prompt_ids(
            EvidenceKind.AUTHORIZED_FALLBACK,
            minimum=EvidenceStrength.STRONG,
        )
        alternatives = [
            item
            for item in ordered
            if authorization_ids
            if item.candidate.action_candidate.intent_rank < preferred_rank
            and item.capability_status == CapabilityStatus.AVAILABLE
            and item.candidate.action_candidate.derived_from
            and not item.candidate.action_candidate.derived_from[0].startswith(
                "default:"
            )
            and item.disposition == CandidateDisposition.EXECUTABLE
        ]
        if alternatives:
            alternative_rank = max(
                item.candidate.action_candidate.intent_rank
                for item in alternatives
            )
            authorized = [
                item
                for item in alternatives
                if item.candidate.action_candidate.intent_rank == alternative_rank
            ]
            selected = CandidateEvaluator._select_target_or_ask(authorized)
            user_choice = any(
                item.kind == "multiple_executable_alternatives"
                for item in selected.active_constraints
            )
            return selected, FallbackResolution(
                selected_candidate_id=selected.candidate.candidate_id,
                preferred_candidate_ids=preferred_ids,
                fallback_applied=True,
                reason=(
                    FallbackReason.USER_CHOICE_REQUIRED
                    if user_choice
                    else FallbackReason.AUTHORIZED_FALLBACK_SELECTED
                ),
                authorized_candidate_ids=tuple(
                    item.candidate.candidate_id for item in authorized
                ),
                derived_from=tuple(
                    dict.fromkeys(
                        authorization_ids
                        + tuple(
                            evidence_id
                            for item in authorized
                            for evidence_id in item.derived_from
                        )
                    )
                ),
            )

        selected = preferred[0]
        return selected, FallbackResolution(
            selected_candidate_id=selected.candidate.candidate_id,
            preferred_candidate_ids=preferred_ids,
            fallback_applied=False,
            reason=(
                FallbackReason.NO_AUTHORIZED_FALLBACK
                if selected.capability_status == CapabilityStatus.UNAVAILABLE
                else FallbackReason.PREFERRED_CAPABILITY_UNAVAILABLE
            ),
            authorized_candidate_ids=(),
            derived_from=(
                f"capability:{selected.candidate.action_candidate.required_capability}",
            ),
        )


class FinalDecisionBuilder:
    CONTROL_BY_DISPOSITION = {
        CandidateDisposition.BLOCKED: "hold",
        CandidateDisposition.NEEDS_CLARIFICATION: "ask",
        CandidateDisposition.AMENDABLE: "amend",
        CandidateDisposition.EXECUTABLE: "proceed",
    }

    @classmethod
    def build(cls, state: Any, matrix: DecisionMatrix) -> FinalDecision:
        selected = matrix.selected
        control = cls.CONTROL_BY_DISPOSITION[selected.disposition]
        target, target_source = cls._output_target(state, selected, control)
        reason_code = cls._reason_code(selected)
        operation_mode = selected.candidate.action_candidate.operation_mode
        domain_actions = {
            DomainAction.PAY,
            DomainAction.TOGGLE,
            DomainAction.SCHEDULE,
        }
        execution_emitted = (
            selected.candidate.action_candidate.action in domain_actions
            and operation_mode == "execute"
            and control == "proceed"
        )
        traces = tuple(
            replace(
                trace,
                selected_pair_id=(
                    selected.candidate.candidate_id
                    if trace.domain_context_applied
                    else trace.selected_pair_id
                ),
                execution_emitted=(
                    execution_emitted and trace.domain_context_applied
                ),
            )
            for trace in matrix.promotion_traces
        )
        derived = tuple(
            dict.fromkeys(
                selected.derived_from
                + selected.information.derived_from
                + tuple(
                    evidence_id
                    for constraint in selected.active_constraints
                    for evidence_id in constraint.derived_from
                )
            )
        )
        return FinalDecision(
            selected_pair_id=selected.candidate.candidate_id,
            action=selected.candidate.action_candidate.action,
            operation_mode=operation_mode,
            operation_target=selected.candidate.target,
            target=target,
            target_source=target_source,
            control=control,
            information=selected.information,
            capability_status=selected.capability_status,
            required_capabilities=selected.required_capabilities,
            missing_capabilities=selected.missing_capabilities,
            active_constraints=selected.active_constraints,
            fallback=matrix.fallback,
            domain_promotion=traces,
            reason_code=reason_code,
            historical_focal=(state.focal_decision.source == "session_snapshot"),
            derived_from=derived,
        )

    @staticmethod
    def _output_target(
        state: Any,
        selected: CandidateEvaluation,
        control: str,
    ) -> tuple[str, str]:
        intent = state.evidence.intent_evidence
        action = selected.candidate.action_candidate.action
        if action == DomainAction.CLARIFY:
            return "user", "clarification_target"
        if intent.current(
            EvidenceKind.STOP_PROCESS, minimum=EvidenceStrength.DECISIVE
        ):
            return "user", "explicit_user_stop"
        if any(
            slot.reason_code == SlotReason.REQUIRED_MEMORY_UNAVAILABLE
            for slot in selected.required_slots
        ) and control == "ask":
            return "user", "required_memory_unavailable"
        asks_user = any(
            item.payload == "clarify_user"
            for item in intent.current(
                EvidenceKind.CLARIFICATION_REQUEST,
                minimum=EvidenceStrength.DECISIVE,
            )
        )
        if asks_user and control == "ask":
            return "user", "explicit_user_clarification"
        if selected.candidate.target:
            return selected.candidate.target, selected.candidate.target_role
        return "user", "unresolved_target"

    @staticmethod
    def _reason_code(selected: CandidateEvaluation) -> str:
        hard = next(
            (
                item.kind
                for item in selected.active_constraints
                if item.severity == ConstraintSeverity.HARD
            ),
            "",
        )
        if hard:
            return f"HARD_CONSTRAINT:{hard}"
        if selected.capability_status == CapabilityStatus.UNAVAILABLE:
            return "CAPABILITY_UNAVAILABLE"
        if selected.information.status == InformationStatus.CONFLICT:
            return "REQUIRED_INFORMATION_CONFLICT"
        if selected.information.status == InformationStatus.MISSING:
            return "REQUIRED_INFORMATION_MISSING"
        clarify = next(
            (
                item.kind
                for item in selected.active_constraints
                if item.severity == ConstraintSeverity.CLARIFY
            ),
            "",
        )
        if clarify:
            return f"CLARIFY_CONSTRAINT:{clarify}"
        amend = next(
            (
                item.kind
                for item in selected.active_constraints
                if item.severity == ConstraintSeverity.AMEND
            ),
            "",
        )
        if amend:
            return f"AMEND_CONSTRAINT:{amend}"
        return "EXECUTABLE"


class DecisionEngine:
    @classmethod
    def decide(cls, state: Any) -> tuple[DecisionMatrix, FinalDecision]:
        matrix = CandidateEvaluator.build_matrix(
            state.view,
            state.evidence,
            state.focal,
            state.target_candidates,
            state.operation_intent,
        )
        final = FinalDecisionBuilder.build(state, matrix)
        matrix = replace(matrix, promotion_traces=final.domain_promotion)
        return matrix, final

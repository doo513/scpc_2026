from __future__ import annotations

from typing import Any

from core.decision import DecisionEngine
from core.session_state import MemoryStore, extract_memory_payload, update_session_state
from core.state import StateAssembler
from core.task_view import TaskView
from rules.plan import PlanCompiler
from rules.response import ResponseBuilder
from rules.scope_policy import PolicyCompiler, ScopeCompiler


class FinalHarness:
    """Deterministic SCPC answer engine with no filesystem side effects."""

    def __init__(self) -> None:
        self.memory_store = MemoryStore()

    def prepare(self, tasks: list[dict[str, Any]] | None = None) -> None:
        # The task list is intentionally ignored: a harness may not preview the
        # screening stream before normal session/turn execution.
        self.memory_store.clear()

    def answer_task(self, task: dict[str, Any], session: dict[str, Any]) -> dict[str, Any]:
        view = TaskView(task, session)

        state = StateAssembler.assemble(view, self.memory_store, session)
        decision_matrix, final_decision = DecisionEngine.decide(state)
        content_scope = ScopeCompiler.compile(
            state, final_decision, decision_matrix
        )
        policy = PolicyCompiler.compile(state, final_decision, content_scope)
        plan_events = PlanCompiler.compile(
            state, final_decision, content_scope, policy
        )
        user_response, audit_tags, counterfactual = ResponseBuilder.build(
            final_decision,
            content_scope,
            policy,
        )

        answer = {
            "focal_id": state.focal_decision.focal_id,
            "target": final_decision.target,
            "control": final_decision.control,
            "content_scope": content_scope,
            "policy": policy,
            "plan_events": plan_events,
            "user_response": user_response,
            "audit_tags": audit_tags,
            "counterfactual": counterfactual,
            "_trace": {
                "task_id": view.task_id,
                "state": state.to_trace(),
                "focal": state.focal_decision.to_trace(),
                "final_decision": final_decision.to_trace(),
                "evidence": state.evidence.to_trace(),
                "records": view.record_index.to_trace(),
                "relations": state.relation_graph.to_trace(),
                "decision_matrix": decision_matrix.to_trace(),
                "scope_mode": content_scope["mode"],
            },
        }
        self._commit_memory(view, final_decision, plan_events)
        update_session_state(session, answer)
        if state.focal:
            session["last_focal_snapshot"] = dict(state.focal)
            session["last_focal_source_task"] = view.task_id
            session["last_focal_source_turn"] = view.turn_index
        return answer

    def _commit_memory(
        self,
        view: TaskView,
        decision: Any,
        plan_events: list[dict[str, Any]],
    ) -> None:
        if decision.control not in {"proceed", "amend"}:
            return
        if decision.action.value != "memory_update":
            return
        if not any(event.get("verb") == "update" for event in plan_events):
            return
        for value in view.record_values("persistent_memory_write"):
            if isinstance(value, dict):
                self.memory_store.write(
                    value,
                    task_id=view.task_id,
                    session_id=view.session_id,
                    turn_index=view.turn_index,
                )
            elif isinstance(value, str) and value:
                self.memory_store.write(
                    extract_memory_payload(view.prompt, value),
                    task_id=view.task_id,
                    session_id=view.session_id,
                    turn_index=view.turn_index,
                )

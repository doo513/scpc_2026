from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import subprocess
import sys
from typing import Any

from build_manifest import publish_candidate_manifest
from core.candidate_evaluation import CandidateEvaluationEngine
from local_score import evaluate_dev_payload
from run_submission import run_tasks
from utils.io import find_data_dir, load_jsonl
from validate_artifacts import validate_current_artifacts


BASE_DIR = Path(__file__).resolve().parent
KNOWN_DEV_GATE = "tests/test_regression.py::test_dev_score_and_optional_fields"


def _run_pytest(arguments: list[str], log_path: Path) -> dict[str, Any]:
    completed = subprocess.run(
        [sys.executable, "-m", "pytest", "-q", *arguments],
        cwd=BASE_DIR,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    log_path.write_text(completed.stdout, encoding="utf-8")
    failed = sorted(set(re.findall(r"FAILED ([^\s]+)", completed.stdout)))
    return {"exit_code": completed.returncode, "failed_tests": failed}


def _dev() -> tuple[dict[str, Any], dict[str, Any]]:
    data_dir = find_data_dir()
    references = json.loads(
        (data_dir / "dev_answers.json").read_text(encoding="utf-8")
    )
    return evaluate_dev_payload(
        run_tasks(load_jsonl(data_dir / "dev_tasks.jsonl")),
        references,
    )


def _dev_gate(dev: dict[str, Any]) -> dict[str, Any]:
    spec = json.loads(
        (BASE_DIR / "tests" / "specs" / "generalization_v1.json").read_text(
            encoding="utf-8"
        )
    )["dev_hard_gate"]
    checks = {
        "overall": dev["overall"] >= spec["minimum_overall"],
        **{
            f"axis.{axis}": dev["axes"][axis] >= floor
            for axis, floor in spec["minimum_axes"].items()
        },
        "non_exact": dev["non_exact_count"] <= spec["maximum_non_exact_tasks"],
    }
    return {"passed": all(checks.values()), "checks": checks, "contract": spec}


def _specificity_scan() -> dict[str, Any]:
    paths = tuple(sorted((BASE_DIR / "core").glob("*.py"))) + tuple(
        sorted((BASE_DIR / "rules").glob("*.py"))
    ) + (BASE_DIR / "harness.py",)
    text = "\n".join(path.read_text(encoding="utf-8") for path in paths)
    markers = tuple(
        marker
        for marker in ("final_dev_", "final_screening_", "dev_answers", "screening_results")
        if marker in text
    )
    return {"passed": not markers, "prohibited_markers": markers}


def _markdown(result: dict[str, Any]) -> str:
    dev = result["dev"]
    lines = [
        "# Current Release Gate Report",
        "",
        f"- status: **{result['status']}**",
        f"- production release allowed: `{result['production_release_allowed']}`",
        f"- source SHA-256: `{result['source_tree_sha256']}`",
        f"- submission SHA-256: `{result['artifact_validation']['submission_sha256']}`",
        f"- official dev: `{dev['overall']:.4f}`",
        f"- exact/non-exact: `{dev['exact_match_count']}/{dev['non_exact_count']}`",
        f"- FixedSLM: `{result['fixed_slm']['decision']}` (production influence `{result['fixed_slm']['production_influence']}`)",
        "",
        "## Checks",
        "",
    ]
    lines.extend(
        f"- {name}: `{'PASS' if passed else 'FAIL'}`"
        for name, passed in result["checks"].items()
    )
    lines.extend(
        [
            "",
            "## Decision",
            "",
            "Output projection, pure compilation, validation-before-commit, atomic single-answer commit, schema validation, and artifact reproduction are current. The typed semantic replacement is not promoted because the official dev hard gate is not met. FixedSLM remains KEEP_SHADOW with zero production influence.",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--skip-tests", action="store_true")
    args = parser.parse_args()
    reports = BASE_DIR / "reports"
    reports.mkdir(parents=True, exist_ok=True)

    tests = (
        {
            "full": {"exit_code": -1, "failed_tests": []},
            "without_dev_gate": {"exit_code": -1, "failed_tests": []},
        }
        if args.skip_tests
        else {
            "full": _run_pytest([], reports / "pytest_release_full.log"),
            "without_dev_gate": _run_pytest(
                ["-k", "not test_dev_score_and_optional_fields"],
                reports / "pytest_release_without_dev_gate.log",
            ),
        }
    )
    dev, diagnostics = _dev()
    artifact = validate_current_artifacts(reproduce=True)
    fixed_slm = json.loads(
        (BASE_DIR / "manifest" / "fixed_slm_status.json").read_text(
            encoding="utf-8"
        )
    )
    dev_gate = _dev_gate(dev)
    specificity = _specificity_scan()
    harness_source = (BASE_DIR / "harness.py").read_text(encoding="utf-8")
    lifecycle = (
        harness_source.index("ConsistencyValidator.validate_or_warn")
        < harness_source.index("AtomicSessionCommitter.commit")
    )
    typed_semantic_promoted = (
        CandidateEvaluationEngine.production_active
        and "CandidateEvaluationEngine" in harness_source
    )
    only_known_failure = (
        tests["full"]["exit_code"] == 1
        and tests["full"]["failed_tests"] == [KNOWN_DEV_GATE]
    )
    checks = {
        "tests_without_dev_gate": tests["without_dev_gate"]["exit_code"] == 0,
        "only_known_full_test_failure": only_known_failure,
        "official_dev_hard_gate": dev_gate["passed"],
        "artifact_reproduction": bool(
            artifact.get("reproduction", {}).get("submission_byte_identical")
            and artifact.get("reproduction", {}).get("dev_metrics_identical")
        ),
        "task_specific_runtime_rules_absent": specificity["passed"],
        "validation_before_commit": lifecycle,
        "projection_pipeline_wired": "ProductionProjectionPipeline.compile"
        in harness_source,
        "typed_semantic_pipeline_promoted": typed_semantic_promoted,
        "fixed_slm_status_valid": fixed_slm["decision"]
        in {"PROMOTE", "KEEP_SHADOW", "REMOVE"}
        and (
            fixed_slm["decision"] == "PROMOTE"
            or fixed_slm["production_influence"] is False
        ),
    }
    released = all(checks.values())
    result = {
        "schema": "scpc.release-gate.v1",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "status": "PASS" if released else "RELEASE_BLOCKED",
        "production_release_allowed": released,
        "source_tree_sha256": artifact["source_tree_sha256"],
        "dev": dev,
        "dev_diagnostics": diagnostics,
        "dev_hard_gate": dev_gate,
        "artifact_validation": artifact,
        "fixed_slm": {
            "decision": fixed_slm["decision"],
            "production_influence": fixed_slm["production_influence"],
        },
        "specificity": specificity,
        "tests": tests,
        "checks": checks,
    }
    json_path = reports / "release_gate_report.json"
    md_path = reports / "release_gate_report.md"
    json_path.write_text(
        json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    md_path.write_text(_markdown(result), encoding="utf-8")
    publish_candidate_manifest(dev, BASE_DIR / "submission.csv")
    validate_current_artifacts(reproduce=True)
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if released else 1


if __name__ == "__main__":
    raise SystemExit(main())

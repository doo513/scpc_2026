# SCPC Dev Score Report

- Overall: `0.8186`
- Required-memory input visibility gaps: 3
- Tasks: 120
- Exact tasks: 15
- Non-exact tasks: 105

## Axes

| Axis | Score | Weight |
| --- | ---: | ---: |
| focal | 1.0000 | 0.18 |
| target | 0.9333 | 0.12 |
| control | 0.9583 | 0.18 |
| content_scope | 0.7419 | 0.17 |
| policy | 0.6845 | 0.13 |
| plan | 0.7723 | 0.18 |
| semantic_response | 0.0000 | 0.04 |
| counterfactual | 0.0000 | 0.00 |

## Control Confusion
- amend->amend: 25
- amend->ask: 3
- ask->ask: 24
- ask->hold: 2
- hold->hold: 20
- proceed->proceed: 46

## Scope Mode Confusion
- none->none: 21
- none->summary: 1
- raw->raw: 4
- redacted->none: 1
- redacted->raw: 1
- redacted->redacted: 19
- redacted->status_only: 1
- redacted->summary: 14
- status_only->status_only: 38
- status_only->summary: 2
- summary->none: 2
- summary->raw: 1
- summary->redacted: 2
- summary->summary: 13

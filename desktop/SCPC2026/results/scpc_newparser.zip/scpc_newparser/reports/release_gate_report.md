# Current Release Gate Report

- status: **RELEASE_BLOCKED**
- production release allowed: `False`
- source SHA-256: `600bf11e6fcdd97e06b19c1c29eb041cdb8a7b931ac9b6c094e13c2a38b71113`
- submission SHA-256: `bef9b996db7c883e26ea2c6bf595b4f4ea8597dd0f5b61913dc2d8ab87e241f0`
- official dev: `0.8186`
- exact/non-exact: `15/105`
- FixedSLM: `KEEP_SHADOW` (production influence `False`)

## Checks

- tests_without_dev_gate: `PASS`
- only_known_full_test_failure: `PASS`
- official_dev_hard_gate: `FAIL`
- artifact_reproduction: `PASS`
- task_specific_runtime_rules_absent: `PASS`
- validation_before_commit: `PASS`
- projection_pipeline_wired: `PASS`
- typed_semantic_pipeline_promoted: `FAIL`
- fixed_slm_status_valid: `PASS`

## Decision

Output projection, pure compilation, validation-before-commit, atomic single-answer commit, schema validation, and artifact reproduction are current. The typed semantic replacement is not promoted because the official dev hard gate is not met. FixedSLM remains KEEP_SHADOW with zero production influence.

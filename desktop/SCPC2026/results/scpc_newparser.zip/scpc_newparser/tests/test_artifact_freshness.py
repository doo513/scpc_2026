from __future__ import annotations

import copy
import json

from build_manifest import (
    FIXED_SLM_STATUS_PATH,
    MANIFEST_PRODUCER,
    manifest_content_fingerprint,
)


def test_manifest_fingerprint_uses_content_not_generation_time() -> None:
    first = {
        "schema": "scpc.artifact-manifest.v2",
        "producer": MANIFEST_PRODUCER,
        "generated_at": "2026-01-01T00:00:00Z",
        "submission_sha256": "a" * 64,
    }
    later = copy.deepcopy(first)
    later["generated_at"] = "2030-01-01T00:00:00Z"

    assert manifest_content_fingerprint(first) == manifest_content_fingerprint(later)

    later["submission_sha256"] = "b" * 64
    assert manifest_content_fingerprint(first) != manifest_content_fingerprint(later)


def test_fixed_slm_is_explicitly_shadow_only() -> None:
    status = json.loads(FIXED_SLM_STATUS_PATH.read_text(encoding="utf-8"))

    assert status["decision"] == "KEEP_SHADOW"
    assert status["production_influence"] is False

from __future__ import annotations

import hashlib
import json
import csv
from datetime import datetime, timezone
import os
from pathlib import Path
import tempfile
from typing import Any, Iterable

from utils.io import find_data_dir


BASE_DIR = Path(__file__).resolve().parent
MANIFEST_SCHEMA = "scpc.artifact-manifest.v2"
MANIFEST_PRODUCER = "build_manifest.publish_candidate_manifest"
FIXED_SLM_STATUS_PATH = BASE_DIR / "manifest" / "fixed_slm_status.json"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def source_tree_hash(paths: Iterable[Path]) -> str:
    digest = hashlib.sha256()
    for path in sorted(paths, key=lambda item: item.as_posix()):
        relative = path.relative_to(BASE_DIR).as_posix()
        digest.update(relative.encode("utf-8"))
        digest.update(path.read_bytes())
    return digest.hexdigest()


def external_tree_hash(root: Path, paths: Iterable[Path]) -> str:
    digest = hashlib.sha256()
    for path in sorted(paths, key=lambda item: item.as_posix()):
        digest.update(path.relative_to(root).as_posix().encode("utf-8"))
        digest.update(path.read_bytes())
    return digest.hexdigest()


def source_files() -> list[Path]:
    roots = [BASE_DIR / "core", BASE_DIR / "rules", BASE_DIR / "utils", BASE_DIR / "tests"]
    files = [path for root in roots for path in root.rglob("*.py")]
    files.extend((BASE_DIR / "tests" / "specs").rglob("*.json"))
    files.extend(BASE_DIR.glob("*.py"))
    files.extend(
        path
        for path in (
            BASE_DIR / "README.md",
            BASE_DIR / "requirements.txt",
            BASE_DIR / "submission_schema.json",
            BASE_DIR / ".gitignore",
        )
        if path.is_file()
    )
    return files


def _canonical_hash(value: Any) -> str:
    encoded = json.dumps(
        value,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def manifest_content_fingerprint(manifest: dict[str, Any]) -> str:
    stable = {
        key: value
        for key, value in manifest.items()
        if key not in {"generated_at", "content_fingerprint_sha256"}
    }
    return _canonical_hash(stable)


def official_archive_path() -> Path | None:
    candidates = (
        BASE_DIR / "SCPC2026_Final_data.zip",
        BASE_DIR.parent / "data" / "SCPC2026_Final_data.zip",
    )
    return next((path for path in candidates if path.is_file()), None)


def _fixed_slm_status() -> dict[str, Any]:
    if not FIXED_SLM_STATUS_PATH.is_file():
        raise FileNotFoundError(
            f"FixedSLM promotion decision missing: {FIXED_SLM_STATUS_PATH}"
        )
    status = json.loads(FIXED_SLM_STATUS_PATH.read_text(encoding="utf-8"))
    decision = status.get("decision")
    if decision not in {"PROMOTE", "KEEP_SHADOW", "REMOVE"}:
        raise ValueError("FixedSLM decision must be PROMOTE, KEEP_SHADOW, or REMOVE")
    if decision != "PROMOTE" and status.get("production_influence") is not False:
        raise ValueError("unpromoted FixedSLM must have zero production influence")
    return status


def _default_artifacts() -> tuple[Path, ...]:
    candidates = (
        BASE_DIR / "reports" / "dev_score_report.md",
        BASE_DIR / "reports" / "decision_trace.jsonl",
        BASE_DIR / "reports" / "consistency_report.md",
        BASE_DIR / "reports" / "screening_structural_report.md",
        BASE_DIR / "reports" / "diff_vs_baseline.md",
        BASE_DIR / "reports" / "error_cases.jsonl",
        BASE_DIR / "reports" / "stage3_fixed_slm_report.md",
        BASE_DIR / "reports" / "release_gate_report.json",
        BASE_DIR / "reports" / "release_gate_report.md",
    )
    return tuple(path for path in candidates if path.is_file())


def build_candidate_manifest_payload(
    dev_result: dict[str, Any],
    submission_path: Path,
    *,
    artifact_paths: Iterable[Path] | None = None,
) -> dict[str, Any]:
    data_dir = find_data_dir()
    data_files = {
        name: sha256_file(data_dir / name)
        for name in ("dev_tasks.jsonl", "dev_answers.json", "screening_tasks.jsonl")
    }
    csv.field_size_limit(20_000_000)
    with submission_path.open(encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle)
        next(reader)
        answer_count = len(json.loads(next(reader)[0]).get("answers", {}))
    fixed_slm = _fixed_slm_status()
    archive = official_archive_path()
    artifacts = tuple(artifact_paths) if artifact_paths is not None else _default_artifacts()
    artifact_hashes = {
        path.relative_to(BASE_DIR).as_posix(): sha256_file(path)
        for path in sorted(artifacts, key=lambda item: item.as_posix())
        if path.is_file() and path.is_relative_to(BASE_DIR)
    }
    manifest: dict[str, Any] = {
        "schema": MANIFEST_SCHEMA,
        "producer": MANIFEST_PRODUCER,
        "candidate": "scpc_newparser_authoritative_pipeline",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "source_tree_sha256": source_tree_hash(source_files()),
        "data_sha256": data_files,
        "official_archive_sha256": sha256_file(archive) if archive else None,
        "scorer": {
            "implementation": "local_score.py",
            "sha256": sha256_file(BASE_DIR / "local_score.py"),
            "official_notebook_rule": "strict-first-best-tie",
        },
        "submission_sha256": sha256_file(submission_path),
        "submission_answers": answer_count,
        "artifacts": artifact_hashes,
        "dev": dev_result,
        "fixed_slm": {
            "decision": fixed_slm["decision"],
            "production_influence": fixed_slm["production_influence"],
            "status_path": FIXED_SLM_STATUS_PATH.relative_to(BASE_DIR).as_posix(),
            "status_sha256": sha256_file(FIXED_SLM_STATUS_PATH),
        },
        "contract": {
            "schema": "scpc.final.answer.v1",
            "uses_external_api": False,
            "fixed_slm_policy": "local_fixed_slm_only",
        },
        "reproduction": {
            "submission": "python run_submission.py --output submission.csv",
            "report_bundle": "python generate_reports.py",
            "validation": "python validate_artifacts.py --reproduce",
        },
        "notes": [
            "screening distributions are diagnostic only",
            "semantic_response is not locally scoreable from public references",
            "official dev score includes every task without regression exclusions",
            "missing persistent memory values never trigger person- or task-specific target defaults",
            "generated_at is informational and is never freshness evidence",
        ],
    }
    manifest["content_fingerprint_sha256"] = manifest_content_fingerprint(manifest)
    return manifest


def publish_candidate_manifest(
    dev_result: dict[str, Any],
    submission_path: Path,
    *,
    output_path: Path | None = None,
    artifact_paths: Iterable[Path] | None = None,
) -> dict[str, Any]:
    """The sole candidate-manifest writer.

    Callers may request publication, but must not construct or write an
    independent candidate-manifest shape.
    """
    manifest = build_candidate_manifest_payload(
        dev_result,
        submission_path,
        artifact_paths=artifact_paths,
    )
    output = output_path or BASE_DIR / "manifest" / "candidate_manifest.json"
    output.parent.mkdir(parents=True, exist_ok=True)
    encoded = (
        json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    ).encode("utf-8")
    with tempfile.NamedTemporaryFile(
        dir=output.parent,
        prefix=f".{output.name}.",
        delete=False,
    ) as handle:
        handle.write(encoded)
        temporary = Path(handle.name)
    os.replace(temporary, output)
    return manifest


def build_manifest(dev_result: dict[str, Any], submission_path: Path) -> dict[str, Any]:
    """Compatibility entry point delegated to the sole publisher."""
    return publish_candidate_manifest(dev_result, submission_path)


def write_reference_manifest() -> dict[str, Any]:
    data_dir = find_data_dir()
    manifest = {
        "official_data": {
            name: sha256_file(data_dir / name)
            for name in ("dev_tasks.jsonl", "dev_answers.json", "screening_tasks.jsonl")
        },
        "baseline": {
            "name": "baseline_v5_compatible_actionprofile",
            "dev_overall": 0.9468,
            "focal": 1.0,
            "target": 1.0,
            "control": 1.0,
        },
    }
    baseline_root = (
        BASE_DIR.parent
        / "scpc_Gparser"
        / "baseline_v5_compatible_actionprofile"
    )
    if baseline_root.is_dir():
        baseline_files = [
            path
            for path in baseline_root.rglob("*.py")
            if "__pycache__" not in path.parts
        ]
        manifest["baseline"]["source_tree_sha256"] = external_tree_hash(
            baseline_root, baseline_files
        )
    archive = official_archive_path()
    if archive is not None:
        manifest["official_archive_sha256"] = sha256_file(archive)
    output = BASE_DIR / "manifest" / "reference_manifest.json"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return manifest

from __future__ import annotations

import argparse
import json
from pathlib import Path
import tempfile
from typing import Any

from build_manifest import (
    FIXED_SLM_STATUS_PATH,
    MANIFEST_PRODUCER,
    MANIFEST_SCHEMA,
    manifest_content_fingerprint,
    official_archive_path,
    sha256_file,
    source_files,
    source_tree_hash,
)
from utils.io import find_data_dir, load_jsonl
from validate_submission import find_schema_path, validate_submission


BASE_DIR = Path(__file__).resolve().parent


def validate_current_artifacts(
    submission_path: Path | None = None,
    manifest_path: Path | None = None,
    *,
    reproduce: bool = False,
) -> dict[str, Any]:
    submission_path = submission_path or BASE_DIR / "submission.csv"
    manifest_path = (
        manifest_path or BASE_DIR / "manifest" / "candidate_manifest.json"
    )
    if not submission_path.is_file():
        raise FileNotFoundError(f"submission missing: {submission_path}")
    if not manifest_path.is_file():
        raise FileNotFoundError(f"candidate manifest missing: {manifest_path}")

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("schema") != MANIFEST_SCHEMA:
        raise ValueError("candidate manifest schema is not authoritative v2")
    if manifest.get("producer") != MANIFEST_PRODUCER:
        raise ValueError("candidate manifest has a non-authoritative producer")
    expected_fingerprint = manifest_content_fingerprint(manifest)
    if manifest.get("content_fingerprint_sha256") != expected_fingerprint:
        raise ValueError("candidate manifest content fingerprint is stale")

    current_sources = source_files()
    current_source_hash = source_tree_hash(current_sources)
    manifest_source_hash = str(manifest.get("source_tree_sha256") or "")
    if current_source_hash != manifest_source_hash:
        raise ValueError("candidate manifest source hash is stale")

    submission_hash = sha256_file(submission_path)
    if submission_hash != manifest.get("submission_sha256"):
        raise ValueError("candidate manifest submission hash is stale")

    data_dir = find_data_dir()
    actual_data_hashes = {
        name: sha256_file(data_dir / name)
        for name in ("dev_tasks.jsonl", "dev_answers.json", "screening_tasks.jsonl")
    }
    if manifest.get("data_sha256") != actual_data_hashes:
        raise ValueError("candidate manifest official-data hash is stale")

    scorer = manifest.get("scorer") or {}
    if scorer.get("sha256") != sha256_file(BASE_DIR / "local_score.py"):
        raise ValueError("candidate manifest scorer hash is stale")

    archive = official_archive_path()
    actual_archive_hash = sha256_file(archive) if archive is not None else None
    if manifest.get("official_archive_sha256") != actual_archive_hash:
        raise ValueError("candidate manifest official-archive hash is stale")

    fixed_slm = manifest.get("fixed_slm") or {}
    fixed_status = json.loads(FIXED_SLM_STATUS_PATH.read_text(encoding="utf-8"))
    if fixed_slm.get("status_sha256") != sha256_file(FIXED_SLM_STATUS_PATH):
        raise ValueError("candidate manifest FixedSLM status hash is stale")
    if fixed_slm.get("decision") != fixed_status.get("decision"):
        raise ValueError("candidate manifest FixedSLM decision is stale")
    if fixed_slm.get("production_influence") != fixed_status.get(
        "production_influence"
    ):
        raise ValueError("candidate manifest FixedSLM influence is stale")
    if (
        fixed_status.get("decision") != "PROMOTE"
        and fixed_status.get("production_influence") is not False
    ):
        raise ValueError("unpromoted FixedSLM influences production evidence")

    for relative, expected_hash in (manifest.get("artifacts") or {}).items():
        artifact = (BASE_DIR / relative).resolve()
        if not artifact.is_relative_to(BASE_DIR.resolve()):
            raise ValueError(f"manifest artifact escapes workspace: {relative}")
        if not artifact.is_file():
            raise FileNotFoundError(f"manifest artifact missing: {artifact}")
        if sha256_file(artifact) != expected_hash:
            raise ValueError(f"manifest artifact content is stale: {relative}")

    official_schema = find_schema_path(data_dir)
    local_schema = BASE_DIR / "submission_schema.json"
    if not official_schema.is_file():
        raise FileNotFoundError(f"official schema missing: {official_schema}")
    if sha256_file(official_schema) != sha256_file(local_schema):
        raise ValueError("local submission schema differs from official schema")

    payload = validate_submission(submission_path)
    result: dict[str, Any] = {
        "answers": len(payload.get("answers") or {}),
        "source_tree_sha256": current_source_hash,
        "submission_sha256": submission_hash,
        "official_schema_sha256": sha256_file(official_schema),
        "manifest_content_fingerprint_sha256": expected_fingerprint,
        "data_sha256": actual_data_hashes,
        "scorer_sha256": scorer["sha256"],
        "fixed_slm_decision": fixed_status["decision"],
        "timestamp_used_for_freshness": False,
    }
    if reproduce:
        result["reproduction"] = reproduce_current_artifacts(
            submission_path,
            manifest,
        )
    return result


def reproduce_current_artifacts(
    submission_path: Path,
    manifest: dict[str, Any],
) -> dict[str, Any]:
    """Regenerate submission and dev metrics without overwriting workspace artifacts."""
    from local_score import evaluate_dev_payload
    from run_submission import run_tasks, write_submission

    data_dir = find_data_dir()
    screening_tasks = load_jsonl(data_dir / "screening_tasks.jsonl")
    dev_tasks = load_jsonl(data_dir / "dev_tasks.jsonl")
    references = json.loads(
        (data_dir / "dev_answers.json").read_text(encoding="utf-8")
    )
    with tempfile.TemporaryDirectory(prefix="scpc-artifact-reproduction-") as directory:
        regenerated = Path(directory) / "submission.csv"
        write_submission(run_tasks(screening_tasks), regenerated)
        regenerated_hash = sha256_file(regenerated)
    dev, _diagnostics = evaluate_dev_payload(run_tasks(dev_tasks), references)
    submission_match = regenerated_hash == sha256_file(submission_path)
    dev_match = dev == manifest.get("dev")
    if not submission_match:
        raise ValueError("isolated submission regeneration differs from manifest artifact")
    if not dev_match:
        raise ValueError("isolated dev regeneration differs from manifest metrics")
    return {
        "submission_sha256": regenerated_hash,
        "submission_byte_identical": submission_match,
        "dev_metrics_identical": dev_match,
        "dev_overall": dev["overall"],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--submission", type=Path, default=BASE_DIR / "submission.csv"
    )
    parser.add_argument(
        "--manifest",
        type=Path,
        default=BASE_DIR / "manifest" / "candidate_manifest.json",
    )
    parser.add_argument(
        "--reproduce",
        action="store_true",
        help="regenerate submission and dev metrics in isolation and compare content",
    )
    args = parser.parse_args()
    result = validate_current_artifacts(
        args.submission,
        args.manifest,
        reproduce=args.reproduce,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()

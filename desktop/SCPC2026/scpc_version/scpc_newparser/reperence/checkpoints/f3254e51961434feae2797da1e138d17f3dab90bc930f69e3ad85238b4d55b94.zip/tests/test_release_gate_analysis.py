from __future__ import annotations

from release_gate import _harness_static_analysis, _specificity_hits_for_source


VALID_HARNESS = """
class FinalHarness:
    def answer_task(self, task, session):
        projection = ProductionProjectionPipeline.compile(task)
        ConsistencyValidator.validate_or_warn(projection, task, {}, {})
        if task:
            AtomicSessionCommitter.commit(session, None)
"""


def test_ast_gate_confirms_reachable_projection_validation_commit_order() -> None:
    result = _harness_static_analysis(VALID_HARNESS)

    assert result["projection_pipeline_wired"] is True
    assert result["validation_before_commit"] is True
    assert result["scanner"] == "reachable_python_ast_calls"


def test_comments_and_unreachable_calls_cannot_satisfy_lifecycle_gate() -> None:
    source = """
class FinalHarness:
    def answer_task(self, task, session):
        # ConsistencyValidator.validate_or_warn(...)
        if False:
            ConsistencyValidator.validate_or_warn(None, None, None, None)
        AtomicSessionCommitter.commit(session, None)
"""

    result = _harness_static_analysis(source)

    assert result["validation_before_commit"] is False
    assert result["projection_pipeline_wired"] is False


def test_specificity_ast_ignores_comments_but_detects_runtime_literals() -> None:
    comment_only = "# final_dev_fake must not count\nvalue = 'safe'\n"
    runtime_literal = "value = 'final_dev_forbidden'\n"

    assert _specificity_hits_for_source(comment_only, path="comment.py") == []
    hits = _specificity_hits_for_source(runtime_literal, path="runtime.py")
    assert hits == [
        {"path": "runtime.py", "line": 1, "marker": "final_dev_"}
    ]

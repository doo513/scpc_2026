from __future__ import annotations

import argparse
import ast
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import subprocess
import sys
from typing import Any

from build_manifest import (
    promote_validated_candidate_manifest,
    publish_candidate_manifest,
)
from core.candidate_evaluation import CandidateEvaluationEngine
from local_score import evaluate_dev_payload
from official_scorer import evaluate_current_scorer_parity
from run_submission import run_tasks
from utils.io import find_data_dir, load_jsonl
from validate_artifacts import validate_current_artifacts


BASE_DIR = Path(__file__).resolve().parent
KNOWN_DEV_GATE = "tests/test_regression.py::test_dev_score_and_optional_fields"
PROHIBITED_SPECIFICITY_MARKERS = (
    "final_dev_",
    "final_screening_",
    "dev_answers",
    "screening_results",
)


def _run_pytest(arguments: list[str], log_path: Path) -> dict[str, Any]:
    completed = subprocess.run(
        [sys.executable, "-m", "pytest", "-q", *arguments],
        cwd=BASE_DIR,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    log_path.write_text(completed.stdout, encoding="utf-8")
    failed = sorted(set(re.findall(r"FAILED ([^\s]+)", completed.stdout)))
    return {"exit_code": completed.returncode, "failed_tests": failed}


def _dev() -> tuple[dict[str, Any], dict[str, Any]]:
    data_dir = find_data_dir()
    references = json.loads(
        (data_dir / "dev_answers.json").read_text(encoding="utf-8")
    )
    return evaluate_dev_payload(
        run_tasks(load_jsonl(data_dir / "dev_tasks.jsonl")),
        references,
    )


def _dev_gate(dev: dict[str, Any]) -> dict[str, Any]:
    spec = json.loads(
        (BASE_DIR / "tests" / "specs" / "generalization_v1.json").read_text(
            encoding="utf-8"
        )
    )["dev_hard_gate"]
    checks = {
        "overall": dev["overall"] >= spec["minimum_overall"],
        **{
            f"axis.{axis}": dev["axes"][axis] >= floor
            for axis, floor in spec["minimum_axes"].items()
        },
        "non_exact": dev["non_exact_count"] <= spec["maximum_non_exact_tasks"],
    }
    return {"passed": all(checks.values()), "checks": checks, "contract": spec}


def _specificity_hits_for_source(
    source: str,
    *,
    path: str,
) -> list[dict[str, Any]]:
    tree = ast.parse(source, filename=path)
    hits: list[dict[str, Any]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Constant) or not isinstance(
            node.value, str
        ):
            continue
        for marker in PROHIBITED_SPECIFICITY_MARKERS:
            if marker in node.value:
                hits.append(
                    {
                        "path": path,
                        "line": node.lineno,
                        "marker": marker,
                    }
                )
    return hits


def _specificity_scan() -> dict[str, Any]:
    paths = tuple(sorted((BASE_DIR / "core").glob("*.py"))) + tuple(
        sorted((BASE_DIR / "rules").glob("*.py"))
    ) + (BASE_DIR / "harness.py",)
    hits: list[dict[str, Any]] = []
    for path in paths:
        hits.extend(
            _specificity_hits_for_source(
                path.read_text(encoding="utf-8"),
                path=path.relative_to(BASE_DIR).as_posix(),
            )
        )
    return {
        "passed": not hits,
        "prohibited_markers": sorted(
            {str(hit["marker"]) for hit in hits}
        ),
        "hits": hits,
        "scanner": "python_ast_string_constants",
    }


def _call_name(node: ast.AST) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        prefix = _call_name(node.value)
        return f"{prefix}.{node.attr}" if prefix else node.attr
    return ""


class _ReachableCallVisitor(ast.NodeVisitor):
    def __init__(self, root: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        self.root = root
        self.calls: list[tuple[str, int]] = []

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        if node is self.root:
            for statement in node.body:
                self.visit(statement)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        if node is self.root:
            for statement in node.body:
                self.visit(statement)

    def visit_Lambda(self, _node: ast.Lambda) -> None:
        return

    def visit_If(self, node: ast.If) -> None:
        if isinstance(node.test, ast.Constant):
            branch = node.body if bool(node.test.value) else node.orelse
            for statement in branch:
                self.visit(statement)
            return
        self.visit(node.test)
        for statement in (*node.body, *node.orelse):
            self.visit(statement)

    def visit_Call(self, node: ast.Call) -> None:
        self.calls.append((_call_name(node.func), node.lineno))
        self.generic_visit(node)


def _harness_static_analysis(source: str) -> dict[str, Any]:
    tree = ast.parse(source, filename="harness.py")
    harness_class = next(
        (
            node
            for node in tree.body
            if isinstance(node, ast.ClassDef) and node.name == "FinalHarness"
        ),
        None,
    )
    answer_task = next(
        (
            node
            for node in (harness_class.body if harness_class else [])
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
            and node.name == "answer_task"
        ),
        None,
    )
    if answer_task is None:
        return {
            "validation_before_commit": False,
            "projection_pipeline_wired": False,
            "candidate_engine_called": False,
            "recognized_calls": [],
        }
    visitor = _ReachableCallVisitor(answer_task)
    visitor.visit(answer_task)
    recognized = {
        name: min(line for call, line in visitor.calls if call == name)
        for name in (
            "ProductionProjectionPipeline.compile",
            "ConsistencyValidator.validate_or_warn",
            "AtomicSessionCommitter.commit",
        )
        if any(call == name for call, _line in visitor.calls)
    }
    validation_line = recognized.get("ConsistencyValidator.validate_or_warn")
    commit_line = recognized.get("AtomicSessionCommitter.commit")
    projection_line = recognized.get("ProductionProjectionPipeline.compile")
    return {
        "validation_before_commit": bool(
            validation_line and commit_line and validation_line < commit_line
        ),
        "projection_pipeline_wired": bool(
            projection_line
            and validation_line
            and projection_line < validation_line
        ),
        "candidate_engine_called": any(
            name.startswith("CandidateEvaluationEngine.")
            for name, _line in visitor.calls
        ),
        "recognized_calls": [
            {"call": name, "line": line}
            for name, line in sorted(
                recognized.items(), key=lambda item: item[1]
            )
        ],
        "scanner": "reachable_python_ast_calls",
    }


def _markdown(result: dict[str, Any]) -> str:
    dev = result["dev"]
    lines = [
        "# Current Release Gate Report",
        "",
        f"- status: **{result['status']}**",
        f"- production release allowed: `{result['production_release_allowed']}`",
        f"- source SHA-256: `{result['source_tree_sha256']}`",
        f"- submission SHA-256: `{result['artifact_validation']['submission_sha256']}`",
        f"- official dev: `{dev['overall']:.4f}`",
        f"- exact/non-exact: `{dev['exact_match_count']}/{dev['non_exact_count']}`",
        f"- FixedSLM: `{result['fixed_slm']['decision']}` (production influence `{result['fixed_slm']['production_influence']}`)",
        "",
        "## Checks",
        "",
    ]
    lines.extend(
        f"- {name}: `{'PASS' if passed else 'FAIL'}`"
        for name, passed in result["checks"].items()
    )
    lines.extend(
        [
            "",
            "## Decision",
            "",
            "Output projection, pure compilation, validation-before-commit, atomic single-answer commit, schema validation, and artifact reproduction are current. The typed semantic replacement is not promoted because the official dev hard gate is not met. FixedSLM remains KEEP_SHADOW with zero production influence.",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--skip-tests", action="store_true")
    parser.add_argument(
        "--reproduction-child",
        action="store_true",
        help="disable recursive report reproduction in an isolated child workspace",
    )
    args = parser.parse_args()
    reports = BASE_DIR / "reports"
    reports.mkdir(parents=True, exist_ok=True)

    tests = (
        {
            "full": {"exit_code": -1, "failed_tests": []},
            "without_dev_gate": {"exit_code": -1, "failed_tests": []},
        }
        if args.skip_tests
        else {
            "full": _run_pytest([], reports / "pytest_release_full.log"),
            "without_dev_gate": _run_pytest(
                ["-k", "not test_dev_score_and_optional_fields"],
                reports / "pytest_release_without_dev_gate.log",
            ),
        }
    )
    dev, diagnostics = _dev()
    preflight_manifest = (
        BASE_DIR / "manifest" / ".candidate_manifest.preflight.json"
    )
    try:
        publish_candidate_manifest(
            dev,
            BASE_DIR / "submission.csv",
            output_path=preflight_manifest,
        )
        artifact = validate_current_artifacts(
            manifest_path=preflight_manifest,
            reproduce=True,
            reproduce_reports=False,
            require_complete_reports=False,
        )
    finally:
        preflight_manifest.unlink(missing_ok=True)
    artifact.pop("manifest_content_fingerprint_sha256", None)
    fixed_slm = json.loads(
        (BASE_DIR / "manifest" / "fixed_slm_status.json").read_text(
            encoding="utf-8"
        )
    )
    dev_gate = _dev_gate(dev)
    scorer_parity = evaluate_current_scorer_parity()
    specificity = _specificity_scan()
    harness_source = (BASE_DIR / "harness.py").read_text(encoding="utf-8")
    static_analysis = _harness_static_analysis(harness_source)
    typed_semantic_promoted = (
        CandidateEvaluationEngine.production_active
        and static_analysis["candidate_engine_called"]
    )
    only_known_failure = (
        tests["full"]["exit_code"] == 1
        and tests["full"]["failed_tests"] == [KNOWN_DEV_GATE]
    )
    checks = {
        "tests_without_dev_gate": tests["without_dev_gate"]["exit_code"] == 0,
        "only_known_full_test_failure": only_known_failure,
        "official_dev_hard_gate": dev_gate["passed"],
        "official_scorer_parity": scorer_parity["identical"],
        "artifact_reproduction": bool(
            artifact.get("reproduction", {}).get("submission_byte_identical")
            and artifact.get("reproduction", {}).get("dev_metrics_identical")
        ),
        "task_specific_runtime_rules_absent": specificity["passed"],
        "validation_before_commit": static_analysis[
            "validation_before_commit"
        ],
        "projection_pipeline_wired": static_analysis[
            "projection_pipeline_wired"
        ],
        "typed_semantic_pipeline_promoted": typed_semantic_promoted,
        "fixed_slm_status_valid": fixed_slm["decision"]
        in {"PROMOTE", "KEEP_SHADOW", "REMOVE"}
        and (
            fixed_slm["decision"] == "PROMOTE"
            or fixed_slm["production_influence"] is False
        ),
    }
    released = all(checks.values())
    result = {
        "schema": "scpc.release-gate.v1",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "status": "PASS" if released else "RELEASE_BLOCKED",
        "production_release_allowed": released,
        "source_tree_sha256": artifact["source_tree_sha256"],
        "dev": dev,
        "dev_diagnostics": diagnostics,
        "dev_hard_gate": dev_gate,
        "official_scorer_parity": scorer_parity,
        "artifact_validation": artifact,
        "fixed_slm": {
            "decision": fixed_slm["decision"],
            "production_influence": fixed_slm["production_influence"],
        },
        "specificity": specificity,
        "static_analysis": static_analysis,
        "tests": tests,
        "checks": checks,
    }
    json_path = reports / "release_gate_report.json"
    md_path = reports / "release_gate_report.md"
    json_path.write_text(
        json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    md_path.write_text(_markdown(result), encoding="utf-8")
    staged_manifest = (
        BASE_DIR / "manifest" / ".candidate_manifest.release.pending.json"
    )
    try:
        publish_candidate_manifest(
            dev,
            BASE_DIR / "submission.csv",
            output_path=staged_manifest,
        )
        validation = validate_current_artifacts(
            manifest_path=staged_manifest,
            reproduce=not args.reproduction_child,
            reproduce_reports=not args.reproduction_child,
        )
        promote_validated_candidate_manifest(staged_manifest, validation)
    finally:
        staged_manifest.unlink(missing_ok=True)
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if released else 1


if __name__ == "__main__":
    raise SystemExit(main())

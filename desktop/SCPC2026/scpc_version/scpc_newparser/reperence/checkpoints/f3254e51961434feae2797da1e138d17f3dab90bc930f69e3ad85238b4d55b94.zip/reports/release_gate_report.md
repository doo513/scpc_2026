# Current Release Gate Report

- status: **RELEASE_BLOCKED**
- production release allowed: `False`
- source SHA-256: `f3254e51961434feae2797da1e138d17f3dab90bc930f69e3ad85238b4d55b94`
- submission SHA-256: `9d3f2c280b752c3acb26aea3a56f8ea8e4a48fcd4d03333bcee9a56a39f269a2`
- official dev: `0.8417`
- exact/non-exact: `15/105`
- FixedSLM: `KEEP_SHADOW` (production influence `False`)

## Checks

- tests_without_dev_gate: `PASS`
- only_known_full_test_failure: `PASS`
- official_dev_hard_gate: `FAIL`
- official_scorer_parity: `PASS`
- artifact_reproduction: `PASS`
- task_specific_runtime_rules_absent: `PASS`
- validation_before_commit: `PASS`
- projection_pipeline_wired: `PASS`
- typed_semantic_pipeline_promoted: `FAIL`
- fixed_slm_status_valid: `PASS`

## Decision

Output projection, pure compilation, validation-before-commit, atomic single-answer commit, schema validation, and artifact reproduction are current. The typed semantic replacement is not promoted because the official dev hard gate is not met. FixedSLM remains KEEP_SHADOW with zero production influence.

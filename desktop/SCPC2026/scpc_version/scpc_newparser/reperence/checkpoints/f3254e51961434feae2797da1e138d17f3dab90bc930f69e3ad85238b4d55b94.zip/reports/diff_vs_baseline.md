# Comparison: scpc_newparser/submission.csv vs official_notebook_baseline/submission.csv

## Changed Counts
- **focal changed count**: 497
- **target changed count**: 355
- **control changed count**: 482
- **scope mode changed count**: 512
- **policy confirmation changed count**: 334
- **plan sequence changed count**: 637

## Major Transitions (Control)
- `ask -> proceed`: 166
- `ask -> amend`: 146
- `ask -> hold`: 88
- `amend -> hold`: 42
- `amend -> proceed`: 21
- `proceed -> amend`: 5
- `proceed -> ask`: 5
- `amend -> ask`: 4
- `proceed -> hold`: 3
- `hold -> proceed`: 2
